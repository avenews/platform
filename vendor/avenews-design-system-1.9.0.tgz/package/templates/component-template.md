# {{Component Name}}

## Purpose

What the component does and why it exists. One to two sentences.

If there is a similar component that could be confused with this one, note the distinction here:
> Not to be confused with [Other Component] — [brief differentiator].

## Variants

| Variant / Prop value | Appearance | Use for |
|---|---|---|
| `value` | Visual description | When to use this variant |

## States

- **Default** — resting appearance
- **Focused** — (if applicable)
- **Filled / Active** — (if applicable)
- **Disabled** — reduced opacity, not interactive
- **Loading** — skeleton or spinner; use while async data is pending
- **Error** — (if applicable) — danger-coloured indicator + error message

## Structure

```
ComponentName (ionic-host or div)
├── Slot A (optional description)
├── Primary content
└── Slot B (optional description)
```

- Token references for key values (radius, shadow, background, border)

## Behaviour

### Interaction
- How the component responds to tap/click
- Any state transitions triggered by user interaction

### State transitions
1. **State A → State B**: trigger + what changes visually
2. **Loading → Default**: when data resolves
3. **Default → Error**: when validation fails

### Async pattern (if applicable)
```
User action → loading={true} → async operation
→ success: loading={false}, update UI
→ error:   loading={false}, show error
```

## Rules

**When to use**
- Appropriate contexts and use cases

**When NOT to use**
- Inappropriate contexts
- Alternative component to use instead

**Constraints**
- Hard limits (max items, required props, forbidden combinations)

**Alternatives**
- [Alternative component] for [different use case] — see `components/alternative.md`

## Content Guidelines

- Label / text guidance: length, case, tone
- Placeholder / helper text guidance
- Error message guidance: be specific, not vague

## Ionic Mapping

**`<IonComponentName>`** (or "Avenews-specific — no Ionic equivalent")

The Avenews [ComponentName] wraps `ion-component-name`. [Brief note on what Ionic props are/are not passed.]

```tsx
// Rendered DOM structure
<ion-component class="avenews-component avenews-component--variant">
  ...
</ion-component>
```

Key component props: `prop` (type — description), ...

Key CSS classes: `.avenews-component`, `.avenews-component--{variant}`, ...

Docs: https://ionicframework.com/docs/api/[component]

## Notes

- Token references for font, spacing, or colour values (see `tokens/typography.md`, `tokens/colour.md`)
- Edge cases, platform-specific behaviour, or known limitations
- Cross-references to related patterns or components
