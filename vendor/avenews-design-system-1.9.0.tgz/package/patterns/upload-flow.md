# Upload Flow Pattern

## Purpose

The end-to-end UX pattern for collecting required documents from a user. Covers the complete lifecycle: listing required documents, selecting and uploading individual files, showing upload progress, handling errors, and confirming completion. Applies to any multi-document upload requirement in the Avenews application flow.

---

## Flow States

```
Required documents list
  ↓
[User taps "Upload" on a specific document]
  ↓
File picker → file selected
  ↓
Upload in progress
  ├── Success → Document row updates to "Uploaded"
  └── Error → Inline Banner (danger) + retry
  ↓
[All required documents uploaded]
  ↓
Continue / Submit enabled
```

---

## Screen Structure

### Document List Screen

```
IonPage
├── IonHeader
│   └── IonToolbar → IonTitle ("Your Documents") + back button
├── IonContent
│   ├── Inline Banner (info — optional, if re-applying)
│   ├── SectionHeader ("REQUIRED DOCUMENTS")
│   ├── IonList
│   │   ├── DocumentRow [ID Document] — status: "required" | "uploading" | "uploaded" | "rejected"
│   │   ├── DocumentRow [Proof of Address] — status variant
│   │   └── DocumentRow [Bank Statement] — status variant
│   └── SectionHeader ("OPTIONAL DOCUMENTS") — if applicable
│       └── DocumentRow [Additional Documents]
└── IonFooter → Action Bar
    └── Button "Continue" — disabled until all required docs uploaded
```

### Document Row States (within the list)

| Document status | DocumentRow appearance | Available action |
|---|---|---|
| `required` | Label + "Required" badge (neutral) | "Upload" button (outline) |
| `uploading` | Label + progress bar + filename | "Cancel" link |
| `uploaded` | Label + "Uploaded" badge (success) | "Replace" text link |
| `rejected` | Label + "Rejected" badge (danger) | "Re-upload" button (outline) |

---

## Individual Upload Flow

When the user taps "Upload" on a DocumentRow:

1. `<input type="file">` opens (or Capacitor FilePicker on native)
2. User selects file
3. Client validates:
   - File type: must be in accepted list (PDF, JPG, PNG)
   - File size: must be under 10 MB
   - If invalid: show `Inline Banner` (danger) and return to step 1
4. DocumentRow transitions to `uploading` state:
   - Progress bar (IonProgressBar, determinate) shows upload %
   - Filename displayed
   - Cancel option available
5. Upload completes:
   - **Success**: DocumentRow transitions to `uploaded`; check if all required docs are uploaded; if yes, enable "Continue" button
   - **Error**: DocumentRow transitions back to `required`; `Inline Banner` (danger) shown above the DocumentRow with error message + retry CTA

---

## Code Pattern

```tsx
type DocStatus = 'required' | 'uploading' | 'uploaded' | 'rejected';

interface DocumentState {
  id: string;
  label: string;
  required: boolean;
  status: DocStatus;
  progress?: number;
  filename?: string;
  error?: string;
}

// Document list state
const [docs, setDocs] = useState<DocumentState[]>([
  { id: 'id-document', label: 'ID Document', required: true, status: 'required' },
  { id: 'proof-address', label: 'Proof of Address', required: true, status: 'required' },
  { id: 'bank-statement', label: 'Bank Statement', required: true, status: 'required' },
]);

// All required documents uploaded check
const allRequiredUploaded = docs
  .filter(d => d.required)
  .every(d => d.status === 'uploaded');

function handleUpload(docId: string, file: File) {
  // Validate
  if (!['application/pdf', 'image/jpeg', 'image/png'].includes(file.type)) {
    setDocError(docId, 'This file type is not supported. Please upload a PDF, JPG, or PNG.');
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    setDocError(docId, 'This file is too large. Maximum size is 10 MB.');
    return;
  }

  // Set uploading state
  setDocStatus(docId, 'uploading', { filename: file.name, progress: 0 });

  // Upload
  uploadDocumentAPI(docId, file, (progress) => {
    updateDocProgress(docId, progress);
  })
    .then(() => setDocStatus(docId, 'uploaded'))
    .catch((err) => setDocError(docId, getUploadErrorMessage(err)));
}

function getUploadErrorMessage(err: unknown): string {
  if (err instanceof NetworkError) return 'Upload failed. Please check your connection and try again.';
  if (err instanceof FileSizeError) return 'This file could not be processed. Please try a different file.';
  return 'Your document could not be uploaded. Please try again.';
}
```

---

## Completion Logic

The "Continue" button in the Action Bar is controlled by `allRequiredUploaded`:

```tsx
<IonFooter>
  <IonToolbar>
    <div className="avenews-action-bar">
      <Button
        label="Continue"
        expand="block"
        disabled={!allRequiredUploaded}
        onClick={proceedToNextStep}
      />
      {!allRequiredUploaded && (
        <p className="avenews-action-bar__note">
          Upload all required documents to continue.
        </p>
      )}
    </div>
  </IonToolbar>
</IonFooter>
```

---

## Edge Cases

### Re-application (user has applied before)
- Show `Inline Banner` (info) at the top of the document list:
  > "We noticed you've applied before. Please upload your documents again so we can review your current application."
- Previous uploads may be pre-populated in `uploaded` state if they are still valid

### Rejected documents
- Show `Inline Banner` (danger) above the rejected DocumentRow:
  > "Your [Document Type] was rejected. Please upload a valid copy to continue."
- DocumentRow status = `rejected` (danger badge)
- "Re-upload" button triggers the same file picker flow
- On successful re-upload, Inline Banner is removed

### Network error during upload
- Do not leave the DocumentRow in `uploading` state indefinitely
- Use a timeout (30 seconds) — if no response, transition to error state
- Error message: "Upload timed out. Please check your connection and try again."

### Cancelled upload
- Return DocumentRow to previous state (`required` or `rejected`)
- No error banner shown — cancellation is intentional

---

## Content Guidelines

- Document labels: clear category names — "ID Document", "Proof of Address", "Bank Statement" — not filenames
- Upload button: "Upload [document]" (specific) or "Upload" (when label is already visible)
- Progress text: show the actual filename — "Uploading bank_statement.pdf…"
- Error messages: always actionable — state the problem and what to do
- Completion message: do not show a separate success screen for individual document uploads; let the "Continue" button becoming active communicate readiness

---

## Cross-references

- `components/document-row.md` — the individual row component
- `components/file-upload.md` — the upload trigger and progress pattern
- `components/inline-banner.md` — error and info banners
- `components/action-bar.md` — the fixed-bottom Continue button
- `components/progress-tracker.md` — step indicator for multi-step flows
- `patterns/error-handling.md` — error category decision table
