# Apply Flow V2 — Design System Refactor Audit

Source: `app/apply/page.tsx`
Design system reference: `tokens/colour.md`, `tokens/typography.md`, `components/*`

---

## 1. Refactored UI Structure (Screen by Screen)

Each screen below lists:
- The Ionic page structure
- Every UI element with the DS component, props, and token used
- Interaction logic that must be implemented

---

### Screen 1 — Landing

**Purpose**: Introduce the product and start the application.

**Flow entry**: User taps "Apply" tab or home CTA.

```
IonPage
└── IonContent
    ├── Hero surface (--av-color-surface-dark)
    │   ├── Eyebrow label         → <p> typeStyles.labelXs, SemiBold, --av-aqua-300
    │   ├── H2 Heading            → <h2> typeStyles.h2 (Plus Jakarta Sans 28px Bold, white)
    │   ├── Subheading            → <p> typeStyles.bodySm (13px Regular, --av-aqua-200)
    │   └── Pill strip            → 3× <Chip variant="outline" label="...">
    │                               Note: on dark surface — inverted chip style required
    │
    ├── "How it works" surface (--av-color-surface)
    │   ├── Section label         → <SectionLabel> (10px SemiBold, --av-color-text-muted)
    │   └── 3-column card row     → 3× <Card layout="default" title="..." body="...">
    │                               (static, tappable={false})
    │
    ├── Finance selector surface (--av-color-surface)
    │   ├── Question label        → <p> 13px SemiBold, --av-color-text
    │   └── 3× Finance tile       → [MISSING: FinanceTile component — §4]
    │
    ├── Eligibility checklist (--av-color-surface)
    │   ├── Sub-heading           → <h3> typeStyles.h3 (Plus Jakarta Sans 22px Bold)
    │   ├── 6× Eligibility row    → [MISSING: EligibilityRow component — §4]
    │   └── Confirm checkbox      → [MISSING: ConfirmCheckbox component — §4]
    │
    ├── Primary CTA               → <Button variant="primary" size="lg" expand="block" label="Start application">
    ├── Sub-note                  → <p> typeStyles.labelXs, Medium, --av-color-text-muted
    ├── Contact link              → <Button variant="ghost" size="sm" label="Contact us">
    │
    ├── Trust bar (--av-color-surface-subtle)
    └── Testimonial               → <Card layout="default" subtitle="..." title="..." body="...">
```

**Interaction**:
- Finance tile selection updates the selected amount in state
- "Start application" CTA is disabled until eligibility checkbox is confirmed
- CTA navigates to Screen 2

---

### Screen 2 — About You (Step 1)

**Purpose**: Collect basic personal info and verify phone number via OTP.

**Progress**: `completedUpTo={0}`, `activeSteps={[1]}`, `stepDisplay="Step 1 of 3"`

```
IonPage
├── IonHeader (sticky)
│   ├── IonToolbar
│   │   ├── IonButtons slot="start" → <Button variant="ghost" size="sm" label="← Back">
│   │   └── IonTitle               → Wordmark (typeStyles.h5, SemiBold)
│   ├── <StepIndicator
│   │     currentScreen={1}
│   │     stepDisplay="Step 1 of 3"
│   │     label="About You"
│   │     activeSteps={[1]}
│   │     completedUpTo={0} />
│   └── <ProgressTracker value={0.33} />   [IonProgressBar]
│
└── IonContent className="ion-padding"
    ├── <h2> typeStyles.h2 (Plus Jakarta Sans Bold)
    ├── <p>  typeStyles.bodySm (13px Regular, --av-color-text-subtle)
    ├── Divider (1px, --av-color-neutral-divider)
    │
    ├── IonList
    │   ├── <Input label="First Name" placeholder="Enter your first name" required labelPlacement="stacked">
    │   ├── <Input label="Last Name" placeholder="Enter your last name" required labelPlacement="stacked">
    │   └── Phone verification group
    │       ├── <Input label="Phone number" type="tel" placeholder="+254 7XX XXX XXX" required>
    │       ├── <Button variant="outline" expand="block" label="Send verification code">
    │       │    ↳ disabled until phone field has a valid value
    │       ├── [OTPInput — MISSING: §4]
    │       │   ├── 6× digit tiles
    │       │   ├── Countdown "Resend in 0:45"
    │       │   └── <Button variant="ghost" size="sm" label="Resend code">
    │       └── Verified state → [InlineBanner variant="success" message="Phone verified"]
    │
    ├── Divider
    ├── [TermsCheckbox — MISSING: §4]
    ├── <Button variant="primary" size="lg" expand="block" label="Continue">
    │    ↳ disabled until: first name, last name, phone verified, T&C checked
    └── Security note → <p> 🔒 typeStyles.labelXs, Regular, --av-color-text-muted
```

**Interaction**:
- Phone field validates E.164 format on blur
- "Send verification code" button fires OTP request; enters loading state during request
- OTP entry auto-advances focus on each digit input
- OTP validates on 6th digit entered; on success → InlineBanner "verified" appears
- "Continue" is disabled until all required fields are valid and phone is verified
- On "Continue": navigate to Screen 3; mark step 1 complete in state

---

### Screen 3 — Your Business (Step 2)

**Purpose**: Collect business type, financial profile, and eligibility data.

**Progress**: `completedUpTo={1}`, `activeSteps={[2]}`, `stepDisplay="Step 2 of 3"`

```
IonPage
├── IonHeader (sticky)
│   ├── IonToolbar → Back button + Wordmark
│   ├── <StepIndicator currentScreen={2} stepDisplay="Step 2 of 3" label="Your Business" ... />
│   └── <ProgressTracker value={0.67} />
│
└── IonContent className="ion-padding"
    ├── <h2> typeStyles.h2
    ├── <p>  typeStyles.bodySm
    ├── <SectionLabel label="About your business">
    ├── Divider
    │
    ├── Business type question
    │   ├── <p> 13px SemiBold (question label)
    │   └── 6× [CheckTile — MISSING: §4]
    │
    ├── Active trading question
    │   ├── <p> question label
    │   └── [YesNoTile — MISSING: §4]
    │
    ├── Divider
    ├── <SectionLabel label="About your finances">
    ├── Divider
    │
    ├── Payment methods question
    │   └── 5× [CheckTile — MISSING: §4]
    │
    ├── <Input label="Monthly revenue (KES)" type="number" required>
    │    → [CurrencyInput variant — MISSING: §4]
    │
    ├── Registration status
    │   └── IonItem > IonSelect > IonSelectOption(s)
    │
    ├── Conditional reveals (hidden until registrationStatus is set)
    │   ├── Licence question + [YesNoTile]
    │   │    ↳ shown when: registrationStatus !== null
    │   └── Permit question + [YesNoTile]
    │        ↳ shown when: licenceAnswer === 'no'
    │
    ├── Physical location question + [YesNoTile]
    │
    ├── <Button variant="primary" size="lg" expand="block" label="Check eligibility">
    │    ↳ loading during eligibility API call
    │    ↳ disabled until required fields completed
    │
    └── Result states (post eligibility check)
        ├── Pass → [InlineBanner variant="success" message="You're eligible. Continue to next step."]
        │          <Button variant="primary" expand="block" label="Continue to next step">
        └── Fail → [InlineBanner variant="warning" message="You may not meet eligibility requirements."]
                   <Button variant="outline" expand="block" label="Review answers">
```

**Interaction**:
- CheckTile allows multi-select (business types); at least one required
- YesNoTile is single-select per question
- Conditional reveals use `useState` with conditional render — do not use CSS `display: none`
- "Check eligibility" fires eligibility API (or local logic); button enters loading state
- On pass: InlineBanner success appears; "Continue" button appears
- On fail: InlineBanner warning appears; "Review answers" scrolls to first invalid field
- On "Continue": navigate to Screen 4; mark step 2 complete

---

### Screen 4 — Your Details (Step 3)

**Purpose**: Collect business details, owner identity, and experience data.

**Progress**: `completedUpTo={2}`, `activeSteps={[3]}`, `stepDisplay="Step 3 of 3"`

```
IonPage
├── IonHeader (sticky)
│   ├── IonToolbar → Back button + Wordmark
│   ├── <StepIndicator currentScreen={3} stepDisplay="Step 3 of 3" label="Your Details" ... />
│   └── <ProgressTracker value={1.0} />
│
├── [InlineBanner variant="info" message="Almost there — complete your details to submit."]
│
└── IonContent className="ion-padding"
    ├── <h2> typeStyles.h2
    ├── <p>  typeStyles.bodySm
    │
    ├── <SectionLabel label="About your business">
    ├── Divider
    │
    ├── IonList
    │   ├── IonItem > IonSelect → "What does your agri-business mainly deal in?"
    │   ├── Value-add question + [YesNoTile]
    │   ├── <Input label="Business name" required placeholder="e.g. Avenews Ltd">
    │   └── [AddressGroup — MISSING: §4]
    │       ├── <Input label="Street name" required>
    │       ├── <Input placeholder="Building number" continuation>
    │       └── IonItem (country locked) → "Kenya" + <Button variant="ghost" size="sm" label="Edit">
    │
    ├── [RoleGrid — MISSING: §4]
    │   └── 2×2 single-select tiles for business role
    │
    ├── Divider
    ├── <SectionLabel label="Your experience">
    ├── Divider
    │
    ├── IonList
    │   └── <Input label="National ID" type="password" clearInput required>
    │        → [SecureInput variant with trailing eye toggle — MISSING: §4]
    │
    ├── Years in agribusiness   → [TileSelect — MISSING: §4] (options: 1–3, 3–7, 7+)
    ├── Payment cycle           → [TileSelect] (3 options + "Other")
    ├── Profit margins          → [TileSelect] (options: Thin, Average, Healthy)
    │
    ├── Divider
    ├── <p> typeStyles.labelXs, Medium, centred, --av-color-text-muted (pre-submit note)
    └── <Button variant="primary" size="lg" expand="block" label="Submit my application">
         ↳ disabled until all required fields have values
         ↳ loading during submit API call
```

**Interaction**:
- Role grid enforces single-select — tapping a selected tile deselects all others
- TileSelect is single-select per question
- National ID field has trailing eye icon to toggle `type="password"` / `type="text"`
- Submit button fires application submission API; enters loading state
- On success: navigate to Screen 5
- On error: button leaves loading state; Toast displayed with error message

---

### Screen 5 — Confirmation

**Purpose**: Confirm submission and orient the user on next steps.

**Flow exit**: Application submitted; user is no longer in the apply flow.

```
IonPage
├── IonHeader (sticky, no progress bar, no StepIndicator)
│   └── IonToolbar → Wordmark only (no back button)
│
└── IonContent
    ├── Success block (centred)
    │   ├── Success icon circle (80px, bg --av-color-success-subtle, ✓ --av-color-success)
    │   │    Note: uses SUCCESS token — NOT primary aqua
    │   ├── <h2> "Application submitted" typeStyles.h2
    │   └── <p> typeStyles.bodySm, --av-color-text-subtle
    │
    ├── "What happens next" surface (--av-color-surface-subtle)
    │   ├── <SectionLabel label="What happens next">
    │   └── 3× [StepConnector — MISSING: §4]
    │       Each row: icon circle + step title + timeline label + connector line
    │
    ├── Contact block
    │   ├── <p> question label
    │   ├── <Button variant="outline" expand="block" label="Chat on WhatsApp" icon={logoWhatsapp} iconSlot="start">
    │   ├── <Button variant="outline" expand="block" label="Call us" icon={callOutline} iconSlot="start">
    │   └── <Button variant="ghost" size="sm" label="Back to home">
    │
    └── Footer (--av-color-surface-subtle)
        └── <p> 9px Regular, --av-color-text-muted (legal copy)
```

**Interaction**:
- No navigation back into the apply flow from this screen
- WhatsApp button opens `https://wa.me/...` external link
- Call button dials via `tel:...` deep link
- "Back to home" navigates to the Home tab

---

## 2. Component Mapping

Updated to use the Avenews design system API (no `color=`, `fill=`, `size=` passed to Ionic).

| Prototype primitive | DS component | Props | Notes |
|---|---|---|---|
| Primary CTA | `<Button>` | `variant="primary" size="lg" expand="block"` | Labels sentence-case in code; rendered UPPERCASE via CSS |
| Secondary CTA | `<Button>` | `variant="outline" expand="block"` | |
| Ghost / clear link | `<Button>` | `variant="ghost" size="sm"` | |
| Back button | `<Button>` | `variant="ghost" size="sm" label="← Back"` | Use IonBackButton in production routing |
| Text input field | `<Input>` | `labelPlacement="stacked" required` | |
| Phone / number field | `<Input>` | `type="tel"` or `type="number"` | |
| Password / ID field | `<Input>` | `type="password" clearInput` | Extend to SecureInput with eye toggle |
| Dropdown select | `IonItem > IonSelect` | — | No DS wrapper yet; use Ionic directly |
| Status chip (filter) | `<Chip>` | `variant="primary/neutral/..." selected={...}` | |
| Status badge (count) | `<Badge>` | `variant="danger/warning/..." count={N}` | |
| Progress bar | `<ProgressTracker>` | `value={0–1}` | `IonProgressBar` under the hood |
| Step progress | `<StepIndicator>` | `currentScreen={N} stepDisplay="Step N of M"` | |
| Info card | `<Card>` | `layout="default" subtitle="..." title="..." body="..."` | |
| Banner (success) | `[InlineBanner]` | `variant="success"` | MISSING — see §4 |
| Banner (warning) | `[InlineBanner]` | `variant="warning"` | MISSING — see §4 |
| Banner (info) | `[InlineBanner]` | `variant="info"` | MISSING — see §4 |
| Section divider | `<hr>` | `style="border-color: var(--av-color-neutral-divider)"` | Standardise token |
| Section label | `[SectionLabel]` | `label="..."` | MISSING — see §4 |
| OTP entry | `[OTPInput]` | 6 digits, countdown, resend | MISSING — see §4 |
| Yes/No choice | `[YesNoTile]` | `value selected={...}` | MISSING — see §4 |
| Multi-select tile | `[CheckTile]` | `label selected={...}` | MISSING — see §4 |
| Single-select strip | `[TileSelect]` | `options selected={...}` | MISSING — see §4 |
| Finance amount tile | `[FinanceTile]` | `amount selected={...}` | MISSING — see §4 |
| Address block | `[AddressGroup]` | continuation `<Input>` group | MISSING — see §4 |
| Role selection grid | `[RoleGrid]` | 2×2 single-select | MISSING — see §4 |
| Next-steps rows | `[StepConnector]` | step rows with connector line | MISSING — see §4 |
| Eligibility row | `[EligibilityRow]` | tick + label | MISSING — see §4 |

---

## 3. Inconsistencies Found

### Colour violations

| Location | Current value | Correct DS token | Correct value |
|---|---|---|---|
| `Divider` component | `bg-gray-100` = `#F3F4F6` | `--av-color-neutral-divider` | `#ededed` |
| Verified state background | `#e8f7f0` | `--av-color-success-subtle` | `#e6f9ee` |
| Verified state text | `#0A5C41` | `--av-color-success-text` | `#218c40` |
| Banner success bg | `#e8f7f0` | `--av-color-success-subtle` | `#e6f9ee` |
| Banner teal bg | `#e6f7f5` | `--av-color-info-subtle` | `#e0f7f5` |
| Banner teal text | `#0D5C58` | `--av-color-info-text` | `#007a78` |
| Confirmation success icon bg | `#e8f7f0` | `--av-color-success-subtle` | `#e6f9ee` |
| Confirmation success icon colour | `#0D7A6E` | `--av-color-success` | `#39c173` |
| Trust bar / footer background | `bg-gray-50` = `#F9FAFB` | `--av-color-surface-subtle` | `#f3f4f6` |
| Hint / helper text | `text-gray-400` = `#9ca3af` | `--av-color-text-muted` | `#8c8c8c` |
| NavBar border | `border-gray-100` | `--av-color-neutral-divider` | `#ededed` |
| Primary brand references | `#0D7A6E` (old teal) | `--av-color-action` | `#16b3c4` (aqua) |

### Typography violations

| Location | Current | Correct DS token |
|---|---|---|
| Back button weight | `font-medium` | SemiBold (600) |
| Back button colour | `text-gray-400` | `--av-color-text-muted` (`#8c8c8c`) |
| SectionLabel tracking | `tracking-widest` | `0.8px` (not widest) |
| Helper/hint text | `text-[11px] text-gray-400` | `text-[11px]` + `--av-color-text-muted` |
| Progress bar height | `h-1` = 4px | 3px (`IonProgressBar` default) |
| H1–H3 headings | Geist Sans | **Plus Jakarta Sans** Bold |

### Structural violations

| Issue | Detail |
|---|---|
| CTA button `→` in JSX | Arrow must be in copy, not hardcoded in component |
| Submit not disabled | Must be disabled until all required fields have values |
| No input error states | DS Input requires error state (danger border + helper text after blur/submit) |
| Prototype simulate buttons | Remove or guard behind `process.env.NODE_ENV === 'development'` |
| Conditional reveals always visible | Must be truly conditional — use React state, not CSS hide |
| Role grid has no selected state | No `useState` selection; add single-select logic |
| Progress bar outside `IonHeader` | Must sit inside `IonHeader` as a second slot |
| Plain text step pill | Replace with `<StepIndicator>` component |
| Address group gap | DS Input rules: continuation fields must have no gap between them |

---

## 4. Missing Components

These components are used in the Apply flow but have no DS definition. Each needs a spec added to `components/`.

| Component | Description | Priority |
|---|---|---|
| **OTPInput** | 6-digit code entry with countdown timer and Resend link. States: empty, active (current digit highlighted), complete, error (invalid code), verified. | High |
| **YesNoTile** | Horizontal pair of equal-width outline tiles for binary Yes/No questions. States: default (both unselected), yes-selected, no-selected. Single-select enforced. | High |
| **CheckTile** | Full-width tappable tile with checkbox, label, and optional sub-description. States: unchecked, checked (aqua border + `--av-color-action-subtle` bg). Multi-select. | High |
| **TileSelect** | Horizontal strip of equal-width single-select option tiles. 2–4 options per row. States: default, selected (`variant="primary"` fill). | High |
| **InlineBanner** | Persistent inline status strip. Variants: `success`, `warning`, `info`, `danger`. Not a Toast — does not auto-dismiss. Uses status semantic tokens. | High |
| **FinanceTile** | Full-width single-select tile for financing amount options. Larger than TileSelect. Radio semantics. Used on landing screen. | High |
| **SectionLabel** | Small all-caps label with `letter-spacing: 0.8px`. 10px SemiBold, `--av-color-text-muted`. Not interactive. | Medium |
| **AddressGroup** | Multi-field grouped address block using `<Input continuation>` pattern. Street (required), Building (optional), Country (locked). No gaps between fields. | Medium |
| **CurrencyInput** | Input with a leading currency prefix (KES) separated by a vertical divider. Subtype of Input variant. | Medium |
| **RoleGrid** | 2×2 grid of single-select tiles. Variant of TileSelect. Used for role-in-business selection. | Low |
| **SecureInput** | Input with trailing eye icon to toggle `type="password"` / `type="text"`. Subtype of Input. | Low |
| **StepConnector** | Numbered step rows with a vertical connector line between them. Used in Confirmation "What happens next" section. Not to be confused with StepIndicator. | Low |
| **EligibilityRow** | Read-only row: tick icon + label text. Used on Landing for eligibility checklist. Non-interactive. | Low |

---

## 5. Interaction Logic (Updated)

### Conditional reveals — Screen 3
```
registrationStatus !== null → show licenceQuestion
licenceAnswer === 'no'      → show permitQuestion
```
Use `useState` + conditional render. Do not use CSS visibility/display tricks.

### Form validation pattern
```
onChange: update field state
onBlur:   validate field; if invalid, set error string on <Input error="...">
onSubmit: validate all required fields; scroll to first error; block submission
```

### Submit gate — Screen 4
```
const canSubmit = firstName && lastName && phoneVerified && termsChecked
// Pass canSubmit as the inverse of disabled prop:
<Button disabled={!canSubmit} label="Continue" />
```

### OTP flow — Screen 2
```
"Send code" tapped
→ Button enters loading state
→ POST /otp/send { phone }
→ OTPInput appears
→ User enters 6 digits
→ auto-submit on 6th digit
→ POST /otp/verify { phone, code }
→ success: verified=true → InlineBanner success
→ error:   OTPInput enters error state ("Invalid code")
```

### Eligibility check — Screen 3
```
"Check eligibility" tapped
→ Button enters loading state
→ eligibilityCheck(formData) → { pass: boolean }
→ pass:  InlineBanner success + "Continue" button
→ fail:  InlineBanner warning + "Review answers" button
→ Button leaves loading state
```

### Submit — Screen 4
```
"Submit my application" tapped
→ Button enters loading state
→ POST /applications { ...formData }
→ success: navigate to Screen 5 (Confirmation)
→ error:   Button leaves loading; Toast displayed with error message
```

### Progress bar calculation
```
// Derive from position — do not hardcode
value = (currentStep - 1) / totalSteps

Step 1 of 3 → 0.33
Step 2 of 3 → 0.67
Step 3 of 3 → 1.0
```
