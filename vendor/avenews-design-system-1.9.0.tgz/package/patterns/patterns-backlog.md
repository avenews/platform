# Patterns Backlog

Patterns that need full definition. Each entry has a priority, the screens it appears on, and the components involved.

---

## High Priority

### forms.md

**What it covers**: The Avenews form pattern — how inputs are grouped, labelled, validated, and submitted.

**Screens**: About You (Screen 2), Your Business (Screen 3), Your Details (Screen 4)

**Needs to define**:
- Standard form layout: `IonList` + `IonItem` + `<Input>` grouping
- Required vs optional field conventions (asterisk, no asterisk)
- Validation timing: validate on blur, re-validate on change after first blur, block submit until valid
- Continuation field groups (address blocks)
- Submit gate pattern: derive `canSubmit` boolean from required field states; disable submit button
- Loading state during async submit: `<Button loading={true}>`, restore on response
- Error recovery: Toast on network failure; inline error on field-level failure
- Component usage per step in the apply flow (field-by-field list)

**Components involved**: Input, Button, InlineBanner (planned), Toast, Alert (for submit confirmation)

---

### otp-verification.md

**What it covers**: Phone number verification flow using a 6-digit OTP code.

**Screens**: About You (Screen 2)

**Needs to define**:
- Trigger: phone field filled + "Send verification code" button tapped
- OTPInput behaviour: 6 tiles, auto-advance on digit entry, auto-submit on 6th digit
- Countdown timer: 60 seconds; "Resend code" button disabled during countdown
- Success state: OTPInput replaced by InlineBanner "Phone verified"; Continue button enabled
- Error state: invalid code → OTPInput enters error state ("Incorrect code. 2 attempts remaining.")
- Expiry: code expires after 5 minutes → restart flow
- Component usage: Input (phone), Button (send, resend), OTPInput (planned), InlineBanner (planned)

**Components involved**: Input, Button, OTPInput (planned), InlineBanner (planned)

---

### eligibility-check.md

**What it covers**: Inline eligibility evaluation during Screen 3.

**Screens**: Your Business (Screen 3)

**Needs to define**:
- Pre-check state: "Check eligibility" button enabled when required fields are complete
- During check: button enters loading state; form fields become read-only
- Pass result: InlineBanner success + "Continue" CTA appears
- Fail result: InlineBanner warning + "Review answers" scrolls to first problematic field
- Re-check: user can correct answers and re-trigger check
- Component usage per state

**Components involved**: Button, InlineBanner (planned), CheckTile (planned), YesNoTile (planned)

---

## Medium Priority

### navigation.md

**What it covers**: How navigation works across the app — tabs, back buttons, modals, and deep linking.

**Needs to define**:
- IonTabs root structure: which tabs exist, their routes, their icons
- Back button pattern: `<Button variant="ghost" label="← Back">` in Toolbar vs `IonBackButton`
- When to navigate vs when to open a Modal
- Preventing navigation with unsaved changes (`canDismiss` on Modal, Alert confirmation before routing away)
- Deep link entry points (e.g. landing directly on a specific apply step)
- Toast `positionAnchor="tab-bar"` requirement when tabs are visible

**Components involved**: Button, Tabs, Modal, Alert, Toast

---

### document-upload.md

**What it covers**: The document upload flow within the application — from DocumentCategoryCard through to upload confirmation.

**Screens**: Upload Documents step (not yet implemented)

**Needs to define**:
- Upload trigger: tapping a DocumentRow (future interactive state)
- Upload sheet: Sheet Modal with file picker, preview, and confirm
- Upload states per DocumentRow: action_required → in_review (optimistic update on upload)
- Progress: ProgressTracker during upload
- Success: DocumentRow transitions to in_review; Toast "Document uploaded"
- Error: DocumentRow stays action_required; Toast with error; retry available
- Rejection flow: reviewer rejects → DocumentRow returns to action_required

**Components involved**: DocumentRow, DocumentCategoryCard, Modal (Sheet), Button, ProgressTracker, Toast, Input (for document notes)

---

### status-display.md

**What it covers**: How document and application statuses are displayed across the app — which component to use in which context.

**Needs to define**:
- DocumentRow status pill: when to use (inside document lists, read-only)
- Chip (status variant): when to use (interactive filter rows, entity tags)
- Badge: when to use (count on tab bar icons, list item counts)
- InlineBanner (planned): when to use (persistent page-level status result)
- Toast: when to use (transient confirmation)
- Decision tree: "I need to show a status — which component do I use?"

**Components involved**: DocumentRow, Chip, Badge, InlineBanner (planned), Toast

---

## Low Priority

### empty-states.md

**What it covers**: How to handle empty lists, zero results, and first-use screens.

**Needs to define**:
- When a filtered list returns no results (Searchbar query)
- When a section has no documents yet
- Visual structure: icon + heading + sub-text + optional CTA
- Component usage: Card or plain layout, Button for the CTA

---

### loading-states.md

**What it covers**: How async loading states are handled consistently across all components.

**Needs to define**:
- Component-level loading: `<Card loading>`, `<Input loading>`, `<Button loading>`
- Page-level loading: `IonProgressBar type="indeterminate"` in IonHeader
- List-level loading: skeleton rows
- When to use which pattern (single field vs full page vs list)
- Loading → error recovery pattern
