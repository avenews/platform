# Responsive List Layout Pattern

## Overview

A two-tier layout pattern used on list pages: a **card list** on mobile (below 768px) and a **data table** on desktop. The two representations show the same data with different visual density and interaction models.

This pattern is used on:
- **Invoices page** — list of all submitted invoices
- **Relationships page** — list of partner relationships
- **Home dashboard** — recent invoices and relationships summary sections

---

## When to use

Use this pattern when:
- The data has 4+ columns that would cause horizontal overflow on mobile
- Individual items are more scannable as stacked cards than as truncated table rows
- Row actions (view, download) need 44px touch targets on mobile

Do **not** abstract this into a single reusable component. The mobile card and desktop table have sufficiently different layouts and context that a shared abstraction adds complexity without value. Document the pattern here and implement it consistently.

---

## Structure

```html
<!-- Mobile: card list — hidden on desktop (768px+) -->
<ul class="aff-cards">
  @for (item of items; track item.id) {
    <li class="aff-card">
      <!-- Card content per item -->
      <div class="aff-card__head">
        <div class="aff-card__identity">
          <p class="aff-card__partner">{{ item.clientName }}</p>
          <p class="aff-card__ref">{{ item.reference }}</p>
        </div>
        <div class="aff-card__amount-col">
          <small>Amount</small>
          <strong>{{ item.amount | currency:'KES' }}</strong>
        </div>
      </div>
      <p class="aff-card__due">Due {{ item.dueDate | date }}</p>
      <div class="aff-card__meta">
        <app-status-badge [status]="getStatus(item.status)" />
      </div>
      @if (item.invoiceFile) {
        <div class="aff-card__actions">
          <a avButton variant="secondary" [size]="'sm'" [href]="item.invoiceFile" target="_blank">
            View invoice <av-icon name="external-link" [size]="12" />
          </a>
        </div>
      }
    </li>
  }
</ul>

<!-- Desktop: data table — hidden on mobile (<768px) -->
<div class="aff-dt-desktop">
  <av-data-table [columns]="columns" [rows]="tableRows" (rowClick)="onRowClick($event)">
    <ng-template avTableCell="status" let-value>
      <app-status-badge [status]="getStatus(value)" />
    </ng-template>
    <!-- additional cell templates -->
  </av-data-table>
</div>
```

---

## CSS visibility toggle

The DS stylesheet (`styles-angular.css`) provides the responsive show/hide classes:

```css
/* Default: show table, hide cards */
.aff-cards      { display: none;  }
.aff-dt-desktop { display: block; }

/* Mobile: show cards, hide table */
@media (max-width: 767px) {
  .aff-cards      { display: grid; }
  .aff-dt-desktop { display: none; }
}
```

No additional CSS is needed in the portal's `styles.css` for the toggle itself.

---

## Card CSS classes (provided by DS)

| Class | Purpose |
|---|---|
| `.aff-cards` | Grid container for mobile cards (gap: `--av-space-3`) |
| `.aff-card` | Individual card shell (grid layout, border, shadow) |
| `.aff-card__head` | Flex row: identity (left) + amount column (right) |
| `.aff-card__identity` | Flex column: partner name + reference |
| `.aff-card__partner` | Bold heading (16px Plus Jakarta Sans) |
| `.aff-card__ref` | Muted reference number (sm) |
| `.aff-card__amount-col` | Right-aligned label + value |
| `.aff-card__due` | Due date row (muted, sm) |
| `.aff-card__meta` | Flex row for status badge + CTA |
| `.aff-card__actions` | Full-width action buttons below a divider |

---

## Data mapping

The mobile card and desktop table read from the same data source. Map once in the component, use in both templates.

```typescript
// In component class
readonly tableColumns: DataTableColumn[] = [
  { key: 'client',    header: 'Client'                        },
  { key: 'reference', header: 'Invoice No.', mono: true       },
  { key: 'amount',    header: 'Amount',      align: 'right'   },
  { key: 'due',       header: 'Due Date'                      },
  { key: 'status',    header: 'Status',      width: 120       },
]

get tableRows(): Record<string, unknown>[] {
  return this.invoices.map(inv => ({
    client:    inv.clientName,
    reference: inv.reference,
    amount:    inv.amountKes,    // raw value; format in cell template
    due:       inv.dueDateIso,
    status:    inv.status,
  }))
}
```

---

## Empty states

Both tiers must handle the empty state. Use the same `emptyLabel` message for consistency.

```html
<!-- Mobile empty state -->
@if (items.length === 0) {
  <p class="dt-empty">No invoices found.</p>
}

<!-- Desktop: pass to AvDataTableComponent -->
<av-data-table [columns]="columns" [rows]="tableRows" emptyLabel="No invoices found." />
```

---

## Filter integration

Place `av-filter-select` components above both tiers. Filtering operates on the underlying data array — both the card list and table update from the same filtered source.

```html
<div class="affiliate-filters">
  <av-filter-select label="Status" [options]="statusOptions" [value]="filterStatus"
    (valueChange)="filterStatus = $event" />
</div>

<!-- Both tiers below read from filteredItems -->
<ul class="aff-cards">...</ul>
<div class="aff-dt-desktop">...</div>
```

---

## Do not abstract yet

A `AvResponsiveListComponent` has been discussed but deferred. The current per-page implementation (2–3 instances) does not justify the abstraction cost. Revisit if a fourth usage appears or if the pattern diverges between instances.
