# Load More / Pagination Pattern

## Purpose

How to handle lists with more data than is loaded in the initial request. Covers two patterns used in the Avenews application: **infinite scroll** (content loads automatically as the user scrolls to the bottom) and **explicit load-more** (a button or link the user taps to fetch the next page). Also covers the initial load skeleton and the end-of-list state.

---

## Pattern Selection

| Use | Pattern |
|---|---|
| Long lists with natural scrolling (document history, notification feed, transaction log) | **Infinite scroll** |
| Short or bounded lists where the user should be aware they are seeing a subset | **Load More button** |
| Search results | **Load More button** (pagination matches user mental model for search) |
| Lists with a known total count that fits on one screen | **Load all** (no pagination) |

---

## Infinite Scroll

Uses `IonInfiniteScroll` — automatically fires when the user scrolls within a threshold of the list bottom.

```
List screen
├── IonContent
│   ├── IonList (loaded items)
│   └── IonInfiniteScroll
│       └── IonInfiniteScrollContent (loading spinner)
└── [Nothing when end of list reached — IonInfiniteScroll disabled]
```

### States

| State | UI |
|---|---|
| Initial load | Skeleton rows (match expected per-page count) |
| Loading more | `IonInfiniteScrollContent` shows a crescent spinner |
| More available | `IonInfiniteScroll` enabled; spinner shown on trigger |
| End of list | `IonInfiniteScroll` disabled; optional "All items loaded" note |
| Load error | `Toast` (danger) + `IonInfiniteScroll` re-enabled for retry |

### Code pattern

```tsx
const [items, setItems] = useState<Item[]>([]);
const [page, setPage] = useState(1);
const [hasMore, setHasMore] = useState(true);
const [isLoading, setIsLoading] = useState(true);

// Initial load
useEffect(() => {
  loadPage(1).then(({ data, totalPages }) => {
    setItems(data);
    setHasMore(1 < totalPages);
    setIsLoading(false);
  });
}, []);

async function loadMore(event: CustomEvent<void>) {
  const next = page + 1;
  try {
    const { data, totalPages } = await loadPage(next);
    setItems(prev => [...prev, ...data]);
    setPage(next);
    setHasMore(next < totalPages);
  } catch {
    present({ message: 'Could not load more items. Tap to retry.', duration: 4000, color: 'danger' });
  } finally {
    (event.target as HTMLIonInfiniteScrollElement).complete();
  }
}

return (
  <IonContent>
    {isLoading ? (
      <IonList>
        {Array.from({ length: 8 }).map((_, i) => (
          <SkeletonDocumentRow key={i} />
        ))}
      </IonList>
    ) : (
      <IonList>
        {items.map(item => <DocumentRow key={item.id} {...item} />)}
      </IonList>
    )}

    <IonInfiniteScroll
      disabled={!hasMore}
      onIonInfinite={loadMore}
      threshold="100px"
    >
      <IonInfiniteScrollContent
        loadingSpinner="crescent"
        loadingText=""
      />
    </IonInfiniteScroll>

    {!isLoading && !hasMore && items.length > 0 && (
      <p className="avenews-list__end-note">All documents loaded</p>
    )}
  </IonContent>
);
```

---

## Load More Button

Uses a manual "Load more" button at the bottom of the list. The user explicitly triggers the next page fetch.

```
List screen
├── IonContent
│   ├── IonList (loaded items)
│   └── [Bottom of list]
│       ├── Loading: IonSpinner (crescent, centred)
│       ├── More available: Button ("Load more", variant="ghost", expand="block")
│       └── End of list: p.avenews-list__end-note ("Showing all X results")
```

### Code pattern

```tsx
const [items, setItems] = useState<Item[]>([]);
const [page, setPage] = useState(1);
const [hasMore, setHasMore] = useState(true);
const [isLoadingMore, setIsLoadingMore] = useState(false);

async function handleLoadMore() {
  setIsLoadingMore(true);
  try {
    const next = page + 1;
    const { data, totalPages } = await loadPage(next);
    setItems(prev => [...prev, ...data]);
    setPage(next);
    setHasMore(next < totalPages);
  } catch {
    present({ message: 'Could not load more items. Please try again.', duration: 4000, color: 'danger' });
  } finally {
    setIsLoadingMore(false);
  }
}

// Bottom of list:
{isLoadingMore ? (
  <div style={{ display: 'flex', justifyContent: 'center', padding: '16px' }}>
    <IonSpinner name="crescent" style={{ color: 'var(--av-color-action)' }} />
  </div>
) : hasMore ? (
  <div style={{ padding: '8px 16px 16px' }}>
    <Button label="Load more" variant="ghost" expand="block" onClick={handleLoadMore} />
  </div>
) : (
  <p className="avenews-list__end-note">Showing all {items.length} results</p>
)}
```

---

## Initial Load Skeleton

Always show skeleton rows during the initial page load. Match the skeleton count to the expected number of items per page.

```tsx
// Skeleton count: use the page size (e.g. 10)
const SKELETON_COUNT = 10;

{isInitialLoading && (
  <IonList>
    {Array.from({ length: SKELETON_COUNT }).map((_, i) => (
      <IonItem key={i} lines="inset">
        <IonSkeletonText animated style={{ width: '40px', height: '40px', borderRadius: '50%', flexShrink: 0, marginRight: '12px' }} />
        <div style={{ flex: 1 }}>
          <IonSkeletonText animated style={{ width: '60%', height: '14px', marginBottom: '6px' }} />
          <IonSkeletonText animated style={{ width: '40%', height: '12px' }} />
        </div>
        <IonSkeletonText animated slot="end" style={{ width: '80px', height: '22px', borderRadius: '12px' }} />
      </IonItem>
    ))}
  </IonList>
)}
```

---

## Empty and Error States After Load

| After load result | Render |
|---|---|
| Zero items | `Empty State` (no-results variant) |
| Load failed | `Empty State` (error variant) with retry CTA |
| Zero items after search/filter | `Empty State` (no-results variant) with "Clear filters" CTA |

Never show a Load More button or infinite scroll trigger when the list is empty.

---

## End-of-List Styling

```css
.avenews-list__end-note {
  font-size: 13px;
  font-family: var(--av-font-body);
  color: var(--av-color-text-muted);
  text-align: center;
  padding: var(--av-space-3) var(--av-space-4) var(--av-space-5);
  margin: 0;
}
```

---

## Rules

- **Always show a skeleton on initial load** — never render an empty list while the first page is fetching
- **Never show both a spinner and items simultaneously** — initial load = full skeleton; load more = spinner below existing items
- `IonInfiniteScroll`: set `threshold="100px"` (100px from bottom) to give enough time for the API call before the user reaches the end
- `IonInfiniteScrollContent`: use `loadingText=""` (empty string) — let the spinner speak for itself; avoid "Loading more..." text
- **Always disable `IonInfiniteScroll` when `hasMore` is false** — failure to do so will trigger repeated API calls at end of list
- **Errors during load-more**: show a `Toast` (not an Inline Banner); the existing list content remains visible
- Provide the total count in the end-of-list note when it is a search result: "Showing all 23 results for 'statement'"

---

## Cross-references

- `components/spinner.md` — IonSpinner and IonSkeletonText patterns
- `components/empty-state.md` — what to render when list is empty or errored
- `components/document-row.md` — the typical list item in document lists
- `components/toast.md` — load-more error notification
