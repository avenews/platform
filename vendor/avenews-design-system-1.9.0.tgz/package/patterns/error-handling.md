# Error Handling Patterns

## Purpose

A decision framework for choosing the correct Avenews feedback component for each category of error. Consistent error handling prevents UX fragmentation and ensures users always understand what went wrong and how to recover.

---

## Error Category Decision Table

| Error type | Where it occurs | Correct component | When to dismiss |
|---|---|---|---|
| **Field validation** | Inline, below a single form field | `ion-note[slot="error"]` on `Input` or `Select` | Automatically, when the user corrects the value |
| **Form-level validation** | Multiple invalid fields | `Inline Banner` (danger) above the first invalid field | When all fields pass validation or user dismisses (if `dismissible`) |
| **API / server error (blocking)** | Page-level — prevents the user from continuing | `Inline Banner` (danger) at top of content area | When the error resolves or the user takes corrective action |
| **API error (non-blocking)** | Action completed but something peripheral failed | `Toast` (danger variant) | Auto-dismiss after 4000ms |
| **No data / empty state** | Entire content area is empty after a successful load | `Empty State` (error variant) with retry CTA | When data loads successfully |
| **Page-level load failure** | Page could not load its primary data | `Empty State` (error variant) with retry CTA | When retry succeeds |
| **Action result error** | Background operation failed (upload, submit) | `Toast` (danger) + restore prior state | Auto-dismiss; user initiates retry manually |
| **Network / connectivity** | Device offline or timeout | `Inline Banner` (warning) at top of page | Automatically when connectivity restores |
| **Blocking decision required** | User must acknowledge before proceeding | `Alert` | User taps "OK" or "Dismiss" |
| **Rejected document** | A previously uploaded document was rejected | `Inline Banner` (danger) above DocumentRow | When user re-uploads and the new upload succeeds |

---

## Component Decision Rules

### Use field-level `ion-note[slot="error"]` when:
- The error relates to a single specific form field
- The correction is obvious and directly in context (format, required, min/max)
- The error should disappear as soon as the user corrects the value

### Use `Inline Banner` (danger) when:
- Multiple fields fail validation simultaneously (summarise above the first error)
- A page-level blocking condition exists (eligibility failed, account suspended)
- A specific section's API call failed but the rest of the page is functional
- A persistent error needs to stay visible while the user takes corrective action

```tsx
// Form-level validation error
{hasValidationErrors && (
  <div className="avenews-inline-banner avenews-inline-banner--danger">
    <IonIcon icon={alertCircleOutline} />
    <p>Please correct the highlighted fields before continuing.</p>
  </div>
)}
```

### Use `Toast` (danger) when:
- A non-blocking background action failed (document upload, autosave)
- The error does not prevent the user from continuing the current flow
- The user needs to be aware but is not required to act immediately

```tsx
present({
  message: 'Document upload failed. Please try again.',
  duration: 4000,
  color: 'danger',
  position: 'bottom',
  positionAnchor: 'tab-bar',
  icon: alertCircleOutline,
  buttons: [{ text: 'Retry', handler: retryUpload }],
});
```

### Use `Empty State` (error variant) when:
- A page or section could not load its primary content
- The error prevents any meaningful content from displaying
- A clear retry action is available

```tsx
{loadError && (
  <EmptyState
    variant="error"
    title="Something went wrong"
    description="We couldn't load your applications. Please check your connection and try again."
    action={{ label: 'Try again', onClick: retry }}
  />
)}
```

### Use `Alert` when:
- The error requires the user to make a binary decision before proceeding
- The consequence of the error is destructive or irreversible
- Simple error acknowledgement with a single "OK" is sufficient

---

## Error Message Writing Rules

1. **State the problem, not the system state** — "Your document was rejected" not "Error 422: validation failed"
2. **Tell the user what to do** — "Please upload a valid bank statement" not just "Invalid file"
3. **Use plain language** — avoid technical terms; write for a first-time user
4. **Match the severity** — don't use "Warning" colour for a blocking error
5. **Don't blame the user** — "We couldn't process your request" not "You entered an invalid value"
6. **Never show raw error messages** from the API — map server errors to user-readable copy in the client

### Tone by variant

| Banner/Toast variant | Tone | Example |
|---|---|---|
| `danger` | Direct, factual, solution-first | "Your document was rejected. Please upload a valid copy to continue." |
| `warning` | Cautionary, non-alarming | "Your application is still under review. We'll notify you when it's ready." |
| `info` | Neutral, informational | "We noticed you've applied before. Some fields have been pre-filled." |
| `success` | Brief confirmation | "Your document has been uploaded successfully." |

---

## Stacking and Priority Rules

- **One Inline Banner per page section maximum** — if multiple section-level errors occur, surface the most critical one
- **Do not show both a Toast and an Inline Banner for the same error** — choose the most appropriate channel
- **Field errors do not replace Inline Banners** — they are complementary; show both when a form has section-level AND field-level errors
- **Toast does not replace field errors** — for form submission failures, use an Inline Banner above the first invalid field, not a Toast

---

## Recovery Patterns

### Retry — idempotent actions (GET, file upload)
```tsx
const [error, setError] = useState<string | null>(null);

async function loadData() {
  setError(null);
  try {
    const data = await fetchApplications();
    setApplications(data);
  } catch {
    setError('We couldn\'t load your applications. Please try again.');
  }
}
```

### Revert — optimistic updates (Toggle, inline edit)
```tsx
// 1. Flip state optimistically
const prev = isEnabled;
setIsEnabled(!prev);

// 2. Call API
try {
  await updatePreference(!prev);
} catch {
  // 3. Revert on failure + show Toast
  setIsEnabled(prev);
  present({ message: 'Setting could not be saved. Please try again.', duration: 3000, color: 'danger' });
}
```

### Guard — irreversible actions (delete, submit)
```tsx
// Show Alert before committing the action
present({
  header: 'Cancel application?',
  message: 'This cannot be undone. Your application will be permanently cancelled.',
  buttons: [
    { text: 'Keep application', role: 'cancel' },
    { text: 'Cancel application', role: 'destructive', handler: cancelApplication },
  ],
});
```

---

## Cross-references

- `components/inline-banner.md` — persistent contextual error strip
- `components/toast.md` — transient non-blocking notification
- `components/alert.md` — blocking binary decision dialog
- `components/empty-state.md` — page-level failure with retry
- `components/input.md` — field-level validation via `ion-note[slot="error"]`
