# Component Overlap Analysis

This document records all cases where two or more components have overlapping appearance or purpose, and defines the official differentiation between them. Use this when deciding which component to reach for.

---

## Badge vs Chip

**Decision: Keep both. They are different in interaction model, placement, and information density.**

| Dimension | Badge | Chip |
|---|---|---|
| **Interactive** | Never | Yes — selectable, dismissible |
| **Standalone** | No — always attached to or inside another element | Yes — inline, in its own layout space |
| **Content** | Count (number) or short keyword (≤4 chars) | Short noun phrase (1–3 words) |
| **Icons / Avatars** | No | Yes |
| **Use as filter** | No | Yes |
| **Use as count** | Yes | No |
| **Dismissible** | No | Yes |
| **Placement** | Overlaid on icons, in list item end slots | Inline in filter rows, tag lists |
| **Ionic primitive** | `ion-badge` | `ion-chip` |

**Rule**: If the element carries a count or a very short keyword passively attached to another element, use **Badge**. If the element is interactive, carries a descriptive label, or lives inline in a row of filters or tags, use **Chip**.

**Anti-pattern**: Using a Badge with a status word like "In Review" inside a document row — use the DocumentRow's own built-in status pill or a Chip if the row is interactive.

---

## StepIndicator vs ProgressTracker

**Decision: Keep both. They serve different levels of information and different contexts.**

| Dimension | StepIndicator | ProgressTracker |
|---|---|---|
| **Shows step names** | Yes | No |
| **Shows individual step status** | Yes | No |
| **Expandable** | Yes | No |
| **Interactive** | Yes (tap to expand) | No |
| **Height** | Full collapsible panel | 3px slim bar |
| **Ionic primitive** | None — custom Avenews component | `ion-progress-bar` |
| **Primary use** | Apply flow progress (labelled, detailed) | Upload/processing feedback, ambient signal |
| **When to show** | On every apply flow step screen | During async operations or as a secondary reinforcer |

**Rule**: Use **StepIndicator** as the primary navigation progress UI in the apply flow — it replaces the need for any separate step label in the toolbar. Use **ProgressTracker** (IonProgressBar) inside the IonHeader for ambient visual reinforcement, or standalone during file upload / processing operations.

**Anti-pattern**: Using `IonProgressBar` as the only progress indicator on a multi-step apply screen — users cannot understand their step-by-step context from a bare bar.

---

## Card vs DocumentCategoryCard

**Decision: Keep both. DocumentCategoryCard is NOT a Card variant — it is a separate component with custom status-coloured borders.**

| Dimension | Card | DocumentCategoryCard |
|---|---|---|
| **Ionic primitive** | `ion-card` | Custom `div` |
| **Border colour** | None (shadow only) | Status-coloured (`--av-color-{status}`) |
| **Content structure** | Media / text / list layouts | Fixed: header + document rows + optional hint |
| **Tappable** | Yes (optional) | No (static, current) |
| **Displays documents** | No | Yes — DocumentRow children |
| **Loading / error states** | Yes | No (status is always server-driven) |
| **Use for** | General entity summaries, media items | Document upload categories only |

**Rule**: Use **Card** for general content surfaces. Use **DocumentCategoryCard** for document groupings with aggregate status borders. Never substitute one for the other — the visual semantics are different.

---

## Input vs Searchbar

**Decision: Keep both. Different purpose, context, and interaction model.**

| Dimension | Input | Searchbar |
|---|---|---|
| **Placement** | Inside a form (`IonList`) | Inside a second `IonToolbar` in `IonHeader` |
| **Purpose** | Collect structured data (name, ID, address) | Filter or search an existing list |
| **Cancel button** | No | Yes (`showCancelButton`) |
| **Clear button** | Optional (`clearInput`) | Yes (default) |
| **Label** | Required (stacked or floating) | None (placeholder only) |
| **Error state** | Yes | No |
| **Ionic primitive** | `ion-item` + `ion-input` | `ion-searchbar` |
| **Debounce** | Not applicable | 300ms default |

**Rule**: Use **Input** for any form field that collects data. Use **Searchbar** exclusively for content filtering or search, placed in the Header toolbar. Never use Searchbar as a form field.

---

## Alert vs Modal (for confirmations)

**Decision: Keep both. Use Alert for simple binary confirmations; Modal for rich confirmations.**

| Dimension | Alert | Modal |
|---|---|---|
| **Content richness** | 1–2 sentences maximum | Unlimited — full scrollable content |
| **Input collection** | Short single-field only | Full forms |
| **Dismissible by swipe** | No | Yes (Sheet and Card presentations) |
| **Button count** | 2 maximum | Unlimited (in footer) |
| **Platform native** | Yes — uses OS-level dialog appearance | Ionic custom overlay |

**Rule**: If the confirmation is binary (Cancel / Confirm) with a short message (1–2 sentences), use **Alert**. If the confirmation requires explanation longer than 2 sentences, involves multiple choices, or shows a preview of what will be affected, use a **Sheet Modal**.

---

## Toast vs InlineBanner (planned)

**Decision: Keep both. Toast is transient; InlineBanner is persistent.**

| Dimension | Toast | InlineBanner |
|---|---|---|
| **Persistence** | Auto-dismisses (timeout) | Persistent — stays until status changes |
| **Blocks interaction** | No | No |
| **Triggered by** | Completed actions | Data state (server-driven status) |
| **User can dismiss** | Yes (via action button or timeout) | No (disappears when status resolves) |
| **Position** | Fixed overlay, above tab bar | Inline, within page content flow |
| **Use for** | "Document uploaded", "Changes saved" | Eligibility pass/fail, phone verified, field errors after submit |

**Rule**: Use **Toast** to confirm that something just happened. Use **InlineBanner** to show the current status of something that may need to be acted upon.

---

## Chip (status) vs DocumentRow status pill

**Decision: They are different. DocumentRow status pills are plain `span` elements, not Chip instances.**

DocumentRow renders its own status pill as a plain `<span>` with inline status styles. This is intentional:
- The pill is a sub-element of the row, not a standalone interactive component
- Using `<Chip>` inside a DocumentRow would add unnecessary DOM complexity and interaction affordance
- DocumentRow pills cannot be dismissed, selected, or filtered — they are purely visual

**Rule**: Do not refactor DocumentRow status pills to `<Chip>` unless interactive behaviour (tap to change status, dismiss, or filter) is being introduced. When that happens, introduce a `Chip` and update this document.

---

## Summary: What to merge or remove

No components were merged or removed. All overlapping components serve distinct roles and are differentiated above.

The following components from the prototype are **not yet in the design system** and need to be added before they can be used correctly. They are documented in `patterns/apply-flow-refactor.md §4`:

- OTPInput
- YesNoTile
- CheckTile
- TileSelect
- InlineBanner
- FinanceTile
- SectionLabel
- AddressGroup
- CurrencyInput
- RoleGrid
- SecureInput
- StepConnector
- EligibilityRow
