# Avenews Ionic Design System

The component library, design tokens, and pattern documentation for the Avenews mobile and web applications. Built on [Ionic React](https://ionicframework.com/docs/react) and documented in [Storybook](https://storybook.js.org/).

**Live Storybook:** https://avenews-design-system.vercel.app/
**Repository:** https://github.com/brendanswil/Avenews-Ionic-Design-System

---

## What's inside

This repo contains three things:

1. **React components** organised by surface — Ionic-wrapped (mobile / Android), pure React/HTML (web portal), and cross-platform (shared between both). See [Consuming the design system](#consuming-the-design-system) below for the entry points.
2. **Design tokens** — colour, typography, spacing, and radius values in TypeScript and CSS (`src/tokens/`, `src/styles.css`).
3. **Specifications** — markdown documentation for every component, pattern, and template that informs both design and engineering (`components/`, `patterns/`, `specs/`, `templates/`, `tokens/`, `docs/`).

The component code and the markdown specs are kept in sync — the markdown is the source of truth for behaviour and visual rules, the code is the source of truth for the actual implementation.

---

## Consuming the design system

The package exposes five entry points so consumers import only what their surface needs.

| Entry point | Path | Use this from |
|-------------|------|---------------|
| `@avenews/design-system/web` | `src/components/web/index.ts` | The web application portal (React + Vite/Next, no Ionic). Re-exports cross-platform components. |
| `@avenews/design-system/ionic` | `src/components/ionic/index.ts` | The Android app (Ionic React). Re-exports cross-platform components. |
| `@avenews/design-system/cross-platform` | `src/components/cross-platform/index.ts` | Components that work on both surfaces (Alert, Popover, DocumentRow, DocumentCategoryCard, StepIndicator, SectionHeader). |
| `@avenews/design-system/tokens` | `src/tokens/index.ts` | Raw design tokens (colours, typography, spacing, radius) as TypeScript values. |
| `@avenews/design-system/shared` | `src/components/shared/index.ts` | Framework-agnostic types (`ButtonVariant`, `UploadStatus`) and utilities (`cn`, `formatFileSize`). |
| `@avenews/design-system/styles.css` | `src/styles.css` | The full stylesheet — all tokens, all component CSS for both `.av-*` and `.avenews-*` classes. |

The package ships **TypeScript source** (no compiled JS). Consumer bundlers (Vite, Next.js, Angular CLI, etc.) transpile on demand — every modern build chain handles this natively.

### From a React web portal (Vite / Next)

```tsx
// 1. Import the stylesheet once at the app root
import '@avenews/design-system/styles.css';

// 2. Import components from the /web entry
import { Button, Card, Header, Toolbar, SectionHeader, Alert } from '@avenews/design-system/web';

export function ApplicationStatus() {
  return (
    <>
      <Header title="My application" subtitle="Submitted 14 April 2026" />
      <SectionHeader title="Documents" variant="with-count" count={3} />
      <Card title="Bank statement" subtitle="Verified" />
      <Toolbar>
        <Button label="Continue" expand="block" onClick={submit} />
      </Toolbar>
    </>
  );
}
```

### From the Android Ionic React app

```tsx
// styles.css must still be imported once (alongside @ionic/react/css/core.css etc.)
import '@avenews/design-system/styles.css';

// Components from the /ionic entry are wrapped Ionic primitives
import { Button, Card, Modal, ActionSheet, StepIndicator } from '@avenews/design-system/ionic';
```

### From an Angular project (CSS-only path)

The web React components themselves are not Angular-compatible without a port, but the **styling is fully framework-agnostic**. Angular consumers can adopt the entire visual system by importing only the stylesheet:

```ts
// In angular.json or a global stylesheet
"styles": ["node_modules/@avenews/design-system/src/styles.css"]
```

Then use the documented CSS classes directly in Angular templates:

```html
<button class="av-btn av-btn--primary">Submit</button>
<input class="av-input__field" placeholder="Email" />
<div class="av-card">
  <div class="av-card__header"><h3 class="av-card__title">Card title</h3></div>
  <div class="av-card__body"><p class="av-card__text">Body…</p></div>
</div>
```

Every web component's class API is documented in the corresponding `components/*.md` spec. See [Component architecture](#component-architecture) for the full class-name reference.

---

## Quick start

**Requirements:** Node 18+ and npm.

```bash
# Install dependencies
npm install

# Run Storybook locally on http://localhost:6006
npm run storybook

# Build a static Storybook (output in storybook-static/)
npm run build-storybook

# Build and deploy Storybook to Vercel
npm run deploy-storybook
```

The `prebuild-storybook` script copies `src/styles.css` to `public/avenews-design-system.css` so the stylesheet is served at a stable URL in the deployed Storybook.

---

## Folder structure

```
.
├── .storybook/          Storybook configuration (main.ts, preview.tsx)
├── components/          Markdown spec for each component (source of truth for behaviour)
├── docs/                Phase summaries and Figma audits
├── patterns/            Cross-component UX patterns (upload flow, error handling, etc.)
├── prompts/             Prompt scaffolding used during build
├── public/              Static assets served by Storybook
├── specs/               Detailed component specs (button, input, upload-card)
├── src/
│   ├── components/
│   │   ├── ionic/             43 Ionic-wrapped components (Button, Input, Modal, Toast, …)
│   │   ├── web/               32 pure React/HTML components for the portal
│   │   ├── cross-platform/    6 shared components (Alert, Popover, DocumentRow, …)
│   │   └── shared/            Framework-agnostic types + utilities (cn, formatFileSize)
│   ├── foundations/           Storybook stories for tokens (Colour, Typography)
│   ├── tokens/                TypeScript token definitions (colours, typography, spacing, radius)
│   ├── index.ts               Top-level package entry (re-exports tokens + shared)
│   └── styles.css             Compiled stylesheet with all token + component CSS
├── templates/           Reusable component-spec templates
├── tokens/              Markdown documentation for the token system
├── package.json
└── vercel.json          Vercel deployment config
```

---

## Component architecture

Components live in `src/components/` and are organised by *surface*:

- **`ionic/`** (43 components) — built on Ionic React primitives (`IonButton`, `IonInput`, …) with Avenews styling applied via CSS classes rather than Ionic's `color`, `fill`, or `size` props. Used in the Android app.
- **`web/`** (32 components) — pure React + plain HTML elements with `.av-*` class names. No Ionic dependency. Used in the application portal.
- **`cross-platform/`** (6 components) — components shared between both surfaces (Alert, Popover, DocumentRow, DocumentCategoryCard, StepIndicator, SectionHeader). Both `web/` and `ionic/` re-export from here.
- **`shared/`** — framework-agnostic TypeScript types and utilities (no React, no Ionic, no DOM).

Class-name conventions:

- **`.avenews-*`** — Ionic component classes. Bind Ionic CSS vars (`--background`, `--color`, `--padding-*`) on Ionic component hosts.
- **`.av-*`** — Web component classes. Use real CSS properties (`background`, `color`, `padding`) on plain HTML elements.

Both class systems consume the same design tokens via CSS variables. The web `.av-*` classes reference `--ion-color-*` directly so the Ionic theming layer is the single source of truth — change `--ion-color-primary` in one place and it propagates to every surface.

Each component typically has:

- `ComponentName.tsx` — the React component
- `ComponentName.stories.tsx` — Storybook stories covering variants, states, and edge cases

Stories are picked up automatically from `src/**/*.stories.@(js|jsx|mjs|ts|tsx)`.

---

## Documentation conventions

Every component has a markdown file in `/components` describing its purpose, variants, states, accessibility requirements, and usage rules. When implementing or modifying a component, **read the markdown spec first** — it captures decisions that aren't obvious from the code.

- **`/components/*.md`** — per-component specs (variants, props, states, a11y)
- **`/patterns/*.md`** — multi-component UX patterns (e.g., `upload-flow.md`, `error-handling.md`)
- **`/specs/components/*.spec.md`** — deeper engineering specs for select components
- **`/tokens/*.md`** — design token rationale (colour, typography)
- **`/templates/component-template.md`** — the structure new component specs should follow
- **`/docs/figma-audit.md`** — mapping between Figma kit and Ionic components

---

## Design tokens

Tokens are defined in TypeScript (`src/tokens/`) and exported from `src/index.ts`. They cover:

- **Colour** — brand, status, neutral, text, and surface scales (`colours.ts`)
- **Typography** — font family, weight, size, line-height, letter-spacing, and composed text styles (`typography.ts`)
- **Iconography** — platform split (Lucide for web, Ionicons for mobile), sizing rules, and migration table (`tokens/iconography.md`)
- **Spacing** — spacing scale (`spacing.ts`)
- **Radius** — border-radius scale (`radius.ts`)

CSS variables that mirror these tokens live in `src/styles.css` and are consumed by every component.

---

## Conventions for contributors

- **Don't pass Ionic styling props.** No `color=`, `fill=`, or `size=` directly on Ionic components — use the Avenews CSS classes defined in `src/styles.css`. See `patterns/apply-flow-refactor.md` for examples.
- **Update the markdown spec when behaviour changes.** Code and spec must stay in sync.
- **Add a story for every new variant or state.** Storybook is the visual contract.
- **Token-first.** New colours, spacing, or text styles should be added to the token files before being used in a component.

---

## Scripts

| Script | What it does |
| --- | --- |
| `npm run storybook` | Run Storybook dev server on port 6006 |
| `npm run build-storybook` | Build static Storybook into `storybook-static/` |
| `npm run deploy-storybook` | Build and deploy to Vercel (production) |

---

## Deployment

Storybook is deployed to Vercel. Configuration lives in `vercel.json`:

```json
{
  "buildCommand": "npm run build-storybook",
  "outputDirectory": "storybook-static",
  "framework": null
}
```

Pushes to the connected branch trigger a deploy automatically.

---

## License

ISC
