/**
 * Avenews Border Radius Tokens
 * CSS custom properties: --av-radius-{name}
 */

export const radius = {
  none: '0px',
  xs:   '4px',
  sm:   '6px',
  md:   '8px',
  lg:    '12px',
  xl:    '16px',
  '2xl': '20px',
  pill:  '9999px',
} as const;

export type RadiusKey = keyof typeof radius;
