/**
 * Design tokens — colours, typography, spacing, and radius.
 *
 * Tokens are also exposed as CSS custom properties (`--av-*` and `--ion-*`)
 * via `src/styles.css`. Use the TypeScript exports when you need the raw
 * values inside JS (e.g. dynamic styles, constants); use the CSS variables
 * inside stylesheets and component classes.
 */

export {
  brand,
  aqua,
  darkblue,
  purple,
  tertiary,
  medium,
  statusBase,
  statusScale,
  neutral,
  text,
  surface,
  statusPairs,
  statusLabels,
  colours,
} from './colours';
export type { StatusKey, StatusPair } from './colours';

export {
  fontFamily,
  fontWeight,
  fontSize,
  lineHeight,
  letterSpacing,
  typeStyles,
  typography,
} from './typography';

export { spacing } from './spacing';
export type { SpacingKey } from './spacing';

export { radius } from './radius';
export type { RadiusKey } from './radius';
