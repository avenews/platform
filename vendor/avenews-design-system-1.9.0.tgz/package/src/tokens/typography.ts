/**
 * Avenews Typography Tokens
 * Source of truth: Figma — Avenews Ionic Design Kit for Android
 * CSS custom properties are generated in src/styles.css from these values.
 */

// ─── Font families ────────────────────────────────────────────────────────────
// H1–H6 use Plus Jakarta Sans; all other type uses Poppins.

export const fontFamily = {
  heading: '"Plus Jakarta Sans", sans-serif',
  body:    'Poppins, sans-serif',
  label:   'Poppins, sans-serif',
} as const;

// ─── Font weights ─────────────────────────────────────────────────────────────

export const fontWeight = {
  regular:  400,
  medium:   500,
  semibold: 600,
  bold:     700,
} as const;

// ─── Font sizes ───────────────────────────────────────────────────────────────
// Sourced directly from Figma text style definitions.

export const fontSize = {
  // Headings — Plus Jakarta Sans
  h1:  '26px',
  h2:  '24px',
  h3:  '22px',
  // Sub-headings — Poppins
  h4:  '20px',
  h5:  '18px',
  h6:  '16px',
  // Body
  lg:  '16px',   // Paragraph/Regular — input values, body copy
  md:  '14px',   // Small/Regular — card subtitle, body small
  sm:  '13px',   // Buttons/Small, stacked input label, badge
  // Captions / micro
  xs:  '12px',   // Input help-text
  xxs: '11px',   // Note/Label
  tab: '10px',   // Tabs/Label
  // Button-specific
  btnDefault: '14px',   // Buttons/Default
  btnLarge:   '20px',   // Buttons/Large
} as const;

// ─── Line heights ─────────────────────────────────────────────────────────────

export const lineHeight = {
  compact:  '1',
  snug:     '1.2',
  normal:   '1.4',
  relaxed:  '1.625',
} as const;

// ─── Letter spacing ───────────────────────────────────────────────────────────
// Figma values are percentages; expressed here as em equivalents.
// e.g. Figma "2" (%) = 0.02em, "-2.5" (%) = -0.025em

export const letterSpacing = {
  tight:   '-0.025em',  // -2.5% — input labels, tabs, notes
  tighter: '-0.01em',   // -1%   — badge label
  normal:  '0em',
  wide:    '0.02em',    // 2%    — button labels, segment labels
} as const;

// ─── Tailwind-style aliases (parallel scales used by web components) ───────────
// `leading` is a separate line-height scale (note normal: 1.5 vs lineHeight.normal: 1.4).
// `tracking` aliases letterSpacing. CSS: --av-leading-* / --av-tracking-*

export const leading = {
  tight:   '1.2',
  snug:    '1.375',
  normal:  '1.5',
  relaxed: '1.625',
} as const;

export const tracking = {
  tight:   letterSpacing.tight,
  tighter: letterSpacing.tighter,
  wide:    letterSpacing.wide,
} as const;

// ─── Named type styles (maps to Figma tokens) ─────────────────────────────────

export const typeStyles = {
  h1: {
    fontFamily: fontFamily.heading,
    fontSize: fontSize.h1,
    fontWeight: fontWeight.bold,
    lineHeight: lineHeight.snug,
  },
  h2: {
    fontFamily: fontFamily.heading,
    fontSize: fontSize.h2,
    fontWeight: fontWeight.bold,
    lineHeight: lineHeight.snug,
  },
  h3: {
    fontFamily: fontFamily.heading,
    fontSize: fontSize.h3,
    fontWeight: fontWeight.bold,
    lineHeight: lineHeight.snug,
  },
  h4: {
    fontFamily: fontFamily.heading,
    fontSize: fontSize.h4,
    fontWeight: fontWeight.semibold,
    lineHeight: lineHeight.snug,
  },
  h5: {
    fontFamily: fontFamily.heading,
    fontSize: fontSize.h5,
    fontWeight: fontWeight.semibold,
    lineHeight: lineHeight.snug,
  },
  h6: {
    fontFamily: fontFamily.heading,
    fontSize: fontSize.h6,
    fontWeight: fontWeight.semibold,
    lineHeight: lineHeight.snug,
  },
  bodyDefault: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.regular,
    lineHeight: lineHeight.normal,
  },
  bodyMedium: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.medium,
    lineHeight: lineHeight.normal,
  },
  bodySmall: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.regular,
    lineHeight: lineHeight.normal,
  },
  cardSubtitle: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.medium,
    lineHeight: lineHeight.normal,
    letterSpacing: letterSpacing.normal,
  },
  buttonDefault: {
    fontFamily: fontFamily.label,
    fontSize: fontSize.btnDefault,
    fontWeight: fontWeight.semibold,
    letterSpacing: letterSpacing.wide,
  },
  buttonSmall: {
    fontFamily: fontFamily.label,
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    letterSpacing: letterSpacing.wide,
  },
  buttonLarge: {
    fontFamily: fontFamily.label,
    fontSize: fontSize.btnLarge,
    fontWeight: fontWeight.semibold,
    letterSpacing: letterSpacing.wide,
  },
  badgeLabel: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    letterSpacing: letterSpacing.tighter,
  },
  inputLabel: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.regular,
    letterSpacing: letterSpacing.tight,
  },
  inputHelperText: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.regular,
    letterSpacing: letterSpacing.tight,
  },
  tabLabel: {
    fontSize: fontSize.tab,
    fontWeight: fontWeight.semibold,
    letterSpacing: letterSpacing.tight,
  },
  noteLabel: {
    fontSize: fontSize.xxs,
    fontWeight: fontWeight.regular,
    letterSpacing: letterSpacing.tight,
  },
} as const;

// ─── Flat export (legacy compat + Storybook docs) ─────────────────────────────

export const typography = {
  fontFamily,
  fontSize,
  fontWeight,
  lineHeight,
  letterSpacing,
  leading,
  tracking,
} as const;
