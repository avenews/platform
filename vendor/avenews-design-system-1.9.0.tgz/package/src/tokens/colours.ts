/**
 * Avenews Colour Tokens
 * Source of truth: Figma — Avenews Ionic Design Kit for Android
 * CSS custom properties are generated in src/styles.css from these values.
 */

// ─── Brand (Primary Aqua) ─────────────────────────────────────────────────────

export const brand = {
  primary:       '#16b3c4',  // Aqua/500  → --av-color-action / --av-color-primary
  primaryHover:  '#1691a4',  // Aqua/600
  primaryActive: '#187486',  // Aqua/700
  primaryLight:  '#73e6ed',  // Aqua/300
  secondary:     '#1a2e44',  // Darkblue/500 → --av-color-secondary
  accent:        '#df9013',  // Warning/500  → --av-color-accent
} as const;

// ─── Full palette scales ──────────────────────────────────────────────────────

export const aqua = {
  300: '#73e6ed',
  500: '#16b3c4',
  600: '#1691a4',
  700: '#187486',
} as const;

export const darkblue = {
  300: '#81d4f8',
  500: '#16a7e1',
  700: '#096a9b',
} as const;

export const purple = {
  300: '#deacfb',
  500: '#b548ed',
  600: '#a73dda',
  700: '#821ead',
} as const;

export const tertiary = {
  base:  '#0f4b6b',
  shade: '#092a3e',
  tint:  '#096a9b',
} as const;

export const medium = {
  base:  '#1d5e6d',
  shade: '#187486',
  tint:  '#1691a4',
} as const;

// ─── Status (base colours) ───────────────────────────────────────────────────

export const statusBase = {
  success: '#39c173',
  warning: '#df9013',
  danger:  '#ea4c4c',
  info:    '#16a7e1',
} as const;

export const statusScale = {
  success: { 300: '#92e3b4', 500: '#39c173', 600: '#269354', 700: '#217445' },
  warning: { 300: '#f4c350', 500: '#df9013', 600: '#c06e0e', 700: '#9a4d0e' },
  danger:  { 300: '#f9a8a8', 500: '#ea4c4c', 600: '#d62c2c', 700: '#b42121' },
} as const;

// ─── Neutral / Text scale ─────────────────────────────────────────────────────
// Sourced from Figma "Text color steps" and "Background color steps"

export const neutral = {
   0:   '#FFFFFF',
  50:   '#f3f5f7',
  100:  '#e6eaee',
  150:  '#dbe0e6',
  200:  '#d0d7df',
  300:  '#b7c1cc',
  400:  '#93a1b0',
  500:  '#6c7a8b',
  600:  '#5b6776',
  700:  '#4a5360',
  800:  '#373e49',
  900:  '#232830',
  950:  '#15191f',
} as const;

// ─── Semantic surfaces & text ─────────────────────────────────────────────────

export const text = {
  default: neutral[900],     // #232830
  muted:   neutral[500],     // #6c7a8b
  inverse: '#ffffff',
  dark:    '#0d343f',        // Aqua950 — dark teal text on light
} as const;

export const surface = {
  default:    '#ffffff',
  subtle:     '#f6f8fc',     // Light/Base
  border:     neutral[200],  // #d0d7df
  darkBg:     '#0d343f',     // Background/Aqua950
} as const;

// ─── Document-status colour pairs ────────────────────────────────────────────
// Used by DocumentRow and DocumentCategoryCard.

export type StatusKey =
  | 'action_required'
  | 'in_review'
  | 'completed'
  | 'pending'
  | 'in_progress'
  | 'optional';

export interface StatusPair {
  foreground: string;
  background: string;
  border: string;
}

export const statusPairs: Record<StatusKey, StatusPair> = {
  action_required: {
    foreground: statusScale.warning[700],  // #9a4d0e
    background: '#fef3e2',
    border:     statusBase.warning,
  },
  in_review: {
    foreground: darkblue[700],             // #096a9b
    background: '#e3f4fd',
    border:     darkblue[500],
  },
  completed: {
    foreground: statusScale.success[700],  // #217445
    background: '#e8f8ef',
    border:     statusBase.success,
  },
  pending: {
    foreground: neutral[500],
    background: neutral[50],
    border:     neutral[200],
  },
  in_progress: {
    foreground: brand.primary,
    background: '#e3f8fa',
    border:     brand.primary,
  },
  optional: {
    foreground: neutral[500],
    background: neutral[50],
    border:     neutral[200],
  },
};

export const statusLabels: Record<StatusKey, string> = {
  action_required: 'Action Required',
  in_review:       'In Review',
  completed:       'Completed',
  pending:         'Pending',
  in_progress:     'In Progress',
  optional:        'Optional',
};

// ─── Flat export (legacy compatibility + Storybook docs) ─────────────────────

export const colours = {
  brand,
  aqua,
  darkblue,
  purple,
  tertiary,
  medium,
  status: statusBase,
  statusScale,
  neutral,
  text,
  surface,
} as const;
