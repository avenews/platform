import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Button } from './Button';

// ─── Inline SVG helpers (replaces ionicons for the web version) ───────────────

const PlusIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2.5" strokeLinecap="round">
    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
  </svg>
);

const TrashIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="3 6 5 6 21 6"/>
    <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
    <path d="M10 11v6M14 11v6M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
  </svg>
);

const CheckIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Button> = {
  title:     'Avenews/Web/Button',
  component: Button,
  tags:      ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: 'Pure React button — no Ionic dependency. Same variant/size API as the Ionic Button. Uses Avenews CSS tokens (`av-btn--*`). `icon` accepts any ReactNode.',
      },
    },
    layout: 'centered',
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['primary','secondary','outline','ghost','danger','success','warning','inverted','inverted-outline'],
    },
    size:    { control: 'radio', options: ['sm','md','lg'] },
    expand:  { control: 'radio', options: [undefined,'block','full'] },
    iconSlot:{ control: 'radio', options: ['start','end','icon-only'] },
  },
};

export default meta;
type Story = StoryObj<typeof Button>;

// ─── States ───────────────────────────────────────────────────────────────────

export const Default: Story  = { args: { label: 'Submit Application' } };
export const Loading: Story  = { args: { label: 'Submit Application', loading: true } };
export const Disabled: Story = { args: { label: 'Submit Application', disabled: true } };

// ─── Variants ────────────────────────────────────────────────────────────────

export const Secondary:      Story = { args: { label: 'Reset password',   variant: 'secondary' } };
export const Outline:        Story = { args: { label: 'View Details',     variant: 'outline'   } };
export const Ghost:          Story = { args: { label: 'Cancel',           variant: 'ghost'     } };
export const Danger:         Story = { args: { label: 'Delete Document',  variant: 'danger'    } };
export const Success:        Story = { args: { label: 'Approve',          variant: 'success'   } };
export const Warning:        Story = { args: { label: 'Review Required',  variant: 'warning'   } };

export const Inverted: Story = {
  args: { label: 'Get Started', variant: 'inverted' },
  decorators: [(S) => (
    <div style={{ background: 'var(--av-color-surface-dark)', padding: 24, borderRadius: 12, display: 'inline-flex', gap: 12 }}>
      <S />
    </div>
  )],
};

export const InvertedOutline: Story = {
  args: { label: 'Learn More', variant: 'inverted-outline' },
  decorators: [(S) => (
    <div style={{ background: 'var(--av-color-surface-dark)', padding: 24, borderRadius: 12, display: 'inline-flex', gap: 12 }}>
      <S />
    </div>
  )],
};

// ─── Sizes ────────────────────────────────────────────────────────────────────

export const Small: Story = { args: { label: 'View',        size: 'sm' } };
export const Large: Story = { args: { label: 'Get Started', size: 'lg', expand: 'block' } };
export const Block: Story = { args: { label: 'Continue',    expand: 'block' } };

// ─── Icons ────────────────────────────────────────────────────────────────────

export const WithIconStart: Story = {
  args: { label: 'Add Document', icon: <PlusIcon /> },
};

export const WithIconEnd: Story = {
  args: { label: 'Delete', variant: 'danger', icon: <TrashIcon />, iconSlot: 'end' },
};

export const IconOnly: Story = {
  args: { label: 'Add Document', ariaLabel: 'Add document', icon: <PlusIcon />, iconSlot: 'icon-only' },
};

// ─── All variants / sizes / states ────────────────────────────────────────────

export const AllVariants: Story = {
  args: {
    variant: "secondary"
  },

  name: 'All Variants',

  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, padding: 16, alignItems: 'center' }}>
      <Button label="Primary"   variant="primary"   />
      <Button label="Reset password" variant="secondary" />
      <Button label="Outline"   variant="outline"   />
      <Button label="Ghost"     variant="ghost"     />
      <Button label="Danger"    variant="danger"    />
      <Button label="Success"   variant="success"   icon={<CheckIcon />} />
      <Button label="Warning"   variant="warning"   />
    </div>
  )
};

export const AllSizes: Story = {
  name: 'All Sizes',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, padding: 16, alignItems: 'center' }}>
      <Button label="Small"          size="sm" />
      <Button label="Medium (default)" size="md" />
      <Button label="Large"          size="lg" />
    </div>
  ),
};

export const AllStates: Story = {
  name: 'All States',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, padding: 16, alignItems: 'center' }}>
      <Button label="Default"              />
      <Button label="With icon" icon={<CheckIcon />} />
      <Button label="Loading"   loading    />
      <Button label="Disabled"  disabled   />
    </div>
  ),
};
