import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import * as IonIcons from 'ionicons/icons';
import * as LucideIcons from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Icon } from './Icon';
import type { IconName } from './Icon';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Icon> = {
  title:     'Avenews/Web/Icon',
  component: Icon,
  tags:      ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Triple-mode icon component.\n\n' +
          '**`lucideIcon` prop** — Lucide icons (web canonical). ' +
          'Import a component from `lucide-react` and pass it directly: ' +
          '`import { Home } from "lucide-react"` → `<Icon lucideIcon={Home} />`. ' +
          'Renders with `strokeWidth=2` and `currentColor` enforced. Use this for all new web components.\n\n' +
          '**`name` prop** — 46 built-in outline SVGs (back-compat, no dependency).\n\n' +
          '**`icon` prop** — full Ionicons library (mobile only / legacy). ' +
          'Import the data-URI export from `ionicons/icons` and pass it directly: ' +
          '`import { homeOutline } from "ionicons/icons"` → `<Icon icon={homeOutline} />`. ' +
          'Rendered via CSS `mask-image` so `color` and `currentColor` both work.',
      },
    },
    layout: 'padded',
  },
  argTypes: {
    size:  { control: 'radio',  options: ['xs', 'sm', 'md', 'lg', 'xl'] },
    color: { control: 'color' },
  },
  args: { size: 'md' },
};

export default meta;
type Story = StoryObj<typeof Icon>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { icon: IonIcons.homeOutline, size: 'lg' },
};

// ─── Sizes ────────────────────────────────────────────────────────────────────

export const Sizes: Story = {
  name: 'Sizes',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24, flexWrap: 'wrap', padding: 16 }}>
      {(['xs', 'sm', 'md', 'lg', 'xl'] as const).map(size => (
        <div key={size} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <Icon icon={IonIcons.notificationsOutline} size={size} />
          <span style={{ fontFamily: 'Poppins, sans-serif', fontSize: 11, color: '#6c7a8b' }}>{size}</span>
        </div>
      ))}
    </div>
  ),
};

// ─── Colors ──────────────────────────────────────────────────────────────────

export const Colors: Story = {
  name: 'Colors',
  render: () => (
    <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', padding: 16, alignItems: 'center' }}>
      <Icon icon={IonIcons.checkmarkCircleOutline} size="lg" color="var(--av-color-success)" />
      <Icon icon={IonIcons.warningOutline}          size="lg" color="var(--av-color-warning)" />
      <Icon icon={IonIcons.closeCircleOutline}      size="lg" color="var(--av-color-danger)"  />
      <Icon icon={IonIcons.informationCircleOutline} size="lg" color="var(--av-color-info)"   />
      <Icon icon={IonIcons.shieldCheckmarkOutline}  size="lg" color="var(--av-color-action)"  />
      <Icon icon={IonIcons.starOutline}             size="lg" color="#f4c350"                  />
    </div>
  ),
};

// ─── Styles comparison ────────────────────────────────────────────────────────

export const Styles: Story = {
  name: 'Styles / Filled · Outline · Sharp',
  render: () => {
    const pairs: [string, string, string, string][] = [
      ['home',      IonIcons.home,      IonIcons.homeOutline,      IonIcons.homeSharp],
      ['document',  IonIcons.document,  IonIcons.documentOutline,  IonIcons.documentSharp],
      ['person',    IonIcons.person,    IonIcons.personOutline,    IonIcons.personSharp],
      ['settings',  IonIcons.settings,  IonIcons.settingsOutline,  IonIcons.settingsSharp],
      ['mail',      IonIcons.mail,      IonIcons.mailOutline,      IonIcons.mailSharp],
      ['heart',     IonIcons.heart,     IonIcons.heartOutline,     IonIcons.heartSharp],
    ];
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, padding: 16 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '100px 80px 80px 80px', gap: 8, alignItems: 'center' }}>
          <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 11, color: '#6c7a8b' }}>icon</span>
          <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 11, color: '#6c7a8b', textAlign: 'center' }}>filled</span>
          <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 11, color: '#6c7a8b', textAlign: 'center' }}>outline</span>
          <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 11, color: '#6c7a8b', textAlign: 'center' }}>sharp</span>
        </div>
        {pairs.map(([name, filled, outline, sharp]) => (
          <div key={name} style={{ display: 'grid', gridTemplateColumns: '100px 80px 80px 80px', alignItems: 'center' }}>
            <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 12, color: '#0d343f' }}>{name}</span>
            <div style={{ display: 'flex', justifyContent: 'center' }}><Icon icon={filled}  size="lg" color="var(--av-color-action)" /></div>
            <div style={{ display: 'flex', justifyContent: 'center' }}><Icon icon={outline} size="lg" /></div>
            <div style={{ display: 'flex', justifyContent: 'center' }}><Icon icon={sharp}   size="lg" /></div>
          </div>
        ))}
      </div>
    );
  },
};

// ─── Built-in catalog ─────────────────────────────────────────────────────────

const BUILTIN: IconName[] = [
  'home','document','document-text','receipt','cash','calendar','time',
  'person','mail','call','search','notifications','menu','list',
  'add','remove','trash','create','share','download','upload','attach','refresh',
  'checkmark','checkmark-circle','close','close-circle','warning','information-circle',
  'chevron-forward','chevron-back','chevron-down','chevron-up',
  'arrow-forward','arrow-back','ellipsis-vertical','ellipsis-horizontal',
  'eye','eye-off','bar-chart','wallet','settings','help-circle','heart','star',
  'shield-checkmark',
];

export const BuiltinCatalog: Story = {
  name: 'Gallery / Built-in catalog (name prop)',
  render: () => (
    <div style={{ padding: 16 }}>
      <p style={{ fontFamily: 'Poppins,sans-serif', fontSize: 12, color: '#6c7a8b', marginBottom: 16 }}>
        46 hand-crafted 24×24 SVG icons. Pass via <code>name</code> prop. No external dependency.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(90px,1fr))', gap: 8 }}>
        {BUILTIN.map(name => (
          <div key={name} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6, padding:'10px 6px', borderRadius:8, background:'var(--av-color-surface-subtle)' }}>
            <Icon name={name} size="lg" />
            <span style={{ fontFamily:'Poppins,sans-serif', fontSize:9, color:'var(--av-color-text-muted)', textAlign:'center', lineHeight:1.3, wordBreak:'break-all' }}>{name}</span>
          </div>
        ))}
      </div>
    </div>
  ),
};

// ─── Full ionicons galleries ──────────────────────────────────────────────────

function iconGallery(
  entries: [string, string][],
  desc: string,
) {
  return (
    <div style={{ padding: 16 }}>
      <p style={{ fontFamily: 'Poppins,sans-serif', fontSize: 12, color: '#6c7a8b', marginBottom: 16 }}>{desc}</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(90px,1fr))', gap: 6 }}>
        {entries.map(([label, iconData]) => (
          <div key={label} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6, padding:'10px 6px', borderRadius:8, background:'var(--av-color-surface-subtle)' }}>
            <Icon icon={iconData} size="lg" />
            <span style={{ fontFamily:'Poppins,sans-serif', fontSize:9, color:'var(--av-color-text-muted)', textAlign:'center', lineHeight:1.3, wordBreak:'break-all' }}>{label.replace(/Outline$|Sharp$/, '')}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// Outline icons (most useful for UI)
const OUTLINE_ENTRIES = Object.entries(IonIcons).filter(([k]) => k.endsWith('Outline') && !k.startsWith('logo')) as [string, string][];
const FILLED_ENTRIES  = Object.entries(IonIcons).filter(([k]) => !k.endsWith('Outline') && !k.endsWith('Sharp') && !k.startsWith('logo')) as [string, string][];
const SHARP_ENTRIES   = Object.entries(IonIcons).filter(([k]) => k.endsWith('Sharp') && !k.startsWith('logo')) as [string, string][];
const LOGO_ENTRIES    = Object.entries(IonIcons).filter(([k]) => k.startsWith('logo')) as [string, string][];

export const GalleryOutline: Story = {
  name: 'Gallery / Ionicons Outline (421)',
  render: () => iconGallery(OUTLINE_ENTRIES, `${OUTLINE_ENTRIES.length} outline icons. Usage: import { homeOutline } from 'ionicons/icons'; → <Icon icon={homeOutline} />`),
};

export const GalleryFilled: Story = {
  name: 'Gallery / Ionicons Filled (515)',
  render: () => iconGallery(FILLED_ENTRIES, `${FILLED_ENTRIES.length} filled icons. Import from 'ionicons/icons' without Outline/Sharp suffix.`),
};

export const GallerySharp: Story = {
  name: 'Gallery / Ionicons Sharp (421)',
  render: () => iconGallery(SHARP_ENTRIES, `${SHARP_ENTRIES.length} sharp/square icons. Import from 'ionicons/icons' with Sharp suffix.`),
};

export const GalleryLogos: Story = {
  name: 'Gallery / Ionicons Logos (90)',
  render: () => iconGallery(LOGO_ENTRIES, `${LOGO_ENTRIES.length} brand/logo icons. Usage: import { logoGithub } from 'ionicons/icons'.`),
};

// ─── Lucide catalog (web canonical) ──────────────────────────────────────────
// All 47 icons that map 1:1 from the in-house catalog.
// New web components import directly: `import { Home } from 'lucide-react'`

const LUCIDE_CATALOG: [string, LucideIcon][] = [
  ['Plus',             LucideIcons.Plus],
  ['ArrowLeft',        LucideIcons.ArrowLeft],
  ['ArrowRight',       LucideIcons.ArrowRight],
  ['Paperclip',        LucideIcons.Paperclip],
  ['BarChart3',        LucideIcons.BarChart3],
  ['Calendar',         LucideIcons.Calendar],
  ['Phone',            LucideIcons.Phone],
  ['Banknote',         LucideIcons.Banknote],
  ['Check',            LucideIcons.Check],
  ['CheckCircle2',     LucideIcons.CheckCircle2],
  ['ChevronLeft',      LucideIcons.ChevronLeft],
  ['ChevronDown',      LucideIcons.ChevronDown],
  ['ChevronRight',     LucideIcons.ChevronRight],
  ['ChevronUp',        LucideIcons.ChevronUp],
  ['X',                LucideIcons.X],
  ['XCircle',          LucideIcons.XCircle],
  ['Pencil',           LucideIcons.Pencil],
  ['File',             LucideIcons.File],
  ['FileText',         LucideIcons.FileText],
  ['Download',         LucideIcons.Download],
  ['MoreHorizontal',   LucideIcons.MoreHorizontal],
  ['MoreVertical',     LucideIcons.MoreVertical],
  ['Eye',              LucideIcons.Eye],
  ['EyeOff',           LucideIcons.EyeOff],
  ['Heart',            LucideIcons.Heart],
  ['HelpCircle',       LucideIcons.HelpCircle],
  ['Home',             LucideIcons.Home],
  ['Info',             LucideIcons.Info],
  ['List',             LucideIcons.List],
  ['Mail',             LucideIcons.Mail],
  ['Menu',             LucideIcons.Menu],
  ['Bell',             LucideIcons.Bell],
  ['User',             LucideIcons.User],
  ['Receipt',          LucideIcons.Receipt],
  ['RotateCw',         LucideIcons.RotateCw],
  ['Minus',            LucideIcons.Minus],
  ['Search',           LucideIcons.Search],
  ['Settings',         LucideIcons.Settings],
  ['Share',            LucideIcons.Share],
  ['ShieldCheck',      LucideIcons.ShieldCheck],
  ['Star',             LucideIcons.Star],
  ['Clock',            LucideIcons.Clock],
  ['Trash2',           LucideIcons.Trash2],
  ['Upload',           LucideIcons.Upload],
  ['Wallet',           LucideIcons.Wallet],
  ['AlertTriangle',    LucideIcons.AlertTriangle],
];

export const LucideDefault: Story = {
  name: 'Lucide / Playground',
  args: { lucideIcon: LucideIcons.Home, size: 'lg' },
};

export const LucideCatalog: Story = {
  name: 'Gallery / Lucide catalog (web)',
  render: () => (
    <div style={{ padding: 16 }}>
      <p style={{ fontFamily: 'Poppins,sans-serif', fontSize: 12, color: '#6c7a8b', marginBottom: 16 }}>
        47 Lucide icons — the canonical web library. All map 1:1 to the in-house catalog.
        New components import directly from <code>lucide-react</code>; existing code uses the back-compat <code>name</code> prop.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(90px,1fr))', gap: 8 }}>
        {LUCIDE_CATALOG.map(([name, Comp]) => (
          <div key={name} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6, padding:'10px 6px', borderRadius:8, background:'var(--av-color-surface-subtle)' }}>
            <Icon lucideIcon={Comp} size="lg" />
            <span style={{ fontFamily:'Poppins,sans-serif', fontSize:9, color:'var(--av-color-text-muted)', textAlign:'center', lineHeight:1.3, wordBreak:'break-all' }}>{name}</span>
          </div>
        ))}
      </div>
    </div>
  ),
};

export const LucideSizes: Story = {
  name: 'Lucide / Sizes',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24, flexWrap: 'wrap', padding: 16 }}>
      {(['xs', 'sm', 'md', 'lg', 'xl'] as const).map(size => (
        <div key={size} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <Icon lucideIcon={LucideIcons.Bell} size={size} />
          <span style={{ fontFamily: 'Poppins, sans-serif', fontSize: 11, color: '#6c7a8b' }}>{size}</span>
        </div>
      ))}
    </div>
  ),
};

export const LucideColors: Story = {
  name: 'Lucide / Colors',
  render: () => (
    <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', padding: 16, alignItems: 'center' }}>
      <Icon lucideIcon={LucideIcons.CheckCircle2}   size="lg" color="var(--av-color-success)" />
      <Icon lucideIcon={LucideIcons.AlertTriangle}  size="lg" color="var(--av-color-warning)" />
      <Icon lucideIcon={LucideIcons.XCircle}        size="lg" color="var(--av-color-danger)"  />
      <Icon lucideIcon={LucideIcons.Info}           size="lg" color="var(--av-color-info)"    />
      <Icon lucideIcon={LucideIcons.ShieldCheck}    size="lg" color="var(--av-color-action)"  />
      <Icon lucideIcon={LucideIcons.Star}           size="lg" color="#f4c350"                  />
    </div>
  ),
};

// ─── In context ──────────────────────────────────────────────────────────────

export const InContext: Story = {
  name: 'Usage / In context',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 16, maxWidth: 320 }}>
      {[
        { icon: IonIcons.documentTextOutline,      label: 'Business registration', note: 'Uploaded · 2 Jan 2024', color: undefined },
        { icon: IonIcons.checkmarkCircleOutline,   label: 'KRA PIN certificate',   note: 'Approved',              color: 'var(--av-color-success)' },
        { icon: IonIcons.warningOutline,           label: 'Director ID',           note: 'Action required',       color: 'var(--av-color-warning)' },
      ].map(row => (
        <div key={row.label} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Icon icon={row.icon} size="lg" color={row.color} />
          <div>
            <div style={{ fontFamily: 'Poppins,sans-serif', fontSize: 14, fontWeight: 600, color: '#0d343f' }}>{row.label}</div>
            <div style={{ fontFamily: 'Poppins,sans-serif', fontSize: 12, color: '#6c7a8b' }}>{row.note}</div>
          </div>
        </div>
      ))}
    </div>
  ),
};
