import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { StepTracker, APPLICATION_STEPS } from './StepTracker';

const meta: Meta<typeof StepTracker> = {
  title:     'Avenews/Web/Portal/StepTracker',
  component: StepTracker,
  tags:      ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Seven-step application flow tracker. Shows done/current/future states with connecting lines and an optional progress bar. Used in the Application Portal to visualise progress through the financing application.',
      },
    },
  },
  argTypes: {
    current: { control: { type: 'range', min: 1, max: 7, step: 1 } },
    showBar: { control: 'boolean' },
  },
};

export default meta;
type Story = StoryObj<typeof StepTracker>;

export const Step1: Story = {
  args: { steps: APPLICATION_STEPS, current: 1 },
};

export const Step4Documents: Story = {
  name: 'Step 4 — Documents',
  args: { steps: APPLICATION_STEPS, current: 4 },
};

export const Step7Complete: Story = {
  name: 'Step 7 — Disbursal (final)',
  args: { steps: APPLICATION_STEPS, current: 7 },
};

export const NoProgressBar: Story = {
  args: { steps: APPLICATION_STEPS, current: 3, showBar: false },
};

export const CustomSteps: Story = {
  name: 'Custom steps (4-step)',
  args: {
    steps: [
      { id: 1, label: 'Identity' },
      { id: 2, label: 'Business' },
      { id: 3, label: 'Documents' },
      { id: 4, label: 'Review' },
    ],
    current: 2,
  },
};

export const AllStates: Story = {
  name: 'All states at a glance',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      {[1, 2, 3, 4, 5, 6, 7].map(step => (
        <StepTracker key={step} steps={APPLICATION_STEPS} current={step} showBar={false} />
      ))}
    </div>
  ),
};
