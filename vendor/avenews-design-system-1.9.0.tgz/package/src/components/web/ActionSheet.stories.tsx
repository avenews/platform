import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { ActionSheet } from './ActionSheet';

// ���── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof ActionSheet> = {
  title: 'Avenews/Web/ActionSheet',
  component: ActionSheet,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Bottom-anchored contextual menu for touch-friendly action lists. ' +
          'Supports header, subheader, icons, destructive and disabled buttons, ' +
          'and tap-outside dismiss.',
      },
    },
    layout: 'fullscreen',
  },
};

export default meta;
type Story = StoryObj<typeof ActionSheet>;

// ─── Helper trigger wrapper ───────────────────────────────────────────────────

const Trigger: React.FC<{
  label?: string;
  children: (open: boolean, setOpen: (v: boolean) => void) => React.ReactNode;
}> = ({ label = 'Open action sheet', children }) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const [open, setOpen] = useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, padding: 40 }}>
      <button
        style={{
          fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
          padding: '10px 20px', borderRadius: 8, border: 'none',
          background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer',
        }}
        onClick={() => setOpen(true)}
      >
        {label}
      </button>
      {children(open, setOpen)}
    </div>
  );
};

// ─── SVG icons ────────────────────────────────────────────────────────────────

const IconDownload: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const IconShare: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <circle cx="18" cy="5" r="3" stroke="currentColor" strokeWidth="2"/>
    <circle cx="6" cy="12" r="3" stroke="currentColor" strokeWidth="2"/>
    <circle cx="18" cy="19" r="3" stroke="currentColor" strokeWidth="2"/>
    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

const IconEdit: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const IconTrash: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <polyline points="3 6 5 6 21 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6M10 11v6M14 11v6M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// ─── Basic variants ───────────────────────────────────────────────────────────

export const SimpleList: Story = {
  name: 'Basic / Simple list',
  render: () => (
    <Trigger>
      {(open, setOpen) => (
        <ActionSheet
          open={open}
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Download', onClick: () => setOpen(false) },
            { text: 'Share',    onClick: () => setOpen(false) },
            { text: 'Cancel',   onClick: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

export const WithHeader: Story = {
  name: 'Basic / With header',
  render: () => (
    <Trigger>
      {(open, setOpen) => (
        <ActionSheet
          open={open}
          header="Document options"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Download', onClick: () => setOpen(false) },
            { text: 'Share',    onClick: () => setOpen(false) },
            { text: 'Cancel',   onClick: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

export const WithHeaderAndSubheader: Story = {
  name: 'Basic / Header + subheader',
  render: () => (
    <Trigger>
      {(open, setOpen) => (
        <ActionSheet
          open={open}
          header="Invoice_Q3_2024.pdf"
          subheader="Choose what to do with this document"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Download', onClick: () => setOpen(false) },
            { text: 'Share',    onClick: () => setOpen(false) },
            { text: 'Cancel',   onClick: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

// ─── With icons ───────────────────────────────────────────────────────────────

export const WithIcons: Story = {
  name: 'Feature / With icons',
  render: () => (
    <Trigger>
      {(open, setOpen) => (
        <ActionSheet
          open={open}
          header="Invoice options"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Download', icon: <IconDownload />, onClick: () => setOpen(false) },
            { text: 'Share',    icon: <IconShare />,    onClick: () => setOpen(false) },
            { text: 'Edit',     icon: <IconEdit />,     onClick: () => setOpen(false) },
            { text: 'Cancel',                           onClick: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

// ─── Destructive action ───────────────────────────────────────────────────────

export const WithDestructive: Story = {
  name: 'Feature / Destructive action',
  render: () => (
    <Trigger label="Open with destructive option">
      {(open, setOpen) => (
        <ActionSheet
          open={open}
          header="Document options"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Download', icon: <IconDownload />, onClick: () => setOpen(false) },
            { text: 'Share',    icon: <IconShare />,    onClick: () => setOpen(false) },
            { text: 'Delete',   icon: <IconTrash />,    onClick: () => setOpen(false), destructive: true },
            { text: 'Cancel',                           onClick: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

// ─── With disabled option ─────────────────────────────────────────────────────

export const WithDisabledOption: Story = {
  name: 'Feature / Disabled option',
  render: () => (
    <Trigger>
      {(open, setOpen) => (
        <ActionSheet
          open={open}
          header="Repayment options"
          subheader="Early repayment not yet available"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Schedule repayment', onClick: () => setOpen(false) },
            { text: 'Pay early',          onClick: () => setOpen(false), disabled: true },
            { text: 'Cancel',             onClick: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const DocumentActions: Story = {
  name: 'App / Document actions',
  render: () => (
    <Trigger label="Document options">
      {(open, setOpen) => (
        <ActionSheet
          open={open}
          header="Bank_Statement_Feb.pdf"
          subheader="Uploaded 14 Feb 2024"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'View document',  icon: <IconEdit />,     onClick: () => setOpen(false) },
            { text: 'Download',       icon: <IconDownload />, onClick: () => setOpen(false) },
            { text: 'Share',          icon: <IconShare />,    onClick: () => setOpen(false) },
            { text: 'Delete',         icon: <IconTrash />,    onClick: () => setOpen(false), destructive: true },
            { text: 'Cancel',                                 onClick: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

export const RepaymentOptions: Story = {
  name: 'App / Repayment options',
  render: () => (
    <Trigger label="Repayment options">
      {(open, setOpen) => (
        <ActionSheet
          open={open}
          header="Repayment — KES 12,500"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Pay now',          onClick: () => setOpen(false) },
            { text: 'Schedule payment', onClick: () => setOpen(false) },
            { text: 'Request extension', onClick: () => setOpen(false) },
            { text: 'Cancel',           onClick: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};
