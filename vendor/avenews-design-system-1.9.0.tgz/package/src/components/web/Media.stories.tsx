import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Avatar, Thumbnail, MediaIcon } from './Media';
import type { MediaIconColor, MediaIconSize } from './Media';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta = {
  title: 'Avenews/Web/Media',
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Three media primitives: **Avatar** (circular person image or initials), ' +
          '**Thumbnail** (square image tile), and **MediaIcon** (colour-tinted icon container). ' +
          'Used as start/end slots inside `Item` and `Card`.',
      },
    },
    layout: 'centered',
  },
};

export default meta;
type Story = StoryObj;

// ─── Shared icon ──────────────────────────────────────────────────────────────

const DocIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <polyline points="14 2 14 8 20 8"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const UserIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="12" cy="7" r="4"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const StarIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
  </svg>
);

// ═══════════════════════════════════════════════════════════════════════════════
// AVATAR
// ═══════════════════════════════════════════════════════════════════════════════

export const AvatarWithImage: Story = {
  name: 'Avatar / With image',
  render: () => (
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      <Avatar src="https://i.pravatar.cc/96?img=47" alt="Amara Kone" size="sm" />
      <Avatar src="https://i.pravatar.cc/96?img=12" alt="James Mwangi" size="md" />
      <Avatar src="https://i.pravatar.cc/96?img=33" alt="Fatima Diallo" size="lg" />
    </div>
  ),
};

export const AvatarInitials: Story = {
  name: 'Avatar / Initials',
  render: () => (
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      <Avatar initials="AK" size="sm" />
      <Avatar initials="JM" size="md" />
      <Avatar initials="FD" size="lg" />
    </div>
  ),
};

export const AvatarPlaceholder: Story = {
  name: 'Avatar / Placeholder (no src, no initials)',
  render: () => (
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      <Avatar size="sm" />
      <Avatar size="md" />
      <Avatar size="lg" />
    </div>
  ),
};

export const AvatarSizes: Story = {
  name: 'Avatar / All sizes',
  render: () => (
    <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end' }}>
      {(['sm', 'md', 'lg'] as const).map((s) => (
        <div key={s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <Avatar initials="JM" size={s} />
          <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 11, color: 'var(--av-color-text-muted)' }}>{s}</span>
        </div>
      ))}
    </div>
  ),
};

// ═══════════════════════════════════════════════════════════════════════════════
// THUMBNAIL
// ═══════════════════════════════════════════════════════════════════════════════

export const ThumbnailWithImage: Story = {
  name: 'Thumbnail / With image',
  render: () => (
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      <Thumbnail src="https://images.unsplash.com/photo-1545987796-200677ee1011?w=200&q=80" alt="Document" size="sm" />
      <Thumbnail src="https://images.unsplash.com/photo-1545987796-200677ee1011?w=200&q=80" alt="Document" size="md" />
      <Thumbnail src="https://images.unsplash.com/photo-1545987796-200677ee1011?w=200&q=80" alt="Document" size="lg" />
    </div>
  ),
};

export const ThumbnailPlaceholder: Story = {
  name: 'Thumbnail / Placeholder',
  render: () => (
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      <Thumbnail size="sm" />
      <Thumbnail size="md" />
      <Thumbnail size="lg" />
    </div>
  ),
};

export const ThumbnailSizes: Story = {
  name: 'Thumbnail / All sizes',
  render: () => (
    <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end' }}>
      {(['sm', 'md', 'lg'] as const).map((s) => (
        <div key={s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <Thumbnail size={s} />
          <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 11, color: 'var(--av-color-text-muted)' }}>{s}</span>
        </div>
      ))}
    </div>
  ),
};

// ═══════════════════════════════════════════════════════════════════════════════
// MEDIA ICON
// ═══════════════════════════════════════════════════════════════════════════════

const ICON_COLORS: MediaIconColor[] = [
  'primary', 'secondary', 'tertiary',
  'success', 'warning', 'danger',
  'medium', 'dark',
];

const ICON_SIZES: MediaIconSize[] = ['sm', 'default', 'lg'];

export const MediaIconDefault: Story = {
  name: 'MediaIcon / Default',
  render: () => <MediaIcon icon={<DocIcon />} color="primary" />,
};

export const MediaIconSizes: Story = {
  name: 'MediaIcon / Sizes',
  render: () => (
    <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end' }}>
      {ICON_SIZES.map((s) => (
        <div key={s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <MediaIcon icon={<DocIcon />} size={s} color="primary" />
          <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 11, color: 'var(--av-color-text-muted)' }}>{s}</span>
        </div>
      ))}
    </div>
  ),
};

export const MediaIconColors: Story = {
  name: 'MediaIcon / All colors',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
      {ICON_COLORS.map((c) => (
        <div key={c} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <MediaIcon icon={<DocIcon />} color={c} />
          <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 11, color: 'var(--av-color-text-muted)' }}>{c}</span>
        </div>
      ))}
    </div>
  ),
};

// ─── Combined app use-case ────────────────────────────────────────────────────

export const AppUsage: Story = {
  name: 'App / Media in context',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Person row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12,
        padding: '12px 16px', background: 'var(--av-color-surface)', borderRadius: 12 }}>
        <Avatar initials="AK" size="md" />
        <div>
          <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
            color: 'var(--av-color-text-body)' }}>Amara Kone</p>
          <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 12,
            color: 'var(--av-color-text-muted)' }}>Account manager</p>
        </div>
      </div>

      {/* Document row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12,
        padding: '12px 16px', background: 'var(--av-color-surface)', borderRadius: 12 }}>
        <MediaIcon icon={<DocIcon />} color="primary" />
        <div style={{ flex: 1 }}>
          <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
            color: 'var(--av-color-text-body)' }}>Bank Statement</p>
          <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 12,
            color: 'var(--av-color-text-muted)' }}>Feb 2024 · PDF</p>
        </div>
        <MediaIcon icon={<StarIcon />} color="warning" size="sm" />
      </div>
    </div>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 340, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
};
