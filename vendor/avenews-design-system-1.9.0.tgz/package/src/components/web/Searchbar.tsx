import React, { useEffect, useRef, useState } from 'react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';

export type SearchbarCancelButton = 'never' | 'focus' | 'always';
export type SearchbarClearButton  = 'never' | 'focus' | 'always';

export interface SearchbarProps {
  placeholder?:       string;
  value?:             string;
  debounce?:          number;
  showCancelButton?:  SearchbarCancelButton;
  showClearButton?:   SearchbarClearButton;
  disabled?:          boolean;
  loading?:           boolean;
  error?:             boolean;
  autoFocus?:         boolean;
  /** Accessible name, for when the searchbar has no visible label beside it. */
  ariaLabel?:         string;
  /** Renamed from onIonInput */
  onChange?:          (value: string) => void;
  /** Renamed from onIonClear */
  onClear?:           () => void;
  /** Renamed from onIonCancel */
  onCancel?:          () => void;
  className?:         string;
}


export const Searchbar: React.FC<SearchbarProps> = ({
  placeholder       = 'Search',
  value,
  debounce          = 300,
  showCancelButton  = 'focus',
  showClearButton   = 'focus',
  disabled          = false,
  loading           = false,
  error             = false,
  autoFocus         = false,
  ariaLabel,
  onChange,
  onClear,
  onCancel,
  className,
}) => {
  const [internal, setInternal] = useState(value ?? '');
  const [focused,  setFocused]  = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Sync the display buffer whenever the parent changes `value`, and cancel any
  // pending emission at the same time. Without the cancel, a controlled searchbar
  // silently undoes a programmatic clear: the user types, the parent's "Reset
  // filters" sets value to '', and the in-flight timer then fires ~debounce ms
  // later and re-emits the typed text, restoring the filter the reset removed.
  useEffect(() => {
    if (value === undefined) return;
    setInternal(value);
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
      debounceRef.current = null;
    }
  }, [value]);

  if (loading) {
    return <div className="av-searchbar av-searchbar--skeleton" aria-hidden="true" />;
  }

  // Always render from the local buffer, even when controlled. Rendering straight
  // from `value` made this a controlled input whose displayed text only caught up
  // after the debounce, so any unrelated re-render in that window reconciled the
  // field back to the stale prop and wiped what had just been typed.
  const current = internal;
  const showCancel = showCancelButton === 'always' || (showCancelButton === 'focus' && focused);
  const showClear  = (showClearButton === 'always' || (showClearButton === 'focus' && focused)) && current.length > 0;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = e.target.value;
    // Update the buffer synchronously so the field never lags a keystroke.
    setInternal(v);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (debounce <= 0) {
      debounceRef.current = null;
      onChange?.(v);
      return;
    }
    debounceRef.current = setTimeout(() => onChange?.(v), debounce);
  };

  const handleClear = () => {
    setInternal('');
    if (debounceRef.current) { clearTimeout(debounceRef.current); debounceRef.current = null; }
    onChange?.('');
    onClear?.();
    inputRef.current?.focus();
  };

  const handleCancel = () => {
    setInternal('');
    if (debounceRef.current) { clearTimeout(debounceRef.current); debounceRef.current = null; }
    onChange?.('');
    onCancel?.();
    setFocused(false);
    inputRef.current?.blur();
  };

  return (
    <div className={cn(
      'av-searchbar',
      focused  && 'av-searchbar--focused',
      error    && 'av-searchbar--error',
      disabled && 'av-searchbar--disabled',
      className,
    )}>
      <span className="av-searchbar__icon" aria-hidden="true"><Icon name="search" size={16} /></span>

      <input
        ref={inputRef}
        type="search"
        className="av-searchbar__input"
        placeholder={placeholder}
        value={current}
        disabled={disabled}
        autoFocus={autoFocus}
        aria-label={ariaLabel}
        onChange={handleChange}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
      />

      {showClear && (
        <button type="button" className="av-searchbar__clear" onClick={handleClear} aria-label="Clear search">
          ✕
        </button>
      )}

      {showCancel && (
        <button type="button" className="av-searchbar__cancel" onClick={handleCancel}>
          Cancel
        </button>
      )}
    </div>
  );
};

export default Searchbar;
