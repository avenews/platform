import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Modal } from './Modal';
import type { ModalVariant, ModalSize } from './Modal';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Modal> = {
  title: 'Avenews/Web/Modal',
  component: Modal,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Dialog and bottom-sheet overlay. ' +
          'Two variants (dialog / sheet), four sizes, toolbar-style header with optional left action, ' +
          'close button, custom footer, or auto-rendered confirm/cancel/destructive button row.',
      },
    },
    layout: 'fullscreen',
  },
};

export default meta;
type Story = StoryObj<typeof Modal>;

// ─── Helper trigger wrapper ────────────────────────────────────────────────────

const Trigger: React.FC<{
  label?: string;
  children: (open: boolean, setOpen: (v: boolean) => void) => React.ReactNode;
}> = ({ label = 'Open modal', children }) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const [open, setOpen] = useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, padding: 40 }}>
      <button
        style={{
          fontFamily:   'var(--av-font-body)',
          fontSize:     14,
          fontWeight:   600,
          padding:      '10px 20px',
          borderRadius: 8,
          border:       'none',
          background:   'var(--av-color-action)',
          color:        '#fff',
          cursor:       'pointer',
        }}
        onClick={() => setOpen(true)}
      >
        {label}
      </button>
      {children(open, setOpen)}
    </div>
  );
};

// ─── Dialog sizes ─────────────────────────────────────────────────────────────

export const SmallDialog: Story = {
  name: 'Dialog / Small',
  render: () => (
    <Trigger label="Open small dialog">
      {(open, setOpen) => (
        <Modal open={open} title="Confirm action" size="sm"
          buttons={[
            { text: 'Cancel',  role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Confirm', role: 'confirm', handler: () => setOpen(false) },
          ]}
          onDismiss={() => setOpen(false)}>
          <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-text-body)', margin: 0 }}>
            Are you sure you want to proceed?
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const DefaultDialog: Story = {
  name: 'Dialog / Default',
  render: () => (
    <Trigger label="Open default dialog">
      {(open, setOpen) => (
        <Modal open={open} title="Fund request details" closeButton
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Cancel', role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Submit', role: 'confirm', handler: () => setOpen(false) },
          ]}>
          <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-text-body)', margin: 0 }}>
            Review your fund request details before submitting. Once submitted, changes cannot be made.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const LargeDialog: Story = {
  name: 'Dialog / Large',
  render: () => (
    <Trigger label="Open large dialog">
      {(open, setOpen) => (
        <Modal open={open} title="Terms & Conditions" size="lg" closeButton
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Decline', role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Accept',  role: 'confirm', handler: () => setOpen(false) },
          ]}>
          <div style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-text-body)',
            display: 'flex', flexDirection: 'column', gap: 12 }}>
            <p style={{ margin: 0 }}>By accepting these terms you agree to the Avenews lending agreement.</p>
            <p style={{ margin: 0 }}>Repayments are due on the agreed schedule. Late payments may incur additional fees.</p>
            <p style={{ margin: 0 }}>You have the right to repay early without penalty.</p>
          </div>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── Toolbar-style header ─────────────────────────────────────────────────────

export const ToolbarHeader: Story = {
  name: 'Dialog / Toolbar header (left action)',
  render: () => (
    <Trigger label="Open toolbar modal">
      {(open, setOpen) => (
        <Modal open={open} title="Select document"
          leftAction={{ text: 'Cancel', handler: () => setOpen(false) }}
          onDismiss={() => setOpen(false)}>
          <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-text-body)', margin: 0 }}>
            Choose a document to attach to this request.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── Destructive action ───────────────────────────────────────────────────────

export const DestructiveAction: Story = {
  name: 'Dialog / Destructive action (stacked)',
  render: () => (
    <Trigger label="Open delete confirmation">
      {(open, setOpen) => (
        <Modal open={open} title="Delete document?"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Delete',     role: 'destructive', handler: () => setOpen(false) },
            { text: 'Keep file',  role: 'cancel',      handler: () => setOpen(false) },
          ]}>
          <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-text-body)', margin: 0 }}>
            This will permanently remove Invoice_Q3.pdf from your account.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── Bottom sheet ─────────────────────────────────────────────────────────────

export const BottomSheet: Story = {
  name: 'Sheet / Default',
  render: () => (
    <Trigger label="Open bottom sheet">
      {(open, setOpen) => (
        <Modal open={open} variant="sheet" title="Filter documents" showHandle
          closeButton onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Clear filters', role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Apply',         role: 'confirm', handler: () => setOpen(false) },
          ]}>
          <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-text-body)', margin: 0 }}>
            Filter by status, date, and document type.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const FullSheet: Story = {
  name: 'Sheet / Full-height',
  render: () => (
    <Trigger label="Open full sheet">
      {(open, setOpen) => (
        <Modal open={open} variant="sheet" size="full" title="Document viewer"
          leftAction={{ text: 'Close', handler: () => setOpen(false) }}
          onDismiss={() => setOpen(false)}>
          <div style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-text-muted)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 200 }}>
            Document preview content
          </div>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const RepaymentConfirmation: Story = {
  name: 'App / Repayment confirmation',
  render: () => (
    <Trigger label="Confirm repayment">
      {(open, setOpen) => (
        <Modal open={open} title="Confirm repayment" size="sm"
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Cancel',  role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Pay now', role: 'confirm', handler: () => setOpen(false) },
          ]}>
          <div style={{ fontFamily: 'var(--av-font-body)', fontSize: 14,
            color: 'var(--av-color-text-body)', display: 'flex', flexDirection: 'column', gap: 8 }}>
            <p style={{ margin: 0 }}>You are about to pay:</p>
            <p style={{ margin: 0, fontWeight: 600, fontSize: 20, color: 'var(--av-color-action)' }}>KES 12,500</p>
            <p style={{ margin: 0, color: 'var(--av-color-text-muted)' }}>Loan ref: AVN-2024-00123</p>
          </div>
        </Modal>
      )}
    </Trigger>
  ),
};
