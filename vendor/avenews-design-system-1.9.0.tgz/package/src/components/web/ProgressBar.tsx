import React from 'react';
import { cn } from '../shared/utils';

// ─── Types ────────────────────────────────────────────────────────────────────

export type ProgressBarColor =
  | 'primary' | 'secondary'
  | 'success' | 'warning'  | 'danger';

export type ProgressBarSize  = 'sm' | 'md' | 'lg';
export type ProgressBarStyle = 'default' | 'segmented';

export interface ProgressBarSegment {
  label:  string;
  value:  number;   // 0–100
  color?: ProgressBarColor;
}

export interface ProgressBarProps {
  /** 0–100 */
  value?:         number;
  indeterminate?: boolean;
  color?:         ProgressBarColor;
  size?:          ProgressBarSize;
  /** Visible label above the bar */
  label?:         string;
  /** Show numeric percentage to the right of label */
  showValue?:     boolean;
  /** Divide track into N equal segments */
  segments?:      number;
  /** Explicit segment data — overrides `segments` */
  segmentData?:   ProgressBarSegment[];
  className?:     string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value         = 0,
  indeterminate = false,
  color         = 'primary',
  size          = 'md',
  label,
  showValue     = false,
  segments,
  segmentData,
  className,
}) => {
  const pct   = Math.min(100, Math.max(0, value));
  const isSegmented = Boolean(segments || segmentData);

  const rootCls = cn(
    'av-progress-bar',
    `av-progress-bar--${color}`,
    `av-progress-bar--${size}`,
    indeterminate   && 'av-progress-bar--indeterminate',
    isSegmented     && 'av-progress-bar--segmented',
    className,
  );

  // ── Segmented rendering ───────────────────────────────────────────────────

  if (isSegmented) {
    const segs: ProgressBarSegment[] = segmentData
      ?? Array.from({ length: segments! }, (_, i) => ({
           label: `Step ${i + 1}`,
           value: pct > (i / segments!) * 100 ? 100 : 0,
         }));

    return (
      <div className={rootCls} role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        {(label || showValue) && (
          <div className="av-progress-bar__header">
            {label && <span className="av-progress-bar__label">{label}</span>}
            {showValue && <span className="av-progress-bar__value">{pct}%</span>}
          </div>
        )}
        <div className="av-progress-bar__segments">
          {segs.map((seg, i) => (
            <div
              key={i}
              className={cn(
                'av-progress-bar__segment',
                seg.color && `av-progress-bar--${seg.color}`,
                seg.value > 0 && 'av-progress-bar__segment--active',
              )}
            >
              <div
                className="av-progress-bar__segment-fill"
                style={{ transform: `scaleX(${seg.value / 100})` }}
              />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ── Default / indeterminate ───────────────────────────────────────────────

  return (
    <div
      className={rootCls}
      role="progressbar"
      aria-valuenow={!indeterminate ? pct          : undefined}
      aria-valuemin={!indeterminate ? 0            : undefined}
      aria-valuemax={!indeterminate ? 100          : undefined}
      aria-label={label ?? 'Progress'}
      aria-busy={indeterminate || undefined}
    >
      {(label || showValue) && (
        <div className="av-progress-bar__header">
          {label     && <span className="av-progress-bar__label">{label}</span>}
          {showValue && !indeterminate && <span className="av-progress-bar__value">{pct}%</span>}
        </div>
      )}

      <div className="av-progress-bar__track">
        <div
          className="av-progress-bar__fill"
          style={!indeterminate ? { width: `${pct}%` } : undefined}
        />
      </div>
    </div>
  );
};

export default ProgressBar;
