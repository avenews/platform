import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Accordion } from './Accordion';
import type { AccordionItem } from './Accordion';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Accordion> = {
  title: 'Avenews/Web/Accordion',
  component: Accordion,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Expandable panel group for progressive disclosure. ' +
          'Supports single or multi-expand, controlled and uncontrolled modes, ' +
          'left-arrow variant, and per-item disabled state.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Accordion>;

// ─── Sample data ──────────────────────────────────────────────────────────────

const FAQ_ITEMS: AccordionItem[] = [
  {
    value:   'what',
    label:   'What is Avenews?',
    content: (
      <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 14,
        color: 'var(--av-color-text-body)', lineHeight: 1.6 }}>
        Avenews is a fintech platform providing working capital and financial tools
        to agricultural businesses across Africa.
      </p>
    ),
  },
  {
    value:   'apply',
    label:   'How do I apply for a loan?',
    content: (
      <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 14,
        color: 'var(--av-color-text-body)', lineHeight: 1.6 }}>
        Complete your profile, upload the required KYC documents, and submit a
        fund request. Our team will review within 2 business days.
      </p>
    ),
  },
  {
    value:   'repay',
    label:   'When are repayments due?',
    content: (
      <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 14,
        color: 'var(--av-color-text-body)', lineHeight: 1.6 }}>
        Repayments follow the schedule agreed at origination. You can view your
        full schedule in the Repayments section of your account.
      </p>
    ),
  },
];

const DOC_ITEMS: AccordionItem[] = [
  {
    value: 'bank',
    label: 'Bank statement requirements',
    content: (
      <ul style={{ margin: 0, padding: '0 0 0 16px', fontFamily: 'var(--av-font-body)',
        fontSize: 14, color: 'var(--av-color-text-body)', lineHeight: 1.8 }}>
        <li>Last 3 months of statements</li>
        <li>Must show business account transactions</li>
        <li>PDF or clear image accepted</li>
      </ul>
    ),
  },
  {
    value: 'id',
    label: 'Director ID requirements',
    content: (
      <ul style={{ margin: 0, padding: '0 0 0 16px', fontFamily: 'var(--av-font-body)',
        fontSize: 14, color: 'var(--av-color-text-body)', lineHeight: 1.8 }}>
        <li>National ID or passport</li>
        <li>Certified copy required</li>
        <li>Must not be expired</li>
      </ul>
    ),
  },
  {
    value: 'reg',
    label: 'Business registration',
    content: (
      <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 14,
        color: 'var(--av-color-text-body)', lineHeight: 1.6 }}>
        Certificate of incorporation or business registration. Must match the
        legal name on your application.
      </p>
    ),
    disabled: true,
  },
];

// ─── Default (single expand) ──────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (single expand)',
  render: () => <Accordion items={FAQ_ITEMS} />,
};

// ─── Multiple expand ──────────────────────────────────────────────────────────

export const MultipleExpand: Story = {
  name: 'Feature / Multi-expand',
  render: () => <Accordion items={FAQ_ITEMS} multiple />,
};

// ─── Left arrow variant ────────────────────────────────────────────────────────

export const LeftArrow: Story = {
  name: 'Feature / Left arrow',
  render: () => (
    <Accordion items={FAQ_ITEMS.map((i) => ({ ...i, leftArrow: true }))} />
  ),
};

// ─── Pre-opened ───────────────────────────────────────────────────────────────

export const PreOpened: Story = {
  name: 'Feature / Pre-opened',
  render: () => <Accordion items={FAQ_ITEMS} value="what" />,
};

export const MultiplePreOpened: Story = {
  name: 'Feature / Multiple pre-opened',
  render: () => <Accordion items={FAQ_ITEMS} multiple value={['what', 'apply']} />,
};

// ─── With disabled item ───────────────────────────────────────────────────────

export const WithDisabledItem: Story = {
  name: 'State / Disabled item',
  render: () => <Accordion items={DOC_ITEMS} />,
};

// ─── Controlled ──────────────────────────────────────────────────────────────

export const Controlled: Story = {
  name: 'Feature / Controlled (external state)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState<string | undefined>('what');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          {FAQ_ITEMS.map((item) => (
            <button key={item.value}
              style={{
                fontFamily: 'var(--av-font-body)', fontSize: 12,
                padding: '4px 10px', borderRadius: 6, cursor: 'pointer',
                border: `1px solid ${open === item.value ? 'var(--av-color-action)' : 'var(--av-color-border)'}`,
                background: open === item.value ? 'var(--av-color-action)' : 'transparent',
                color: open === item.value ? '#fff' : 'var(--av-color-text-body)',
              }}
              onClick={() => setOpen(open === item.value ? undefined : item.value)}>
              {item.value}
            </button>
          ))}
        </div>
        <Accordion items={FAQ_ITEMS} value={open} onChange={(v) => setOpen(v as string)} />
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const FaqSection: Story = {
  name: 'App / FAQ section',
  render: () => (
    <div>
      <h2 style={{ fontFamily: 'var(--av-font-heading)', fontSize: 20, fontWeight: 700,
        color: 'var(--av-color-text-heading)', marginBottom: 12, marginTop: 0 }}>
        Frequently asked questions
      </h2>
      <Accordion items={FAQ_ITEMS} />
    </div>
  ),
};

export const DocumentGuide: Story = {
  name: 'App / Document requirements guide',
  render: () => (
    <div>
      <h2 style={{ fontFamily: 'var(--av-font-heading)', fontSize: 20, fontWeight: 700,
        color: 'var(--av-color-text-heading)', marginBottom: 12, marginTop: 0 }}>
        Required documents
      </h2>
      <Accordion items={DOC_ITEMS} multiple />
    </div>
  ),
};
