import React from 'react';
import { cn } from '../shared/utils';

export type ProgressType  = 'determinate' | 'indeterminate' | 'buffer';
export type ProgressColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

export interface ProgressTrackerProps {
  /** 0–1 for determinate */
  value?:    number;
  /** 0–1 buffer fill — only for type 'buffer' */
  buffer?:   number;
  type?:     ProgressType;
  color?:    ProgressColor;
  reversed?: boolean;
  /** Shorthand for type='indeterminate' */
  loading?:  boolean;
  /** Shorthand for color='danger' + value=1 */
  error?:    boolean;
  className?: string;
}

export const ProgressTracker: React.FC<ProgressTrackerProps> = ({
  value    = 0,
  buffer   = 0,
  type     = 'determinate',
  color    = 'primary',
  reversed = false,
  loading  = false,
  error    = false,
  className,
}) => {
  const resolvedType:  ProgressType  = loading ? 'indeterminate' : type;
  const resolvedColor: ProgressColor = error   ? 'danger'        : color;
  const resolvedValue = error ? 1 : Math.min(1, Math.max(0, value));
  const pct = Math.round(resolvedValue * 100);

  const trackCls = cn(
    'av-progress',
    `av-progress--${resolvedColor}`,
    resolvedType === 'indeterminate' && 'av-progress--indeterminate',
    resolvedType === 'buffer'        && 'av-progress--buffer',
    reversed                         && 'av-progress--reversed',
    className,
  );

  return (
    <div
      className={trackCls}
      role="progressbar"
      aria-valuenow={resolvedType === 'determinate' ? pct          : undefined}
      aria-valuemin={resolvedType === 'determinate' ? 0            : undefined}
      aria-valuemax={resolvedType === 'determinate' ? 100          : undefined}
      aria-label="Progress"
    >
      {/* Buffer fill (behind the main fill) */}
      {resolvedType === 'buffer' && (
        <div
          className="av-progress__buffer"
          style={{ transform: `scaleX(${buffer})`, transformOrigin: reversed ? 'right' : 'left' }}
        />
      )}

      {/* Main fill */}
      {resolvedType !== 'indeterminate' && (
        <div
          className="av-progress__fill"
          style={{
            transform:       `scaleX(${resolvedValue})`,
            transformOrigin: reversed ? 'right' : 'left',
          }}
        />
      )}

      {/* Indeterminate animation bar */}
      {resolvedType === 'indeterminate' && (
        <div className="av-progress__indeterminate" />
      )}
    </div>
  );
};

export default ProgressTracker;
