import React from 'react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';
import type { IconName } from './Icon';

export interface SidebarNavItem {
  id:          string;
  label:       string;
  /** Back-compat: in-house catalog name */
  icon?:       IconName;
  /** Preferred: Lucide icon component — `import { Home } from 'lucide-react'` */
  lucideIcon?: LucideIcon;
  href?:       string;
  badge?:  number;
}

export interface SidebarProps {
  /** Nav items rendered in the main nav section */
  navItems:    SidebarNavItem[];
  /** Active nav item id */
  activeId?:   string;
  /** Footer nav items (settings, sign-out etc.) */
  footerItems?: SidebarNavItem[];
  /** Logo src — defaults to the Avenews wordmark */
  logoSrc?:    string;
  logoAlt?:    string;
  onNavigate?: (id: string) => void;
  className?:  string;
}

const NavItem: React.FC<{
  item:     SidebarNavItem;
  isActive: boolean;
  onClick:  (id: string) => void;
}> = ({ item, isActive, onClick }) => (
  <button
    type="button"
    className={cn('ap-nav-item', isActive && 'is-active')}
    onClick={() => onClick(item.id)}
    aria-current={isActive ? 'page' : undefined}
  >
    <Icon lucideIcon={item.lucideIcon} name={item.icon} size={20} aria-hidden />
    <span>{item.label}</span>
    {item.badge != null && item.badge > 0 && (
      <span
        className="av-badge av-badge--danger"
        style={{ marginLeft: 'auto', borderRadius: '999px', height: '18px', padding: '0 6px', fontSize: '10px' }}
        aria-label={`${item.badge} notifications`}
      >
        {item.badge > 99 ? '99+' : item.badge}
      </span>
    )}
  </button>
);

export const Sidebar: React.FC<SidebarProps> = ({
  navItems,
  activeId,
  footerItems = [],
  logoSrc     = '/avenews-logo-new.svg',
  logoAlt     = 'Avenews',
  onNavigate  = () => {},
  className,
}) => (
  <aside className={cn('ap-sidebar', className)}>
    <div className="ap-sidebar__logo">
      <img src={logoSrc} alt={logoAlt} />
    </div>

    <nav className="ap-sidebar__nav" aria-label="Main navigation">
      {navItems.map(item => (
        <NavItem
          key={item.id}
          item={item}
          isActive={item.id === activeId}
          onClick={onNavigate}
        />
      ))}
    </nav>

    {footerItems.length > 0 && (
      <div className="ap-sidebar__foot">
        {footerItems.map(item => (
          <NavItem
            key={item.id}
            item={item}
            isActive={item.id === activeId}
            onClick={onNavigate}
          />
        ))}
      </div>
    )}
  </aside>
);

export const DEFAULT_NAV_ITEMS: SidebarNavItem[] = [
  { id: 'dashboard',    label: 'Dashboard',       icon: 'home' },
  { id: 'application',  label: 'My application',  icon: 'document' },
  { id: 'documents',    label: 'Documents',        icon: 'attach' },
  { id: 'transactions', label: 'Transactions',     icon: 'wallet' },
  { id: 'reports',      label: 'Reports',          icon: 'bar-chart' },
];

export const DEFAULT_FOOTER_ITEMS: SidebarNavItem[] = [
  { id: 'settings',  label: 'Settings',  icon: 'settings' },
  { id: 'sign-out',  label: 'Sign out',  icon: 'share' },
];

export default Sidebar;
