import React from 'react';
import { cn } from '../shared/utils';

export type NoteColor =
  | 'default'
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

export type NoteAlign = 'left' | 'center' | 'right';

export interface NoteProps {
  label:      string;
  color?:     NoteColor;
  /** Horizontal text alignment — useful in full-width stacked contexts */
  align?:     NoteAlign;
  className?: string;
}

export const Note: React.FC<NoteProps> = ({
  label,
  color     = 'default',
  align     = 'left',
  className,
}) => (
  <span
    className={cn(
      'av-note',
      color !== 'default' && `av-note--${color}`,
      align !== 'left'    && `av-note--align-${align}`,
      className,
    )}
  >
    {label}
  </span>
);

export default Note;
