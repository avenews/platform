import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Checkbox } from './Checkbox';
import type { CheckboxColor } from './Checkbox';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Checkbox> = {
  title: 'Avenews/Web/Checkbox',
  component: Checkbox,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Accessible checkbox with optional label, indeterminate state, and 11 colour tokens. ' +
          'Supports three label placements and two justify modes for list item layouts.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 320, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color: {
      control: 'select',
      options: [
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark', 'white', 'black',
      ] satisfies CheckboxColor[],
    },
    labelPlacement: {
      control: 'radio',
      options: ['start', 'end', 'stacked'],
    },
    justify: {
      control: 'radio',
      options: ['space-between', 'start', 'end'],
    },
    checked:       { control: 'boolean' },
    indeterminate: { control: 'boolean' },
    disabled:      { control: 'boolean' },
    label:         { control: 'text' },
  },
  args: {
    color:          'primary',
    labelPlacement: 'start',
    justify:        'space-between',
    checked:        false,
    indeterminate:  false,
    disabled:       false,
    label:          'Accept terms',
  },
};

export default meta;
type Story = StoryObj<typeof Checkbox>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { label: 'Accept terms', checked: false },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const Checked: Story = {
  name: 'State / Checked',
  args: { label: 'Accepted', checked: true },
};

export const Unchecked: Story = {
  name: 'State / Unchecked',
  args: { label: 'Not accepted', checked: false },
};

export const Indeterminate: Story = {
  name: 'State / Indeterminate',
  args: { label: 'Some selected', indeterminate: true },
};

export const Disabled: Story = {
  name: 'State / Disabled (unchecked)',
  args: { label: 'Locked option', checked: false, disabled: true },
};

export const DisabledChecked: Story = {
  name: 'State / Disabled (checked)',
  args: { label: 'Locked option', checked: true, disabled: true },
};

export const Standalone: Story = {
  name: 'State / Standalone (no label)',
  args: { checked: false },
};

// ─── Label placements ─────────────────────────────────────────────────────────

export const LabelStart: Story = {
  name: 'Label / Start (default)',
  args: { label: 'Label at start', labelPlacement: 'start' },
};

export const LabelEnd: Story = {
  name: 'Label / End',
  args: { label: 'Label at end', labelPlacement: 'end', justify: 'start' },
};

export const LabelStacked: Story = {
  name: 'Label / Stacked',
  args: { label: 'Stacked label', labelPlacement: 'stacked' },
};

// ─── All colours ──────────────────────────────────────────────────────────────

const COLORS: CheckboxColor[] = [
  'primary', 'secondary', 'tertiary',
  'success', 'warning', 'danger',
  'medium', 'dark',
];

export const AllColors: Story = {
  name: 'Colors / All',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      {COLORS.map((c) => <Checkbox key={c} label={c} checked color={c} />)}
    </div>
  ),
};

// ─── Interactive list ─────────────────────────────────────────────────────────

const DOC_OPTIONS = [
  'Proof of business registration',
  'Latest bank statement (3 months)',
  'Signed director ID copy',
  'Tax compliance certificate',
];

export const SelectableList: Story = {
  name: 'App / Selectable document list',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [selected, setSelected] = useState<string[]>([]);
    const toggle = (item: string) =>
      setSelected((s) => s.includes(item) ? s.filter((x) => x !== item) : [...s, item]);

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        {DOC_OPTIONS.map((doc) => (
          <Checkbox
            key={doc}
            label={doc}
            checked={selected.includes(doc)}
            onChange={() => toggle(doc)}
          />
        ))}
        <p style={{ margin: '12px 0 0', fontFamily: 'var(--av-font-body)', fontSize: 12, color: 'var(--av-color-text-muted)' }}>
          {selected.length} of {DOC_OPTIONS.length} selected
        </p>
      </div>
    );
  },
};

export const SelectAll: Story = {
  name: 'App / Select-all with indeterminate',
  render: () => {
    const ITEMS = ['Invoice A', 'Invoice B', 'Invoice C'];
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [checked, setChecked] = useState<boolean[]>(ITEMS.map(() => false));
    const allOn  = checked.every(Boolean);
    const someOn = checked.some(Boolean) && !allOn;

    const toggleAll = () => setChecked(ITEMS.map(() => !allOn));

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <Checkbox
          label="Select all"
          checked={allOn}
          indeterminate={someOn}
          onChange={toggleAll}
        />
        <div style={{ paddingLeft: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
          {ITEMS.map((item, i) => (
            <Checkbox
              key={item} label={item} checked={checked[i]}
              onChange={(v) => setChecked((c) => c.map((x, j) => j === i ? v : x))}
            />
          ))}
        </div>
      </div>
    );
  },
};
