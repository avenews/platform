import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { RadioGroup, Radio } from './Radio';
import type { RadioColor, RadioLayout } from './Radio';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof RadioGroup> = {
  title: 'Avenews/Web/Radio',
  component: RadioGroup,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Accessible radio group with stacked and inline layouts, optional descriptions, ' +
          '9 colour tokens, error state, helper/error text, and disabled support per-option or at group level.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color: {
      control: 'select',
      options: [
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark',
      ] satisfies RadioColor[],
    },
    layout: {
      control: 'radio',
      options: ['stacked', 'inline'] satisfies RadioLayout[],
    },
    disabled: { control: 'boolean' },
    error:    { control: 'boolean' },
  },
  args: {
    name:   'demo',
    color:  'primary',
    layout: 'stacked',
  },
};

export default meta;
type Story = StoryObj<typeof RadioGroup>;

// ─── Shared options ────────────────────────────────────────────────────────────

const LOAN_OPTIONS = [
  { value: 'working-capital', label: 'Working capital' },
  { value: 'invoice',         label: 'Invoice financing' },
  { value: 'asset',           label: 'Asset finance' },
];

const TENURE_OPTIONS = [
  { value: '3m',  label: '3 months' },
  { value: '6m',  label: '6 months' },
  { value: '12m', label: '12 months' },
  { value: '24m', label: '24 months' },
];

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: {
    name:    'loan-type',
    options: LOAN_OPTIONS,
    value:   'working-capital',
    label:   'Loan type',
  },
};

// ─── Layouts ──────────────────────────────────────────────────────────────────

export const LayoutStacked: Story = {
  name: 'Layout / Stacked',
  args: {
    name:    'tenure',
    options: TENURE_OPTIONS,
    value:   '6m',
    layout:  'stacked',
    label:   'Loan tenure',
  },
};

export const LayoutInline: Story = {
  name: 'Layout / Inline',
  args: {
    name:    'tenure-inline',
    options: TENURE_OPTIONS,
    value:   '12m',
    layout:  'inline',
    label:   'Loan tenure',
  },
};

// ─── With descriptions ────────────────────────────────────────────────────────

export const WithDescriptions: Story = {
  name: 'Feature / With descriptions',
  args: {
    name:   'loan-desc',
    layout: 'stacked',
    label:  'Select loan product',
    value:  'working-capital',
    options: [
      {
        value:       'working-capital',
        label:       'Working capital',
        description: 'Short-term funding for day-to-day operations',
      },
      {
        value:       'invoice',
        label:       'Invoice financing',
        description: 'Advance against outstanding invoices',
      },
      {
        value:       'asset',
        label:       'Asset finance',
        description: 'Purchase equipment, vehicles, or machinery',
      },
    ],
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateNone: Story = {
  name: 'State / No selection',
  args: {
    name:    'unselected',
    options: LOAN_OPTIONS,
    value:   undefined,
    label:   'Loan type',
  },
};

export const StateDisabledGroup: Story = {
  name: 'State / Disabled group',
  args: {
    name:     'disabled-group',
    options:  LOAN_OPTIONS,
    value:    'working-capital',
    disabled: true,
    label:    'Loan type (disabled)',
  },
};

export const StateDisabledOption: Story = {
  name: 'State / Disabled option',
  args: {
    name:  'partial-disabled',
    label: 'Loan type',
    value: 'working-capital',
    options: [
      { value: 'working-capital', label: 'Working capital' },
      { value: 'invoice',         label: 'Invoice financing', disabled: true },
      { value: 'asset',           label: 'Asset finance' },
    ],
  },
};

export const StateError: Story = {
  name: 'State / Error',
  args: {
    name:      'error-group',
    options:   LOAN_OPTIONS,
    error:     true,
    errorText: 'Please select a loan type to continue.',
    label:     'Loan type',
  },
};

export const StateWithHelper: Story = {
  name: 'State / Helper text',
  args: {
    name:       'helper-group',
    options:    LOAN_OPTIONS,
    value:      'invoice',
    helperText: 'Your selection determines the available loan amounts.',
    label:      'Loan type',
  },
};

// ─── Colors ───────────────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'Color / All colors',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      {(
        ['primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'medium', 'dark'] as RadioColor[]
      ).map((color) => (
        <RadioGroup
          key={color}
          name={`color-${color}`}
          color={color}
          value="a"
          options={[
            { value: 'a', label: color.charAt(0).toUpperCase() + color.slice(1) },
            { value: 'b', label: 'Unselected option' },
          ]}
        />
      ))}
    </div>
  ),
};

// ─── Interactive ──────────────────────────────────────────────────────────────

export const Interactive: Story = {
  name: 'Interactive / Controlled',
  render: () => {
    const [val, setVal] = useState('working-capital');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <RadioGroup
          name="interactive"
          label="Loan type"
          helperText="Selection updates live."
          options={LOAN_OPTIONS}
          value={val}
          onChange={setVal}
        />
        <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 13, color: 'var(--av-color-text-muted)', margin: 0 }}>
          Selected: <strong style={{ color: 'var(--av-color-text)' }}>{val}</strong>
        </p>
      </div>
    );
  },
};

// ─── Single Radio ─────────────────────────────────────────────────────────────

export const SingleRadio: Story = {
  name: 'Single / Radio item',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <Radio name="single" value="a" label="Unselected" />
      <Radio name="single" value="b" label="Selected"  checked />
      <Radio name="single" value="c" label="Disabled"  disabled />
      <Radio name="single" value="d" label="Error"     error />
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanApplication: Story = {
  name: 'App / Loan application',
  render: () => {
    const [product, setProduct] = useState('working-capital');
    const [tenure,  setTenure]  = useState('12m');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        <RadioGroup
          name="product"
          label="Loan product"
          helperText="Select the product that best fits your need."
          value={product}
          onChange={setProduct}
          options={[
            { value: 'working-capital', label: 'Working capital',  description: 'Short-term operational funding' },
            { value: 'invoice',         label: 'Invoice financing', description: 'Advance against outstanding invoices' },
            { value: 'asset',           label: 'Asset finance',     description: 'Equipment or vehicle purchases' },
          ]}
        />
        <RadioGroup
          name="tenure"
          label="Loan tenure"
          value={tenure}
          onChange={setTenure}
          layout="inline"
          options={TENURE_OPTIONS}
        />
      </div>
    );
  },
};

export const AppKycConsent: Story = {
  name: 'App / KYC consent',
  render: () => {
    const [consent, setConsent] = useState<string | undefined>(undefined);
    return (
      <RadioGroup
        name="kyc-consent"
        label="Identity verification consent"
        error={consent === undefined}
        errorText="You must provide consent to continue."
        helperText="Avenews will verify your identity using government-issued documents."
        value={consent}
        onChange={setConsent}
        options={[
          { value: 'yes', label: 'I consent to identity verification' },
          { value: 'no',  label: 'I do not consent', disabled: true },
        ]}
      />
    );
  },
};
