import React, { useRef } from 'react';
import type { UploadCardProps, UploadStatus } from '../shared/types';
import { cn, formatFileSize, clamp, uploadStatusLabel } from '../shared/utils';
import { Icon } from './Icon';

export type { UploadCardProps, UploadStatus };

// ─── Badge icon per status ────────────────────────────────────────────────────

const StatusIcon: React.FC<{ status: UploadStatus }> = ({ status }) => {
  if (status === 'uploading') return <span className="av-upload-card__spinner" />;
  if (status === 'uploaded' || status === 'approved') return <Icon name="checkmark" size={12} aria-hidden />;
  if (status === 'rejected') return <Icon name="warning" size={12} aria-hidden />;
  return null;
};


// ─── Component ────────────────────────────────────────────────────────────────

export const UploadCard: React.FC<UploadCardProps> = ({
  title,
  status   = 'empty',
  fileName,
  fileSize,
  progress = 0,
  required = false,
  disabled = false,
  accept   = '*/*',
  onUpload,
  onRemove,
  className,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pct = Math.round(clamp(progress, 0, 1) * 100);

  const openPicker = () => {
    if (disabled || status === 'uploading' || status === 'approved') return;
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) onUpload?.(file);
    e.target.value = '';
  };

  const showZone     = status === 'empty' || status === 'rejected';
  const showProgress = status === 'uploading';
  const showFile     = (status === 'uploaded' || status === 'approved' || status === 'rejected') && !!fileName;

  return (
    <div
      className={cn(
        'av-upload-card',
        `av-upload-card--${status}`,
        disabled && 'av-upload-card--disabled',
        className,
      )}
      role="region"
      aria-label={title}
    >
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <div className="av-upload-card__header">
        <span className="av-upload-card__title">
          {title}
          {required && <span className="av-upload-card__required" aria-hidden="true">{'\u200A'}*</span>}
        </span>
        <span className={cn('av-upload-card__badge', `av-upload-card__badge--${status}`)}>
          <StatusIcon status={status} />
          {uploadStatusLabel(status, required)}
        </span>
      </div>

      {/* ── Body ────────────────────────────────────────────────────────── */}
      <div className="av-upload-card__body">

        {/* Empty / rejected — upload zone ─────────────────────────────── */}
        {showZone && (
          <button
            type="button"
            className="av-upload-zone"
            onClick={openPicker}
            disabled={disabled}
            aria-label={`Upload ${title}`}
          >
            <span className="av-upload-zone__icon"><Icon name="upload" size={28} aria-hidden /></span>
            <span className="av-upload-zone__label">
              {status === 'rejected' ? 'Re-upload document' : 'Tap to upload'}
            </span>
            <span className="av-upload-zone__hint">PDF, JPG, PNG — max 10 MB</span>
          </button>
        )}

        {/* Uploading — progress ────────────────────────────────────────── */}
        {showProgress && (
          <div className="av-upload-progress">
            <div className="av-upload-progress__row">
              <span className="av-upload-card__spinner" aria-hidden="true" />
              <span className="av-upload-progress__name">{fileName ?? 'Uploading…'}</span>
              <span className="av-upload-progress__pct">{pct}%</span>
            </div>
            <div
              className="av-upload-progress__track"
              role="progressbar"
              aria-valuenow={pct}
              aria-valuemin={0}
              aria-valuemax={100}
            >
              <div className="av-upload-progress__fill" style={{ width: `${pct}%` }} />
            </div>
          </div>
        )}

        {/* File info ───────────────────────────────────────────────────── */}
        {showFile && (
          <div className="av-upload-file">
            <span className="av-upload-file__icon"><Icon name="document" size={20} aria-hidden /></span>
            <div className="av-upload-file__meta">
              <span className="av-upload-file__name">{fileName}</span>
              {fileSize != null && (
                <span className="av-upload-file__size">{formatFileSize(fileSize)}</span>
              )}
            </div>
            {onRemove && status !== 'approved' && (
              <button
                type="button"
                className="av-upload-file__remove"
                onClick={onRemove}
                aria-label="Remove file"
              >
                <Icon name="trash" size={16} aria-hidden />
              </button>
            )}
          </div>
        )}

        {/* Rejected — replace action ───────────────────────────────────── */}
        {status === 'rejected' && (
          <button
            type="button"
            className="av-upload-replace"
            onClick={openPicker}
            disabled={disabled}
          >
            <Icon name="refresh" size={13} aria-hidden />
            Replace file
          </button>
        )}

      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept={accept}
        hidden
        aria-hidden="true"
        onChange={handleFileChange}
      />
    </div>
  );
};

export default UploadCard;
