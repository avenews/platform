import React from 'react';
import { ChevronUp, ChevronDown, ChevronsUpDown } from 'lucide-react';
import { cn } from '../shared/utils';

export interface TableColumn<T = Record<string, unknown>> {
  key:            string;
  header:         string;
  /** Render a custom cell. Receives the row data and the raw cell value. */
  render?:        (row: T, value: unknown) => React.ReactNode;
  /** Applies .ap-table__mono — monospaced numbers/codes */
  mono?:          boolean;
  /** Applies .ap-table__muted — de-emphasised secondary cell */
  muted?:         boolean;
  align?:         'left' | 'center' | 'right';
  width?:         string | number;
  sortable?:      boolean;
  sortDirection?: 'asc' | 'desc' | null;
}

export interface TableProps<T = Record<string, unknown>> {
  columns:       TableColumn<T>[];
  rows:          T[];
  /** Unique key per row — defaults to "id" if present, otherwise row index */
  rowKey?:       keyof T | ((row: T, index: number) => string | number);
  /** Empty state label shown when rows.length === 0 */
  emptyLabel?:   string;
  /** Wrap in a white rounded card shell */
  card?:         boolean;
  onRowClick?:   (row: T) => void;
  /** Called when a sortable column header is clicked */
  onSort?:       (key: string) => void;
  className?:    string;
}

function getRowKey<T>(
  row:   T,
  index: number,
  rowKey?: TableProps<T>['rowKey'],
): string | number {
  if (typeof rowKey === 'function') return rowKey(row, index);
  if (rowKey) return row[rowKey] as string | number;
  if ((row as Record<string, unknown>).id != null) return (row as Record<string, unknown>).id as string | number;
  return index;
}

function SortIcon({ direction }: { direction?: 'asc' | 'desc' | null }) {
  if (direction === 'asc')  return <ChevronUp  size={14} strokeWidth={2} style={{ flexShrink: 0 }} />;
  if (direction === 'desc') return <ChevronDown size={14} strokeWidth={2} style={{ flexShrink: 0 }} />;
  return <ChevronsUpDown size={14} strokeWidth={2} style={{ flexShrink: 0, opacity: 0.35 }} />;
}

export function Table<T = Record<string, unknown>>({
  columns,
  rows,
  rowKey,
  emptyLabel  = 'No records found.',
  card        = true,
  onRowClick,
  onSort,
  className,
}: TableProps<T>) {
  const tableEl = (
    <table className={cn('ap-table', className)}>
      <thead>
        <tr>
          {columns.map(col => (
            <th
              key={col.key}
              style={{
                textAlign: col.align ?? 'left',
                width:     col.width,
                cursor:    col.sortable ? 'pointer' : undefined,
                userSelect: col.sortable ? 'none' : undefined,
              }}
              onClick={col.sortable && onSort ? () => onSort(col.key) : undefined}
              aria-sort={
                col.sortDirection === 'asc'  ? 'ascending'  :
                col.sortDirection === 'desc' ? 'descending' :
                col.sortable ? 'none' : undefined
              }
            >
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                {col.header}
                {col.sortable && <SortIcon direction={col.sortDirection} />}
              </span>
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.length === 0 ? (
          <tr>
            <td
              colSpan={columns.length}
              style={{ textAlign: 'center', color: 'var(--av-color-text-muted)', padding: '32px 20px' }}
            >
              {emptyLabel}
            </td>
          </tr>
        ) : (
          rows.map((row, i) => (
            <tr
              key={getRowKey(row, i, rowKey)}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              style={onRowClick ? { cursor: 'pointer' } : undefined}
            >
              {columns.map(col => {
                const val = (row as Record<string, unknown>)[col.key];
                return (
                  <td
                    key={col.key}
                    style={{ textAlign: col.align ?? 'left' }}
                    className={cn(
                      col.mono  && 'ap-table__mono',
                      col.muted && 'ap-table__muted',
                    )}
                  >
                    {col.render ? col.render(row, val) : (val as React.ReactNode)}
                  </td>
                );
              })}
            </tr>
          ))
        )}
      </tbody>
    </table>
  );

  if (card) {
    return <div className="ap-table__wrap">{tableEl}</div>;
  }

  return tableEl;
}

export default Table;
