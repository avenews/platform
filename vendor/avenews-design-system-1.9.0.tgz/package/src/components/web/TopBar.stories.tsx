import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { TopBar } from './TopBar';
import { Icon } from './Icon';

const meta: Meta<typeof TopBar> = {
  title:     'Avenews/Web/Portal/TopBar',
  component: TopBar,
  tags:      ['autodocs'],
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Application portal sticky top bar. Shows page title, optional breadcrumb, icon action buttons, and an avatar chip. On mobile (≤900px) the sidebar is hidden and this bar gains a menu trigger.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof TopBar>;

const AVATAR = { initials: 'JM', name: 'John Mwangi', role: 'Acme Agri Ltd' };

export const Default: Story = {
  args: {
    title:      'Dashboard',
    breadcrumb: 'Avenews · Application',
    avatar:     AVATAR,
    actions: [
      {
        id:        'search',
        icon:      <Icon name="search" size={20} aria-hidden />,
        ariaLabel: 'Search',
      },
      {
        id:        'notifications',
        icon:      <Icon name="notifications" size={20} aria-hidden />,
        ariaLabel: 'Notifications',
        hasDot:    true,
      },
    ],
  },
};

export const DocumentsStep: Story = {
  args: {
    title:      'Documents',
    breadcrumb: 'My application · Step 4 of 7',
    avatar:     AVATAR,
    actions: [
      {
        id:        'notifications',
        icon:      <Icon name="notifications" size={20} aria-hidden />,
        ariaLabel: 'Notifications',
        hasDot:    true,
      },
    ],
  },
};

export const NoAvatar: Story = {
  args: {
    title:   'Reports',
    actions: [
      {
        id:        'search',
        icon:      <Icon name="search" size={20} aria-hidden />,
        ariaLabel: 'Search',
      },
    ],
  },
};

export const MobileWithMenu: Story = {
  name: 'Mobile (menu trigger)',
  args: {
    title:      'My application',
    breadcrumb: 'Step 4 of 7',
    mobile:     true,
    avatar:     AVATAR,
    actions: [
      {
        id:        'notifications',
        icon:      <Icon name="notifications" size={20} aria-hidden />,
        ariaLabel: 'Notifications',
        hasDot:    true,
      },
    ],
  },
};
