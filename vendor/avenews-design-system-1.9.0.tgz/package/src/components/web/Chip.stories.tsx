import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Chip } from './Chip';
import type { ChipColor, ChipFill } from './Chip';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Chip> = {
  title: 'Avenews/Web/Chip',
  component: Chip,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Compact interactive pill for filters, tags, and status tokens. ' +
          'Supports 11 colours × 2 fills, a selected state, leading icon or avatar, ' +
          'dismissible mode, and a loading skeleton.',
      },
    },
    layout: 'centered',
  },
  argTypes: {
    color: {
      control: 'select',
      options: [
        'default', 'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger', 'info',
        'light', 'medium', 'dark', 'accent',
      ] satisfies ChipColor[],
    },
    fill: {
      control: 'radio',
      options: ['solid', 'outline'] satisfies ChipFill[],
    },
    selected:    { control: 'boolean' },
    dismissible: { control: 'boolean' },
    disabled:    { control: 'boolean' },
    loading:     { control: 'boolean' },
    label:       { control: 'text' },
  },
  args: {
    label:    'Filter',
    color:    'primary',
    fill:     'solid',
    selected: false,
    disabled: false,
    loading:  false,
  },
};

export default meta;
type Story = StoryObj<typeof Chip>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { label: 'Filter', color: 'primary' },
};

// ─── Fill variants ────────────────────────────────────────────────────────────

export const Solid: Story = {
  name: 'Fill / Solid',
  args: { label: 'Solid', fill: 'solid', color: 'primary' },
};

export const Outline: Story = {
  name: 'Fill / Outline',
  args: { label: 'Outline', fill: 'outline', color: 'primary' },
};

export const SolidVsOutline: Story = {
  name: 'Fill / Solid vs Outline',
  render: () => (
    <div style={{ display: 'flex', gap: 12 }}>
      <Chip label="Solid"   fill="solid"   color="primary" />
      <Chip label="Outline" fill="outline" color="primary" />
    </div>
  ),
};

// ─── States ───────────────────────────────────────────────────────────────────

export const Selected: Story = {
  name: 'State / Selected',
  args: { label: 'Selected', color: 'primary', selected: true },
};

export const Disabled: Story = {
  name: 'State / Disabled',
  args: { label: 'Disabled', color: 'primary', disabled: true },
};

export const Loading: Story = {
  name: 'State / Loading',
  args: { label: 'Loading', loading: true },
};

// ─── With leading icon ────────────────────────────────────────────────────────

const FilterIcon: React.FC = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const StarIcon: React.FC = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
  </svg>
);

export const WithLeadingIcon: Story = {
  name: 'Slots / Leading icon',
  args: { label: 'Filtered', color: 'primary', leadingIcon: <FilterIcon /> },
};

export const WithAvatarSlot: Story = {
  name: 'Slots / Avatar',
  args: {
    label:     'Amara K.',
    avatarUrl: 'https://i.pravatar.cc/32?img=47',
    avatarAlt: 'Amara Kone',
    color:     'default',
  },
};

// ─── Dismissible ─────────────────────────────────────────────────────────────

export const Dismissible: Story = {
  name: 'Feature / Dismissible',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [chips, setChips] = useState(['Invoice', 'Loan', 'Repayment', 'Statement']);
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {chips.map((c) => (
          <Chip
            key={c} label={c} color="primary"
            dismissible onDismiss={() => setChips((prev) => prev.filter((x) => x !== c))}
          />
        ))}
        {chips.length === 0 && (
          <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 13, color: 'var(--av-color-text-muted)' }}>
            All chips dismissed
          </span>
        )}
      </div>
    );
  },
};

// ─── All colours ──────────────────────────────────────────────────────────────

const ALL_COLORS: ChipColor[] = [
  'default', 'primary', 'secondary', 'tertiary',
  'success', 'warning', 'danger',
  'light', 'medium', 'dark', 'accent',
];

export const AllColorsSolid: Story = {
  name: 'Colors / All solid',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
      {ALL_COLORS.map((c) => <Chip key={c} label={c} color={c} fill="solid" />)}
    </div>
  ),
};

export const AllColorsOutline: Story = {
  name: 'Colors / All outline',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
      {ALL_COLORS.map((c) => <Chip key={c} label={c} color={c} fill="outline" />)}
    </div>
  ),
};

// ─── Interactive filter row ───────────────────────────────────────────────────

const STATUS_FILTERS = ['All', 'Action required', 'In review', 'Completed', 'Optional'];

export const FilterRow: Story = {
  name: 'App / Filter row (interactive)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [active, setActive] = useState('All');
    return (
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {STATUS_FILTERS.map((f) => (
          <Chip
            key={f} label={f}
            color={f === 'All' ? 'primary' : 'default'}
            fill="solid"
            selected={active === f}
            onClick={() => setActive(f)}
          />
        ))}
      </div>
    );
  },
};

export const PriorityTag: Story = {
  name: 'App / Priority tag (leading star)',
  args: { label: 'Priority', color: 'warning', leadingIcon: <StarIcon /> },
};
