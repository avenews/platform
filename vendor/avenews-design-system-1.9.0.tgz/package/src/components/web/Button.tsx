import React from 'react';
import type { ButtonVariant, ButtonSize, ButtonExpand } from '../shared/types';
import { cn } from '../shared/utils';

export type { ButtonVariant, ButtonSize, ButtonExpand };

// ─── Props ────────────────────────────────────────────────────────────────────
// API is intentionally aligned with the Ionic Button.
// `icon` accepts ReactNode (SVG, emoji, or any element) since this version
// has no Ionic / ionicons dependency.

export interface ButtonProps {
  label:        string;
  ariaLabel?:   string;
  variant?:     ButtonVariant;
  size?:        ButtonSize;
  expand?:      ButtonExpand;
  disabled?:    boolean;
  loading?:     boolean;
  /** Icon element — ReactNode (use inline SVG, emoji, etc.) */
  icon?:        React.ReactNode;
  iconSlot?:    'start' | 'end' | 'icon-only';
  type?:        'button' | 'submit' | 'reset';
  onClick?:     () => void;
  className?:   string;
}

// ─── Spinner ──────────────────────────────────────────────────────────────────

const BtnSpinner: React.FC = () => (
  <span className="av-btn__spinner" aria-hidden="true" />
);

// ─── Component ────────────────────────────────────────────────────────────────

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      label,
      ariaLabel,
      variant  = 'primary',
      size     = 'md',
      expand,
      disabled = false,
      loading  = false,
      icon,
      iconSlot = 'start',
      type = 'button',
      onClick,
      className,
    },
    ref,
  ) => {
    const iconOnly = iconSlot === 'icon-only';

    return (
      <button
        ref={ref}
        type={type}
        className={cn(
          'av-btn',
          `av-btn--${variant}`,
          size !== 'md'   && `av-btn--${size}`,
          expand          && `av-btn--${expand}`,
          loading         && 'av-btn--loading',
          iconOnly        && 'av-btn--icon-only',
          className,
        )}
        disabled={disabled || loading}
        onClick={onClick}
        aria-label={ariaLabel ?? label}
        aria-busy={loading ? true : undefined}
      >
        {loading ? (
          <BtnSpinner />
        ) : (
          <>
            {icon && iconSlot === 'start' && (
              <span className="av-btn__icon av-btn__icon--start" aria-hidden="true">{icon}</span>
            )}
            {!iconOnly && <span className="av-btn__label">{label}</span>}
            {icon && iconSlot === 'end' && (
              <span className="av-btn__icon av-btn__icon--end" aria-hidden="true">{icon}</span>
            )}
            {icon && iconOnly && (
              <span className="av-btn__icon" aria-hidden="true">{icon}</span>
            )}
          </>
        )}
      </button>
    );
  },
);

Button.displayName = 'WebButton';

export default Button;
