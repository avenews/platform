import React from 'react';
import { Badge } from '../cross-platform/Badge';
import type { BadgeVariant } from '../cross-platform/Badge';
import { cn } from '../shared/utils';

export type InfoRowVariant = 'default' | 'stacked' | 'with-copy' | 'with-badge';

export interface InfoRowProps {
  label:         string;
  value?:        string;
  variant?:      InfoRowVariant;
  badgeVariant?: BadgeVariant;
  loading?:      boolean;
  onCopy?:       () => void;
  className?:    string;
}

const CopyIcon: React.FC = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </svg>
);

export const InfoRow: React.FC<InfoRowProps> = ({
  label,
  value,
  variant      = 'default',
  badgeVariant = 'neutral',
  loading      = false,
  onCopy,
  className,
}) => {
  if (loading) {
    return (
      <div className={cn('av-info-row av-info-row--loading', className)}>
        <span className="av-skeleton-line" style={{ width: '35%', height: '12px' }} />
        <span className="av-skeleton-line" style={{ width: '120px', height: '14px' }} />
      </div>
    );
  }

  if (variant === 'stacked') {
    return (
      <div className={cn('av-info-row av-info-row--stacked', className)}>
        <span className="av-info-row__label">{label}</span>
        <div className="av-info-row__end">
          <span className="av-info-row__value">{value ?? '—'}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={cn('av-info-row', variant !== 'default' && `av-info-row--${variant}`, className)}>
      <span className="av-info-row__label">{label}</span>
      <div className="av-info-row__end">
        {variant === 'with-badge'
          ? (value
              ? <Badge count={value} variant={badgeVariant} hideOnEmpty={false} />
              : <span className="av-info-row__value">—</span>
            )
          : <span className="av-info-row__value">{value ?? '—'}</span>
        }
        {variant === 'with-copy' && (
          <button
            type="button"
            onClick={onCopy}
            aria-label={`Copy ${label}`}
            className="av-info-row__copy-btn"
          >
            <CopyIcon />
          </button>
        )}
      </div>
    </div>
  );
};

export default InfoRow;
