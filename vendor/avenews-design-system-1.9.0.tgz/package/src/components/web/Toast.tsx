import React, { useEffect, useRef } from 'react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';
import type { IconName } from './Icon';

// ─── Types ────────────────────────────────────────────────────────────────────

export type ToastVariant  = 'neutral' | 'success' | 'warning' | 'danger' | 'info';
export type ToastPosition =
  | 'top' | 'top-start' | 'top-end'
  | 'bottom' | 'bottom-start' | 'bottom-end';

export interface ToastAction {
  label:    string;
  onClick?: () => void;
}

export interface ToastProps {
  message:      string;
  visible?:     boolean;
  variant?:     ToastVariant;
  position?:    ToastPosition;
  /** Auto-dismiss delay in ms. 0 = persistent. Default 3500. */
  duration?:    number;
  icon?:        React.ReactNode;
  /** Hides the default variant icon */
  hideIcon?:    boolean;
  action?:      ToastAction;
  dismissible?: boolean;
  onDismiss?:   () => void;
  className?:   string;
}

// ─── Icon name map ────────────────────────────────────────────────────────────

const ICON_NAMES: Record<ToastVariant, IconName | null> = {
  neutral: null,
  success: 'checkmark-circle',
  warning: 'warning',
  danger:  'close-circle',
  info:    'information-circle',
};

// ─── Component ────────────────────────────────────────────────────────────────

export const Toast: React.FC<ToastProps> = ({
  message,
  visible      = false,
  variant      = 'neutral',
  position     = 'bottom',
  duration     = 3500,
  icon,
  hideIcon     = false,
  action,
  dismissible  = false,
  onDismiss,
  className,
}) => {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!visible || duration === 0) return;
    timerRef.current = setTimeout(() => onDismiss?.(), duration);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [visible, duration, onDismiss]);

  if (!visible) return null;

  const iconName    = ICON_NAMES[variant];
  const resolvedIcon = icon ?? (!hideIcon && iconName ? <Icon name={iconName} size={18} aria-hidden /> : null);

  return (
    <div
      className={cn('av-toast-viewport', `av-toast-viewport--${position}`)}
      role="region"
      aria-live="assertive"
      aria-atomic="true"
    >
      <div className={cn('av-toast', `av-toast--${variant}`, className)}>
        {resolvedIcon && (
          <span className="av-toast__icon" aria-hidden="true">{resolvedIcon}</span>
        )}
        <span className="av-toast__message">{message}</span>
        {action && (
          <button
            type="button"
            className="av-toast__action"
            onClick={() => { action.onClick?.(); onDismiss?.(); }}
          >
            {action.label}
          </button>
        )}
        {dismissible && (
          <button
            type="button"
            className="av-toast__dismiss"
            aria-label="Dismiss"
            onClick={onDismiss}
          >
            <Icon name="close" size={16} aria-hidden />
          </button>
        )}
      </div>
    </div>
  );
};

export default Toast;
