import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Pagination } from './Pagination';

const meta: Meta<typeof Pagination> = {
  title: 'Avenews/Web/Pagination',
  component: Pagination,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Footer pagination for the `.dt-table` data-table family. Client-side: the parent owns ' +
          'the page index and slices its own list; this renders a "Showing X–Y of Z" summary plus ' +
          'previous / numbered / next controls. Long page ranges collapse with an ellipsis, and the ' +
          'control renders nothing when everything fits on one page. Touch targets grow from 32px to ' +
          '44px on phones and any coarse-pointer device.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Pagination>;

/** Stateful wrapper so the controls actually page within the Storybook canvas. */
function Interactive({
  pageSize = 10,
  total,
  itemLabel,
}: {
  pageSize?: number;
  total: number;
  itemLabel?: string;
}) {
  const [page, setPage] = useState(1);
  return (
    <Pagination
      page={page}
      pageSize={pageSize}
      total={total}
      itemLabel={itemLabel}
      onPageChange={setPage}
    />
  );
}

// ─── Default ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default — 12 items',
  render: () => <Interactive total={12} itemLabel="invoices" />,
};

// ─── Many pages (ellipsis windowing) ──────────────────────────────────────────

export const ManyPages: Story = {
  name: 'Many pages — ellipsis windowing',
  render: () => <Interactive total={240} itemLabel="records" />,
};

// ─── Single page (renders nothing) ────────────────────────────────────────────

export const SinglePage: Story = {
  name: 'Single page — renders nothing',
  render: () => (
    <div style={{ fontFamily: 'var(--av-font-body)', color: 'var(--av-color-text-muted)' }}>
      <p style={{ marginTop: 0 }}>
        With 8 items at 10 per page there is only one page, so the control renders nothing
        (the box below is intentionally empty):
      </p>
      <div style={{ border: '1px dashed var(--av-neutral-300)', borderRadius: 8, padding: 16 }}>
        <Interactive total={8} itemLabel="items" />
      </div>
    </div>
  ),
};

// ─── Mobile touch targets ─────────────────────────────────────────────────────

export const MobileTouchTargets: Story = {
  name: 'Mobile — 44px touch targets',
  parameters: { viewport: { defaultViewport: 'mobileM' } },
  render: () => <Interactive total={120} itemLabel="invoices" />,
};
