import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Item, ItemDivider } from './Item';
import { Avatar, MediaIcon } from './Media';
import { Badge } from '../cross-platform/Badge';
import type { ItemColor, ItemLines } from './Item';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Item> = {
  title: 'Avenews/Web/Item',
  component: Item,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'List row with one, two, or three lines of text. ' +
          'Supports start/end slots, chevron detail arrow, button/link modes, ' +
          'loading skeleton, and an `ItemDivider` section header sub-component.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color: {
      control: 'select',
      options: [
        'default', 'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger', 'light', 'medium', 'dark',
      ] satisfies ItemColor[],
    },
    lines: {
      control: 'radio',
      options: ['full', 'inset', 'none'] satisfies ItemLines[],
    },
    detailArrow: { control: 'boolean' },
    button:      { control: 'boolean' },
    disabled:    { control: 'boolean' },
    loading:     { control: 'boolean' },
    label:       { control: 'text' },
    secondLine:  { control: 'text' },
    thirdLine:   { control: 'text' },
  },
  args: {
    label:    'Item label',
    color:    'default',
    lines:    'full',
  },
};

export default meta;
type Story = StoryObj<typeof Item>;

// ─── Shared icon ──────────────────────────────────────────────────────────────

const DocIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <polyline points="14 2 14 8 20 8"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// ─── Basic variants ───────────────────────────────────────────────────────────

export const SingleLine: Story = {
  name: 'Lines / One line',
  args: { label: 'Bank statement', lines: 'full' },
};

export const TwoLines: Story = {
  name: 'Lines / Two lines',
  args: { label: 'Bank statement', secondLine: 'Uploaded 14 Feb 2024', lines: 'full' },
};

export const ThreeLines: Story = {
  name: 'Lines / Three lines (default variant)',
  args: {
    label:      'Bank statement',
    secondLine: 'Uploaded 14 Feb 2024',
    thirdLine:  'PDF · 2.4 MB',
    lines:      'full',
  },
};

export const List3Variant: Story = {
  name: 'Lines / Three lines (list3 variant)',
  args: {
    variant:    'list3',
    label:      'Feb 2024',
    secondLine: 'Bank Statement',
    thirdLine:  'PDF · 2.4 MB',
    lines:      'full',
  },
};

// ─── Slots ────────────────────────────────────────────────────────────────────

export const WithStartSlot: Story = {
  name: 'Slots / Start (media icon)',
  args: {
    label:      'Bank statement',
    secondLine: 'Feb 2024',
    startSlot:  <MediaIcon icon={<DocIcon />} color="primary" size="sm" />,
    lines:      'full',
  },
};

export const WithAvatarStart: Story = {
  name: 'Slots / Start (avatar)',
  args: {
    label:      'Amara Kone',
    secondLine: 'Account manager',
    startSlot:  <Avatar initials="AK" size="sm" />,
    lines:      'full',
  },
};

export const WithEndBadge: Story = {
  name: 'Slots / End (badge)',
  args: {
    label:      'Invoices',
    secondLine: 'Action required',
    startSlot:  <MediaIcon icon={<DocIcon />} color="danger" size="sm" />,
    endSlot:    <Badge count={3} variant="danger" />,
    lines:      'full',
  },
};

// ─── Interactive ─────────────────────────────────────────────────────────────

export const ButtonItem: Story = {
  name: 'State / Button (tappable)',
  args: {
    label:       'View document',
    secondLine:  'Tap to open',
    button:      true,
    detailArrow: true,
    lines:       'full',
  },
};

export const LinkItem: Story = {
  name: 'State / Link (href)',
  args: {
    label:       'Go to account settings',
    href:        '#',
    detailArrow: true,
    lines:       'full',
  },
};

export const Disabled: Story = {
  name: 'State / Disabled',
  args: {
    label:    'Upload disabled',
    disabled: true,
    lines:    'full',
  },
};

export const Loading: Story = {
  name: 'State / Loading skeleton',
  args: { label: 'ignored', loading: true },
};

// ─── Line separators ──────────────────────────────────────────────────────────

export const LinesFull: Story = {
  name: 'Lines / Full',
  args: { label: 'Full border', lines: 'full' },
};

export const LinesInset: Story = {
  name: 'Lines / Inset',
  args: { label: 'Inset border', lines: 'inset' },
};

export const LinesNone: Story = {
  name: 'Lines / None',
  args: { label: 'No border', lines: 'none' },
};

// ─── ItemDivider ─────────────────────────────────────────────────────────────

export const Divider: StoryObj<typeof ItemDivider> = {
  name: 'ItemDivider / Default',
  render: () => <ItemDivider label="Documents" />,
};

export const DividerLoading: StoryObj<typeof ItemDivider> = {
  name: 'ItemDivider / Loading',
  render: () => <ItemDivider label="ignored" loading />,
};

// ─── App: full document list ──────────────────────────────────────────────────

export const DocumentList: Story = {
  name: 'App / Document list',
  render: () => (
    <div style={{ background: 'var(--av-color-surface)' }}>
      <ItemDivider label="Required documents" />
      <Item
        label="Bank statement"
        secondLine="Upload 3 months of statements"
        startSlot={<MediaIcon icon={<DocIcon />} color="primary" size="sm" />}
        endSlot={<Badge count="Due" variant="warning-subtle" />}
        button detailArrow lines="full"
      />
      <Item
        label="Director ID"
        secondLine="Certified copy required"
        startSlot={<MediaIcon icon={<DocIcon />} color="primary" size="sm" />}
        endSlot={<Badge count="✓" variant="success-subtle" />}
        button detailArrow lines="full"
      />
      <Item
        label="Business registration"
        secondLine="Certificate of incorporation"
        startSlot={<MediaIcon icon={<DocIcon />} color="primary" size="sm" />}
        endSlot={<Badge count={0} hideOnEmpty />}
        button detailArrow lines="none"
      />
    </div>
  ),
};
