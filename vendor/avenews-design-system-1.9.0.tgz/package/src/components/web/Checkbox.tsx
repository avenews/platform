import React, { useId } from 'react';
import { cn } from '../shared/utils';

export type CheckboxColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light' | 'medium' | 'dark' | 'white' | 'black';

export interface CheckboxProps {
  checked?:        boolean;
  indeterminate?:  boolean;
  disabled?:       boolean;
  label?:          string;
  labelPlacement?: 'start' | 'end' | 'stacked';
  justify?:        'space-between' | 'start' | 'end';
  color?:          CheckboxColor;
  /** Renamed from onIonChange for web parity */
  onChange?:       (checked: boolean) => void;
  className?:      string;
}

export const Checkbox: React.FC<CheckboxProps> = ({
  checked        = false,
  indeterminate  = false,
  disabled       = false,
  label,
  labelPlacement = 'start',
  justify        = 'space-between',
  color          = 'primary',
  onChange,
  className,
}) => {
  const uid = useId();

  const rootCls = cn(
    'av-checkbox',
    `av-checkbox--${color}`,
    !label         && 'av-checkbox--standalone',
    disabled       && 'av-checkbox--disabled',
    label          && `av-checkbox--label-${labelPlacement}`,
    label          && `av-checkbox--justify-${justify}`,
    className,
  );

  const control = (
    <span className="av-checkbox__box" aria-hidden="true">
      {indeterminate
        ? <span className="av-checkbox__mark av-checkbox__mark--indeterminate" />
        : <span className="av-checkbox__mark" />
      }
    </span>
  );

  if (!label) {
    return (
      <label className={rootCls}>
        <input
          type="checkbox"
          id={uid}
          className="av-checkbox__input"
          checked={checked}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.checked)}
          aria-label="Checkbox"
          ref={(el) => { if (el) el.indeterminate = indeterminate; }}
        />
        {control}
      </label>
    );
  }

  const labelEl = <span className="av-checkbox__label">{label}</span>;

  return (
    <label htmlFor={uid} className={rootCls}>
      <input
        type="checkbox"
        id={uid}
        className="av-checkbox__input"
        checked={checked}
        disabled={disabled}
        onChange={(e) => onChange?.(e.target.checked)}
        ref={(el) => { if (el) el.indeterminate = indeterminate; }}
      />
      {labelPlacement === 'start' && labelEl}
      {control}
      {(labelPlacement === 'end' || labelPlacement === 'stacked') && labelEl}
    </label>
  );
};

export default Checkbox;
