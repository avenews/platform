import React from 'react';
import { cn } from '../shared/utils';

// ─── Types ────────────────────────────────────────────────────────────────────

export type HeaderVariant = 'default' | 'subtle' | 'dark';
export type HeaderSize    = 'sm' | 'md' | 'lg';

export interface HeaderProps {
  title:         string;
  subtitle?:     string;
  description?:  string;
  variant?:      HeaderVariant;
  size?:         HeaderSize;
  /** Avatar / logo / icon — any ReactNode */
  avatar?:       React.ReactNode;
  /** Action buttons row — any ReactNode */
  actions?:      React.ReactNode;
  /** Breadcrumb / back nav — any ReactNode */
  breadcrumb?:   React.ReactNode;
  className?:    string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  description,
  variant    = 'default',
  size       = 'md',
  avatar,
  actions,
  breadcrumb,
  className,
}) => (
  <div
    className={cn(
      'av-header',
      `av-header--${variant}`,
      `av-header--${size}`,
      className,
    )}
  >
    {breadcrumb && (
      <div className="av-header__breadcrumb">{breadcrumb}</div>
    )}

    <div className="av-header__row">
      {avatar && (
        <div className="av-header__avatar">{avatar}</div>
      )}

      <div className="av-header__content">
        <h1 className="av-header__title">{title}</h1>
        {subtitle && (
          <p className="av-header__subtitle">{subtitle}</p>
        )}
        {description && (
          <p className="av-header__description">{description}</p>
        )}
      </div>

      {actions && (
        <div className="av-header__actions">{actions}</div>
      )}
    </div>
  </div>
);

export default Header;
