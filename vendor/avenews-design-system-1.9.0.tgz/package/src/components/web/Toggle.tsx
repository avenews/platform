import React, { useId } from 'react';
import { cn } from '../shared/utils';

export interface ToggleProps {
  label:       string;
  helperText?: string;
  checked?:    boolean;
  disabled?:   boolean;
  /** Renamed from onIonChange for web parity */
  onChange?:   (checked: boolean) => void;
  className?:  string;
}

export const Toggle: React.FC<ToggleProps> = ({
  label,
  helperText,
  checked  = false,
  disabled = false,
  onChange,
  className,
}) => {
  const uid = useId();

  return (
    <label
      htmlFor={uid}
      className={cn('av-toggle', disabled && 'av-toggle--disabled', className)}
    >
      <div className="av-toggle__label-wrap">
        <span className="av-toggle__label">{label}</span>
        {helperText && <span className="av-toggle__helper">{helperText}</span>}
      </div>

      <div className="av-toggle__track-wrap">
        <input
          id={uid}
          type="checkbox"
          className="av-toggle__input"
          checked={checked}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.checked)}
          aria-label={label}
        />
        <span className="av-toggle__track" aria-hidden="true">
          <span className="av-toggle__thumb" />
        </span>
      </div>
    </label>
  );
};

export default Toggle;
