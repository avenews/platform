import React, { useEffect, useId, useRef, useState } from 'react';
import type { InputLabelPlacement, InputType } from '../shared/types';
import { cn } from '../shared/utils';

export type { InputLabelPlacement, InputType };

// ─── Props ────────────────────────────────────────────────────────────────────
// API mirrors the Ionic Input.  Event handlers use standard React events
// (onChange/onBlur/onFocus) instead of onIonInput/onIonChange/onIonBlur.
// `startIcon` / `endIcon` accept ReactNode (no Ionic dependency).

export interface InputProps {
  label?:             string;
  labelPlacement?:    InputLabelPlacement;
  placeholder?:       string;
  value?:             string;
  type?:              InputType;
  required?:          boolean;
  disabled?:          boolean;
  loading?:           boolean;
  error?:             string;
  success?:           boolean;
  helperText?:        string;
  counter?:           boolean;
  maxlength?:         number;
  clearInput?:        boolean;
  /** Passive icon (16px) rendered before the input */
  startIcon?:         React.ReactNode;
  /** Click handler promotes startIcon to interactive 28px icon-button */
  onStartIconClick?:  () => void;
  startIconAriaLabel?: string;
  /** Passive icon (16px) rendered after the input */
  endIcon?:           React.ReactNode;
  /** Click handler promotes endIcon to interactive icon-button */
  onEndIconClick?:    () => void;
  endIconAriaLabel?:  string;
  multiline?:         boolean;
  rows?:              number;
  autoGrow?:          boolean;
  /** Dial code prefix e.g. "+254" — activates phone layout */
  phonePrefix?:       string;
  phoneFlagEmoji?:    string;
  onChange?:          (value: string) => void;
  onBlur?:            () => void;
  onFocus?:           () => void;
  className?:         string;
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

const InputSkeleton: React.FC = () => (
  <div className="av-input av-input--skeleton" aria-hidden="true">
    <div className="av-input__skeleton-label" />
    <div className="av-input__skeleton-field" />
  </div>
);

// ─── Component ────────────────────────────────────────────────────────────────

export const Input: React.FC<InputProps> = ({
  label,
  labelPlacement  = 'stacked',
  placeholder,
  value,
  type            = 'text',
  required        = false,
  disabled        = false,
  loading         = false,
  error,
  success         = false,
  helperText,
  counter         = false,
  maxlength,
  clearInput      = false,
  startIcon,
  onStartIconClick,
  startIconAriaLabel,
  endIcon,
  onEndIconClick,
  endIconAriaLabel,
  multiline       = false,
  rows            = 4,
  autoGrow        = true,
  phonePrefix,
  phoneFlagEmoji  = '🇰🇪',
  onChange,
  onBlur,
  onFocus,
  className,
}) => {
  const uid = useId();
  const inputId  = `av-input-${uid}`;
  const helperId = `av-input-help-${uid}`;

  const [focused,  setFocused]  = useState(false);
  const [internal, setInternal] = useState(value ?? '');

  // Keep uncontrolled state in sync when the controlled `value` prop changes
  useEffect(() => {
    if (value !== undefined) setInternal(value);
  }, [value]);

  const current    = value !== undefined ? value : internal;
  const charCount  = current.length;
  const isFloating = labelPlacement === 'floating';
  const isInline   = labelPlacement === 'start' || labelPlacement === 'fixed';
  const textaRef   = useRef<HTMLTextAreaElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const v = e.target.value;
    if (value === undefined) setInternal(v);
    onChange?.(v);
    if (autoGrow && multiline && textaRef.current) {
      textaRef.current.style.height = 'auto';
      textaRef.current.style.height = `${textaRef.current.scrollHeight}px`;
    }
  };

  if (loading) return <InputSkeleton />;

  const rootCls = cn(
    'av-input',
    `av-input--${labelPlacement}`,
    error             && 'av-input--error',
    success && !error && 'av-input--success',
    focused           && 'av-input--focused',
    disabled          && 'av-input--disabled',
    multiline         && 'av-input--multiline',
    phonePrefix != null && 'av-input--phone',
    isInline          && 'av-input--inline',
    className,
  );

  const sharedField = {
    id:           inputId,
    disabled,
    required,
    value:        current,
    maxLength:    maxlength,
    'aria-invalid':     Boolean(error),
    'aria-describedby': (helperText || error) ? helperId : undefined,
    onChange: handleChange,
    onFocus:  () => { setFocused(true);  onFocus?.(); },
    onBlur:   () => { setFocused(false); onBlur?.();  },
  };

  // ── Label ──────────────────────────────────────────────────────────────────

  const labelEl = label ? (
    <label
      htmlFor={inputId}
      className={cn(
        'av-input__label',
        isFloating && 'av-input__label--floating',
        isFloating && (focused || current) && 'av-input__label--lifted',
      )}
    >
      {label}
      {required && <span className="av-input__required" aria-hidden="true">{'\u200A'}*</span>}
    </label>
  ) : null;

  // ── Footer (helper / error / counter) ─────────────────────────────────────

  const footerEl = (error || helperText || (counter && maxlength)) ? (
    <div className="av-input__footer">
      {(error || helperText) && (
        <span id={helperId} className={cn('av-input__helper', error && 'av-input__helper--error')}>
          {error ?? helperText}
        </span>
      )}
      {counter && maxlength && (
        <span className="av-input__counter" aria-live="polite">
          {charCount}/{maxlength}
        </span>
      )}
    </div>
  ) : null;

  // ── Icon slots ─────────────────────────────────────────────────────────────

  const startSlot = startIcon ? (
    onStartIconClick ? (
      <button type="button" className="av-input__icon-btn av-input__icon-btn--start"
        onClick={onStartIconClick} aria-label={startIconAriaLabel}>
        <span className="av-input__icon">{startIcon}</span>
      </button>
    ) : (
      <span className="av-input__icon av-input__icon--start" aria-hidden="true">{startIcon}</span>
    )
  ) : null;

  const endSlot = endIcon ? (
    onEndIconClick ? (
      <button type="button" className="av-input__icon-btn av-input__icon-btn--end"
        onClick={onEndIconClick} aria-label={endIconAriaLabel}>
        <span className="av-input__icon">{endIcon}</span>
      </button>
    ) : (
      <span className="av-input__icon av-input__icon--end" aria-hidden="true">{endIcon}</span>
    )
  ) : null;

  const clearBtn = clearInput && current ? (
    <button type="button" className="av-input__icon-btn av-input__icon-btn--clear"
      aria-label="Clear input"
      onClick={() => { onChange?.(''); if (value === undefined) setInternal(''); }}>
      <span className="av-input__icon" aria-hidden="true">✕</span>
    </button>
  ) : null;

  const phoneEl = phonePrefix != null ? (
    <span className="av-input__phone-prefix">
      <span className="av-input__phone-flag" aria-hidden="true">{phoneFlagEmoji}</span>
      <span className="av-input__phone-code">{phonePrefix}</span>
    </span>
  ) : null;

  // ── Field ──────────────────────────────────────────────────────────────────

  const fieldEl = multiline ? (
    <textarea
      ref={textaRef}
      className="av-input__field"
      placeholder={isFloating ? '' : placeholder}
      rows={rows}
      {...(sharedField as React.TextareaHTMLAttributes<HTMLTextAreaElement>)}
    />
  ) : (
    <input
      className="av-input__field"
      type={type}
      placeholder={isFloating ? '' : placeholder}
      {...(sharedField as React.InputHTMLAttributes<HTMLInputElement>)}
    />
  );

  // ── Inline layout (start / fixed) ─────────────────────────────────────────

  if (isInline) {
    return (
      <div className={rootCls}>
        <div className="av-input__row">
          {labelEl}
          <div className="av-input__field-wrap">
            {phoneEl}{startSlot}{fieldEl}{clearBtn}{endSlot}
          </div>
        </div>
        {footerEl}
      </div>
    );
  }

  // ── Floating label ─────────────────────────────────────────────────────────

  if (isFloating) {
    return (
      <div className={rootCls}>
        <div className="av-input__field-wrap av-input__field-wrap--floating">
          {labelEl}
          {phoneEl}{startSlot}{fieldEl}{clearBtn}{endSlot}
        </div>
        {footerEl}
      </div>
    );
  }

  // ── Stacked (default) ──────────────────────────────────────────────────────

  return (
    <div className={rootCls}>
      {labelEl}
      <div className="av-input__field-wrap">
        {phoneEl}{startSlot}{fieldEl}{clearBtn}{endSlot}
      </div>
      {footerEl}
    </div>
  );
};

export default Input;
