import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { InlineBanner } from './InlineBanner';
import type { InlineBannerVariant } from './InlineBanner';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof InlineBanner> = {
  title: 'Avenews/Web/InlineBanner',
  component: InlineBanner,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Inline contextual feedback banner with icon, message, and optional dismiss button. ' +
          'Four semantic variants: success / warning / info / danger. ' +
          'Use for form-level feedback, page alerts, or status messages.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    variant: {
      control: 'radio',
      options: ['success', 'warning', 'info', 'danger'] satisfies InlineBannerVariant[],
    },
    message:     { control: 'text' },
    dismissible: { control: 'boolean' },
  },
  args: {
    variant:     'info',
    message:     'Your application is under review.',
    dismissible: false,
  },
};

export default meta;
type Story = StoryObj<typeof InlineBanner>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (info)',
};

// ─── All variants ─────────────────────────────────────────────────────────────

export const Success: Story = {
  name: 'Variant / Success',
  args: { variant: 'success', message: 'Your documents have been successfully submitted.' },
};

export const Warning: Story = {
  name: 'Variant / Warning',
  args: { variant: 'warning', message: 'Your repayment is due in 3 days. Please ensure sufficient balance.' },
};

export const Info: Story = {
  name: 'Variant / Info',
  args: { variant: 'info', message: 'Your application is currently under review.' },
};

export const Danger: Story = {
  name: 'Variant / Danger',
  args: { variant: 'danger', message: 'Document upload failed. Please check your file and try again.' },
};

export const AllVariants: Story = {
  name: 'Variants / All',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <InlineBanner variant="success" message="Documents submitted successfully." />
      <InlineBanner variant="info"    message="Your application is under review." />
      <InlineBanner variant="warning" message="Repayment due in 3 days." />
      <InlineBanner variant="danger"  message="Upload failed. Please try again." />
    </div>
  ),
};

// ─── Dismissible ─────────────────────────────────────────────────────────────

export const Dismissible: Story = {
  name: 'Feature / Dismissible',
  args: {
    variant:     'info',
    message:     'Your application is currently under review. We\'ll notify you when it\'s complete.',
    dismissible: true,
  },
};

export const DismissibleInteractive: Story = {
  name: 'Feature / Dismissible (interactive)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [visible, setVisible] = useState(true);

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {visible
          ? <InlineBanner variant="warning"
              message="Your repayment is due in 3 days."
              dismissible onDismiss={() => setVisible(false)} />
          : <button
              style={{ fontFamily: 'var(--av-font-body)', fontSize: 13,
                color: 'var(--av-color-action)', background: 'none',
                border: '1px solid var(--av-color-action)', borderRadius: 6,
                padding: '6px 12px', cursor: 'pointer' }}
              onClick={() => setVisible(true)}>
              Show banner again
            </button>
        }
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const ApplicationSubmitted: Story = {
  name: 'App / Application submitted',
  args: {
    variant: 'success',
    message: 'Your loan application has been submitted. You\'ll hear back within 2 business days.',
  },
};

export const DocumentRequired: Story = {
  name: 'App / Document required',
  args: {
    variant: 'warning',
    message: 'Action required: Upload your bank statement to proceed with your application.',
    dismissible: true,
  },
};

export const RepaymentOverdue: Story = {
  name: 'App / Repayment overdue',
  args: {
    variant: 'danger',
    message: 'Your repayment of KES 12,500 is overdue. Late fees may apply.',
  },
};

export const AccountReview: Story = {
  name: 'App / Account under review',
  args: {
    variant: 'info',
    message: 'Your account is being reviewed. Some features are temporarily limited.',
    dismissible: true,
  },
};
