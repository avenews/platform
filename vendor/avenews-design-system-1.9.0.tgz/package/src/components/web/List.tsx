import React from 'react';
import { cn } from '../shared/utils';

export type ListColor      = 'default' | 'primary' | 'secondary' | 'tertiary' | 'success' | 'warning' | 'danger' | 'light' | 'medium' | 'dark';
export type ListLines      = 'full' | 'inset' | 'none';
export type ListHeaderSize = 'default' | 'large';

export interface ListHeaderProps {
  label:      string;
  size?:      ListHeaderSize;
  color?:     ListColor;
  className?: string;
}

export interface ListProps {
  children:   React.ReactNode;
  inset?:     boolean;
  lines?:     ListLines;
  color?:     ListColor;
  className?: string;
}

export const ListHeader: React.FC<ListHeaderProps> = ({
  label,
  size      = 'default',
  color,
  className,
}) => (
  <div className={cn(
    'av-list-header',
    size === 'large'           && 'av-list-header--large',
    color && color !== 'default' && `av-list-header--${color}`,
    className,
  )}>
    <span className="av-list-header__label">{label}</span>
  </div>
);

export const List: React.FC<ListProps> = ({
  children,
  inset     = false,
  lines     = 'inset',
  color,
  className,
}) => (
  <div className={cn(
    'av-list',
    inset                        && 'av-list--inset',
    `av-list--lines-${lines}`,
    color && color !== 'default' && `av-list--${color}`,
    className,
  )}>
    {children}
  </div>
);

export default List;
