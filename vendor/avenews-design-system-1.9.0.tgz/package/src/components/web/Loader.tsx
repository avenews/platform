import React from 'react';
import { cn } from '../shared/utils';

// ─── Types ────────────────────────────────────────────────────────────────────

export type LoaderVariant = 'inline' | 'centered' | 'overlay';
export type LoaderSize    = 'sm' | 'md' | 'lg';
export type LoaderColor   =
  | 'primary' | 'secondary'
  | 'success' | 'warning' | 'danger'
  | 'light'   | 'white';

export interface LoaderProps {
  variant?:  LoaderVariant;
  size?:     LoaderSize;
  color?:    LoaderColor;
  label?:    string;
  /** Controls visibility — useful for overlay variant */
  visible?:  boolean;
  className?: string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Loader: React.FC<LoaderProps> = ({
  variant = 'inline',
  size    = 'md',
  color   = 'primary',
  label,
  visible = true,
  className,
}) => {
  if (!visible) return null;

  return (
    <div
      className={cn(
        'av-loader',
        `av-loader--${variant}`,
        `av-loader--${size}`,
        `av-loader--${color}`,
        className,
      )}
      role="status"
      aria-label={label ?? 'Loading'}
      aria-live="polite"
    >
      <span className="av-loader__spinner" aria-hidden="true" />
      {label && (
        <span className="av-loader__label">{label}</span>
      )}
    </div>
  );
};

export default Loader;
