import React from 'react';
import { InfoRow } from './InfoRow';
import type { InfoRowVariant } from './InfoRow';
import type { BadgeVariant } from '../cross-platform/Badge';
import { SectionHeader } from '../cross-platform/SectionHeader';
import { cn } from '../shared/utils';

export type DataListVariant = 'default' | 'compact' | 'two-column';

export interface DataField {
  key?:          string;
  label:         string;
  value?:        string;
  variant?:      InfoRowVariant;
  badgeVariant?: BadgeVariant;
  onCopy?:       () => void;
}

export interface DataListProps {
  fields:         DataField[];
  variant?:       DataListVariant;
  title?:         string;
  loading?:       boolean;
  skeletonCount?: number;
  className?:     string;
}

export const DataList: React.FC<DataListProps> = ({
  fields,
  variant       = 'default',
  title,
  loading       = false,
  skeletonCount = 4,
  className,
}) => {
  const rows = loading
    ? Array.from({ length: skeletonCount }, (_, i) => (
        <InfoRow key={i} label="" loading />
      ))
    : fields.map((f, i) => (
        <InfoRow
          key={f.key ?? f.label ?? i}
          label={f.label}
          value={f.value}
          variant={f.variant}
          badgeVariant={f.badgeVariant}
          onCopy={f.onCopy}
        />
      ));

  return (
    <div className={cn('av-data-list', variant !== 'default' && `av-data-list--${variant}`, className)}>
      {title && <SectionHeader title={title} className="av-data-list__header" />}
      <div className="av-data-list__fields">
        {rows}
      </div>
    </div>
  );
};

export default DataList;
