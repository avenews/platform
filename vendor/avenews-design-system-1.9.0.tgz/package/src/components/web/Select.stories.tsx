import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Select } from './Select';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Select> = {
  title: 'Avenews/Web/Select',
  component: Select,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Custom dropdown select with stacked label, placeholder, and helper/error text. ' +
          'Keyboard navigable: Enter/Space to open, Arrow keys to navigate, Escape to close. ' +
          'No native `<select>` — fully styled and accessible via ARIA roles.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    disabled: { control: 'boolean' },
    required: { control: 'boolean' },
    label:       { control: 'text' },
    placeholder: { control: 'text' },
    helperText:  { control: 'text' },
    error:       { control: 'text' },
  },
  args: {
    label:       'Loan type',
    placeholder: 'Select an option',
    options: [
      { value: 'working-capital', label: 'Working capital' },
      { value: 'invoice',         label: 'Invoice financing' },
      { value: 'asset',           label: 'Asset finance' },
    ],
  },
};

export default meta;
type Story = StoryObj<typeof Select>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { value: 'working-capital' },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateEmpty: Story = {
  name: 'State / Unselected',
  args: {},
};

export const StateSelected: Story = {
  name: 'State / Selected',
  args: { value: 'invoice' },
};

export const StateDisabled: Story = {
  name: 'State / Disabled',
  args: { value: 'asset', disabled: true },
};

export const StateError: Story = {
  name: 'State / Error',
  args: { error: 'Please select a loan type to continue.' },
};

export const StateHelper: Story = {
  name: 'State / Helper text',
  args: { value: 'working-capital', helperText: 'Your selection determines available amounts.' },
};

export const StateRequired: Story = {
  name: 'State / Required',
  args: { required: true },
};

export const WithDisabledOption: Story = {
  name: 'State / Disabled option',
  args: {
    options: [
      { value: 'working-capital', label: 'Working capital' },
      { value: 'invoice',         label: 'Invoice financing', disabled: true },
      { value: 'asset',           label: 'Asset finance' },
    ],
  },
};

// ─── Interactive ──────────────────────────────────────────────────────────────

export const Interactive: Story = {
  name: 'Interactive / Controlled',
  render: () => {
    const [val, setVal] = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <Select
          label="Loan type"
          placeholder="Select a loan type"
          value={val}
          onChange={setVal}
          options={[
            { value: 'working-capital', label: 'Working capital' },
            { value: 'invoice',         label: 'Invoice financing' },
            { value: 'asset',           label: 'Asset finance' },
          ]}
        />
        {val && (
          <p style={{
            fontFamily: 'var(--av-font-body)', fontSize: 13,
            color: 'var(--av-color-text-muted)', margin: 0,
          }}>
            Selected: <strong style={{ color: 'var(--av-color-text)' }}>{val}</strong>
          </p>
        )}
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanForm: Story = {
  name: 'App / Loan application form',
  render: () => {
    const [product, setProduct] = useState('');
    const [tenure,  setTenure]  = useState('');
    const [purpose, setPurpose] = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        <Select
          label="Loan product"
          placeholder="Select a product"
          required
          value={product}
          onChange={setProduct}
          options={[
            { value: 'working-capital', label: 'Working capital' },
            { value: 'invoice',         label: 'Invoice financing' },
            { value: 'asset',           label: 'Asset finance' },
          ]}
        />
        <Select
          label="Loan tenure"
          placeholder="Select tenure"
          value={tenure}
          onChange={setTenure}
          options={[
            { value: '3m',  label: '3 months' },
            { value: '6m',  label: '6 months' },
            { value: '12m', label: '12 months' },
            { value: '24m', label: '24 months' },
          ]}
        />
        <Select
          label="Purpose of loan"
          placeholder="Select purpose"
          value={purpose}
          onChange={setPurpose}
          helperText="How will you use this loan?"
          options={[
            { value: 'inventory',  label: 'Inventory purchase' },
            { value: 'equipment',  label: 'Equipment' },
            { value: 'operations', label: 'Day-to-day operations' },
            { value: 'expansion',  label: 'Business expansion' },
          ]}
        />
      </div>
    );
  },
};

export const AppKYCForm: Story = {
  name: 'App / KYC business form',
  render: () => {
    const [sector,    setSector]    = useState('');
    const [employees, setEmployees] = useState('');
    const [country,   setCountry]   = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        <Select
          label="Business sector"
          placeholder="Select sector"
          required
          value={sector}
          onChange={setSector}
          options={[
            { value: 'agriculture',   label: 'Agriculture' },
            { value: 'manufacturing', label: 'Manufacturing' },
            { value: 'retail',        label: 'Retail & trade' },
            { value: 'services',      label: 'Professional services' },
            { value: 'technology',    label: 'Technology' },
          ]}
        />
        <Select
          label="Number of employees"
          placeholder="Select range"
          value={employees}
          onChange={setEmployees}
          options={[
            { value: '1-5',    label: '1–5 employees' },
            { value: '6-20',   label: '6–20 employees' },
            { value: '21-50',  label: '21–50 employees' },
            { value: '51-200', label: '51–200 employees' },
            { value: '200+',   label: '200+ employees' },
          ]}
        />
        <Select
          label="Country of registration"
          placeholder="Select country"
          required
          value={country}
          onChange={setCountry}
          options={[
            { value: 'ke', label: 'Kenya' },
            { value: 'ug', label: 'Uganda' },
            { value: 'tz', label: 'Tanzania' },
            { value: 'rw', label: 'Rwanda' },
            { value: 'et', label: 'Ethiopia' },
          ]}
        />
      </div>
    );
  },
};
