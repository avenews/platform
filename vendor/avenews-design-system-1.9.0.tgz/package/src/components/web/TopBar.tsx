import React from 'react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';

export interface TopBarAvatar {
  initials: string;
  name:     string;
  role?:    string;
}

export interface TopBarAction {
  id:        string;
  icon:      React.ReactNode;
  ariaLabel: string;
  hasDot?:   boolean;
  onClick?:  () => void;
}

export interface TopBarProps {
  title:        string;
  breadcrumb?:  string;
  avatar?:      TopBarAvatar;
  actions?:     TopBarAction[];
  /** Renders a compact mobile top bar with a menu trigger */
  mobile?:      boolean;
  onMenuClick?: () => void;
  className?:   string;
}

export const TopBar: React.FC<TopBarProps> = ({
  title,
  breadcrumb,
  avatar,
  actions    = [],
  mobile     = false,
  onMenuClick,
  className,
}) => (
  <header className={cn('ap-topbar', className)}>
    <div className="ap-topbar__title">
      {mobile && (
        <button
          type="button"
          className="ap-iconbtn"
          aria-label="Open menu"
          onClick={onMenuClick}
          style={{ marginRight: 12 }}
        >
          <Icon name="menu" size={20} aria-hidden />
        </button>
      )}
      {breadcrumb && <div className="ap-topbar__crumb">{breadcrumb}</div>}
      <h1>{title}</h1>
    </div>

    <div className="ap-topbar__actions">
      {actions.map(action => (
        <button
          key={action.id}
          type="button"
          className="ap-iconbtn"
          aria-label={action.ariaLabel}
          onClick={action.onClick}
        >
          {action.icon}
          {action.hasDot && <span className="ap-iconbtn__dot" aria-hidden="true" />}
        </button>
      ))}

      {avatar && (
        <div className="ap-avatar">
          <div className="ap-avatar__circle" aria-hidden="true">{avatar.initials}</div>
          <div>
            <div className="ap-avatar__name">{avatar.name}</div>
            {avatar.role && <div className="ap-avatar__role">{avatar.role}</div>}
          </div>
        </div>
      )}
    </div>
  </header>
);

export default TopBar;
