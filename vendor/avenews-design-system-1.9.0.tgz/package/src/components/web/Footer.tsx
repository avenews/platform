import React from 'react';
import { cn } from '../shared/utils';
import { Button } from './Button';
import type { ButtonVariant } from '../shared/types';

// ─── Types ────────────────────────────────────────────────────────────────────

export type FooterVariant = 'default' | 'elevated' | 'primary' | 'dark';
export type FooterLayout  = 'stack' | 'row';
export type FooterPosition = 'static' | 'sticky' | 'fixed';

export interface FooterAction {
  label:     string;
  variant?:  ButtonVariant;
  loading?:  boolean;
  disabled?: boolean;
  icon?:     React.ReactNode;
  iconSlot?: 'start' | 'end';
  onClick?:  () => void;
}

export interface FooterProps {
  /** Supporting text above buttons (legal note, hint, step counter, etc.) */
  caption?:   string;
  actions?:   FooterAction[];
  /** Custom slot — overrides actions */
  children?:  React.ReactNode;
  variant?:   FooterVariant;
  /** Show a top border divider. Default true. */
  divider?:   boolean;
  /** Button arrangement. `stack` = full-width stacked; `row` = side-by-side. */
  layout?:    FooterLayout;
  /** CSS position strategy. `static` = in-flow; `sticky` = sticks to bottom of
   *  scroll container; `fixed` = fixed to viewport bottom. */
  position?:  FooterPosition;
  className?: string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Footer: React.FC<FooterProps> = ({
  caption,
  actions   = [],
  children,
  variant   = 'default',
  divider   = true,
  layout    = 'stack',
  position  = 'static',
  className,
}) => (
  <footer
    className={cn(
      'av-footer',
      `av-footer--${variant}`,
      divider           && 'av-footer--divider',
      position !== 'static' && `av-footer--${position}`,
      className,
    )}
  >
    {caption && (
      <p className="av-footer__caption">{caption}</p>
    )}

    {children ? (
      <div className="av-footer__slot">{children}</div>
    ) : actions.length > 0 ? (
      <div className={cn(
        'av-footer__actions',
        layout === 'row' && 'av-footer__actions--row',
      )}>
        {actions.map((action, i) => (
          <Button
            key={action.label + i}
            label={action.label}
            variant={action.variant ?? (i === 0 ? 'primary' : 'ghost')}
            expand={layout === 'stack' ? 'block' : undefined}
            loading={action.loading}
            disabled={action.disabled}
            icon={action.icon}
            iconSlot={action.iconSlot ?? 'start'}
            onClick={action.onClick}
          />
        ))}
      </div>
    ) : null}
  </footer>
);

export default Footer;
