import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { UploadCard } from './UploadCard';

const meta: Meta<typeof UploadCard> = {
  title:     'Avenews/Web/UploadCard',
  component: UploadCard,
  tags:      ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component: 'Pure React UploadCard — no Ionic dependency. Inline SVG icons, token-based CSS. Five status variants: empty, uploading, uploaded, approved, rejected.',
      },
    },
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: 420, padding: 16 }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    status: {
      control: 'select',
      options: ['empty','uploading','uploaded','approved','rejected'],
    },
    progress: {
      control: { type: 'range', min: 0, max: 1, step: 0.01 },
    },
  },
  args: {
    title:    'Business Registration',
    status:   'empty',
    required: true,
    accept:   '.pdf,.jpg,.png',
  },
};

export default meta;
type Story = StoryObj<typeof UploadCard>;

// ─── Status variants ──────────────────────────────────────────────────────────

export const Empty: Story     = { args: { status: 'empty' } };

export const Uploading: Story = {
  args: { status: 'uploading', fileName: 'business-registration.pdf', progress: 0.6 },
};

export const Uploaded: Story = {
  args: { status: 'uploaded', fileName: 'business-registration.pdf', fileSize: 1_432_000 },
};

export const Approved: Story = {
  args: { status: 'approved', fileName: 'business-registration.pdf', fileSize: 1_432_000 },
};

export const Rejected: Story = {
  args: { status: 'rejected', fileName: 'blurry-scan.jpg', fileSize: 284_000 },
};

export const Disabled: Story = { args: { status: 'empty', disabled: true } };

// ─── Interactive ──────────────────────────────────────────────────────────────

export const Interactive: Story = {
  name: 'Interactive — full flow',
  render: () => {
    const [status,   setStatus]   = useState<'empty' | 'uploading' | 'uploaded'>('empty');
    const [fileName, setFileName] = useState<string  | undefined>();
    const [fileSize, setFileSize] = useState<number  | undefined>();
    const [progress, setProgress] = useState(0);

    const handleUpload = (file: File) => {
      setFileName(file.name);
      setFileSize(file.size);
      setStatus('uploading');
      setProgress(0);
      const tick = setInterval(() => {
        setProgress((p) => {
          if (p >= 1) { clearInterval(tick); setStatus('uploaded'); return 1; }
          return p + 0.1;
        });
      }, 200);
    };

    return (
      <UploadCard
        title="KRA Certificate"
        status={status}
        fileName={fileName}
        fileSize={fileSize}
        progress={progress}
        required
        onUpload={handleUpload}
        onRemove={() => { setStatus('empty'); setFileName(undefined); setFileSize(undefined); }}
      />
    );
  },
};

// ─── All variants (static showcase) ──────────────────────────────────────────

export const AllVariants: Story = {
  name: 'All Variants',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <UploadCard title="Empty (required)"            status="empty"     required />
      <UploadCard title="Uploading"                   status="uploading" fileName="doc.pdf"   progress={0.55} />
      <UploadCard title="Uploaded"                    status="uploaded"  fileName="cert.pdf"  fileSize={982_000} />
      <UploadCard title="Approved"                    status="approved"  fileName="cert.pdf"  fileSize={982_000} />
      <UploadCard title="Rejected — re-upload needed" status="rejected"  fileName="blurry.jpg" fileSize={124_000} />
    </div>
  ),
};

// ─── Document upload group ────────────────────────────────────────────────────

export const DocumentGroup: Story = {
  name: 'App / Document upload group',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <UploadCard title="Business Registration"  status="approved" fileName="reg.pdf"    fileSize={1_200_000} required />
      <UploadCard title="KRA Certificate"        status="uploaded" fileName="kra.pdf"    fileSize={980_000}   required />
      <UploadCard title="Bank Statement (3 months)" status="empty"                                           required />
      <UploadCard title="Director's ID"          status="rejected" fileName="id-scan.jpg" fileSize={320_000}  required />
      <UploadCard title="Utility Bill (optional)" status="empty" />
    </div>
  ),
};
