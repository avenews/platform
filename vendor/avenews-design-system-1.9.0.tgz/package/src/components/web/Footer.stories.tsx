import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Footer } from './Footer';
import { Icon } from './Icon';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Footer> = {
  title:     'Avenews/Web/Footer',
  component: Footer,
  tags:      ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Bottom action bar — rendered at the base of a page or scroll container. ' +
          'Supports a caption, stacked or row action buttons, 4 variants, ' +
          'and 3 position modes (static · sticky · fixed). ' +
          'Distinct from Toolbar, which is the top navigation bar.',
      },
    },
    layout: 'fullscreen',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '100%', maxWidth: 420, margin: '0 auto', minHeight: 200, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    variant:  { control: 'radio',   options: ['default', 'elevated', 'primary', 'dark'] },
    layout:   { control: 'radio',   options: ['stack', 'row'] },
    position: { control: 'radio',   options: ['static', 'sticky', 'fixed'] },
    divider:  { control: 'boolean' },
    caption:  { control: 'text' },
  },
  args: {
    variant:  'default',
    layout:   'stack',
    position: 'static',
    divider:  true,
  },
};

export default meta;
type Story = StoryObj<typeof Footer>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: {
    actions: [{ label: 'Continue' }],
  },
};

// ─── Single CTA ───────────────────────────────────────────────────────────────

export const SingleCTA: Story = {
  name: 'CTA / Single primary',
  args: {
    actions: [{ label: 'Submit application' }],
  },
};

export const SingleWithCaption: Story = {
  name: 'CTA / With caption',
  args: {
    caption: 'By submitting you agree to Avenews Terms & Privacy Policy.',
    actions: [{ label: 'Submit application' }],
  },
};

// ─── Two actions ─────────────────────────────────────────────────────────────

export const StackedTwoActions: Story = {
  name: 'Actions / Stacked (primary + ghost)',
  args: {
    actions: [
      { label: 'Continue' },
      { label: 'Save for later' },
    ],
  },
};

export const RowTwoActions: Story = {
  name: 'Actions / Row (cancel + confirm)',
  args: {
    layout:  'row',
    actions: [
      { label: 'Cancel',  variant: 'outline' },
      { label: 'Confirm' },
    ],
  },
};

// ─── Variants ────────────────────────────────────────────────────────────────

export const VariantElevated: Story = {
  name: 'Variant / Elevated',
  args: {
    variant: 'elevated',
    actions: [{ label: 'Apply for loan' }],
  },
};

export const VariantPrimary: Story = {
  name: 'Variant / Primary',
  args: {
    variant: 'primary',
    actions: [{ label: 'Get started', variant: 'inverted' }],
  },
};

export const VariantDark: Story = {
  name: 'Variant / Dark',
  args: {
    variant: 'dark',
    caption: 'Secured by 256-bit encryption.',
    actions: [{ label: 'Submit securely', variant: 'primary' }],
  },
};

// ─── No divider ───────────────────────────────────────────────────────────────

export const NoDivider: Story = {
  name: 'Style / No divider',
  args: {
    divider:  false,
    variant:  'elevated',
    actions:  [{ label: 'Continue' }],
  },
};

// ─── With icon ────────────────────────────────────────────────────────────────

export const WithIcon: Story = {
  name: 'Feature / Button with icon',
  args: {
    actions: [
      { label: 'Make repayment', icon: <Icon name="cash" size="sm" /> },
      { label: 'View schedule',  variant: 'ghost' },
    ],
  },
};

// ─── Custom slot ─────────────────────────────────────────────────────────────

export const CustomSlot: Story = {
  name: 'Feature / Custom slot',
  args: {
    caption: '3 of 5 steps completed',
  },
  render: (args) => (
    <Footer {...args}>
      <div style={{ display: 'flex', gap: 8 }}>
        <button type="button" style={{
          flex: 1, height: 48, background: 'transparent', border: '1.5px solid var(--av-color-surface-border)',
          borderRadius: 8, fontFamily: 'Poppins, sans-serif', fontSize: 14, fontWeight: 600,
          color: 'var(--av-color-text)', cursor: 'pointer',
        }}>Back</button>
        <button type="button" style={{
          flex: 1, height: 48, background: 'var(--av-color-action)',
          border: 'none', borderRadius: 8, fontFamily: 'Poppins, sans-serif', fontSize: 14,
          fontWeight: 600, color: '#fff', cursor: 'pointer',
        }}>Next step</button>
      </div>
    </Footer>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanApplication: Story = {
  name: 'App / Loan application CTA',
  args: {
    caption: 'Submitting will not affect your credit score.',
    variant: 'elevated',
    actions: [{ label: 'Submit application' }],
  },
};

export const AppRepayment: Story = {
  name: 'App / Repayment confirm',
  args: {
    layout:  'row',
    caption: 'KES 25,000 will be debited on 20 Apr 2026.',
    actions: [
      { label: 'Cancel',   variant: 'outline' },
      { label: 'Confirm payment' },
    ],
  },
};

export const AppKYCStep: Story = {
  name: 'App / KYC step navigation',
  args: {
    layout:  'row',
    actions: [
      { label: 'Back',   variant: 'ghost'   },
      { label: 'Next',   variant: 'primary' },
    ],
  },
};

export const AppDocumentUpload: Story = {
  name: 'App / Document upload',
  args: {
    actions: [
      { label: 'Upload document', icon: <Icon name="upload" size="sm" /> },
      { label: 'Skip for now' },
    ],
  },
};
