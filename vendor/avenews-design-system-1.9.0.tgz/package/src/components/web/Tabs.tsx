import React from 'react';
import { cn } from '../shared/utils';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface TabItem {
  value:     string;
  label?:    string;
  /** ReactNode icon (SVG, emoji, etc.) */
  icon?:     React.ReactNode;
  badge?:    number;
  disabled?: boolean;
}

export type TabsVariant = 'underline' | 'pill' | 'bar';

export interface TabsProps {
  tabs:       TabItem[];
  value?:     string;
  /** Visual style. `bar` is suited for fixed bottom navigation. */
  variant?:   TabsVariant;
  /** Distribute tabs equally across full width */
  stretch?:   boolean;
  ariaLabel?: string;
  onChange?:  (value: string) => void;
  className?: string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Tabs: React.FC<TabsProps> = ({
  tabs,
  value,
  variant  = 'underline',
  stretch  = false,
  ariaLabel,
  onChange,
  className,
}) => (
  <div
    className={cn(
      'av-tabs',
      `av-tabs--${variant}`,
      stretch && 'av-tabs--stretch',
      className,
    )}
    role="tablist"
    aria-label={ariaLabel}
  >
    {tabs.map((tab) => {
      const isActive = tab.value === value;
      return (
        <button
          key={tab.value}
          type="button"
          role="tab"
          aria-selected={isActive}
          disabled={tab.disabled}
          className={cn(
            'av-tabs__tab',
            isActive     && 'av-tabs__tab--active',
            tab.disabled && 'av-tabs__tab--disabled',
          )}
          onClick={() => !tab.disabled && onChange?.(tab.value)}
        >
          {tab.icon && (
            <span className="av-tabs__icon" aria-hidden="true">{tab.icon}</span>
          )}
          {tab.label && (
            <span className="av-tabs__label">{tab.label}</span>
          )}
          {tab.badge !== undefined && tab.badge > 0 && (
            <span className="av-tabs__badge" aria-label={`${tab.badge} notifications`}>
              {tab.badge > 99 ? '99+' : tab.badge}
            </span>
          )}
        </button>
      );
    })}
  </div>
);

export default Tabs;
