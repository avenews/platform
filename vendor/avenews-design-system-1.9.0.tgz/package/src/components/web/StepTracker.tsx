import React from 'react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';

export interface StepTrackerStep {
  id:     number;
  label:  string;
}

export type StepState = 'done' | 'current' | 'future';

export interface StepTrackerProps {
  steps:    StepTrackerStep[];
  current:  number;
  /** Show the progress bar + label row below the steps */
  showBar?: boolean;
  className?: string;
}

const DEFAULT_STEPS: StepTrackerStep[] = [
  { id: 1, label: 'Eligibility' },
  { id: 2, label: 'Business info' },
  { id: 3, label: 'Owners' },
  { id: 4, label: 'Documents' },
  { id: 5, label: 'Review' },
  { id: 6, label: 'Offer' },
  { id: 7, label: 'Disbursal' },
];

export const StepTracker: React.FC<StepTrackerProps> = ({
  steps   = DEFAULT_STEPS,
  current = 1,
  showBar = true,
  className,
}) => {
  const total    = steps.length;
  const pct      = total > 1 ? Math.round(((current - 1) / (total - 1)) * 100) : 100;
  const barWidth = `${pct}%`;

  return (
    <div className={cn('ap-tracker', className)}>
      <div
        className="ap-tracker__steps"
        style={{ gridTemplateColumns: `repeat(${total}, 1fr)` }}
      >
        {steps.map(step => {
          const state: StepState =
            step.id < current ? 'done'
            : step.id === current ? 'current'
            : 'future';

          return (
            <div key={step.id} className={`ap-step ap-step--${state}`}>
              <div className="ap-step__dot">
                {state === 'done'
                  ? <Icon name="checkmark" size={14} aria-hidden />
                  : step.id}
              </div>
              <div className="ap-step__lbl">{step.label}</div>
            </div>
          );
        })}
      </div>

      {showBar && (
        <>
          <div className="ap-tracker__bar">
            <i style={{ width: barWidth }} />
          </div>
          <div className="ap-tracker__bar-lbl">
            <span>Step {current} of {total}</span>
            <span>{pct}% complete</span>
          </div>
        </>
      )}
    </div>
  );
};

export { DEFAULT_STEPS as APPLICATION_STEPS };
export default StepTracker;
