import React from 'react';
import { X } from 'lucide-react';
import { cn } from '../shared/utils';

export interface FilterBarOption {
  label: string;
  value: string;
}

export interface FilterBarFilter {
  /** Unique identifier for this filter */
  id:        string;
  label:     string;
  value:     string;
  options:   FilterBarOption[];
  onChange:  (value: string) => void;
}

export interface FilterBarProps {
  filters:     FilterBarFilter[];
  /** Called when the user clicks "Clear all" — reset all filters to their default */
  onClearAll?: () => void;
  className?:  string;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onClearAll,
  className,
}) => {
  const hasActive = filters.some(f => f.value !== '' && f.value !== f.options[0]?.value);

  return (
    <div className={cn('av-filter-bar', className)}>
      <div className="av-filter-bar__filters">
        {filters.map(filter => (
          <div key={filter.id} className="av-filter-bar__item">
            <label className="av-filter-bar__label" htmlFor={`filter-${filter.id}`}>
              {filter.label}
            </label>
            <select
              id={`filter-${filter.id}`}
              className="av-filter-bar__select"
              value={filter.value}
              onChange={e => filter.onChange(e.target.value)}
            >
              {filter.options.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
        ))}
      </div>

      {hasActive && onClearAll && (
        <button
          type="button"
          className="av-filter-bar__clear"
          onClick={onClearAll}
          aria-label="Clear all filters"
        >
          <X size={14} strokeWidth={2} aria-hidden />
          Clear all
        </button>
      )}
    </div>
  );
};

export default FilterBar;
