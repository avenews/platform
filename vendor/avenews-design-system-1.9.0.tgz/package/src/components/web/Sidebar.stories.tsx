import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Sidebar, DEFAULT_NAV_ITEMS, DEFAULT_FOOTER_ITEMS } from './Sidebar';

const meta: Meta<typeof Sidebar> = {
  title:     'Avenews/Web/Portal/Sidebar',
  component: Sidebar,
  tags:      ['autodocs'],
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Application portal left-sidebar navigation. Sticky, 248px wide on desktop. Accepts nav items with icons and optional notification badges. Collapses below 900px (hidden, replaced by mobile top bar).',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Sidebar>;

export const Default: Story = {
  args: {
    navItems:    DEFAULT_NAV_ITEMS,
    footerItems: DEFAULT_FOOTER_ITEMS,
    activeId:    'dashboard',
  },
  render: (args) => {
    const [active, setActive] = useState(args.activeId ?? 'dashboard');
    return (
      <div style={{ display: 'flex', height: '100vh', background: '#f6f7f9' }}>
        <Sidebar {...args} activeId={active} onNavigate={setActive} />
        <div style={{ flex: 1, padding: 32, color: '#6b7280', fontFamily: 'Poppins, sans-serif' }}>
          Active: <strong style={{ color: '#0d343f' }}>{active}</strong>
        </div>
      </div>
    );
  },
};

export const WithBadge: Story = {
  args: {
    navItems: [
      ...DEFAULT_NAV_ITEMS.slice(0, 2),
      { ...DEFAULT_NAV_ITEMS[2], badge: 3 },
      ...DEFAULT_NAV_ITEMS.slice(3),
    ],
    footerItems: DEFAULT_FOOTER_ITEMS,
    activeId:    'application',
  },
  render: (args) => {
    const [active, setActive] = useState(args.activeId ?? 'dashboard');
    return (
      <div style={{ display: 'flex', height: '100vh', background: '#f6f7f9' }}>
        <Sidebar {...args} activeId={active} onNavigate={setActive} />
        <div style={{ flex: 1, padding: 32 }} />
      </div>
    );
  },
};
