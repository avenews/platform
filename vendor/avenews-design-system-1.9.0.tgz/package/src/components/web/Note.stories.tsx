import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Note } from './Note';

const meta: Meta<typeof Note> = {
  title: 'Avenews/Web/Note',
  component: Note,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Inline helper text rendered as a <span>. ' +
          'Supports 11 colour tokens and left / center / right alignment.',
      },
    },
    layout: 'padded',
  },
};

export default meta;
type Story = StoryObj<typeof Note>;

// ─── Default ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: {
    label: 'This is a note.',
  },
};

// ─── Colours ──────────────────────────────────────────────────────────────────

const colors = [
  'default', 'primary', 'secondary', 'tertiary',
  'success', 'warning', 'danger',
  'light', 'medium', 'dark',
] as const;

export const AllColours: Story = {
  name: 'Colours / All',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontFamily: 'var(--av-font-body)' }}>
      {colors.map((color) => (
        <div key={color} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ width: 80, fontSize: 12, color: 'var(--av-neutral-400)' }}>{color}</span>
          <Note label={`${color} — helper text for this field`} color={color} />
        </div>
      ))}
    </div>
  ),
};

// ─── Alignment ────────────────────────────────────────────────────────────────

export const Alignment: Story = {
  name: 'Alignment / Left · Center · Right',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, width: 320, fontFamily: 'var(--av-font-body)' }}>
      <Note label="Left-aligned helper text"   align="left"   />
      <Note label="Centered helper text"        align="center" />
      <Note label="Right-aligned helper text"   align="right"  />
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const FormHelper: Story = {
  name: 'App / Form helper text',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontFamily: 'var(--av-font-body)', width: 300 }}>
      <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--av-neutral-700)' }}>
        Business registration number
      </label>
      <input
        placeholder="e.g. BRN-2024-00123"
        style={{ padding: '10px 12px', borderRadius: 8, border: '1px solid var(--av-neutral-300)', fontSize: 14, fontFamily: 'inherit' }}
      />
      <Note label="Find this on your certificate of incorporation." color="medium" />
    </div>
  ),
};

export const ErrorNote: Story = {
  name: 'App / Validation error',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontFamily: 'var(--av-font-body)', width: 300 }}>
      <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--av-neutral-700)' }}>
        Repayment amount (KES)
      </label>
      <input
        defaultValue="0"
        style={{ padding: '10px 12px', borderRadius: 8, border: '1.5px solid var(--av-color-danger)', fontSize: 14, fontFamily: 'inherit' }}
      />
      <Note label="Amount must be greater than KES 100." color="danger" />
    </div>
  ),
};

export const SuccessNote: Story = {
  name: 'App / Success confirmation',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontFamily: 'var(--av-font-body)', width: 300 }}>
      <label style={{ fontSize: 13, fontWeight: 600, color: 'var(--av-neutral-700)' }}>
        M-Pesa phone number
      </label>
      <input
        defaultValue="+254 712 345 678"
        style={{ padding: '10px 12px', borderRadius: 8, border: '1.5px solid var(--av-color-success)', fontSize: 14, fontFamily: 'inherit' }}
      />
      <Note label="✓ Number verified successfully." color="success" />
    </div>
  ),
};
