import React from 'react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';

// ─── Types ────────────────────────────────────────────────────────────────────

export type ToolbarVariant = 'default' | 'transparent' | 'primary' | 'dark';

export interface ToolbarAction {
  icon:      React.ReactNode;
  label:     string;
  onClick?:  () => void;
  disabled?: boolean;
}

export interface ToolbarProps {
  title?:           string;
  subtitle?:        string;
  variant?:         ToolbarVariant;
  /** Center the title even when leading/trailing slots are present */
  centerTitle?:     boolean;
  showBackButton?:  boolean;
  onBack?:          () => void;
  backLabel?:       string;
  /** Custom leading slot — overrides showBackButton */
  leadingSlot?:     React.ReactNode;
  /** Up to 3 trailing icon-button actions */
  trailingActions?: ToolbarAction[];
  /** Custom trailing slot — overrides trailingActions when provided. Use when
   *  the trailing area needs a richer element (e.g. a Popover trigger button). */
  trailingSlot?:    React.ReactNode;
  className?:       string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Toolbar: React.FC<ToolbarProps> = ({
  title,
  subtitle,
  variant         = 'default',
  centerTitle     = false,
  showBackButton  = false,
  onBack,
  backLabel,
  leadingSlot,
  trailingActions = [],
  trailingSlot,
  className,
}) => {
  const hasLeading  = Boolean(leadingSlot ?? showBackButton);
  const hasTrailing = Boolean(trailingSlot) || trailingActions.length > 0;

  const leading = leadingSlot ?? (showBackButton ? (
    <button
      type="button"
      className="av-toolbar__back"
      onClick={onBack}
      aria-label={backLabel ?? 'Go back'}
    >
      <Icon name="chevron-back" size={20} />
      {backLabel && <span className="av-toolbar__back-label">{backLabel}</span>}
    </button>
  ) : null);

  return (
    <div
      className={cn(
        'av-toolbar',
        `av-toolbar--${variant}`,
        centerTitle && 'av-toolbar--center-title',
        className,
      )}
      role="banner"
    >
      <div className={cn('av-toolbar__leading', !hasLeading && 'av-toolbar__leading--empty')}>
        {leading}
      </div>

      <div className="av-toolbar__title-wrap">
        {title && <span className="av-toolbar__title">{title}</span>}
        {subtitle && <span className="av-toolbar__subtitle">{subtitle}</span>}
      </div>

      <div className={cn('av-toolbar__trailing', !hasTrailing && 'av-toolbar__trailing--empty')}>
        {trailingSlot ?? trailingActions.slice(0, 3).map((action, i) => (
          <button
            key={i}
            type="button"
            className="av-toolbar__action"
            aria-label={action.label}
            disabled={action.disabled}
            onClick={action.onClick}
          >
            {action.icon}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Toolbar;
