import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Segment } from './Segment';
import type { SegmentOption } from './Segment';

// ─── Meta ───────────────────────��──────────────────────────────────���──────────

const meta: Meta<typeof Segment> = {
  title: 'Avenews/Web/Segment',
  component: Segment,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Horizontal tab-bar for switching between mutually exclusive views. ' +
          'Supports text, icon, or icon+text buttons, an optional scrollable mode ' +
          'for many options, and per-option disabled states.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Segment>;

// ─── Helpers ────────────────────────���───────────────────────��─────────────────

const GridIcon: React.FC = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <rect x="3" y="3" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
    <rect x="14" y="3" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
    <rect x="3" y="14" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
    <rect x="14" y="14" width="7" height="7" stroke="currentColor" strokeWidth="2"/>
  </svg>
);

const ListIcon: React.FC = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <line x1="8" y1="6" x2="21" y2="6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <line x1="8" y1="12" x2="21" y2="12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <line x1="8" y1="18" x2="21" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <line x1="3" y1="6" x2="3.01" y2="6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <line x1="3" y1="12" x2="3.01" y2="12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <line x1="3" y1="18" x2="3.01" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

// ─── Text-only segments ───────────────────────────��───────────────────────────

const TEXT_OPTIONS: SegmentOption[] = [
  { value: 'all',       label: 'All' },
  { value: 'active',    label: 'Active' },
  { value: 'completed', label: 'Completed' },
];

export const Default: Story = {
  name: 'Default (text)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('all');
    return <Segment options={TEXT_OPTIONS} value={val} onChange={setVal} />;
  },
};

export const TwoOptions: Story = {
  name: 'Text / Two options',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('loans');
    return (
      <Segment
        value={val}
        onChange={setVal}
        options={[
          { value: 'loans',      label: 'Loans' },
          { value: 'repayments', label: 'Repayments' },
        ]}
      />
    );
  },
};

export const FourOptions: Story = {
  name: 'Text / Four options',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('overview');
    return (
      <Segment
        value={val}
        onChange={setVal}
        options={[
          { value: 'overview',   label: 'Overview' },
          { value: 'documents',  label: 'Documents' },
          { value: 'payments',   label: 'Payments' },
          { value: 'activity',   label: 'Activity' },
        ]}
      />
    );
  },
};

// ─── Icon-only ────────────────────────────────────────────────────────────────

export const IconOnly: Story = {
  name: 'Icons / Icon-only',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('grid');
    return (
      <Segment
        value={val}
        onChange={setVal}
        options={[
          { value: 'grid', label: 'Grid view', icon: <GridIcon />, iconPosition: 'icon-only' },
          { value: 'list', label: 'List view', icon: <ListIcon />, iconPosition: 'icon-only' },
        ]}
      />
    );
  },
};

// ─── Icon + text ──────────────────────────────────────────────────────────────

export const IconStart: Story = {
  name: 'Icons / Icon + text (start)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('grid');
    return (
      <Segment
        value={val}
        onChange={setVal}
        options={[
          { value: 'grid', label: 'Grid', icon: <GridIcon />, iconPosition: 'start' },
          { value: 'list', label: 'List', icon: <ListIcon />, iconPosition: 'start' },
        ]}
      />
    );
  },
};

// ─── With disabled option ─────────────────────────────────────────────────────

export const WithDisabledOption: Story = {
  name: 'State / Disabled option',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('active');
    return (
      <Segment
        value={val}
        onChange={setVal}
        options={[
          { value: 'active',   label: 'Active' },
          { value: 'archived', label: 'Archived', disabled: true },
          { value: 'draft',    label: 'Draft' },
        ]}
      />
    );
  },
};

// ─── Scrollable ──────────────────────���────────────────────────────────────────

export const Scrollable: Story = {
  name: 'Feature / Scrollable',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('jan');
    return (
      <Segment
        scrollable
        value={val}
        onChange={setVal}
        options={['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
          .map((m) => ({ value: m.toLowerCase(), label: m }))}
      />
    );
  },
};

// ─── App use-cases ──────────────────────────────���─────────────────────────────

export const DocumentStatus: Story = {
  name: 'App / Document status filter',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('all');
    return (
      <Segment
        value={val}
        onChange={setVal}
        options={[
          { value: 'all',    label: 'All' },
          { value: 'action', label: 'Action required' },
          { value: 'review', label: 'In review' },
          { value: 'done',   label: 'Completed' },
        ]}
      />
    );
  },
};

export const ViewToggle: Story = {
  name: 'App / View toggle (grid / list)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [val, setVal] = useState('grid');
    return (
      <Segment
        value={val}
        onChange={setVal}
        options={[
          { value: 'grid', label: 'Grid', icon: <GridIcon />, iconPosition: 'start' },
          { value: 'list', label: 'List', icon: <ListIcon />, iconPosition: 'start' },
        ]}
      />
    );
  },
};
