import React from 'react';
import { cn } from '../shared/utils';

export type MediaIconColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light' | 'medium' | 'dark' | 'white' | 'black';

export type MediaIconSize  = 'sm' | 'default' | 'lg';
export type AvatarSize     = 'sm' | 'md' | 'lg';
export type ThumbnailSize  = 'sm' | 'md' | 'lg';

// ─── Avatar ───────────────────────────────────────────────────────────────────

export interface AvatarProps {
  src?:       string;
  alt?:       string;
  initials?:  string;
  size?:      AvatarSize;
  className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({
  src,
  alt      = '',
  initials,
  size     = 'md',
  className,
}) => (
  <div className={cn('avenews-avatar', `avenews-avatar--${size}`, className)}>
    {src ? (
      <img src={src} alt={alt} />
    ) : initials ? (
      <span className="avenews-avatar__initials">{initials.slice(0, 2).toUpperCase()}</span>
    ) : (
      <span className="avenews-avatar__placeholder" aria-hidden="true" />
    )}
  </div>
);

// ─── Thumbnail ────────────────────────────────────────────────────────────────

export interface ThumbnailProps {
  src?:       string;
  alt?:       string;
  size?:      ThumbnailSize;
  className?: string;
}

export const Thumbnail: React.FC<ThumbnailProps> = ({
  src,
  alt      = '',
  size     = 'md',
  className,
}) => (
  <div className={cn('avenews-thumbnail', `avenews-thumbnail--${size}`, className)}>
    {src ? (
      <img src={src} alt={alt} />
    ) : (
      <span className="avenews-thumbnail__placeholder" aria-hidden="true" />
    )}
  </div>
);

// ─── MediaIcon ────────────────────────────────────────────────────────────────
// API change: `icon` accepts ReactNode instead of an Ionic icon string.

export interface MediaIconProps {
  /** ReactNode icon (SVG, emoji, etc.) — replaces Ionic icon string */
  icon:       React.ReactNode;
  color?:     MediaIconColor;
  size?:      MediaIconSize;
  className?: string;
}

export const MediaIcon: React.FC<MediaIconProps> = ({
  icon,
  color     = 'primary',
  size      = 'default',
  className,
}) => (
  <span className={cn(
    'av-media-icon',
    `av-media-icon--${size}`,
    `av-media-icon--${color}`,
    className,
  )}>
    {icon}
  </span>
);

export default MediaIcon;
