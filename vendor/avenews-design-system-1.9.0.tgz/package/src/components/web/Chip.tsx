import React from 'react';
import { cn } from '../shared/utils';

export type ChipColor =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  // `info` completes the semantic set alongside success/warning/danger. It was
  // missing until v1.8.0, so consumers whose status maps emitted an `info` token
  // fell through to the dark default chip and had to define the class locally.
  | 'success' | 'warning' | 'danger' | 'info'
  | 'light' | 'medium' | 'dark' | 'accent';

export type ChipFill    = 'solid' | 'outline';
export type ChipVariant = ChipColor | 'neutral' | 'outline';

export interface ChipProps {
  label:        string;
  color?:       ChipColor;
  fill?:        ChipFill;
  /** @deprecated Use color + fill */
  variant?:     ChipVariant;
  /** ReactNode leading icon (replaces Ionic icon string) */
  leadingIcon?: React.ReactNode;
  dismissible?: boolean;
  avatarUrl?:   string;
  avatarAlt?:   string;
  selected?:    boolean;
  disabled?:    boolean;
  loading?:     boolean;
  onClick?:     () => void;
  onDismiss?:   () => void;
  className?:   string;
}

function resolveColor(color?: ChipColor, variant?: ChipVariant): ChipColor {
  if (color)  return color;
  if (!variant) return 'default';
  if (variant === 'neutral' || variant === 'outline') return 'default';
  return variant as ChipColor;
}

function resolveFill(fill?: ChipFill, variant?: ChipVariant): ChipFill {
  if (fill) return fill;
  if (variant === 'outline') return 'outline';
  return 'solid';
}

export const Chip: React.FC<ChipProps> = ({
  label,
  color,
  fill,
  variant,
  leadingIcon,
  dismissible = false,
  avatarUrl,
  avatarAlt   = '',
  selected    = false,
  disabled    = false,
  loading     = false,
  onClick,
  onDismiss,
  className,
}) => {
  const resolvedColor = resolveColor(color, variant);
  const resolvedFill  = resolveFill(fill, variant);
  const isOutline     = resolvedFill === 'outline' && !selected;

  const handleDismiss = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!disabled && !loading) onDismiss?.();
  };

  return (
    <button
      type="button"
      className={cn(
        'av-chip',
        `av-chip--${resolvedColor}`,
        isOutline  && 'av-chip--outline',
        selected   && 'av-chip--selected',
        className,
      )}
      disabled={disabled || loading}
      onClick={(!disabled && !loading) ? onClick : undefined}
    >
      {avatarUrl && !leadingIcon && (
        <span className="av-chip__avatar">
          <img src={avatarUrl} alt={avatarAlt} />
        </span>
      )}

      {leadingIcon && !avatarUrl && (
        <span className="av-chip__icon" aria-hidden="true">{leadingIcon}</span>
      )}

      <span>{loading ? 'Loading…' : label}</span>

      {dismissible && (
        <span className="av-chip__dismiss" onClick={handleDismiss} aria-label="Remove">
          ✕
        </span>
      )}
    </button>
  );
};

export default Chip;
