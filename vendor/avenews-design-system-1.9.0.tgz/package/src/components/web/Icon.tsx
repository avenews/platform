import React from 'react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '../shared/utils';

// ─── Types ────────────────────────────────────────────────────────────────────

export type IconName =
  | 'add'
  | 'arrow-back'
  | 'arrow-forward'
  | 'attach'
  | 'bar-chart'
  | 'calendar'
  | 'call'
  | 'cash'
  | 'checkmark'
  | 'checkmark-circle'
  | 'chevron-back'
  | 'chevron-down'
  | 'chevron-forward'
  | 'chevron-up'
  | 'close'
  | 'close-circle'
  | 'create'
  | 'document'
  | 'document-text'
  | 'download'
  | 'ellipsis-horizontal'
  | 'ellipsis-vertical'
  | 'eye'
  | 'eye-off'
  | 'heart'
  | 'help-circle'
  | 'home'
  | 'information-circle'
  | 'list'
  | 'mail'
  | 'menu'
  | 'notifications'
  | 'person'
  | 'receipt'
  | 'refresh'
  | 'remove'
  | 'search'
  | 'settings'
  | 'share'
  | 'shield-checkmark'
  | 'star'
  | 'time'
  | 'trash'
  | 'upload'
  | 'wallet'
  | 'warning';

export type IconSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export interface IconProps {
  /** Built-in named icon from the catalog */
  name?:         IconName;
  /** Ionicons data-URI export — `import { homeOutline } from 'ionicons/icons'`
   *  Supports all 1357 ionicons (filled / outline / sharp variants). */
  icon?:         string;
  /** Lucide icon component — `import { Home } from 'lucide-react'` → `<Icon lucideIcon={Home} />`
   *  Renders with strokeWidth=2 and currentColor per Avenews icon rules. */
  lucideIcon?:   LucideIcon;
  size?:         IconSize | number;
  color?:        string;
  className?:    string;
  'aria-label'?: string;
  'aria-hidden'?: boolean;
}

// ─── Size map ─────────────────────────────────────────────────────────────────

const SIZE_PX: Record<IconSize, number> = {
  xs: 14,
  sm: 16,
  md: 20,
  lg: 24,
  xl: 32,
};

// ─── Icon paths ───────────────────────────────────────────────────────────────
// All icons use a 24×24 viewBox, outline/stroke style.
// The parent <svg> sets stroke="currentColor" strokeWidth="2"
// strokeLinecap="round" strokeLinejoin="round" fill="none".

const ICONS: Record<IconName, React.ReactNode> = {

  add: (
    <>
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5"  y1="12" x2="19" y2="12" />
    </>
  ),

  'arrow-back': (
    <>
      <line x1="19" y1="12" x2="5" y2="12" />
      <polyline points="12 19 5 12 12 5" />
    </>
  ),

  'arrow-forward': (
    <>
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="12 5 19 12 12 19" />
    </>
  ),

  attach: (
    <path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48" />
  ),

  'bar-chart': (
    <>
      <line x1="18" y1="20" x2="18" y2="10" />
      <line x1="12" y1="20" x2="12" y2="4"  />
      <line x1="6"  y1="20" x2="6"  y2="14" />
    </>
  ),

  calendar: (
    <>
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8"  y1="2" x2="8"  y2="6" />
      <line x1="3"  y1="10" x2="21" y2="10" />
    </>
  ),

  call: (
    <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z" />
  ),

  cash: (
    <>
      <rect x="2" y="7" width="20" height="13" rx="2" ry="2" />
      <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2" />
      <line x1="12" y1="12" x2="12" y2="16" />
      <line x1="10" y1="14" x2="14" y2="14" />
    </>
  ),

  checkmark: (
    <polyline points="20 6 9 17 4 12" />
  ),

  'checkmark-circle': (
    <>
      <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </>
  ),

  'chevron-back': (
    <polyline points="15 18 9 12 15 6" />
  ),

  'chevron-down': (
    <polyline points="6 9 12 15 18 9" />
  ),

  'chevron-forward': (
    <polyline points="9 18 15 12 9 6" />
  ),

  'chevron-up': (
    <polyline points="18 15 12 9 6 15" />
  ),

  close: (
    <>
      <line x1="18" y1="6"  x2="6"  y2="18" />
      <line x1="6"  y1="6"  x2="18" y2="18" />
    </>
  ),

  'close-circle': (
    <>
      <circle cx="12" cy="12" r="10" />
      <line x1="15" y1="9"  x2="9"  y2="15" />
      <line x1="9"  y1="9"  x2="15" y2="15" />
    </>
  ),

  create: (
    <>
      <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" />
    </>
  ),

  document: (
    <>
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
      <polyline points="14 2 14 8 20 8" />
    </>
  ),

  'document-text': (
    <>
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
      <polyline points="10 9 9 9 8 9" />
    </>
  ),

  download: (
    <>
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </>
  ),

  'ellipsis-horizontal': (
    <>
      <circle cx="5"  cy="12" r="1" fill="currentColor" stroke="none" />
      <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
      <circle cx="19" cy="12" r="1" fill="currentColor" stroke="none" />
    </>
  ),

  'ellipsis-vertical': (
    <>
      <circle cx="12" cy="5"  r="1" fill="currentColor" stroke="none" />
      <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
      <circle cx="12" cy="19" r="1" fill="currentColor" stroke="none" />
    </>
  ),

  eye: (
    <>
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),

  'eye-off': (
    <>
      <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94" />
      <path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19" />
      <line x1="1"  y1="1"  x2="23" y2="23" />
    </>
  ),

  heart: (
    <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" />
  ),

  'help-circle': (
    <>
      <circle cx="12" cy="12" r="10" />
      <path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </>
  ),

  home: (
    <>
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </>
  ),

  'information-circle': (
    <>
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8"  x2="12.01" y2="8" />
    </>
  ),

  list: (
    <>
      <line x1="8"  y1="6"  x2="21" y2="6"  />
      <line x1="8"  y1="12" x2="21" y2="12" />
      <line x1="8"  y1="18" x2="21" y2="18" />
      <line x1="3"  y1="6"  x2="3.01" y2="6"  />
      <line x1="3"  y1="12" x2="3.01" y2="12" />
      <line x1="3"  y1="18" x2="3.01" y2="18" />
    </>
  ),

  mail: (
    <>
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
      <polyline points="22 6 12 13 2 6" />
    </>
  ),

  menu: (
    <>
      <line x1="3" y1="12" x2="21" y2="12" />
      <line x1="3" y1="6"  x2="21" y2="6"  />
      <line x1="3" y1="18" x2="21" y2="18" />
    </>
  ),

  notifications: (
    <>
      <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.73 21a2 2 0 01-3.46 0" />
    </>
  ),

  person: (
    <>
      <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </>
  ),

  receipt: (
    <>
      <path d="M20 5H4a1 1 0 00-1 1v12.5l2.5-1.5 2.5 1.5 2.5-1.5 2.5 1.5 2.5-1.5 2.5 1.5 2.5-1.5V6a1 1 0 00-1-1z" />
      <line x1="9"  y1="10" x2="15" y2="10" />
      <line x1="9"  y1="14" x2="13" y2="14" />
    </>
  ),

  refresh: (
    <>
      <polyline points="23 4 23 10 17 10" />
      <polyline points="1 20 1 14 7 14" />
      <path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15" />
    </>
  ),

  remove: (
    <line x1="5" y1="12" x2="19" y2="12" />
  ),

  search: (
    <>
      <circle cx="11" cy="11" r="8" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </>
  ),

  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" />
    </>
  ),

  share: (
    <>
      <path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8" />
      <polyline points="16 6 12 2 8 6" />
      <line x1="12" y1="2" x2="12" y2="15" />
    </>
  ),

  'shield-checkmark': (
    <>
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <polyline points="9 12 11 14 15 10" />
    </>
  ),

  star: (
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
  ),

  time: (
    <>
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </>
  ),

  trash: (
    <>
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14H6L5 6" />
      <path d="M10 11v6M14 11v6" />
      <path d="M9 6V4h6v2" />
    </>
  ),

  upload: (
    <>
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </>
  ),

  wallet: (
    <>
      <path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z" />
      <path d="M16 3.13a4 4 0 010 7.75" />
      <circle cx="16" cy="13" r="1" fill="currentColor" stroke="none" />
    </>
  ),

  warning: (
    <>
      <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
      <line x1="12" y1="9"  x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </>
  ),
};

// ─── Component ────────────────────────────────────────────────────────────────

export const Icon: React.FC<IconProps> = ({
  name,
  icon,
  lucideIcon: LucideComp,
  size           = 'md',
  color,
  className,
  'aria-label':  ariaLabel,
  'aria-hidden': ariaHidden = true,
}) => {
  const px = typeof size === 'number' ? size : SIZE_PX[size];
  const hiddenAttr = ariaHidden ? ('true' as const) : undefined;

  // ── Lucide icon path ──────────────────────────────────────────────────────
  // strokeWidth=2 and currentColor are enforced per Avenews icon rules.
  if (LucideComp) {
    return (
      <LucideComp
        size={px}
        strokeWidth={2}
        aria-hidden={hiddenAttr}
        aria-label={ariaLabel}
        className={cn('av-icon', className)}
        style={color ? { color } : undefined}
        focusable={false}
      />
    );
  }

  // ── Ionicons data-URI path ────────────────────────────────────────────────
  // Render via CSS mask-image so currentColor colouring works for all variants.
  if (icon) {
    return (
      <span
        role={ariaLabel ? 'img' : undefined}
        aria-label={ariaLabel}
        aria-hidden={hiddenAttr}
        className={cn('av-icon', 'av-icon--ion', className)}
        style={{
          width:                  px,
          height:                 px,
          WebkitMaskImage:        `url("${icon}")`,
          maskImage:              `url("${icon}")`,
          color:                  color ?? undefined,
          backgroundColor:        color ?? 'currentColor',
        }}
      />
    );
  }

  // ── Built-in catalog path ─────────────────────────────────────────────────
  if (!name) return null;

  return (
    <svg
      width={px}
      height={px}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden={hiddenAttr}
      aria-label={ariaLabel}
      className={cn('av-icon', className)}
      style={color ? { color } : undefined}
      focusable="false"
    >
      {ICONS[name]}
    </svg>
  );
};

export default Icon;
