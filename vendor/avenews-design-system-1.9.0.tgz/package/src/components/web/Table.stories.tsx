import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Table } from './Table';
import type { TableColumn } from './Table';

const meta: Meta = {
  title:     'Avenews/Web/Portal/Table',
  component: Table,
  tags:      ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Generic data table for CRM portals, admin dashboards, and transaction history. White card with subtle shadow and hairline row dividers. Supports custom cell renderers, mono/muted column variants, and empty state.',
      },
    },
  },
};

export default meta;
type Story = StoryObj;

// ─── Transaction history ──────────────────────────────────────────────────────

interface TxRow {
  id:     string;
  date:   string;
  ref:    string;
  desc:   string;
  amount: string;
  status: string;
}

const TX_COLS: TableColumn<TxRow>[] = [
  { key: 'date',   header: 'Date' },
  { key: 'ref',    header: 'Reference',  mono: true },
  { key: 'desc',   header: 'Description' },
  { key: 'amount', header: 'Amount (KES)', align: 'right', mono: true },
  {
    key:    'status',
    header: 'Status',
    render: (_row, val) => {
      const cls: Record<string, string> = {
        Completed:  'av-badge av-badge--success',
        Pending:    'av-badge av-badge--neutral',
        Failed:     'av-badge av-badge--danger',
      };
      return <span className={cls[val as string] ?? 'av-badge'}>{val as string}</span>;
    },
  },
];

const TX_ROWS: TxRow[] = [
  { id: '1', date: '6 May 2026',  ref: 'TXN-00412', desc: 'Loan disbursement',        amount: '1,200,000', status: 'Completed' },
  { id: '2', date: '2 May 2026',  ref: 'TXN-00391', desc: 'Repayment — May instalment', amount: '48,000',   status: 'Completed' },
  { id: '3', date: '28 Apr 2026', ref: 'TXN-00364', desc: 'Repayment — Apr instalment', amount: '48,000',   status: 'Pending' },
  { id: '4', date: '15 Apr 2026', ref: 'TXN-00320', desc: 'Processing fee',             amount: '6,000',    status: 'Completed' },
  { id: '5', date: '10 Apr 2026', ref: 'TXN-00298', desc: 'Insurance premium',          amount: '3,200',    status: 'Failed' },
];

export const Transactions: Story = {
  render: () => <Table<TxRow> columns={TX_COLS} rows={TX_ROWS} rowKey="id" />,
};

export const EmptyState: Story = {
  render: () => (
    <Table<TxRow>
      columns={TX_COLS}
      rows={[]}
      emptyLabel="No transactions yet."
    />
  ),
};

export const NoCardShell: Story = {
  name: 'No card shell',
  render: () => (
    <Table<TxRow>
      columns={TX_COLS}
      rows={TX_ROWS.slice(0, 3)}
      rowKey="id"
      card={false}
    />
  ),
};

// ─── Applicant list ───────────────────────────────────────────────────────────

interface ApplicantRow {
  id:     string;
  name:   string;
  amount: string;
  stage:  string;
  agent:  string;
}

const AP_COLS: TableColumn<ApplicantRow>[] = [
  { key: 'name',   header: 'Business name' },
  { key: 'amount', header: 'Requested (KES)', align: 'right', mono: true },
  { key: 'stage',  header: 'Stage',
    render: (_r, val) => {
      const cls: Record<string, string> = {
        'Documents': 'av-badge av-badge--info',
        'In review': 'av-badge av-badge--warning',
        'Approved':  'av-badge av-badge--success',
      };
      return <span className={cls[val as string] ?? 'av-badge'}>{val as string}</span>;
    },
  },
  { key: 'agent', header: 'Agent', muted: true },
];

const AP_ROWS: ApplicantRow[] = [
  { id: '1', name: 'Acme Agri Ltd',    amount: '1,200,000', stage: 'Documents', agent: 'Mary Njeri' },
  { id: '2', name: 'Savanah Feeds',    amount: '450,000',   stage: 'In review', agent: 'David Ouma' },
  { id: '3', name: 'Green Valley Ltd', amount: '2,800,000', stage: 'Approved',  agent: 'Mary Njeri' },
];

export const Applicants: Story = {
  render: () => <Table<ApplicantRow> columns={AP_COLS} rows={AP_ROWS} rowKey="id" />,
};
