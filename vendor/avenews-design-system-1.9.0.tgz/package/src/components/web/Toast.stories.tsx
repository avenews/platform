import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Toast } from './Toast';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Toast> = {
  title: 'Avenews/Web/Toast',
  component: Toast,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Lightweight fixed-position notification. Auto-dismisses after `duration` ms (0 = persistent). ' +
          'Supports 5 variants, 6 positions, optional action button, and optional dismiss control.',
      },
    },
    layout: 'centered',
  },
  argTypes: {
    variant:     { control: 'select', options: ['neutral', 'success', 'warning', 'danger', 'info'] },
    position:    { control: 'select', options: ['top', 'top-start', 'top-end', 'bottom', 'bottom-start', 'bottom-end'] },
    visible:     { control: 'boolean' },
    dismissible: { control: 'boolean' },
    duration:    { control: { type: 'number', min: 0, step: 500 } },
    message:     { control: 'text' },
  },
  args: {
    message:     'Your application has been submitted.',
    visible:     true,
    variant:     'neutral',
    position:    'bottom',
    duration:    0,
    dismissible: true,
  },
};

export default meta;
type Story = StoryObj<typeof Toast>;

// ─── Helper — interactive demo with toggle ────────────────────────────────────

const Demo: React.FC<React.ComponentProps<typeof Toast>> = (props) => {
  const [visible, setVisible] = useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
      <button
        onClick={() => setVisible(true)}
        style={{
          fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
          padding: '10px 20px', borderRadius: 8, border: 'none',
          background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer',
        }}
      >
        Show toast
      </button>
      <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 12, color: 'var(--av-color-text-muted)', margin: 0 }}>
        {props.duration ? `Auto-dismisses after ${props.duration / 1000}s` : 'Persistent — dismiss manually'}
      </p>
      <Toast
        {...props}
        visible={visible}
        onDismiss={() => setVisible(false)}
      />
    </div>
  );
};

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (neutral)',
  render: (args) => <Demo {...args} />,
  args: { message: 'Document uploaded successfully.', variant: 'neutral', duration: 3000, dismissible: true },
};

// ─── Variants ────────────────────────────────────────────────────────────────

export const VariantSuccess: Story = {
  name: 'Variant / Success',
  render: (args) => <Demo {...args} />,
  args: { message: 'Loan application submitted.', variant: 'success', duration: 3000 },
};

export const VariantWarning: Story = {
  name: 'Variant / Warning',
  render: (args) => <Demo {...args} />,
  args: { message: 'Your session will expire in 5 minutes.', variant: 'warning', duration: 0, dismissible: true },
};

export const VariantDanger: Story = {
  name: 'Variant / Danger',
  render: (args) => <Demo {...args} />,
  args: { message: 'Upload failed. Please try again.', variant: 'danger', duration: 0, dismissible: true },
};

export const VariantInfo: Story = {
  name: 'Variant / Info',
  render: (args) => <Demo {...args} />,
  args: { message: 'Your repayment is due in 3 days.', variant: 'info', duration: 4000, dismissible: true },
};

// ─── Positions ───────────────────────────────────────────────────────────────

export const PositionTop: Story = {
  name: 'Position / Top center',
  render: (args) => <Demo {...args} />,
  args: { message: 'Changes saved.', variant: 'success', position: 'top', duration: 2500 },
};

export const PositionTopStart: Story = {
  name: 'Position / Top start',
  render: (args) => <Demo {...args} />,
  args: { message: 'Draft saved.', variant: 'neutral', position: 'top-start', duration: 2500 },
};

// ─── Features ────────────────────────────────────────────────────────────────

export const WithAction: Story = {
  name: 'Feature / With action',
  render: (args) => <Demo {...args} />,
  args: {
    message:  'Document deleted.',
    variant:  'neutral',
    duration: 5000,
    action:   { label: 'Undo' },
    dismissible: true,
  },
};

export const WithActionDanger: Story = {
  name: 'Feature / With action (danger)',
  render: (args) => <Demo {...args} />,
  args: {
    message:  'Submission failed — network error.',
    variant:  'danger',
    duration: 0,
    action:   { label: 'Retry' },
    dismissible: true,
  },
};

export const Persistent: Story = {
  name: 'Feature / Persistent (duration=0)',
  render: (args) => <Demo {...args} />,
  args: {
    message:     'Reviewing your documents — this may take a moment.',
    variant:     'info',
    duration:    0,
    dismissible: true,
  },
};

// ─── All variants static ──────────────────────────────────────────────────────

export const AllVariants: Story = {
  name: 'All variants (static)',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, width: 380 }}>
      {(['neutral', 'success', 'warning', 'danger', 'info'] as const).map((v) => (
        <Toast
          key={v}
          message={`This is a ${v} toast message.`}
          variant={v}
          visible
          duration={0}
          dismissible
        />
      ))}
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanSubmitted: Story = {
  name: 'App / Loan submitted',
  render: (args) => <Demo {...args} />,
  args: {
    message:  'Your loan application has been submitted for review.',
    variant:  'success',
    position: 'bottom',
    duration: 4000,
  },
};

export const AppDocumentError: Story = {
  name: 'App / Document upload error',
  render: (args) => <Demo {...args} />,
  args: {
    message:     'File too large. Maximum size is 10 MB.',
    variant:     'danger',
    position:    'bottom',
    duration:    0,
    dismissible: true,
  },
};

export const AppUndoDelete: Story = {
  name: 'App / Undo delete',
  render: (args) => <Demo {...args} />,
  args: {
    message:  'Document removed.',
    variant:  'neutral',
    position: 'bottom',
    duration: 5000,
    action:   { label: 'Undo' },
    dismissible: true,
  },
};
