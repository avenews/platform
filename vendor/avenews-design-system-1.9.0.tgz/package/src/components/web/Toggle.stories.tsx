import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Toggle } from './Toggle';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Toggle> = {
  title: 'Avenews/Web/Toggle',
  component: Toggle,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Accessible on/off switch with label and optional helper text. ' +
          'Can be used uncontrolled or fully controlled via `checked` + `onChange`.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 340, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    label:      { control: 'text' },
    helperText: { control: 'text' },
    checked:    { control: 'boolean' },
    disabled:   { control: 'boolean' },
  },
  args: {
    label:    'Enable notifications',
    checked:  false,
    disabled: false,
  },
};

export default meta;
type Story = StoryObj<typeof Toggle>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (off)',
  args: { label: 'Enable notifications', checked: false },
};

export const On: Story = {
  name: 'State / On',
  args: { label: 'Enable notifications', checked: true },
};

export const Off: Story = {
  name: 'State / Off',
  args: { label: 'Enable notifications', checked: false },
};

export const Disabled: Story = {
  name: 'State / Disabled (off)',
  args: { label: 'Auto-save', checked: false, disabled: true },
};

export const DisabledOn: Story = {
  name: 'State / Disabled (on)',
  args: { label: 'Auto-save', checked: true, disabled: true },
};

// ─── With helper text ─────────────────────────────────────────────────────────

export const WithHelperText: Story = {
  name: 'Feature / Helper text',
  args: {
    label:      'Email reminders',
    helperText: 'Receive a reminder 3 days before each repayment.',
    checked:    false,
  },
};

export const WithHelperTextOn: Story = {
  name: 'Feature / Helper text (on)',
  args: {
    label:      'Email reminders',
    helperText: 'Receive a reminder 3 days before each repayment.',
    checked:    true,
  },
};

// ─── Interactive ─────────────────────────────────────────────────────────────

export const Interactive: Story = {
  name: 'Interactive (controlled)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [on, setOn] = useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Toggle
          label={on ? 'Notifications on' : 'Notifications off'}
          helperText={on ? 'You will receive account updates.' : 'Turn on to get account updates.'}
          checked={on}
          onChange={setOn}
        />
        <p style={{ margin: 0, fontFamily: 'var(--av-font-body)', fontSize: 12, color: 'var(--av-color-text-muted)' }}>
          Value: {String(on)}
        </p>
      </div>
    );
  },
};

// ─── Toggle group ─────────────────────────────────────────────────────────────

export const ToggleGroup: Story = {
  name: 'App / Notification preferences',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [prefs, setPrefs] = useState({
      email:   true,
      sms:     false,
      inApp:   true,
      weekly:  false,
    });
    const toggle = (key: keyof typeof prefs) =>
      setPrefs((p) => ({ ...p, [key]: !p[key] }));

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        <Toggle label="Email notifications" helperText="Repayment reminders and alerts"
          checked={prefs.email}   onChange={() => toggle('email')} />
        <Toggle label="SMS notifications"   helperText="Urgent account updates only"
          checked={prefs.sms}     onChange={() => toggle('sms')} />
        <Toggle label="In-app notifications" helperText="Banner alerts inside the app"
          checked={prefs.inApp}   onChange={() => toggle('inApp')} />
        <Toggle label="Weekly digest"       helperText="Summary of account activity"
          checked={prefs.weekly}  onChange={() => toggle('weekly')} />
      </div>
    );
  },
};
