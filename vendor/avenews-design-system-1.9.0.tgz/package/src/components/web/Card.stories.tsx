import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Card } from './Card';
import type { CardColor, CardLayout } from './Card';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Card> = {
  title: 'Avenews/Web/Card',
  component: Card,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Surface container for grouped content. ' +
          'Three layouts (default / media / list), 9 colour tokens, tappable mode, ' +
          'disabled, loading skeleton, error state, and up to 3 action buttons.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color:  {
      control: 'select',
      options: [
        'default', 'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark',
      ] satisfies CardColor[],
    },
    layout: {
      control: 'radio',
      options: ['default', 'media', 'list'] satisfies CardLayout[],
    },
    tappable: { control: 'boolean' },
    disabled: { control: 'boolean' },
    loading:  { control: 'boolean' },
  },
  args: {
    color:    'default',
    layout:   'default',
    title:    'Card Title',
    subtitle: 'Subtitle',
    body:     'Supporting content goes here. Keep it short and informative.',
    tappable: false,
    disabled: false,
    loading:  false,
  },
};

export default meta;
type Story = StoryObj<typeof Card>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
};

// ─── Layout variants ──────────────────────────────────────────────────────────

export const DefaultLayout: Story = {
  name: 'Layout / Default',
  args: { layout: 'default', subtitle: 'Category', title: 'Fund Request' },
};

export const MediaLayout: Story = {
  name: 'Layout / Media (with image)',
  args: {
    layout:   'media',
    subtitle: 'Product update',
    title:    'New repayment options available',
    body:     'We\'ve added flexible weekly and monthly repayment schedules for qualifying accounts.',
    imageUrl: 'https://images.unsplash.com/photo-1580519542036-c47de6196ba5?w=720&q=80',
    imageAlt: 'Financial planning illustration',
  },
};

export const ListLayout: Story = {
  name: 'Layout / List (custom content)',
  args: {
    layout:      'list',
    title:       'Documents required',
    listContent: (
      <ul style={{ margin: 0, padding: '0 0 0 16px', fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-text-body)', lineHeight: 1.6 }}>
        <li>Proof of business registration</li>
        <li>Last 3 months bank statements</li>
        <li>Signed director ID copy</li>
      </ul>
    ),
  },
};

// ─── Actions ─────────────────────────────────────────────────────────────────

export const WithSingleAction: Story = {
  name: 'Actions / Single',
  args: {
    title:   'Loan offer ready',
    body:    'Your pre-approved offer of KES 150,000 is ready for review.',
    actions: [{ label: 'View offer', variant: 'primary' }],
  },
};

export const WithTwoActions: Story = {
  name: 'Actions / Two buttons',
  args: {
    title:   'Confirm repayment',
    body:    'A scheduled repayment of KES 12,500 will be processed tomorrow.',
    actions: [
      { label: 'Confirm',  variant: 'primary' },
      { label: 'Postpone', variant: 'outline'  },
    ],
  },
};

export const WithThreeActions: Story = {
  name: 'Actions / Three buttons (max)',
  args: {
    title:   'Document actions',
    body:    'Invoice_2024_Q3.pdf is pending review.',
    actions: [
      { label: 'Approve', variant: 'success' },
      { label: 'Reject',  variant: 'danger'  },
      { label: 'Hold',    variant: 'outline'  },
    ],
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const Tappable: Story = {
  name: 'State / Tappable',
  args: {
    tappable: true,
    title:    'View account summary',
    body:     'Tap to see your full balance and transaction history.',
  },
};

export const Disabled: Story = {
  name: 'State / Disabled',
  args: {
    disabled: true,
    title:    'Unavailable',
    body:     'This card is not currently available.',
  },
};

export const LoadingState: Story = {
  name: 'State / Loading skeleton',
  args: { loading: true, title: 'ignored' },
};

export const LoadingWithImage: Story = {
  name: 'State / Loading skeleton (media)',
  args: { loading: true, layout: 'media', imageUrl: 'placeholder', title: 'ignored' },
};

export const ErrorState: Story = {
  name: 'State / Error',
  args: {
    title: 'Fund request',
    error: 'Something went wrong loading this card. Please try again.',
  },
};

export const LinkCard: Story = {
  name: 'State / Link card (href)',
  args: {
    href:  '#',
    title: 'Visit support centre',
    body:  'Find answers to common questions about your account.',
  },
};

// ─── Colour variants ──────────────────────────────────────────────────────────

const CARD_COLORS: CardColor[] = [
  'primary', 'secondary', 'tertiary',
  'success', 'warning', 'danger',
  'light', 'medium', 'dark',
];

export const AllColors: Story = {
  name: 'Colors / All',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {CARD_COLORS.map((c) => (
        <Card
          key={c} color={c}
          subtitle={c} title="Card title"
          body="Short supporting body text."
        />
      ))}
    </div>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const LoanOffer: Story = {
  name: 'App / Loan offer',
  args: {
    subtitle: 'Pre-approved offer',
    title:    'KES 150,000',
    body:     '12-month term · 2.5% monthly interest · No collateral required.',
    actions: [
      { label: 'Accept offer', variant: 'primary' },
      { label: 'Learn more',   variant: 'ghost'   },
    ],
    color: 'primary',
  },
};

export const RepaymentDue: Story = {
  name: 'App / Repayment due',
  args: {
    subtitle: 'Next payment',
    title:    'KES 12,500 due in 3 days',
    body:     'Loan ref: AVN-2024-00123 · Avoid late fees by paying before the due date.',
    actions: [
      { label: 'Pay now', variant: 'primary' },
      { label: 'Schedule', variant: 'outline' },
    ],
    color: 'warning',
  },
};

export const DocumentAlert: Story = {
  name: 'App / Document action required',
  args: {
    subtitle: '2 documents needed',
    title:    'Complete your KYC to unlock higher limits',
    body:     'Upload your proof of business and director ID to continue.',
    actions: [{ label: 'Upload documents', variant: 'primary' }],
    color:   'danger',
  },
};
