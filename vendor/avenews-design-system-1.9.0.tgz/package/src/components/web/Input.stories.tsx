import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Input } from './Input';

// ─── Inline SVG icon helpers ──────────────────────────────────────────────────

const makeIcon = (path: string) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <path d={path} />
  </svg>
);

const EyeIcon      = () => makeIcon('M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 9a3 3 0 100 6 3 3 0 000-6z');
const EyeOffIcon   = () => makeIcon('M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24M1 1l22 22');
const SearchIcon   = () => makeIcon('M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z');
const MailIcon     = () => makeIcon('M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2zM22 6l-10 7L2 6');
const PersonIcon   = () => makeIcon('M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z');
const LockIcon     = () => makeIcon('M19 11H5a2 2 0 00-2 2v7a2 2 0 002 2h14a2 2 0 002-2v-7a2 2 0 00-2-2zM7 11V7a5 5 0 0110 0v4');
const ChevronIcon  = () => makeIcon('M19 9l-7 7-7-7');
const CalendarIcon = () => makeIcon('M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V6a2 2 0 012-2z');
const CardIcon     = () => makeIcon('M1 4h22v16H1zM1 10h22');

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Input> = {
  title:     'Avenews/Web/Input',
  component: Input,
  tags:      ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: 'Pure React input — no Ionic dependency. Matches the Ionic Input API (except events use `onChange/onBlur/onFocus` and `icon` accepts ReactNode). Renders with Ionic-inspired solid-fill styling via `av-input--*` CSS classes.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    labelPlacement: { control: 'radio', options: ['stacked','floating','fixed','start'] },
    type:           { control: 'select', options: ['text','email','number','password','tel','url','date'] },
  },
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'stacked' },
};

export default meta;
type Story = StoryObj<typeof Input>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = { args: { label: 'First name', placeholder: 'Enter your first name' } };

// ─── Label placements ─────────────────────────────────────────────────────────

export const AllLabelPlacements: Story = {
  name: 'Label / All placements',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      <Input label="Stacked"  placeholder="Text" labelPlacement="stacked"  />
      <Input label="Floating" placeholder="Text" labelPlacement="floating" />
      <Input label="Fixed"    placeholder="Text" labelPlacement="fixed"    />
      <Input label="Inline"   placeholder="Text" labelPlacement="start"    />
    </div>
  ),
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateDefault:  Story = { name: 'State / Default',  args: { label: 'Label', placeholder: 'Text' } };
export const StateFilled:   Story = { name: 'State / Filled',   args: { label: 'Label', value: 'Text' } };
export const StateDisabled: Story = { name: 'State / Disabled', args: { label: 'Label', value: 'Text', disabled: true } };

export const StateError: Story = {
  name: 'State / Error',
  args: { label: 'Email', value: 'not-valid', type: 'email', error: 'Enter a valid email address.' },
};

export const StateSuccess: Story = {
  name: 'State / Success',
  args: { label: 'Email', value: 'user@example.com', type: 'email', success: true, helperText: 'Email verified.' },
};

export const StateLoading: Story = {
  name: 'State / Loading skeleton',
  args: { label: 'First name', loading: true },
};

export const AllStates: Story = {
  name: 'State / All states',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      <Input label="Default"  placeholder="Text" />
      <Input label="Filled"   value="Text" />
      <Input label="Error"    value="bad-val"          error="This field is required." />
      <Input label="Success"  value="user@example.com" success helperText="Looks good!" />
      <Input label="Disabled" value="Text"             disabled />
    </div>
  ),
};

// ─── Features ─────────────────────────────────────────────────────────────────

export const Required: Story = {
  name: 'Feature / Required',
  args: { label: 'Business name', placeholder: 'e.g. Avenews Ltd', required: true },
};

export const WithHelperText: Story = {
  name: 'Feature / Helper text',
  args: { label: 'KRA PIN', placeholder: 'e.g. A001234567X', helperText: 'Must be a valid 11-character KRA PIN.' },
};

export const WithCounter: Story = {
  name: 'Feature / Character counter',
  args: { label: 'Description', placeholder: 'Brief description…', counter: true, maxlength: 140 },
};

export const WithClearButton: Story = {
  name: 'Feature / Clear button',
  args: { label: 'Search', placeholder: 'Search…', clearInput: true, value: 'Something typed' },
};

// ─── Icon slots ───────────────────────────────────────────────────────────────

export const SlotPassiveIcon: Story = {
  name: 'Slots / Passive icon',
  args: { label: 'Search', placeholder: 'Search transactions…', startIcon: <SearchIcon /> },
};

export const SlotPasswordToggle: Story = {
  name: 'Slots / Password reveal',
  render: () => {
    const [show, setShow] = useState(false);
    return (
      <Input
        label="Password"
        type={show ? 'text' : 'password'}
        placeholder="••••••••"
        value="hunter2"
        endIcon={show ? <EyeOffIcon /> : <EyeIcon />}
        onEndIconClick={() => setShow((v) => !v)}
        endIconAriaLabel={show ? 'Hide password' : 'Show password'}
      />
    );
  },
};

export const SlotGallery: Story = {
  name: 'Slots / Full gallery',
  render: () => {
    const [pw, setPw] = useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <Input label="Full name"  placeholder="Name"     startIcon={<PersonIcon />} />
        <Input label="Email"      placeholder="Email"    startIcon={<MailIcon />}   type="email" />
        <Input label="Business"   placeholder="Company"  startIcon={<PersonIcon />} />
        <Input
          label="Password"
          type={pw ? 'text' : 'password'}
          placeholder="••••••••"
          endIcon={pw ? <EyeOffIcon /> : <EyeIcon />}
          onEndIconClick={() => setPw((v) => !v)}
          endIconAriaLabel={pw ? 'Hide password' : 'Show password'}
        />
        <Input
          label="Date"
          placeholder="Select date…"
          startIcon={<CalendarIcon />}
          endIcon={<ChevronIcon />}
          onEndIconClick={() => {}}
          endIconAriaLabel="Open date picker"
        />
        <Input
          label="Amount"
          type="number"
          placeholder="0.00"
          startIcon={<CardIcon />}
          endIcon={<ChevronIcon />}
          onEndIconClick={() => {}}
          endIconAriaLabel="Select currency"
        />
      </div>
    );
  },
};

// ─── Phone input ──────────────────────────────────────────────────────────────

export const PhoneInput: Story = {
  name: 'Variant / Phone input',
  args: { label: 'Phone number', placeholder: '700 000 000', type: 'tel', phonePrefix: '+254', phoneFlagEmoji: '🇰🇪' },
};

export const PhoneInputError: Story = {
  name: 'Variant / Phone input error',
  args: {
    label: 'Phone number', value: '123', type: 'tel',
    phonePrefix: '+254', phoneFlagEmoji: '🇰🇪',
    error: 'Enter a valid Kenyan mobile number.',
  },
};

// ─── Textarea ─────────────────────────────────────────────────────────────────

export const Textarea: Story = {
  name: 'Variant / Textarea',
  args: { label: 'Message', placeholder: 'Write your message…', multiline: true, rows: 4 },
};

export const TextareaWithCounter: Story = {
  name: 'Variant / Textarea with counter',
  args: { label: 'Notes', placeholder: 'Add notes…', multiline: true, rows: 4, counter: true, maxlength: 250 },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const LoginForm: Story = {
  name: 'App / Login form',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      <Input label="Email"    type="email"    placeholder="you@example.com" startIcon={<MailIcon />}  required />
      <Input label="Password" type="password" placeholder="••••••••"        endIcon={<EyeIcon />}     required />
    </div>
  ),
};

export const SignUpForm: Story = {
  name: 'App / Sign-up form',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      <Input label="Full name" placeholder="First and last name"  startIcon={<PersonIcon />} required />
      <Input label="Email"     placeholder="you@example.com"      startIcon={<MailIcon />}   type="email" required />
      <Input label="Phone"     placeholder="700 000 000"           phonePrefix="+254"         phoneFlagEmoji="🇰🇪" />
      <Input label="Password"  placeholder="••••••••"              endIcon={<EyeIcon />}      type="password" required />
      <Input
        label="Confirm password" placeholder="Confirm password"
        endIcon={<LockIcon />} type="password" required
        error="Passwords do not match."
      />
    </div>
  ),
};
