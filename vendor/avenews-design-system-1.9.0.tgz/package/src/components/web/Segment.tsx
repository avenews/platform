import React from 'react';
import { cn } from '../shared/utils';

export interface SegmentOption {
  value:         string;
  label?:        string;
  /** ReactNode icon (replaces Ionic icon string) */
  icon?:         React.ReactNode;
  iconPosition?: 'start' | 'end' | 'top' | 'bottom' | 'icon-only';
  disabled?:     boolean;
}

export interface SegmentProps {
  options:     SegmentOption[];
  value?:      string;
  scrollable?: boolean;
  /** Renamed from onIonChange */
  onChange?:   (value: string) => void;
  className?:  string;
}

export const Segment: React.FC<SegmentProps> = ({
  options,
  value,
  scrollable = false,
  onChange,
  className,
}) => {
  return (
    <div
      className={cn('av-segment', scrollable && 'av-segment--scrollable', className)}
      role="tablist"
    >
      {options.map((opt) => {
        const isSelected   = opt.value === value;
        const showIcon     = Boolean(opt.icon) && opt.iconPosition !== undefined;
        const showLabel    = Boolean(opt.label) && opt.iconPosition !== 'icon-only';
        const iconOnly     = opt.iconPosition === 'icon-only' && Boolean(opt.icon);
        const iconAtStart  = showIcon && (opt.iconPosition === 'start' || opt.iconPosition === 'top');
        const iconAtEnd    = showIcon && (opt.iconPosition === 'end'   || opt.iconPosition === 'bottom');

        return (
          <button
            key={opt.value}
            type="button"
            role="tab"
            aria-selected={isSelected}
            className={cn(
              'av-segment__btn',
              isSelected   && 'av-segment__btn--selected',
              opt.disabled && 'av-segment__btn--disabled',
            )}
            disabled={opt.disabled}
            onClick={() => !opt.disabled && onChange?.(opt.value)}
          >
            {iconAtStart && (
              <span className="av-segment__icon" aria-hidden="true">{opt.icon}</span>
            )}
            {showLabel && <span className="av-segment__label">{opt.label}</span>}
            {iconAtEnd && (
              <span className="av-segment__icon" aria-hidden="true">{opt.icon}</span>
            )}
            {iconOnly && (
              <span className="av-segment__icon" aria-label={opt.label}>{opt.icon}</span>
            )}
          </button>
        );
      })}
    </div>
  );
};

export default Segment;
