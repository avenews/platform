import React from 'react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';

export type ItemColor   =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light' | 'medium' | 'dark';

export type ItemLines   = 'full' | 'inset' | 'none';
export type ItemVariant = 'default' | 'list3';

export interface ItemProps {
  label:       string;
  secondLine?: string;
  thirdLine?:  string;
  variant?:    ItemVariant;
  color?:      ItemColor;
  disabled?:   boolean;
  lines?:      ItemLines;
  detailArrow?: boolean;
  button?:     boolean;
  href?:       string;
  startSlot?:  React.ReactNode;
  endSlot?:    React.ReactNode;
  onClick?:    () => void;
  loading?:    boolean;
  className?:  string;
}

export interface ItemDividerProps {
  label:      string;
  color?:     ItemColor;
  loading?:   boolean;
  className?: string;
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

const ItemSkeletonEl: React.FC = () => (
  <div className="avenews-item-skeleton">
    <div className="av-skeleton-line" style={{ width: '40%', height: '12px', marginBottom: '6px' }} />
    <div className="av-skeleton-line" style={{ width: '70%', height: '16px' }} />
  </div>
);

const DividerSkeletonEl: React.FC = () => (
  <div className="avenews-item-divider-skeleton">
    <div className="av-skeleton-line" style={{ width: '30%', height: '12px' }} />
  </div>
);

// ─── Label content ────────────────────────────────────────────────────────────

const ItemLabel: React.FC<Pick<ItemProps, 'label' | 'secondLine' | 'thirdLine' | 'variant'>> = ({
  label, secondLine, thirdLine, variant = 'default',
}) => {
  if (variant === 'list3') {
    return (
      <div className="avenews-item__label">
        <p className="avenews-item__top">{label}</p>
        {secondLine && <h2 className="avenews-item__main">{secondLine}</h2>}
        {thirdLine  && <p  className="avenews-item__sub">{thirdLine}</p>}
      </div>
    );
  }
  return (
    <div className="avenews-item__label">
      <h2 className="avenews-item__main">{label}</h2>
      {secondLine && <p className="avenews-item__sub">{secondLine}</p>}
      {thirdLine  && <p className="avenews-item__sub">{thirdLine}</p>}
    </div>
  );
};


// ─── Item ─────────────────────────────────────────────────────────────────────

export const Item: React.FC<ItemProps> = ({
  label,
  secondLine,
  thirdLine,
  variant     = 'default',
  color       = 'default',
  disabled    = false,
  lines       = 'full',
  detailArrow = false,
  button,
  href,
  startSlot,
  endSlot,
  onClick,
  loading     = false,
  className,
}) => {
  if (loading) return <ItemSkeletonEl />;

  const isInteractive = Boolean(button || onClick || href);

  const rootCls = cn(
    'av-item',
    color !== 'default' && `av-item--${color}`,
    variant === 'list3' && 'av-item--list3',
    `av-item--lines-${lines}`,
    isInteractive      && 'av-item--interactive',
    disabled           && 'av-item--disabled',
    className,
  );

  const inner = (
    <>
      {startSlot && <div className="av-item__slot av-item__slot--start">{startSlot}</div>}
      <ItemLabel label={label} secondLine={secondLine} thirdLine={thirdLine} variant={variant} />
      {endSlot   && <div className="av-item__slot av-item__slot--end">{endSlot}</div>}
      {detailArrow && <span className="av-item__arrow" aria-hidden="true"><Icon name="chevron-forward" size={16} /></span>}
    </>
  );

  if (href) {
    return <a href={href} className={rootCls}>{inner}</a>;
  }

  if (isInteractive) {
    return (
      <button type="button" className={rootCls} onClick={onClick} disabled={disabled}>
        {inner}
      </button>
    );
  }

  return <div className={rootCls}>{inner}</div>;
};

// ─── ItemDivider ──────────────────────────────────────────────────────────────

export const ItemDivider: React.FC<ItemDividerProps> = ({
  label,
  color     = 'default',
  loading   = false,
  className,
}) => {
  if (loading) return <DividerSkeletonEl />;

  return (
    <div className={cn(
      'av-item-divider',
      color !== 'default' && `av-item-divider--${color}`,
      className,
    )}>
      <span className="av-item-divider__label">{label}</span>
    </div>
  );
};

export default Item;
