import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Searchbar } from './Searchbar';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Searchbar> = {
  title: 'Avenews/Web/Searchbar',
  component: Searchbar,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Search input with debounce, configurable clear/cancel buttons, ' +
          'error state, and a loading skeleton. ' +
          'Debounce defaults to 300ms — set to 0 for instant feedback in demos.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 340, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    placeholder:      { control: 'text' },
    showCancelButton: { control: 'radio', options: ['never', 'focus', 'always'] },
    showClearButton:  { control: 'radio', options: ['never', 'focus', 'always'] },
    disabled:         { control: 'boolean' },
    loading:          { control: 'boolean' },
    error:            { control: 'boolean' },
    debounce:         { control: 'number' },
  },
  args: {
    placeholder:      'Search',
    showCancelButton: 'focus',
    showClearButton:  'focus',
    disabled:         false,
    loading:          false,
    error:            false,
    debounce:         0,
  },
};

export default meta;
type Story = StoryObj<typeof Searchbar>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
};

// ─── Cancel / Clear button modes ─────────────────────────────────────────────

export const CancelAlways: Story = {
  name: 'Cancel / Always visible',
  args: { showCancelButton: 'always' },
};

export const CancelNever: Story = {
  name: 'Cancel / Never',
  args: { showCancelButton: 'never' },
};

export const ClearAlways: Story = {
  name: 'Clear / Always visible',
  args: { value: 'invoices', showClearButton: 'always' },
};

export const ClearNever: Story = {
  name: 'Clear / Never',
  args: { value: 'invoices', showClearButton: 'never' },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const WithValue: Story = {
  name: 'State / With value',
  args: { value: 'invoices 2024', showClearButton: 'always' },
};

export const Disabled: Story = {
  name: 'State / Disabled',
  args: { disabled: true, placeholder: 'Search unavailable' },
};

export const Error: Story = {
  name: 'State / Error',
  args: { error: true, value: '!@#$%' },
};

export const Loading: Story = {
  name: 'State / Loading skeleton',
  args: { loading: true },
};

// ─── Interactive ─────────────────────────────────────────────────────────────

const DOCS = [
  'Invoice_Jan_2024.pdf',
  'Bank_Statement_Feb_2024.pdf',
  'Director_ID_Kone.jpg',
  'Business_Registration.pdf',
  'Tax_Certificate_2023.pdf',
  'Signed_Agreement_Q4.pdf',
];

export const LiveFilter: Story = {
  name: 'App / Live document filter',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [query, setQuery] = useState('');
    const filtered = DOCS.filter((d) => d.toLowerCase().includes(query.toLowerCase()));

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <Searchbar
          placeholder="Search documents…"
          value={query}
          debounce={0}
          showCancelButton="focus"
          showClearButton="focus"
          onChange={setQuery}
          onClear={() => setQuery('')}
        />
        <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
          {filtered.length > 0
            ? filtered.map((d) => (
                <li key={d} style={{ fontFamily: 'var(--av-font-body)', fontSize: 14,
                  color: 'var(--av-color-text-body)', padding: '8px 12px',
                  background: 'var(--av-color-surface)', borderRadius: 8 }}>
                  {d}
                </li>
              ))
            : (
                <li style={{ fontFamily: 'var(--av-font-body)', fontSize: 13,
                  color: 'var(--av-color-text-muted)', textAlign: 'center', padding: 16 }}>
                  No documents match "{query}"
                </li>
              )
          }
        </ul>
      </div>
    );
  },
};
