import React, { useEffect, useState } from 'react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';

export interface AccordionItem {
  value:     string;
  label:     string;
  content:   React.ReactNode;
  disabled?: boolean;
  leftArrow?: boolean;
}

export interface AccordionProps {
  items:      AccordionItem[];
  multiple?:  boolean;
  /** Controlled open value */
  value?:     string | string[];
  /** Renamed from onIonChange */
  onChange?:  (value: string | string[] | undefined) => void;
  className?: string;
}


export const Accordion: React.FC<AccordionProps> = ({
  items,
  multiple  = false,
  value,
  onChange,
  className,
}) => {
  const isControlled = value !== undefined;

  const [internalOpen, setInternalOpen] = useState<string[]>(() => {
    if (!value) return [];
    return Array.isArray(value) ? value : [value];
  });

  useEffect(() => {
    if (isControlled) {
      setInternalOpen(Array.isArray(value) ? value : value ? [value] : []);
    }
  }, [value, isControlled]);

  const openValues = isControlled
    ? (Array.isArray(value) ? value : value ? [value] : [])
    : internalOpen;

  const toggle = (itemValue: string) => {
    let next: string[];
    if (openValues.includes(itemValue)) {
      next = openValues.filter((v) => v !== itemValue);
    } else {
      next = multiple ? [...openValues, itemValue] : [itemValue];
    }

    if (!isControlled) setInternalOpen(next);
    onChange?.(multiple ? next : next[0]);
  };

  return (
    <div className={cn('av-accordion', className)}>
      {items.map((item) => {
        const isOpen = openValues.includes(item.value);

        return (
          <div
            key={item.value}
            className={cn(
              'av-accordion__item',
              isOpen         && 'av-accordion__item--open',
              item.disabled  && 'av-accordion__item--disabled',
            )}
          >
            <button
              type="button"
              className="av-accordion__header"
              onClick={() => !item.disabled && toggle(item.value)}
              aria-expanded={isOpen}
              disabled={item.disabled}
            >
              {item.leftArrow && <Icon name="chevron-down" size={18} className={cn('av-accordion__chevron', isOpen && 'av-accordion__chevron--open')} aria-hidden />}
              <span className="av-accordion__label">{item.label}</span>
              {!item.leftArrow && <Icon name="chevron-down" size={18} className={cn('av-accordion__chevron', isOpen && 'av-accordion__chevron--open')} aria-hidden />}
            </button>

            {isOpen && (
              <div className="av-accordion__content">
                {item.content}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default Accordion;
