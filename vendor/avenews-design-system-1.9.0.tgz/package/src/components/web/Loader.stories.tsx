import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Loader } from './Loader';
import type { LoaderVariant, LoaderSize, LoaderColor } from './Loader';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Loader> = {
  title: 'Avenews/Web/Loader',
  component: Loader,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Spinner-based loading indicator with three placement variants: ' +
          '`inline` (horizontal, fits inside buttons/rows), ' +
          '`centered` (full-width centred block), and ' +
          '`overlay` (fixed full-screen backdrop). ' +
          'Supports 3 sizes, 7 colour tokens, and an optional text label.',
      },
    },
    layout: 'centered',
  },
  argTypes: {
    variant: {
      control: 'radio',
      options: ['inline', 'centered', 'overlay'] satisfies LoaderVariant[],
    },
    size: {
      control: 'radio',
      options: ['sm', 'md', 'lg'] satisfies LoaderSize[],
    },
    color: {
      control: 'select',
      options: [
        'primary', 'secondary', 'success', 'warning', 'danger', 'light', 'white',
      ] satisfies LoaderColor[],
    },
    visible: { control: 'boolean' },
    label:   { control: 'text' },
  },
  args: {
    variant: 'inline',
    size:    'md',
    color:   'primary',
    visible: true,
  },
};

export default meta;
type Story = StoryObj<typeof Loader>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { variant: 'inline', size: 'md' },
};

// ─── Variants ────────────────────────────────────────────────────────────────

export const VariantInline: Story = {
  name: 'Variant / Inline',
  args: { variant: 'inline', label: 'Loading…' },
};

export const VariantCentered: Story = {
  name: 'Variant / Centered',
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface-subtle)', borderRadius: 12 }}>
        <Story />
      </div>
    ),
  ],
  args: { variant: 'centered', size: 'lg', label: 'Loading your account…' },
};

export const VariantOverlay: Story = {
  name: 'Variant / Overlay (interactive)',
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center' }}>
        <button
          onClick={() => { setOpen(true); setTimeout(() => setOpen(false), 2500); }}
          style={{
            fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
            padding: '10px 20px', borderRadius: 8, border: 'none',
            background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer',
          }}
        >
          Show overlay loader
        </button>
        <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 12, color: 'var(--av-color-text-muted)', margin: 0 }}>
          Auto-dismisses after 2.5 s
        </p>
        <Loader variant="overlay" size="lg" label="Submitting application…" visible={open} />
      </div>
    );
  },
};

// ─── Sizes ────────────────────────────────────────────────────────────────────

export const AllSizes: Story = {
  name: 'Size / All sizes',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
      {(['sm', 'md', 'lg'] as LoaderSize[]).map((size) => (
        <div key={size} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <Loader size={size} />
          <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 11, color: 'var(--av-color-text-muted)' }}>
            {size}
          </span>
        </div>
      ))}
    </div>
  ),
};

// ─── Colors ───────────────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'Color / All colors',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 20 }}>
      {(['primary', 'secondary', 'success', 'warning', 'danger', 'light'] as LoaderColor[]).map((color) => (
        <div key={color} style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
          background: color === 'light' ? 'var(--av-color-surface-dark)' : undefined,
          padding: 8, borderRadius: 8,
        }}>
          <Loader color={color} size="md" />
          <span style={{
            fontFamily: 'var(--av-font-body)', fontSize: 11,
            color: color === 'light' ? '#ffffff' : 'var(--av-color-text-muted)',
          }}>
            {color}
          </span>
        </div>
      ))}
    </div>
  ),
};

// ─── With label ───────────────────────────────────────────────────────────────

export const WithLabel: Story = {
  name: 'Feature / With label — inline',
  args: { variant: 'inline', label: 'Processing…' },
};

export const CenteredWithLabel: Story = {
  name: 'Feature / With label — centered',
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface)', borderRadius: 12,
        boxShadow: 'var(--av-shadow-card)' }}>
        <Story />
      </div>
    ),
  ],
  args: { variant: 'centered', size: 'lg', label: 'Fetching your data…' },
};

// ─── Visibility ───────────────────────────────────────────────────────────────

export const HiddenLoader: Story = {
  name: 'State / Hidden (visible=false)',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <Loader visible={false} label="This should not appear" />
      <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 13, color: 'var(--av-color-text-muted)' }}>
        Loader is hidden — renders null
      </span>
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppInlineButton: Story = {
  name: 'App / Inline in submit button',
  render: () => (
    <button
      style={{
        display: 'flex', alignItems: 'center', gap: 8,
        fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
        padding: '12px 24px', borderRadius: 8, border: 'none',
        background: 'var(--av-color-action)', color: '#fff', cursor: 'default',
        minWidth: 180, justifyContent: 'center',
      }}
      disabled
    >
      <Loader size="sm" color="white" />
      Submitting…
    </button>
  ),
};

export const AppPageLoad: Story = {
  name: 'App / Full page load',
  decorators: [
    (Story) => (
      <div style={{ width: 360, height: 240, background: 'var(--av-color-surface)',
        borderRadius: 12, boxShadow: 'var(--av-shadow-card)', position: 'relative', overflow: 'hidden' }}>
        <Story />
      </div>
    ),
  ],
  render: () => (
    <Loader variant="centered" size="lg" label="Loading your dashboard…" />
  ),
};

export const AppLoanSubmit: Story = {
  name: 'App / Loan submission overlay',
  render: () => {
    const [submitting, setSubmitting] = useState(false);
    const [done, setDone] = useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center' }}>
        {!done ? (
          <button
            onClick={() => { setSubmitting(true); setTimeout(() => { setSubmitting(false); setDone(true); }, 2000); }}
            style={{
              fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
              padding: '12px 24px', borderRadius: 8, border: 'none',
              background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer',
            }}
          >
            Submit loan application
          </button>
        ) : (
          <p style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, color: 'var(--av-color-success)', fontWeight: 600 }}>
            ✓ Application submitted
          </p>
        )}
        <Loader variant="overlay" size="lg" label="Submitting your application…" visible={submitting} />
      </div>
    );
  },
};
