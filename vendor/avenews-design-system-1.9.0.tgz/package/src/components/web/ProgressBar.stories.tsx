import React, { useState, useEffect } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { ProgressBar } from './ProgressBar';
import type { ProgressBarColor, ProgressBarSize } from './ProgressBar';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof ProgressBar> = {
  title: 'Avenews/Web/ProgressBar',
  component: ProgressBar,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Visible progress bar with optional label and percentage display. ' +
          'Supports determinate, indeterminate, and segmented modes across 3 sizes and 5 colour tokens. ' +
          'Distinct from ProgressTracker (4px thin indicator) — ProgressBar is for prominent step/upload progress.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color: {
      control: 'select',
      options: ['primary', 'secondary', 'success', 'warning', 'danger'] satisfies ProgressBarColor[],
    },
    size: {
      control: 'radio',
      options: ['sm', 'md', 'lg'] satisfies ProgressBarSize[],
    },
    value:         { control: { type: 'range', min: 0, max: 100, step: 1 } },
    indeterminate: { control: 'boolean' },
    showValue:     { control: 'boolean' },
    label:         { control: 'text' },
  },
  args: {
    value:     60,
    color:     'primary',
    size:      'md',
    showValue: false,
  },
};

export default meta;
type Story = StoryObj<typeof ProgressBar>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { value: 60 },
};

// ─── Sizes ────────────────────────────────────────────────────────────────────

export const AllSizes: Story = {
  name: 'Size / All sizes',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {(['sm', 'md', 'lg'] as ProgressBarSize[]).map((size) => (
        <ProgressBar key={size} value={65} size={size} label={`${size} — 4/8/12 px`} showValue />
      ))}
    </div>
  ),
};

// ─── Colors ───────────────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'Color / All colors',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {(['primary', 'secondary', 'success', 'warning', 'danger'] as ProgressBarColor[]).map((color) => (
        <ProgressBar
          key={color}
          value={65}
          color={color}
          size="md"
          label={color.charAt(0).toUpperCase() + color.slice(1)}
          showValue
        />
      ))}
    </div>
  ),
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateEmpty: Story = {
  name: 'State / Empty (0%)',
  args: { value: 0, label: 'Not started', showValue: true },
};

export const StateHalf: Story = {
  name: 'State / In progress (50%)',
  args: { value: 50, label: 'In progress', showValue: true, color: 'primary' },
};

export const StateComplete: Story = {
  name: 'State / Complete (100%)',
  args: { value: 100, label: 'Complete', showValue: true, color: 'success' },
};

export const StateWarning: Story = {
  name: 'State / Warning',
  args: { value: 40, label: 'Action required', showValue: true, color: 'warning' },
};

export const StateError: Story = {
  name: 'State / Error',
  args: { value: 25, label: 'Upload failed', showValue: true, color: 'danger' },
};

export const StateIndeterminate: Story = {
  name: 'State / Indeterminate',
  args: { indeterminate: true, label: 'Processing…' },
};

// ─── Segmented ────────────────────────────────────────────────────────────────

export const SegmentedDefault: Story = {
  name: 'Segmented / Default (5 steps)',
  args: { value: 60, segments: 5, label: 'Application progress', showValue: true },
};

export const SegmentedPartial: Story = {
  name: 'Segmented / Partial completion',
  render: () => (
    <ProgressBar
      value={40}
      segments={5}
      label="Step 2 of 5"
      showValue
      size="lg"
    />
  ),
};

export const SegmentedMultiColor: Story = {
  name: 'Segmented / Multi-color segments',
  render: () => (
    <ProgressBar
      segmentData={[
        { label: 'Identity',  value: 100, color: 'success' },
        { label: 'Documents', value: 100, color: 'success' },
        { label: 'Business',  value: 100, color: 'success' },
        { label: 'Finance',   value: 50,  color: 'warning' },
        { label: 'Review',    value: 0 },
      ]}
      label="Loan application"
      showValue={false}
      size="md"
    />
  ),
};

// ─── With label ───────────────────────────────────────────────────────────────

export const WithLabel: Story = {
  name: 'Feature / With label',
  args: { value: 75, label: 'Document upload', showValue: true },
};

export const LabelOnly: Story = {
  name: 'Feature / Label only (no value)',
  args: { value: 45, label: 'Verification in progress', showValue: false },
};

// ─── Animated ────────────────────────────────────────────────────────────────

export const Animated: Story = {
  name: 'Interactive / Animated upload',
  render: () => {
    const [progress, setProgress] = useState(0);
    const [done, setDone] = useState(false);

    useEffect(() => {
      if (done) return;
      const id = setInterval(() => {
        setProgress((p) => {
          if (p >= 100) { clearInterval(id); setDone(true); return 100; }
          return p + 2;
        });
      }, 80);
      return () => clearInterval(id);
    }, [done]);

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <ProgressBar
          value={progress}
          color={done ? 'success' : 'primary'}
          label={done ? 'Upload complete' : 'Uploading…'}
          showValue
          size="md"
        />
        <button
          onClick={() => { setProgress(0); setDone(false); }}
          style={{ alignSelf: 'flex-start', fontFamily: 'var(--av-font-body)', fontSize: 13,
            padding: '6px 12px', borderRadius: 6, border: '1px solid var(--av-color-surface-border)',
            background: 'var(--av-color-surface)', cursor: 'pointer', color: 'var(--av-color-text)' }}
        >
          Reset
        </button>
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppDocumentUpload: Story = {
  name: 'App / Document upload list',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <ProgressBar value={100} color="success"  size="md" label="Business registration" showValue />
      <ProgressBar value={100} color="success"  size="md" label="KRA PIN certificate"   showValue />
      <ProgressBar value={65}  color="primary"  size="md" label="Bank statement"         showValue indeterminate={false} />
      <ProgressBar value={0}   color="primary"  size="md" label="Director ID"            showValue />
    </div>
  ),
};

export const AppLoanProgress: Story = {
  name: 'App / Loan application progress',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <ProgressBar
        segmentData={[
          { label: 'Personal',  value: 100, color: 'success' },
          { label: 'Business',  value: 100, color: 'success' },
          { label: 'Documents', value: 100, color: 'success' },
          { label: 'Review',    value: 50,  color: 'warning' },
          { label: 'Approved',  value: 0 },
        ]}
        label="Application — Step 4 of 5"
        size="lg"
      />
      <ProgressBar
        value={80}
        color="primary"
        label="Overall completion"
        showValue
        size="md"
      />
    </div>
  ),
};

export const AppOnboarding: Story = {
  name: 'App / Onboarding steps',
  render: () => (
    <ProgressBar
      value={66}
      segments={3}
      color="primary"
      label="Onboarding — 2 of 3 complete"
      size="lg"
      showValue
    />
  ),
};
