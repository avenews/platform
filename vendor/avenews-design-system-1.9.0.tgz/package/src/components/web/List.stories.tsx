import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { List, ListHeader } from './List';
import { Item, ItemDivider } from './Item';
import { Avatar, MediaIcon } from './Media';
import { Badge } from '../cross-platform/Badge';
import type { ListLines } from './List';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof List> = {
  title: 'Avenews/Web/List',
  component: List,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Vertical container for `Item` rows. ' +
          'Controls line separator style and inset padding. ' +
          'Combine with `ListHeader` for section titles and `ItemDivider` for inline dividers.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    inset: { control: 'boolean' },
    lines: { control: 'radio', options: ['full', 'inset', 'none'] satisfies ListLines[] },
  },
  args: {
    inset: false,
    lines: 'inset',
  },
};

export default meta;
type Story = StoryObj<typeof List>;

// ─── Icon ─────────────────────────────────────────────────────────────────────

const DocIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <polyline points="14 2 14 8 20 8"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// ─── Basic ────────────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  render: () => (
    <List>
      <Item label="Account overview" button detailArrow />
      <Item label="Transaction history" button detailArrow />
      <Item label="Repayment schedule" button detailArrow />
    </List>
  ),
};

// ─── Line variants ────────────────────────────────────────────────────────────

export const LinesInset: Story = {
  name: 'Lines / Inset (default)',
  render: () => (
    <List lines="inset">
      <Item label="Overview"    button />
      <Item label="Documents"   button />
      <Item label="Payments"    button />
    </List>
  ),
};

export const LinesFull: Story = {
  name: 'Lines / Full',
  render: () => (
    <List lines="full">
      <Item label="Overview"    button />
      <Item label="Documents"   button />
      <Item label="Payments"    button />
    </List>
  ),
};

export const LinesNone: Story = {
  name: 'Lines / None',
  render: () => (
    <List lines="none">
      <Item label="Overview"    button />
      <Item label="Documents"   button />
      <Item label="Payments"    button />
    </List>
  ),
};

// ─── Inset list ───────────────────────────────────────────────────────────────

export const Inset: Story = {
  name: 'Feature / Inset (card-style)',
  render: () => (
    <List inset>
      <Item label="Bank statement"        secondLine="Feb 2024" button detailArrow />
      <Item label="Business registration" secondLine="2023"     button detailArrow />
      <Item label="Director ID"           secondLine="Certified" button detailArrow />
    </List>
  ),
};

// ─── With ListHeader ──────────────────────────────────────────────────────────

export const WithHeader: Story = {
  name: 'ListHeader / Default',
  render: () => (
    <>
      <ListHeader label="Account" />
      <List>
        <Item label="Profile settings" button detailArrow />
        <Item label="Security"         button detailArrow />
        <Item label="Notifications"    button detailArrow />
      </List>
    </>
  ),
};

export const WithLargeHeader: Story = {
  name: 'ListHeader / Large',
  render: () => (
    <>
      <ListHeader label="Documents" size="large" />
      <List>
        <Item label="Bank statement" secondLine="Feb 2024" button detailArrow />
        <Item label="Director ID"    secondLine="Certified" button detailArrow />
      </List>
    </>
  ),
};

// ─── With ItemDividers ────────────────────────────────────────────────────────

export const WithDividers: Story = {
  name: 'ItemDivider / Inline section breaks',
  render: () => (
    <List>
      <ItemDivider label="Required" />
      <Item label="Bank statement"         secondLine="Upload required"  button detailArrow />
      <Item label="Business registration"  secondLine="Upload required"  button detailArrow />
      <ItemDivider label="Optional" />
      <Item label="Tax certificate"        secondLine="Optional upload"  button detailArrow />
    </List>
  ),
};

// ─── With media slots ─────────────────────────────────────────────────────────

export const WithMediaSlots: Story = {
  name: 'Slots / With avatars and badges',
  render: () => (
    <List>
      <Item
        label="Amara Kone"
        secondLine="Account manager"
        startSlot={<Avatar initials="AK" size="sm" />}
        endSlot={<Badge count={2} variant="primary" />}
        button
      />
      <Item
        label="James Mwangi"
        secondLine="Risk officer"
        startSlot={<Avatar src="https://i.pravatar.cc/64?img=12" alt="James" size="sm" />}
        button
      />
      <Item
        label="Fatima Diallo"
        secondLine="Loan specialist"
        startSlot={<Avatar initials="FD" size="sm" />}
        endSlot={<Badge count="New" variant="success-subtle" />}
        button
      />
    </List>
  ),
};

// ─── App: document checklist ──────────────────────────────────────────────────

export const DocumentChecklist: Story = {
  name: 'App / Document checklist',
  render: () => (
    <>
      <ListHeader label="KYC Documents" size="large" />
      <List inset>
        <ItemDivider label="Mandatory" />
        <Item
          label="Bank statement"
          secondLine="Last 3 months"
          startSlot={<MediaIcon icon={<DocIcon />} color="warning" size="sm" />}
          endSlot={<Badge count="Due" variant="warning-subtle" />}
          button detailArrow
        />
        <Item
          label="Director ID"
          secondLine="Certified copy"
          startSlot={<MediaIcon icon={<DocIcon />} color="success" size="sm" />}
          endSlot={<Badge count="Done" variant="success-subtle" />}
          button detailArrow
        />
        <ItemDivider label="Optional" />
        <Item
          label="Tax certificate"
          secondLine="Speeds up approval"
          startSlot={<MediaIcon icon={<DocIcon />} color="primary" size="sm" />}
          button detailArrow
        />
      </List>
    </>
  ),
};
