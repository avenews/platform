import React from 'react';
import { cn } from '../shared/utils';
import { Icon } from './Icon';
import type { IconName } from './Icon';

export type InlineBannerVariant = 'success' | 'warning' | 'info' | 'danger';

export interface InlineBannerProps {
  message:      string;
  variant?:     InlineBannerVariant;
  dismissible?: boolean;
  onDismiss?:   () => void;
  className?:   string;
}

// ─── Icon name map ────────────────────────────────────────────────────────────

const ICON_NAMES: Record<InlineBannerVariant, IconName> = {
  success: 'checkmark-circle',
  warning: 'warning',
  info:    'information-circle',
  danger:  'close-circle',
};

export const InlineBanner: React.FC<InlineBannerProps> = ({
  message,
  variant     = 'info',
  dismissible = false,
  onDismiss,
  className,
}) => {
  return (
    <div
      className={cn('avenews-inline-banner', `avenews-inline-banner--${variant}`, className)}
      role="status"
      aria-live="polite"
    >
      <Icon name={ICON_NAMES[variant]} size={20} aria-hidden />
      <p style={{ flex: 1, margin: 0 }}>{message}</p>
      {dismissible && (
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss"
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0,
            display: 'flex', alignItems: 'center', color: 'var(--av-color-text-muted)', flexShrink: 0 }}
        >
          <Icon name="close" size={18} aria-hidden />
        </button>
      )}
    </div>
  );
};

export default InlineBanner;
