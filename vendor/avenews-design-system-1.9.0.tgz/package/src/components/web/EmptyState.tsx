import React from 'react';
import { cn } from '../shared/utils';
import { Button } from './Button';
import { Icon } from './Icon';

export type EmptyStateVariant = 'no-content' | 'no-results' | 'error' | 'offline';

export interface EmptyStateAction {
  label:    string;
  onClick:  () => void;
  variant?: 'primary' | 'outline' | 'ghost';
}

export interface EmptyStateProps {
  variant?:         EmptyStateVariant;
  /**
   * ReactNode icon — replaces Ionic icon string.
   * When omitted, a default SVG is used for the variant.
   */
  icon?:            React.ReactNode;
  title:            string;
  description?:     string;
  action?:          EmptyStateAction;
  secondaryAction?: EmptyStateAction;
  className?:       string;
}

// ─── Default icons per variant ────────────────────────────────────────────────

const DEFAULT_ICONS: Record<EmptyStateVariant, React.ReactNode> = {
  'no-content': <Icon name="document"           size={40} aria-hidden />,
  'no-results': <Icon name="search"             size={40} aria-hidden />,
  'error':      <Icon name="information-circle" size={40} aria-hidden />,
  'offline':    <Icon name="warning"            size={40} aria-hidden />,
};

export const EmptyState: React.FC<EmptyStateProps> = ({
  variant         = 'no-content',
  icon,
  title,
  description,
  action,
  secondaryAction,
  className,
}) => {
  const isError     = variant === 'error' || variant === 'offline';
  const resolvedIcon = icon ?? DEFAULT_ICONS[variant];

  return (
    <div className={cn('avenews-empty-state', `avenews-empty-state--${variant}`, className)}>
      <div
        className="avenews-empty-state__icon-wrap"
        style={{ color: isError ? 'var(--av-color-danger)' : 'var(--av-color-text-muted)' }}
      >
        {resolvedIcon}
      </div>

      <h3 className="avenews-empty-state__title">{title}</h3>

      {description && (
        <p className="avenews-empty-state__description">{description}</p>
      )}

      {(action || secondaryAction) && (
        <div className="avenews-empty-state__actions">
          {action && (
            <Button label={action.label} variant={action.variant ?? 'primary'}
              onClick={action.onClick} expand="block" />
          )}
          {secondaryAction && (
            <Button label={secondaryAction.label} variant={secondaryAction.variant ?? 'ghost'}
              onClick={secondaryAction.onClick} expand="block" />
          )}
        </div>
      )}
    </div>
  );
};

export default EmptyState;
