/**
 * Web components — pure React/HTML, no Ionic runtime. For the application portal.
 *
 * AUTO-GENERATED INDEX. Re-exports every component in this folder so
 * consumers can `import { X } from '@avenews/design-system/web'`
 * without knowing the underlying file structure.
 */

export { Accordion } from './Accordion';
export type { AccordionItem, AccordionProps } from './Accordion';
export { ActionSheet } from './ActionSheet';
export type { ActionSheetButton, ActionSheetProps } from './ActionSheet';
export { Button } from './Button';
export type { ButtonProps } from './Button';
export { Card } from './Card';
export type { CardAction, CardColor, CardLayout, CardProps } from './Card';
export { Checkbox } from './Checkbox';
export type { CheckboxColor, CheckboxProps } from './Checkbox';
export { Chip } from './Chip';
export type { ChipColor, ChipFill, ChipProps, ChipVariant } from './Chip';
export { DataList } from './DataList';
export type { DataField, DataListProps, DataListVariant } from './DataList';
export { EmptyState } from './EmptyState';
export type { EmptyStateAction, EmptyStateProps, EmptyStateVariant } from './EmptyState';
export { FilterBar } from './FilterBar';
export type { FilterBarFilter, FilterBarOption, FilterBarProps } from './FilterBar';
export { Footer } from './Footer';
export type { FooterAction, FooterLayout, FooterPosition, FooterProps, FooterVariant } from './Footer';
export { Header } from './Header';
export type { HeaderProps, HeaderSize, HeaderVariant } from './Header';
export { Icon } from './Icon';
export type { IconName, IconProps, IconSize } from './Icon';
export { InfoRow } from './InfoRow';
export type { InfoRowProps, InfoRowVariant } from './InfoRow';
export { InlineBanner } from './InlineBanner';
export type { InlineBannerProps, InlineBannerVariant } from './InlineBanner';
export { Input } from './Input';
export type { InputProps } from './Input';
export { Item, ItemDivider } from './Item';
export type { ItemColor, ItemDividerProps, ItemLines, ItemProps, ItemVariant } from './Item';
export { List, ListHeader } from './List';
export type { ListColor, ListHeaderProps, ListHeaderSize, ListLines, ListProps } from './List';
export { Loader } from './Loader';
export type { LoaderColor, LoaderProps, LoaderSize, LoaderVariant } from './Loader';
export { Avatar, MediaIcon, Thumbnail } from './Media';
export type { AvatarProps, AvatarSize, MediaIconColor, MediaIconProps, MediaIconSize, ThumbnailProps, ThumbnailSize } from './Media';
export { Modal } from './Modal';
export type { ModalButton, ModalProps, ModalSize, ModalVariant } from './Modal';
export { Note } from './Note';
export type { NoteAlign, NoteColor, NoteProps } from './Note';
export { Pagination } from './Pagination';
export type { PaginationProps } from './Pagination';
export { ProgressBar } from './ProgressBar';
export type { ProgressBarColor, ProgressBarProps, ProgressBarSegment, ProgressBarSize, ProgressBarStyle } from './ProgressBar';
export { ProgressTracker } from './ProgressTracker';
export type { ProgressColor, ProgressTrackerProps, ProgressType } from './ProgressTracker';
export { Radio, RadioGroup } from './Radio';
export type { RadioColor, RadioGroupProps, RadioLayout, RadioOption, RadioProps } from './Radio';
export { Searchbar } from './Searchbar';
export type { SearchbarCancelButton, SearchbarClearButton, SearchbarProps } from './Searchbar';
export { Segment } from './Segment';
export type { SegmentOption, SegmentProps } from './Segment';
export { Select } from './Select';
export type { SelectOption, SelectProps } from './Select';
export { Tabs } from './Tabs';
export type { TabItem, TabsProps, TabsVariant } from './Tabs';
export { Toast } from './Toast';
export type { ToastAction, ToastPosition, ToastProps, ToastVariant } from './Toast';
export { Toggle } from './Toggle';
export type { ToggleProps } from './Toggle';
export { Toolbar } from './Toolbar';
export type { ToolbarAction, ToolbarProps, ToolbarVariant } from './Toolbar';
export { UploadCard } from './UploadCard';

// ── Web-only portal components ────────────────────────────────────────────────
export { Sidebar, DEFAULT_NAV_ITEMS, DEFAULT_FOOTER_ITEMS } from './Sidebar';
export type { SidebarNavItem, SidebarProps } from './Sidebar';
export { TopBar } from './TopBar';
export type { TopBarAction, TopBarAvatar, TopBarProps } from './TopBar';
export { StepTracker, APPLICATION_STEPS } from './StepTracker';
export type { StepTrackerProps, StepTrackerStep, StepState } from './StepTracker';
export { Table } from './Table';
export type { TableColumn, TableProps } from './Table';

// Re-export cross-platform components so consumers can pull every web-app
// component from a single entry point.
export * from '../cross-platform';
