import React, { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { cn } from '../shared/utils';
import { Icon } from './Icon';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface SelectOption {
  value:     string;
  label:     string;
  disabled?: boolean;
}

export interface SelectProps {
  label?:      string;
  placeholder?: string;
  value?:      string;
  options:     SelectOption[];
  disabled?:   boolean;
  required?:   boolean;
  error?:      string;
  helperText?: string;
  onChange?:   (value: string) => void;
  className?:  string;
}


// ─── Component ────────────────────────────────────────────────────────────────

export const Select: React.FC<SelectProps> = ({
  label,
  placeholder = 'Select an option',
  value,
  options,
  disabled    = false,
  required    = false,
  error,
  helperText,
  onChange,
  className,
}) => {
  const uid      = useId();
  const selectId = `av-select-${uid}`;
  const helperId = `av-select-help-${uid}`;
  const listId   = `av-select-list-${uid}`;

  const [open,      setOpen]      = useState(false);
  const [focused,   setFocused]   = useState(false);
  const [highlight, setHighlight] = useState(-1);
  const [pos, setPos] = useState<{ top: number; left: number; width: number; above: boolean } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const triggerRef   = useRef<HTMLButtonElement>(null);
  const dropdownRef  = useRef<HTMLUListElement>(null);

  // Portal-positioning: anchor the dropdown to the trigger via fixed
  // coordinates so it escapes any ancestor overflow (modal body, table cells).
  useLayoutEffect(() => {
    if (!open || !triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    const dropdownHeight = 280;
    const spaceBelow = window.innerHeight - rect.bottom;
    const above = spaceBelow < dropdownHeight && rect.top > dropdownHeight;
    setPos({
      top: above ? rect.top - 4 : rect.bottom,
      left: rect.left,
      width: rect.width,
      above,
    });
  }, [open]);

  // Close dropdown on scroll/resize to avoid stale positioning
  useEffect(() => {
    if (!open) return;
    const onMove = () => setOpen(false);
    window.addEventListener('resize', onMove);
    document.addEventListener('scroll', onMove, true);
    return () => {
      window.removeEventListener('resize', onMove);
      document.removeEventListener('scroll', onMove, true);
    };
  }, [open]);

  const selected = options.find((o) => o.value === value);

  // Set highlight to current value when dropdown opens
  useEffect(() => {
    if (!open) return;
    const idx = options.findIndex((o) => o.value === value);
    setHighlight(idx >= 0 ? idx : 0);
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  // Close on outside click — check both the trigger container AND the
  // portaled dropdown since they're DOM-detached.
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as Node;
      const inTrigger  = containerRef.current?.contains(target);
      const inDropdown = dropdownRef.current?.contains(target);
      if (!inTrigger && !inDropdown) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (disabled) return;
    switch (e.key) {
      case 'Enter':
      case ' ':
        e.preventDefault();
        if (!open) { setOpen(true); return; }
        if (highlight >= 0 && !options[highlight]?.disabled) {
          onChange?.(options[highlight].value);
          setOpen(false);
        }
        break;
      case 'Escape':
        setOpen(false);
        triggerRef.current?.focus();
        break;
      case 'ArrowDown': {
        e.preventDefault();
        if (!open) { setOpen(true); return; }
        const next = options.findIndex((o, i) => i > highlight && !o.disabled);
        if (next >= 0) setHighlight(next);
        break;
      }
      case 'ArrowUp': {
        e.preventDefault();
        const prev = options
          .map((o, i) => (!o.disabled && i < highlight ? i : -1))
          .filter((i) => i >= 0);
        if (prev.length) setHighlight(prev[prev.length - 1]);
        break;
      }
    }
  };

  const handleSelect = (opt: SelectOption) => {
    if (opt.disabled) return;
    onChange?.(opt.value);
    setOpen(false);
    triggerRef.current?.focus();
  };

  return (
    <div
      ref={containerRef}
      className={cn(
        'av-select',
        error    && 'av-select--error',
        disabled && 'av-select--disabled',
        className,
      )}
    >
      {label && (
        <label htmlFor={selectId} className="av-select__label">
          {label}
          {required && <span className="av-select__required" aria-hidden="true">{'\u200A'}*</span>}
        </label>
      )}

      <div className={cn(
        'av-select__wrap',
        open    && 'av-select__wrap--open',
        focused && 'av-select__wrap--focused',
      )}>
        <button
          id={selectId}
          ref={triggerRef}
          type="button"
          role="combobox"
          aria-expanded={open}
          aria-haspopup="listbox"
          aria-controls={listId}
          aria-invalid={Boolean(error)}
          aria-describedby={(error || helperText) ? helperId : undefined}
          disabled={disabled}
          className="av-select__trigger"
          onClick={() => { if (!disabled) setOpen((v) => !v); }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onKeyDown={handleKeyDown}
        >
          <span className={cn('av-select__value', !selected && 'av-select__value--placeholder')}>
            {selected ? selected.label : placeholder}
          </span>
          <span className={cn('av-select__chevron', open && 'av-select__chevron--open')}>
            <Icon name="chevron-down" size={16} />
          </span>
        </button>

        {open && pos && typeof document !== 'undefined' && createPortal(
          <ul
            ref={dropdownRef}
            id={listId}
            role="listbox"
            aria-label={label}
            className={cn('av-select__dropdown', 'av-select__dropdown--portal', pos.above && 'av-select__dropdown--above')}
            style={{
              position: 'fixed',
              top: pos.above ? undefined : pos.top,
              bottom: pos.above ? window.innerHeight - pos.top : undefined,
              left: pos.left,
              width: pos.width,
            }}
          >
            {options.map((opt, i) => (
              <li
                key={opt.value}
                role="option"
                aria-selected={opt.value === value}
                aria-disabled={opt.disabled}
                className={cn(
                  'av-select__option',
                  opt.value === value && 'av-select__option--selected',
                  i === highlight    && 'av-select__option--highlighted',
                  opt.disabled       && 'av-select__option--disabled',
                )}
                onMouseEnter={() => !opt.disabled && setHighlight(i)}
                onMouseDown={(e) => { e.preventDefault(); handleSelect(opt); }}
              >
                {opt.label}
              </li>
            ))}
          </ul>,
          document.body,
        )}
      </div>

      {(error || helperText) && (
        <p
          id={helperId}
          className={cn('av-select__helper', error && 'av-select__helper--error')}
        >
          {error ?? helperText}
        </p>
      )}
    </div>
  );
};

export default Select;
