import React, { useId } from 'react';
import { cn } from '../shared/utils';

// ─── Types ────────────────────────────────────────────────────────────────────

export type RadioColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

export type RadioLayout = 'stacked' | 'inline';

export interface RadioOption {
  value:        string;
  label:        string;
  description?: string;
  disabled?:    boolean;
}

// ─── Single Radio ─────────────────────────────────────────────────────────────

export interface RadioProps {
  name:         string;
  value:        string;
  checked?:     boolean;
  label:        string;
  description?: string;
  disabled?:    boolean;
  error?:       boolean;
  color?:       RadioColor;
  onChange?:    (value: string) => void;
  className?:   string;
}

export const Radio: React.FC<RadioProps> = ({
  name,
  value,
  checked  = false,
  label,
  description,
  disabled = false,
  error    = false,
  color    = 'primary',
  onChange,
  className,
}) => {
  const uid = useId();

  return (
    <label
      htmlFor={uid}
      className={cn(
        'av-radio',
        `av-radio--${color}`,
        checked  && 'av-radio--checked',
        disabled && 'av-radio--disabled',
        error    && 'av-radio--error',
        className,
      )}
    >
      <input
        id={uid}
        type="radio"
        name={name}
        value={value}
        checked={checked}
        disabled={disabled}
        className="av-radio__input"
        onChange={() => onChange?.(value)}
        aria-label={label}
        aria-invalid={error || undefined}
      />
      <span className="av-radio__circle" aria-hidden="true">
        <span className="av-radio__dot" />
      </span>
      <span className="av-radio__content">
        <span className="av-radio__label">{label}</span>
        {description && (
          <span className="av-radio__description">{description}</span>
        )}
      </span>
    </label>
  );
};

// ─── Radio Group ──────────────────────────────────────────────────────────────

export interface RadioGroupProps {
  name:        string;
  value?:      string;
  options:     RadioOption[];
  layout?:     RadioLayout;
  color?:      RadioColor;
  disabled?:   boolean;
  label?:      string;
  helperText?: string;
  errorText?:  string;
  error?:      boolean;
  onChange?:   (value: string) => void;
  className?:  string;
}

export const RadioGroup: React.FC<RadioGroupProps> = ({
  name,
  value,
  options,
  layout    = 'stacked',
  color     = 'primary',
  disabled  = false,
  label,
  helperText,
  errorText,
  error     = false,
  onChange,
  className,
}) => (
  <fieldset
    className={cn(
      'av-radio-group',
      `av-radio-group--${layout}`,
      error    && 'av-radio-group--error',
      disabled && 'av-radio-group--disabled',
      className,
    )}
    disabled={disabled}
  >
    {label && (
      <legend className="av-radio-group__legend">{label}</legend>
    )}

    <div className={cn('av-radio-group__options', `av-radio-group__options--${layout}`)}>
      {options.map((opt) => (
        <Radio
          key={opt.value}
          name={name}
          value={opt.value}
          label={opt.label}
          description={opt.description}
          checked={value === opt.value}
          disabled={disabled || Boolean(opt.disabled)}
          color={color}
          error={error}
          onChange={onChange}
        />
      ))}
    </div>

    {(helperText || errorText) && (
      <p className={cn('av-radio-group__helper', error && 'av-radio-group__helper--error')}>
        {error && errorText ? errorText : helperText}
      </p>
    )}
  </fieldset>
);

export default RadioGroup;
