import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Header } from './Header';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Header> = {
  title: 'Avenews/Web/Header',
  component: Header,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Content-level page section header — distinct from Toolbar (which is the nav bar). ' +
          'Used below the Toolbar to present a large title, optional subtitle, description, ' +
          'avatar/logo, and action buttons. Supports 3 variants and 3 size levels.',
      },
    },
    layout: 'fullscreen',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '100%', maxWidth: 420, margin: '0 auto' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    variant: { control: 'radio', options: ['default', 'subtle', 'dark'] },
    size:    { control: 'radio', options: ['sm', 'md', 'lg'] },
    title:    { control: 'text' },
    subtitle: { control: 'text' },
    description: { control: 'text' },
  },
  args: {
    title:   'My Loans',
    variant: 'default',
    size:    'md',
  },
};

export default meta;
type Story = StoryObj<typeof Header>;

// ─── Shared action buttons ────────────────────────────────────────────────────

const ActionBtn: React.FC<{ label: string; primary?: boolean }> = ({ label, primary }) => (
  <button
    type="button"
    style={{
      fontFamily: 'var(--av-font-body)', fontSize: 13, fontWeight: 600,
      padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer',
      background: primary ? 'var(--av-color-action)' : 'var(--av-color-surface-subtle)',
      color: primary ? '#fff' : 'var(--av-color-text)',
    }}
  >
    {label}
  </button>
);

const AvatarPlaceholder: React.FC<{ initials: string; color?: string }> = ({ initials, color = 'var(--av-color-action)' }) => (
  <div style={{
    width: 48, height: 48, borderRadius: 12,
    background: color, color: '#fff',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'var(--av-font-heading)', fontWeight: 700, fontSize: 18,
    flexShrink: 0,
  }}>
    {initials}
  </div>
);

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { title: 'My Loans', subtitle: '3 active loans' },
};

// ─── Variants ────────────────────────────────────────────────────────────────

export const VariantSubtle: Story = {
  name: 'Variant / Subtle',
  args: { title: 'Documents', subtitle: '12 files uploaded', variant: 'subtle' },
};

export const VariantDark: Story = {
  name: 'Variant / Dark',
  args: { title: 'Welcome back', subtitle: 'Avenews Capital', variant: 'dark' },
};

// ─── Sizes ───────────────────────────────────────────────────────────────────

export const SizeSm: Story = {
  name: 'Size / Small',
  args: { title: 'Section title', subtitle: '4 items', size: 'sm' },
};

export const SizeLg: Story = {
  name: 'Size / Large',
  args: { title: 'Dashboard', subtitle: 'Welcome back, John', size: 'lg' },
};

// ─── With description ─────────────────────────────────────────────────────────

export const WithDescription: Story = {
  name: 'Feature / With description',
  args: {
    title:       'Working Capital Loan',
    subtitle:    'Loan #AV-2024-001',
    description: 'Short-term financing for operational expenses. Disbursed on 12 Jan 2024.',
  },
};

// ─── With avatar ─────────────────────────────────────────────────────────────

export const WithAvatar: Story = {
  name: 'Feature / With avatar',
  args: {
    title:    'Acacia Trading Ltd',
    subtitle: 'Business account · Nairobi',
    avatar:   <AvatarPlaceholder initials="AT" />,
  },
};

export const WithAvatarAndDescription: Story = {
  name: 'Feature / Avatar + description',
  args: {
    title:       'Acacia Trading Ltd',
    subtitle:    'KRA PIN: A123456789B',
    description: 'Registered 2018 · Retail & trade · 12 employees',
    avatar:      <AvatarPlaceholder initials="AT" />,
  },
};

// ─── With actions ─────────────────────────────────────────────────────────────

export const WithActions: Story = {
  name: 'Feature / With actions',
  args: {
    title:    'My Loans',
    subtitle: '3 active loans',
    actions:  (
      <div style={{ display: 'flex', gap: 8 }}>
        <ActionBtn label="Apply now" primary />
      </div>
    ),
  },
};

export const WithAvatarAndActions: Story = {
  name: 'Feature / Avatar + actions',
  args: {
    title:    'Acacia Trading Ltd',
    subtitle: 'Business account',
    avatar:   <AvatarPlaceholder initials="AT" />,
    actions:  (
      <div style={{ display: 'flex', gap: 8 }}>
        <ActionBtn label="Edit" />
      </div>
    ),
  },
};

// ─── With breadcrumb ─────────────────────────────────────────────────────────

export const WithBreadcrumb: Story = {
  name: 'Feature / With breadcrumb',
  args: {
    title:    'Loan #AV-2024-001',
    subtitle: 'Working capital · KES 500,000',
    breadcrumb: (
      <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 12, color: 'var(--av-color-text-muted)' }}>
        Loans → Active
      </span>
    ),
  },
};

// ─── App use-cases ─────────────────────────────────────────────────────────────

export const AppDashboard: Story = {
  name: 'App / Dashboard greeting',
  args: {
    title:    'Good morning, John',
    subtitle: 'You have 2 pending documents',
    size:     'lg',
    variant:  'default',
    avatar:   <AvatarPlaceholder initials="JK" color="#0f4b6b" />,
  },
};

export const AppLoanDetail: Story = {
  name: 'App / Loan detail header',
  args: {
    title:       'Working Capital Loan',
    subtitle:    'Loan #AV-2024-001',
    description: 'Disbursed 12 Jan 2024 · 12-month term · KES 500,000',
    size:        'md',
    actions:     (
      <div style={{ display: 'flex', gap: 8 }}>
        <ActionBtn label="Repay" primary />
      </div>
    ),
  },
};

export const AppDocumentsSection: Story = {
  name: 'App / Documents section',
  args: {
    title:    'Required documents',
    subtitle: '2 of 5 uploaded',
    size:     'sm',
    variant:  'subtle',
  },
};
