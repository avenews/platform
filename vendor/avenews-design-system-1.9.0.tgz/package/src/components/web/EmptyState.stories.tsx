import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { EmptyState } from './EmptyState';
import type { EmptyStateVariant } from './EmptyState';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof EmptyState> = {
  title: 'Avenews/Web/EmptyState',
  component: EmptyState,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Full-area empty placeholder for zero-data views. ' +
          'Four semantic variants with built-in SVG icons, title, description, ' +
          'and up to two action buttons. Custom icon via `icon` prop.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 32, background: 'var(--av-color-surface-subtle)', borderRadius: 12 }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    variant: {
      control: 'select',
      options: ['no-content', 'no-results', 'error', 'offline'] satisfies EmptyStateVariant[],
    },
    title:       { control: 'text' },
    description: { control: 'text' },
  },
  args: {
    variant:     'no-content',
    title:       'No documents yet',
    description: 'Upload your first document to get started.',
  },
};

export default meta;
type Story = StoryObj<typeof EmptyState>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (no-content)',
};

// ─── All variants ─────────────────────────────────────────────────────────────

export const NoContent: Story = {
  name: 'Variant / No content',
  args: {
    variant:     'no-content',
    title:       'No documents yet',
    description: 'You haven\'t uploaded any documents. Start by uploading your first one.',
  },
};

export const NoResults: Story = {
  name: 'Variant / No results',
  args: {
    variant:     'no-results',
    title:       'No results found',
    description: 'Try adjusting your search or filters to find what you\'re looking for.',
  },
};

export const Error: Story = {
  name: 'Variant / Error',
  args: {
    variant:     'error',
    title:       'Something went wrong',
    description: 'We couldn\'t load your documents. Please try again.',
  },
};

export const Offline: Story = {
  name: 'Variant / Offline',
  args: {
    variant:     'offline',
    title:       'No connection',
    description: 'Check your internet connection and try again.',
  },
};

// ─── With actions ─────────────────────────────────────────────────────────────

export const WithPrimaryAction: Story = {
  name: 'Actions / Primary only',
  args: {
    variant:     'no-content',
    title:       'No documents uploaded',
    description: 'Upload your documents to continue with your application.',
    action:      { label: 'Upload document', onClick: () => {} },
  },
};

export const WithTwoActions: Story = {
  name: 'Actions / Primary + secondary',
  args: {
    variant:          'no-results',
    title:            'No matching documents',
    description:      'Try clearing your filters or upload a new document.',
    action:           { label: 'Clear filters',      onClick: () => {}, variant: 'primary' },
    secondaryAction:  { label: 'Upload document',    onClick: () => {}, variant: 'ghost' },
  },
};

export const ErrorWithRetry: Story = {
  name: 'Actions / Error + retry',
  args: {
    variant:     'error',
    title:       'Failed to load documents',
    description: 'There was a problem fetching your documents.',
    action:      { label: 'Try again', onClick: () => {}, variant: 'primary' },
  },
};

// ─── Custom icon ─────────────────────────────────────────────────────────────

const FolderIcon: React.FC = () => (
  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"
      stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const CustomIcon: Story = {
  name: 'Feature / Custom icon',
  args: {
    variant:     'no-content',
    icon:        <FolderIcon />,
    title:       'No folders found',
    description: 'Create a folder to organise your documents.',
    action:      { label: 'Create folder', onClick: () => {} },
  },
};

// ─── All variants grid ────────────────────────────────────────────────────────

export const AllVariants: Story = {
  name: 'Overview / All variants',
  render: () => (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
      {(['no-content', 'no-results', 'error', 'offline'] as EmptyStateVariant[]).map((v) => (
        <div key={v} style={{ padding: 24, background: 'var(--av-color-surface)', borderRadius: 12 }}>
          <EmptyState
            variant={v}
            title={v.replace('-', ' ')}
            description="Short description."
          />
        </div>
      ))}
    </div>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 600, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const NoLoans: Story = {
  name: 'App / No active loans',
  args: {
    variant:     'no-content',
    title:       'No active loans',
    description: 'You don\'t have any active loan products. Apply for a loan to get started.',
    action:      { label: 'Apply for a loan', onClick: () => {} },
  },
};

export const NoSearchResults: Story = {
  name: 'App / No document search results',
  args: {
    variant:     'no-results',
    title:       'No documents found',
    description: 'No documents match your current search. Try a different term or clear filters.',
    action:          { label: 'Clear search',    onClick: () => {}, variant: 'outline' },
    secondaryAction: { label: 'Upload document', onClick: () => {}, variant: 'ghost'   },
  },
};

export const OfflineApp: Story = {
  name: 'App / Offline mode',
  args: {
    variant:     'offline',
    title:       'You\'re offline',
    description: 'Your documents will reload automatically when you\'re back online.',
  },
};
