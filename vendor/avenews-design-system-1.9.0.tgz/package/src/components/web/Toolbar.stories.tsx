import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Toolbar } from './Toolbar';
import type { ToolbarAction } from './Toolbar';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Toolbar> = {
  title: 'Avenews/Web/Toolbar',
  component: Toolbar,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Top application bar with leading (back/menu), title, and trailing action slots. ' +
          '4 variants: default (white), transparent, primary (brand aqua), dark. ' +
          'Distinct from Header — Toolbar is always the fixed navigation bar.',
      },
    },
    layout: 'fullscreen',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '100%', maxWidth: 420, margin: '0 auto' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    variant:       { control: 'radio', options: ['default', 'transparent', 'primary', 'dark'] },
    centerTitle:   { control: 'boolean' },
    showBackButton:{ control: 'boolean' },
    title:         { control: 'text' },
    subtitle:      { control: 'text' },
    backLabel:     { control: 'text' },
  },
  args: {
    title:   'My Account',
    variant: 'default',
  },
};

export default meta;
type Story = StoryObj<typeof Toolbar>;

// ─── Inline icons ─────────────────────────────────────────────────────────────

const SearchIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);
const BellIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const MoreIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <circle cx="12" cy="5"  r="1" fill="currentColor" />
    <circle cx="12" cy="12" r="1" fill="currentColor" />
    <circle cx="12" cy="19" r="1" fill="currentColor" />
  </svg>
);
const MenuIcon: React.FC = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <line x1="3" y1="12" x2="21" y2="12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="3" y1="6"  x2="21" y2="6"  stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="3" y1="18" x2="21" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const SEARCH_BELL: ToolbarAction[] = [
  { icon: <SearchIcon />, label: 'Search' },
  { icon: <BellIcon />,   label: 'Notifications' },
];

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { title: 'Dashboard', showBackButton: false },
};

// ─── Variants ─────────────────────────────────────────────────────────────────

export const VariantPrimary: Story = {
  name: 'Variant / Primary',
  args: { title: 'My Loans', variant: 'primary', trailingActions: [{ icon: <SearchIcon />, label: 'Search' }] },
};

export const VariantDark: Story = {
  name: 'Variant / Dark',
  args: { title: 'Dashboard', variant: 'dark', trailingActions: SEARCH_BELL },
};

export const VariantTransparent: Story = {
  name: 'Variant / Transparent',
  decorators: [
    (Story) => (
      <div style={{ background: 'linear-gradient(135deg, var(--av-color-action), var(--av-aqua-950))', width: '100%', maxWidth: 420 }}>
        <Story />
      </div>
    ),
  ],
  args: { title: 'Apply for loan', variant: 'transparent', showBackButton: true },
};

// ─── Back button ──────────────────────────────────────────────────────────────

export const WithBackButton: Story = {
  name: 'Nav / Back button',
  args: {
    title:          'Loan details',
    showBackButton: true,
    trailingActions: [{ icon: <MoreIcon />, label: 'More' }],
  },
};

export const WithBackLabel: Story = {
  name: 'Nav / Back with label',
  args: { title: 'Documents', showBackButton: true, backLabel: 'Loans' },
};

// ─── Title alignment ──────────────────────────────────────────────────────────

export const CenteredTitle: Story = {
  name: 'Layout / Centered title',
  args: {
    title:           'Upload document',
    showBackButton:  true,
    centerTitle:     true,
    trailingActions: [{ icon: <MoreIcon />, label: 'More' }],
  },
};

// ─── Trailing actions ──────────────────────────────────────────────────────────

export const WithSubtitle: Story = {
  name: 'Feature / Title + subtitle',
  args: {
    title:    'Business account',
    subtitle: 'Avenews Capital Ltd',
    trailingActions: SEARCH_BELL,
  },
};

export const MenuLeading: Story = {
  name: 'Feature / Menu leading slot',
  args: {
    title:       'Home',
    leadingSlot: (
      <button type="button" aria-label="Menu" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '0 4px', display: 'flex', color: 'inherit' }}>
        <MenuIcon />
      </button>
    ),
    trailingActions: [{ icon: <BellIcon />, label: 'Notifications' }],
  },
};

// ─── App use-cases ─────────────────────────────────────────────────────────────

export const AppDashboard: Story = {
  name: 'App / Dashboard',
  args: {
    title:           'Dashboard',
    variant:         'default',
    trailingActions: SEARCH_BELL,
  },
};

export const AppLoanDetail: Story = {
  name: 'App / Loan detail',
  args: {
    title:           'Loan #AV-2024-001',
    subtitle:        'Working capital',
    showBackButton:  true,
    centerTitle:     false,
    trailingActions: [{ icon: <MoreIcon />, label: 'More options' }],
  },
};

export const AppKYCStep: Story = {
  name: 'App / KYC step',
  args: {
    title:          'Identity verification',
    showBackButton: true,
    centerTitle:    true,
    variant:        'default',
  },
};
