import React from 'react';
import { cn } from '../shared/utils';
import { Button } from './Button';

export type CardColor  =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light' | 'medium' | 'dark';

export type CardLayout = 'default' | 'media' | 'list';

export interface CardAction {
  label:    string;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success' | 'warning';
  onClick?: () => void;
}

export interface CardProps {
  color?:       CardColor;
  layout?:      CardLayout;
  subtitle?:    string;
  title:        string;
  body?:        string;
  imageUrl?:    string;
  imageAlt?:    string;
  actions?:     CardAction[];
  listContent?: React.ReactNode;
  tappable?:    boolean;
  disabled?:    boolean;
  loading?:     boolean;
  error?:       string;
  /** href for router navigation (replaces Ionic routerLink) */
  href?:        string;
  onClick?:     () => void;
  className?:   string;
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

const CardSkeleton: React.FC<{ showImage: boolean }> = ({ showImage }) => (
  <div className="av-card">
    {showImage && <div className="av-card__skeleton-image" />}
    <div className="av-card__header">
      <div className="av-card__skeleton-subtitle" />
      <div className="av-card__skeleton-title"    />
    </div>
    <div className="av-card__body">
      <div className="av-card__skeleton-line av-card__skeleton-line--full"  />
      <div className="av-card__skeleton-line av-card__skeleton-line--short" />
    </div>
  </div>
);

// ─── Component ────────────────────────────────────────────────────────────────

export const Card: React.FC<CardProps> = ({
  color       = 'default',
  layout      = 'default',
  subtitle,
  title,
  body,
  imageUrl,
  imageAlt    = '',
  actions     = [],
  listContent,
  tappable    = false,
  disabled    = false,
  loading     = false,
  error,
  href,
  onClick,
  className,
}) => {
  const showImage = layout === 'media' && !!imageUrl;
  const isColored = color !== 'default';

  if (loading) return <CardSkeleton showImage={showImage} />;

  const rootCls = cn('av-card', isColored && `av-card--${color}`, className);

  const inner = (
    <>
      {showImage && (
        <img src={imageUrl} alt={imageAlt} className="av-card__image" />
      )}

      <div className="av-card__header">
        <h3 className="av-card__title">{title}</h3>
        {subtitle && <p className="av-card__subtitle">{subtitle}</p>}
      </div>

      {(body || listContent || error) && (
        <div className="av-card__body">
          {error        ? <p className="av-card__error">{error}</p>
           : listContent ? listContent
           : <p className="av-card__text">{body}</p>
          }
        </div>
      )}

      {actions.length > 0 && !error && (
        <div className={cn('av-card__actions', isColored && 'av-card__actions--inverted')}>
          {actions.slice(0, 3).map((action) => (
            <Button key={action.label} label={action.label}
              variant={action.variant ?? 'primary'} size="sm" onClick={action.onClick} />
          ))}
        </div>
      )}
    </>
  );

  if (href) {
    return <a href={href} className={cn(rootCls, 'av-card--link')}>{inner}</a>;
  }

  if (tappable || onClick) {
    return (
      <button type="button" className={cn(rootCls, 'av-card--tappable')}
        onClick={onClick} disabled={disabled}>
        {inner}
      </button>
    );
  }

  return <div className={cn(rootCls, disabled && 'av-card--disabled')}>{inner}</div>;
};

export default Card;
