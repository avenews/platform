import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { InfoRow } from './InfoRow';

const meta: Meta<typeof InfoRow> = {
  title: 'Avenews/Web/InfoRow',
  component: InfoRow,
  parameters: { layout: 'padded' },
  argTypes: {
    variant:      { control: 'select', options: ['default', 'stacked', 'with-copy', 'with-badge'] },
    badgeVariant: { control: 'select', options: ['neutral', 'success', 'warning', 'danger', 'info', 'primary'] },
  },
};

export default meta;
type Story = StoryObj<typeof InfoRow>;

export const Default: Story = {
  args: { label: 'Business name', value: 'Acacia Trading Ltd' },
};

export const Stacked: Story = {
  args: { label: 'Registered address', value: '14 Moi Avenue, Nairobi CBD, Nairobi, Kenya', variant: 'stacked' },
};

export const WithCopy: Story = {
  args: { label: 'Reference number', value: 'AV-2024-001-KE', variant: 'with-copy', onCopy: () => {} },
};

export const WithBadge: Story = {
  args: { label: 'Application status', value: 'In Review', variant: 'with-badge', badgeVariant: 'info' },
};

export const Loading: Story = {
  args: { label: '', loading: true },
};

export const GroupExample: Story = {
  render: () => (
    <div style={{ border: '1px solid #d0d7df', borderRadius: 8, overflow: 'hidden', maxWidth: 480 }}>
      <InfoRow label="Business name"       value="Acacia Trading Ltd" />
      <InfoRow label="Director"            value="Brendan Meyer" />
      <InfoRow label="KRA PIN"             value="P051234567A" variant="with-copy" onCopy={() => {}} />
      <InfoRow label="Application status"  value="In Review"  variant="with-badge" badgeVariant="info" />
      <InfoRow label="Registration status" value="Active"     variant="with-badge" badgeVariant="success" />
      <InfoRow label="Registered address"  value="14 Moi Avenue, Nairobi CBD, Nairobi 00100" variant="stacked" />
    </div>
  ),
};

export const LoadingGroup: Story = {
  render: () => (
    <div style={{ border: '1px solid #d0d7df', borderRadius: 8, overflow: 'hidden', maxWidth: 480 }}>
      <InfoRow label="" loading />
      <InfoRow label="" loading />
      <InfoRow label="" loading />
      <InfoRow label="" loading />
    </div>
  ),
};
