import React from 'react';
import { cn } from '../shared/utils';

// ─── Props ────────────────────────────────────────────────────────────────────

export interface PaginationProps {
  /** 1-based current page. */
  page:          number;
  pageSize:      number;
  /** Total number of items across all pages. */
  total:         number;
  onPageChange:  (page: number) => void;
  /** Plural noun for the summary line, e.g. "invoices". Defaults to "items". */
  itemLabel?:    string;
  className?:    string;
}

/** A page token in the control: a 1-based page number, or a collapsed gap (…). */
type PaginationToken = number | 'gap';

/** Build the list of page tokens to render, collapsing long ranges with a gap. */
function pageWindow(current: number, count: number): PaginationToken[] {
  if (count <= 7) {
    return Array.from({ length: count }, (_, i) => i + 1);
  }
  const tokens: PaginationToken[] = [1];
  const start = Math.max(2, current - 1);
  const end = Math.min(count - 1, current + 1);
  if (start > 2) tokens.push('gap');
  for (let p = start; p <= end; p++) tokens.push(p);
  if (end < count - 1) tokens.push('gap');
  tokens.push(count);
  return tokens;
}

// ─── Component ────────────────────────────────────────────────────────────────

/**
 * Footer pagination for data tables and card lists. Pagination is client-side:
 * the parent owns the page index and slices its own list; this component renders
 * the summary line + page controls and reports the requested page through
 * `onPageChange`. Renders nothing when everything fits on a single page.
 *
 * Styled with .dt-pagination so it sits cleanly beneath the .dt-table family.
 */
export const Pagination: React.FC<PaginationProps> = ({
  page,
  pageSize,
  total,
  onPageChange,
  itemLabel = 'items',
  className,
}) => {
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  if (pageCount <= 1) return null;

  const current = Math.min(Math.max(1, page), pageCount);
  const first = (current - 1) * pageSize + 1;
  const last = Math.min(current * pageSize, total);

  const go = (p: number) => {
    const next = Math.min(Math.max(1, p), pageCount);
    if (next !== current) onPageChange(next);
  };

  return (
    <nav className={cn('dt-pagination', className)} aria-label="Pagination">
      <p className="dt-pagination__summary" aria-live="polite">
        Showing <strong>{first}–{last}</strong> of <strong>{total}</strong> {itemLabel}
      </p>

      <div className="dt-pagination__controls">
        <button
          type="button"
          className="dt-pagination__btn dt-pagination__btn--nav"
          onClick={() => go(current - 1)}
          disabled={current === 1}
          aria-label="Previous page"
        >
          ‹
        </button>

        {pageWindow(current, pageCount).map((token, i) =>
          token === 'gap' ? (
            <span key={`gap-${i}`} className="dt-pagination__gap" aria-hidden="true">
              …
            </span>
          ) : (
            <button
              key={token}
              type="button"
              className={cn(
                'dt-pagination__btn',
                token === current && 'dt-pagination__btn--active',
              )}
              onClick={() => go(token)}
              aria-label={`Page ${token}`}
              aria-current={token === current ? 'page' : undefined}
            >
              {token}
            </button>
          ),
        )}

        <button
          type="button"
          className="dt-pagination__btn dt-pagination__btn--nav"
          onClick={() => go(current + 1)}
          disabled={current === pageCount}
          aria-label="Next page"
        >
          ›
        </button>
      </div>
    </nav>
  );
};
