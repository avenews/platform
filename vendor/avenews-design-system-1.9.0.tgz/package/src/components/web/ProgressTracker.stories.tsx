import React, { useEffect, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { ProgressTracker } from './ProgressTracker';

const meta: Meta<typeof ProgressTracker> = {
  title: 'Avenews/Web/ProgressTracker',
  component: ProgressTracker,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Horizontal progress bar with determinate, indeterminate, and buffer modes. ' +
          'Supports 9 colour tokens, reversed fill direction, and loading/error shorthands.',
      },
    },
    layout: 'padded',
  },
};

export default meta;
type Story = StoryObj<typeof ProgressTracker>;

// ─── Determinate ──────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Determinate / Default (50%)',
  args: {
    value: 0.5,
  },
};

export const Complete: Story = {
  name: 'Determinate / Complete (100%)',
  args: {
    value: 1,
    color: 'success',
  },
};

export const Reversed: Story = {
  name: 'Determinate / Reversed',
  args: {
    value: 0.65,
    reversed: true,
  },
};

// ─── Indeterminate ────────────────────────────────────────────────────────────

export const Indeterminate: Story = {
  name: 'Indeterminate / Loading shorthand',
  args: {
    loading: true,
  },
};

export const IndeterminatePrimary: Story = {
  name: 'Indeterminate / Secondary colour',
  args: {
    loading: true,
    color: 'secondary',
  },
};

// ─── Buffer ───────────────────────────────────────────────────────────────────

export const Buffer: Story = {
  name: 'Buffer / Video-style',
  args: {
    type:   'buffer',
    value:  0.4,
    buffer: 0.7,
  },
};

// ─── Error ────────────────────────────────────────────────────────────────────

export const ErrorState: Story = {
  name: 'State / Error shorthand',
  args: {
    error: true,
  },
};

// ─── Colours ──────────────────────────────────────────────────────────────────

const colorOptions = [
  'primary', 'secondary', 'tertiary',
  'success', 'warning',   'danger',
  'light',   'medium',    'dark',
] as const;

export const AllColours: Story = {
  name: 'Colours / All (value 0.6)',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: 360, fontFamily: 'var(--av-font-body)' }}>
      {colorOptions.map((color) => (
        <div key={color} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ width: 72, fontSize: 12, color: 'var(--av-neutral-400)' }}>{color}</span>
          <div style={{ flex: 1 }}>
            <ProgressTracker value={0.6} color={color} />
          </div>
        </div>
      ))}
    </div>
  ),
};

// ─── Interactive ──────────────────────────────────────────────────────────────

export const Animated: Story = {
  name: 'Interactive / Animated fill',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [value, setValue] = useState(0);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [running, setRunning] = useState(false);

    // eslint-disable-next-line react-hooks/rules-of-hooks
    useEffect(() => {
      if (!running) return;
      if (value >= 1) { setRunning(false); return; }
      const t = setTimeout(() => setValue((v) => Math.min(1, v + 0.05)), 120);
      return () => clearTimeout(t);
    }, [running, value]);

    const reset = () => { setValue(0); setRunning(false); };

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 360, fontFamily: 'var(--av-font-body)' }}>
        <ProgressTracker
          value={value}
          color={value === 1 ? 'success' : 'primary'}
        />
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={() => { reset(); setTimeout(() => setRunning(true), 50); }}
            style={{ padding: '8px 16px', borderRadius: 8, border: 'none', background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer', fontSize: 13, fontFamily: 'inherit' }}
          >
            Start upload
          </button>
          <button
            onClick={reset}
            style={{ padding: '8px 16px', borderRadius: 8, border: '1px solid var(--av-neutral-300)', background: '#fff', cursor: 'pointer', fontSize: 13, fontFamily: 'inherit' }}
          >
            Reset
          </button>
        </div>
        <p style={{ margin: 0, fontSize: 13, color: 'var(--av-neutral-500)' }}>
          {value === 1 ? '✓ Upload complete' : running ? `Uploading… ${Math.round(value * 100)}%` : 'Ready'}
        </p>
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const LoanApplication: Story = {
  name: 'App / Loan application progress',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, width: 340, fontFamily: 'var(--av-font-body)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
        <span style={{ fontWeight: 600, color: 'var(--av-neutral-800)' }}>Application progress</span>
        <span style={{ color: 'var(--av-neutral-500)' }}>3 of 5 steps</span>
      </div>
      <ProgressTracker value={0.6} color="primary" />
    </div>
  ),
};

export const DocumentUpload: Story = {
  name: 'App / Document upload states',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 340, fontFamily: 'var(--av-font-body)' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--av-neutral-500)' }}>
          <span>Bank Statement.pdf</span><span>100%</span>
        </div>
        <ProgressTracker value={1} color="success" />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--av-neutral-500)' }}>
          <span>Director_ID.jpg</span><span>60%</span>
        </div>
        <ProgressTracker value={0.6} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--av-neutral-500)' }}>
          <span>Tax_Certificate.pdf</span><span>Upload failed</span>
        </div>
        <ProgressTracker error />
      </div>
    </div>
  ),
};
