import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Tabs } from './Tabs';
import type { TabItem } from './Tabs';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Tabs> = {
  title: 'Avenews/Web/Tabs',
  component: Tabs,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Tab navigation bar with three variants: `underline` (page section switcher), ' +
          '`pill` (compact inline switcher), and `bar` (fixed bottom navigation). ' +
          'Supports icon + label, badge count, disabled tabs, and full-width stretch.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface)', borderRadius: 12, overflow: 'hidden' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    variant: { control: 'radio', options: ['underline', 'pill', 'bar'] },
    stretch: { control: 'boolean' },
  },
  args: {
    variant: 'underline',
    stretch: true,
  },
};

export default meta;
type Story = StoryObj<typeof Tabs>;

// ─── Inline icons ─────────────────────────────────────────────────────────────

const HomeIcon: React.FC = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const DocumentIcon: React.FC = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <polyline points="14 2 14 8 20 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const ChartIcon: React.FC = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <line x1="18" y1="20" x2="18" y2="10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="12" y1="20" x2="12" y2="4"  stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="6"  y1="20" x2="6"  y2="14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);
const ProfileIcon: React.FC = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="2" />
  </svg>
);
const WalletIcon: React.FC = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <rect x="2" y="5" width="20" height="14" rx="2" stroke="currentColor" strokeWidth="2" />
    <path d="M16 13a1 1 0 110-2 1 1 0 010 2z" fill="currentColor" />
    <path d="M2 9h20" stroke="currentColor" strokeWidth="2" />
  </svg>
);

// ─── Shared data ──────────────────────────────────────────────────────────────

const NAV_TABS: TabItem[] = [
  { value: 'home',      label: 'Home',      icon: <HomeIcon /> },
  { value: 'documents', label: 'Documents', icon: <DocumentIcon /> },
  { value: 'analytics', label: 'Analytics', icon: <ChartIcon /> },
  { value: 'profile',   label: 'Profile',   icon: <ProfileIcon /> },
];

const TEXT_TABS: TabItem[] = [
  { value: 'overview',  label: 'Overview' },
  { value: 'documents', label: 'Documents' },
  { value: 'payments',  label: 'Payments' },
  { value: 'activity',  label: 'Activity' },
];

// ─── Variants ────────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Variant / Underline (default)',
  render: () => {
    const [val, setVal] = useState('overview');
    return <Tabs tabs={TEXT_TABS} value={val} onChange={setVal} variant="underline" stretch />;
  },
};

export const VariantPill: Story = {
  name: 'Variant / Pill',
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface-subtle)', borderRadius: 12, padding: 16, overflow: 'hidden' }}>
        <Story />
      </div>
    ),
  ],
  render: () => {
    const [val, setVal] = useState('overview');
    return <Tabs tabs={TEXT_TABS} value={val} onChange={setVal} variant="pill" />;
  },
};

export const VariantBar: Story = {
  name: 'Variant / Bar (bottom nav)',
  render: () => {
    const [val, setVal] = useState('home');
    return <Tabs tabs={NAV_TABS} value={val} onChange={setVal} variant="bar" stretch />;
  },
};

// ─── Icon combinations ────────────────────────────────────────────────────────

export const IconAndLabel: Story = {
  name: 'Icons / Icon + label (underline)',
  render: () => {
    const [val, setVal] = useState('home');
    return <Tabs tabs={NAV_TABS} value={val} onChange={setVal} variant="underline" stretch />;
  },
};

export const TextOnly: Story = {
  name: 'Text / Text only',
  render: () => {
    const [val, setVal] = useState('overview');
    return <Tabs tabs={TEXT_TABS} value={val} onChange={setVal} variant="underline" stretch />;
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const WithDisabled: Story = {
  name: 'State / Disabled tab',
  render: () => {
    const [val, setVal] = useState('overview');
    return (
      <Tabs
        tabs={[
          { value: 'overview',  label: 'Overview' },
          { value: 'documents', label: 'Documents' },
          { value: 'analytics', label: 'Analytics', disabled: true },
          { value: 'activity',  label: 'Activity' },
        ]}
        value={val}
        onChange={setVal}
        variant="underline"
        stretch
      />
    );
  },
};

export const WithBadge: Story = {
  name: 'Feature / With badges',
  render: () => {
    const [val, setVal] = useState('home');
    return (
      <Tabs
        tabs={[
          { value: 'home',      label: 'Home',      icon: <HomeIcon /> },
          { value: 'documents', label: 'Documents', icon: <DocumentIcon />, badge: 3 },
          { value: 'wallet',    label: 'Wallet',    icon: <WalletIcon />, badge: 12 },
          { value: 'profile',   label: 'Profile',   icon: <ProfileIcon /> },
        ]}
        value={val}
        onChange={setVal}
        variant="bar"
        stretch
      />
    );
  },
};

// ─── App use-cases ─────────────────────────────────────────────────────────────

export const AppDashboard: Story = {
  name: 'App / Dashboard navigation',
  render: () => {
    const [val, setVal] = useState('home');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        <div style={{
          padding: '24px 20px',
          fontFamily: 'var(--av-font-body)', fontSize: 14,
          color: 'var(--av-color-text-muted)',
          borderBottom: '1px solid var(--av-color-surface-border)',
        }}>
          Active: <strong style={{ color: 'var(--av-color-text)' }}>{val}</strong>
        </div>
        <Tabs
          tabs={[
            { value: 'home',      label: 'Home',      icon: <HomeIcon /> },
            { value: 'documents', label: 'Documents', icon: <DocumentIcon />, badge: 2 },
            { value: 'analytics', label: 'Analytics', icon: <ChartIcon /> },
            { value: 'profile',   label: 'Profile',   icon: <ProfileIcon /> },
          ]}
          value={val}
          onChange={setVal}
          variant="bar"
          stretch
        />
      </div>
    );
  },
};

export const AppLoanDetail: Story = {
  name: 'App / Loan detail tabs',
  render: () => {
    const [val, setVal] = useState('overview');
    return (
      <Tabs
        tabs={[
          { value: 'overview',  label: 'Overview' },
          { value: 'schedule',  label: 'Schedule' },
          { value: 'documents', label: 'Documents' },
          { value: 'activity',  label: 'Activity' },
        ]}
        value={val}
        onChange={setVal}
        variant="underline"
        stretch
      />
    );
  },
};

export const AppFilterPill: Story = {
  name: 'App / Status filter (pill)',
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface-subtle)', borderRadius: 12, padding: '16px 20px', overflow: 'hidden' }}>
        <Story />
      </div>
    ),
  ],
  render: () => {
    const [val, setVal] = useState('all');
    return (
      <Tabs
        tabs={[
          { value: 'all',    label: 'All' },
          { value: 'active', label: 'Active' },
          { value: 'closed', label: 'Closed' },
        ]}
        value={val}
        onChange={setVal}
        variant="pill"
      />
    );
  },
};
