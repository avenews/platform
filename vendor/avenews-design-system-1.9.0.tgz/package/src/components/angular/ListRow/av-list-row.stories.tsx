/**
 * CSS-contract stories for the `av-list-row` pattern (v1.8.0).
 *
 * There is no `<av-list-row>` component — this is a class contract layered on
 * `.av-data-list` / `.av-info-row`, so the markup below is what a consumer
 * writes by hand. It is rendered here as raw JSX for the same reason the
 * DataList Angular stories reuse the React components: the emitted DOM is what
 * the contract is, regardless of which framework produced it.
 */
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta = {
  title: 'Avenews/Angular/ListRow',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'The non-table record row: a tappable line answering **who → how much → when**. Use it ' +
          'where a full data table is too much furniture — dashboard preview blocks, any list a ' +
          'phone has to render — and reach for `.dt-table` when the reader genuinely needs to ' +
          'compare many columns.\n\n' +
          'Layered on `.av-data-list` / `.av-info-row`, which already supply the container border ' +
          'and radius, the 48px minimum row height, the surface background and a divider that ' +
          'cancels itself on `:last-child`. This pattern adds only the interior layout and the ' +
          'interaction affordances.\n\n' +
          'Everything the reader scans sits in one left-aligned stack; the right column holds only ' +
          'status and the chevron. That ordering came out of a 375px audit — an earlier ' +
          'two-column split gave secondary metadata 47% of the row and the name plus amount only ' +
          '40%, so the least important content was the widest.\n\n' +
          'The row is a `<button>`, so its accessible name is composed from its content: a screen ' +
          'reader announces "Kitale Grain Millers Ltd, Total payable Ksh 35,615,532, 3 periods · ' +
          'due 31 Mar 2026, button".',
      },
    },
  },
};

export default meta;
type Story = StoryObj;

interface RowProps {
  name: string;
  label?: string;
  amount?: string;
  secondary?: string;
  meta?: string;
  metaOnly?: string;
  chip?: { label: string; color: string };
  attention?: boolean;
}

const Row: React.FC<RowProps> = ({
  name, label = 'Total payable', amount, secondary, meta, metaOnly, chip, attention,
}) => (
  <button
    type="button"
    className={`av-info-row av-list-row${attention ? ' av-list-row--attention' : ''}`}
  >
    <span className="av-info-row__label av-list-row__main">
      <span className="av-list-row__title">
        <span className="av-list-row__name">{name}</span>
        {chip && <span className={`av-chip av-chip--${chip.color}`}>{chip.label}</span>}
      </span>
      <span className="av-list-row__money">
        {metaOnly ? (
          <span className="av-list-row__meta av-list-row__meta--only">{metaOnly}</span>
        ) : (
          <>
            <span className="av-list-row__label">{label}</span>
            <span className="av-list-row__amount">{amount}</span>
            <span className="av-list-row__meta">
              {secondary && <span className="av-list-row__meta-secondary">{secondary} · </span>}
              {meta}
            </span>
          </>
        )}
      </span>
    </span>
    <span className="av-info-row__end av-list-row__end">
      <svg className="av-list-row__chevron" width="16" height="16" viewBox="0 0 24 24"
           fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
        <polyline points="9 18 15 12 9 6" />
      </svg>
    </span>
  </button>
);

export const Default: Story = {
  render: () => (
    <div className="av-data-list av-list" style={{ maxWidth: 720 }}>
      <Row name="Meru Highlands Growers" amount="Ksh 5,590,690" secondary="2 periods" meta="due 15 Jun 2026" />
      <Row name="Nyanza Fresh Aggregators" amount="Ksh 1,046,200" secondary="1 period" meta="due 15 Jun 2026" />
    </div>
  ),
};

export const WithAttention: Story = {
  name: 'Attention (overdue)',
  parameters: {
    docs: {
      description: {
        story:
          '`--attention` marks rows the reader is liable for right now — a faint danger wash plus a ' +
          '3px left rule, matching `.dt-tr--attention` and `.asf-card--overdue` so one fact looks ' +
          'the same in every layout. Reserve it for genuine liability, not for anything merely ' +
          'noteworthy: if most rows carry it, none of them read as urgent.',
      },
    },
  },
  render: () => (
    <div className="av-data-list av-list" style={{ maxWidth: 720 }}>
      <Row name="Kitale Grain Millers Ltd" amount="Ksh 35,615,532" secondary="3 periods"
           meta="due 31 Mar 2026" chip={{ label: '1 overdue', color: 'danger' }} attention />
      <Row name="Rift Valley Produce Ltd" amount="Ksh 20,190,002" secondary="4 periods"
           meta="due 15 Apr 2026" chip={{ label: '1 overdue', color: 'danger' }} attention />
      <Row name="Meru Highlands Growers" amount="Ksh 5,590,690" secondary="2 periods" meta="due 15 Jun 2026" />
    </div>
  ),
};

export const WithStatusChip: Story = {
  name: 'Status in the end slot',
  parameters: {
    docs: {
      description: {
        story:
          'A chip can sit in `__end` beside the chevron instead of next to the name. Put it next to ' +
          'the name when it qualifies *what the row is* ("1 overdue"), and in the end slot when it ' +
          'is the row\'s own state ("Open", "Settled").',
      },
    },
  },
  render: () => (
    <div className="av-data-list av-list" style={{ maxWidth: 720 }}>
      {[
        { name: 'Rift Valley Produce Ltd', amount: 'Ksh 9,190,002', meta: 'due 15 Jun 2026 · 27 days' },
        { name: 'Kitale Grain Millers Ltd', amount: 'Ksh 21,135,032', meta: 'due 15 Jun 2026 · 27 days' },
      ].map(r => (
        <button key={r.name} type="button" className="av-info-row av-list-row">
          <span className="av-info-row__label av-list-row__main">
            <span className="av-list-row__title">
              <span className="av-list-row__name">{r.name}</span>
            </span>
            <span className="av-list-row__money">
              <span className="av-list-row__label">Total payable</span>
              <span className="av-list-row__amount">{r.amount}</span>
              <span className="av-list-row__meta">{r.meta}</span>
            </span>
          </span>
          <span className="av-info-row__end av-list-row__end">
            <span className="av-chip av-chip--success">Open</span>
            <svg className="av-list-row__chevron" width="16" height="16" viewBox="0 0 24 24"
                 fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </span>
        </button>
      ))}
    </div>
  ),
};

export const NothingOutstanding: Story = {
  name: 'No amount to show',
  parameters: {
    docs: {
      description: {
        story:
          'When there is no figure, use `__meta--only`, which suppresses the leading separator the ' +
          'meta line otherwise carries. Do not render `Ksh 0` — a zero reads as a balance that ' +
          'happens to be nil, which is a different claim from having nothing outstanding.',
      },
    },
  },
  render: () => (
    <div className="av-data-list av-list" style={{ maxWidth: 720 }}>
      <Row name="Coastal Cashew Co-op" metaOnly="Nothing outstanding" />
      <Row name="Turkana Sorghum Union" metaOnly="No periods yet" />
    </div>
  ),
};

export const Mobile: Story = {
  parameters: {
    viewport: { defaultViewport: 'mobile1' },
    docs: {
      description: {
        story:
          'Below 768px the chevron and `__meta-secondary` drop out, and the meta line takes its own ' +
          'row. Measured at 375px: a labelled amount alone is ~226px of the ~309px available, so ' +
          'the date cannot share that line. Drop only genuinely secondary content into ' +
          '`__meta-secondary` — a period count survives being hidden, an overdue duration does not.',
      },
    },
  },
  render: () => (
    <div className="av-data-list av-list" style={{ maxWidth: 343 }}>
      <Row name="Kitale Grain Millers Ltd" amount="Ksh 35,615,532" secondary="3 periods"
           meta="due 31 Mar 2026" chip={{ label: '1 overdue', color: 'danger' }} attention />
      <Row name="Meru Highlands Growers" amount="Ksh 5,590,690" secondary="2 periods" meta="due 15 Jun 2026" />
    </div>
  ),
};
