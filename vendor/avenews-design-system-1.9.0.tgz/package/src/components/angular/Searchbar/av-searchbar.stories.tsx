/**
 * CSS-contract stories for AvSearchbarComponent.
 * Renders the same `.av-searchbar` markup the Angular `<av-searchbar>` emits,
 * via the React Searchbar component (their output is identical), so the
 * Angular surface is documented alongside the web one.
 */
import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Searchbar } from '../../web/Searchbar';

const meta: Meta = {
  title: 'Avenews/Angular/Searchbar',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvSearchbarComponent` (`<av-searchbar>`) — Angular standalone pill search input for ' +
          'filter bars and toolbars. Inputs: `placeholder`, `value`, `debounce`, `showCancelButton`, ' +
          '`showClearButton`, `disabled`, `loading`, `error`, `ariaLabel`; emits `(valueChange)`, ' +
          '`(cleared)` and `(cancelled)`. Leave `value` unbound for an uncontrolled searchbar, or ' +
          'bind it to make the parent the source of truth — which is what a "Reset filters" button ' +
          'needs. Use this rather than `<av-input type="search">` in a filter bar: the input renders ' +
          'a bordered stacked form field, which sits badly next to `<av-filter-select>`.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

function Interactive(props: React.ComponentProps<typeof Searchbar>) {
  const [value, setValue] = useState('');
  return (
    <div style={{ maxWidth: 320 }}>
      <Searchbar {...props} value={value} onChange={setValue} debounce={0} />
      <p style={{ marginTop: 12, fontSize: 12, color: 'var(--av-color-text-muted)' }}>
        Emitted value: <code>{value || '—'}</code>
      </p>
    </div>
  );
}

export const Default: Story = {
  name: 'Default',
  render: () => <Interactive placeholder="Search supplier or period" />,
};

export const AlwaysShowClear: Story = {
  name: 'Clear always visible',
  render: () => (
    <Interactive placeholder="Search invoice or supplier" showClearButton="always" showCancelButton="never" />
  ),
};

export const NoCancel: Story = {
  name: 'No cancel button — filter-bar usage',
  render: () => (
    <Interactive placeholder="Search supplier or period" showCancelButton="never" />
  ),
};

export const ErrorState: Story = {
  name: 'Error',
  render: () => <Interactive placeholder="Search" error />,
};

export const Disabled: Story = {
  name: 'Disabled',
  render: () => (
    <div style={{ maxWidth: 320 }}>
      <Searchbar placeholder="Search" disabled />
    </div>
  ),
};

export const Loading: Story = {
  name: 'Loading skeleton',
  render: () => (
    <div style={{ maxWidth: 320 }}>
      <Searchbar loading />
    </div>
  ),
};
