import {
  Component, Input, Output, EventEmitter, OnChanges, OnDestroy, SimpleChanges,
  ViewChild, ElementRef, ChangeDetectionStrategy,
} from '@angular/core';
import { AvIconComponent } from '../Icon/av-icon.component';

export type SearchbarCancelButton = 'never' | 'focus' | 'always';
export type SearchbarClearButton  = 'never' | 'focus' | 'always';

/**
 * AvSearchbarComponent — pill search input for filter bars and toolbars.
 *
 * Mirrors the React <Searchbar> 1:1 so both web portals read identically:
 * leading search icon, debounced change emission, and clear / cancel affordances
 * that appear on focus by default.
 *
 * Styled with .av-searchbar from the shared stylesheet (styles-angular.css).
 * Use this instead of `<av-input type="search">` — that renders a bordered
 * stacked form field, which looks wrong sitting beside `<av-filter-select>`.
 *
 * `value` is optional. Leave it unbound for an uncontrolled searchbar; bind it
 * to make the parent the source of truth (needed for a "Reset filters" button).
 *
 * Usage:
 *   <av-searchbar
 *     placeholder="Search supplier or period"
 *     [value]="search"
 *     (valueChange)="search = $event; onFilterChange()"
 *   />
 */
@Component({
  standalone: true,
  selector: 'av-searchbar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [AvIconComponent],
  templateUrl: './av-searchbar.component.html',
  // `.av-searchbar` classes go on the HOST, not a wrapper div. The host is the
  // element a consumer's layout actually sees: with the classes on an inner div,
  // `.av-searchbar--inline`'s `flex: 0 1 320px` and any `margin-left: auto` land
  // on a non-flex-item and are silently ignored, leaving the bare host as an
  // inline shrink-to-fit box. `.av-searchbar` already sets `display: flex`, so
  // the host becomes the flex container too.
  host: { '[class]': 'containerClasses' },
})
export class AvSearchbarComponent implements OnChanges, OnDestroy {
  @Input() placeholder = 'Search';
  /** Bind for a controlled searchbar; leave unset to let the component own it. */
  @Input() value?: string;
  /** Milliseconds to wait before emitting. 0 emits on every keystroke. */
  @Input() debounce = 300;
  @Input() showCancelButton: SearchbarCancelButton = 'focus';
  @Input() showClearButton: SearchbarClearButton   = 'focus';
  @Input() disabled = false;
  @Input() loading  = false;
  @Input() error    = false;
  /**
   * Set when the searchbar sits in a flex toolbar or filter bar. The base
   * `.av-searchbar` carries margin intended for an Ionic list context, which
   * misaligns the control by 8px and adds 16px side gaps next to
   * `<av-filter-select>`. Adds `.av-searchbar--inline` to zero that margin.
   */
  @Input() inline = false;
  /** Accessible name, when the searchbar has no visible label beside it. */
  @Input() ariaLabel = 'Search';

  /** Renamed from React's onChange — matches Angular two-way naming. */
  @Output() valueChange = new EventEmitter<string>();
  @Output() cleared     = new EventEmitter<void>();
  @Output() cancelled   = new EventEmitter<void>();

  @ViewChild('input') private inputRef?: ElementRef<HTMLInputElement>;

  focused = false;

  private internal = '';
  private debounceId: ReturnType<typeof setTimeout> | null = null;

  /** Controlled value when bound, otherwise the component's own state. */
  get current(): string {
    return this.value !== undefined ? this.value : this.internal;
  }

  get containerClasses(): string {
    return [
      'av-searchbar',
      this.inline   ? 'av-searchbar--inline'   : '',
      this.loading  ? 'av-searchbar--skeleton' : '',
      this.focused  ? 'av-searchbar--focused'  : '',
      this.error    ? 'av-searchbar--error'    : '',
      this.disabled ? 'av-searchbar--disabled' : '',
    ].filter(Boolean).join(' ');
  }

  get showCancel(): boolean {
    return this.showCancelButton === 'always'
      || (this.showCancelButton === 'focus' && this.focused);
  }

  get showClear(): boolean {
    const visible = this.showClearButton === 'always'
      || (this.showClearButton === 'focus' && this.focused);
    return visible && this.current.length > 0;
  }

  onInput(event: Event): void {
    const next = (event.target as HTMLInputElement).value;
    if (this.value === undefined) this.internal = next;
    this.emitDebounced(next);
  }

  clear(): void {
    if (this.value === undefined) this.internal = '';
    this.emitNow('');
    this.cleared.emit();
    this.inputRef?.nativeElement.focus();
  }

  cancel(): void {
    if (this.value === undefined) this.internal = '';
    this.emitNow('');
    this.cancelled.emit();
    this.focused = false;
    this.inputRef?.nativeElement.blur();
  }

  /**
   * Cancel a pending debounced emission when `value` is changed from outside.
   *
   * Without this a controlled searchbar silently undoes a programmatic clear: the
   * user types, the parent's "Reset filters" sets `value` to '', and the in-flight
   * timer then fires ~`debounce` ms later and re-emits the typed text, restoring
   * the filter the reset had just removed.
   *
   * Note the residual case: if the bound `value` is *already* '' while the user
   * types (parent only updates on `valueChange`), a reset does not change the
   * binding, so Angular fires no `ngOnChanges` and the pending emission still
   * lands. Pass `[debounce]="0"` where a reset control must be exact.
   */
  ngOnChanges(changes: SimpleChanges): void {
    const change = changes['value'];
    if (!change || change.firstChange) return;
    if (change.currentValue !== change.previousValue && this.debounceId) {
      clearTimeout(this.debounceId);
      this.debounceId = null;
    }
  }

  ngOnDestroy(): void {
    if (this.debounceId) clearTimeout(this.debounceId);
  }

  private emitDebounced(next: string): void {
    if (this.debounceId) clearTimeout(this.debounceId);
    if (this.debounce <= 0) {
      this.valueChange.emit(next);
      return;
    }
    this.debounceId = setTimeout(() => this.valueChange.emit(next), this.debounce);
  }

  /** Clear and cancel bypass the debounce — the intent is immediate. */
  private emitNow(next: string): void {
    if (this.debounceId) clearTimeout(this.debounceId);
    this.valueChange.emit(next);
  }
}
