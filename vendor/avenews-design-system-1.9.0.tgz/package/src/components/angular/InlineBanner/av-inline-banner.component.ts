import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

export type InlineBannerVariant = 'danger' | 'warning' | 'info' | 'success';

@Component({
  standalone: true,
  selector: 'av-inline-banner',
  templateUrl: './av-inline-banner.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AvInlineBannerComponent {
  @Input({ required: true }) message!: string;
  @Input() variant: InlineBannerVariant = 'info';
}
