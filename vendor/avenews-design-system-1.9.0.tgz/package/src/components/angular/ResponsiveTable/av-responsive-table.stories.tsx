/**
 * CSS-contract stories for `av-cards-only` / `av-table-only` and the numeric
 * cell classes (v1.8.0).
 */
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta = {
  title: 'Avenews/Angular/ResponsiveTable',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A data table below 768px is unreadable, so every list screen renders the same records ' +
          'twice — as cards for phones, as a table for wider viewports — and swaps which one is ' +
          'visible. `av-cards-only` and `av-table-only` are that swap.\n\n' +
          '**Both sides must carry the same records.** They are two renderings of one list, not two ' +
          'lists; if they diverge, the two viewports disagree about what exists, and that is a bug ' +
          'no test will catch because only one is ever visible at a time.\n\n' +
          '`.av-td--right` / `.av-th--right` (aliasing `.dt-*--right`) set right alignment **and** ' +
          '`font-variant-numeric: tabular-nums` together. Alignment on its own only half works: with ' +
          'proportional figures a "1" is narrower than an "8", so the digit columns still wobble. ' +
          'The two are set on one class precisely so they cannot drift apart.',
      },
    },
  },
};

export default meta;
type Story = StoryObj;

const ROWS = [
  { supplier: 'Kitale Grain Millers Ltd', due: '31 Mar 2026', payable: 'Ksh 8,000,000',  financed: 'Ksh 5,000,000', status: 'Overdue', tone: 'danger',  attention: true },
  { supplier: 'Rift Valley Produce Ltd',  due: '15 Jun 2026', payable: 'Ksh 9,190,002',  financed: 'Ksh 3,000,000', status: 'Open',    tone: 'success', attention: false },
  { supplier: 'Meru Highlands Growers',   due: '15 Jun 2026', payable: 'Ksh 1,940,690',  financed: 'Ksh 0',         status: 'Open',    tone: 'success', attention: false },
  { supplier: 'Nyanza Fresh Aggregators', due: '30 Apr 2026', payable: 'Ksh 1,250,000',  financed: 'Ksh 0',         status: 'Pending', tone: 'warning', attention: false },
];

const Pair = () => (
  <>
    <div className="av-cards-only">
      {ROWS.map(r => (
        <article key={r.supplier} className={`asf-card${r.attention ? ' asf-card--overdue' : ''}`}>
          <div className="asf-card__head">
            <span className="asf-card__buyer">{r.supplier}</span>
            <span className={`av-chip av-chip--${r.tone}`}>{r.status}</span>
          </div>
          <p className="asf-card__partner">Due {r.due}</p>
          <div className="asf-card__metrics">
            <span><small>Total Payable</small><strong>{r.payable}</strong></span>
            <span><small>Total Financed</small><strong>{r.financed}</strong></span>
          </div>
        </article>
      ))}
    </div>

    <div className="dt-wrapper av-table-only">
      <table className="dt-table">
        <thead className="dt-thead">
          <tr>
            <th className="dt-th dt-th--left">Supplier</th>
            <th className="dt-th dt-th--left">Due Date</th>
            <th className="dt-th av-th--right">Total Payable</th>
            <th className="dt-th av-th--right">Total Financed</th>
            <th className="dt-th dt-th--left">Status</th>
          </tr>
        </thead>
        <tbody>
          {ROWS.map(r => (
            <tr key={r.supplier} className={`dt-tr${r.attention ? ' dt-tr--attention' : ''}`}>
              <td className="dt-td dt-td--left dt-td--bold">{r.supplier}</td>
              <td className="dt-td dt-td--left">{r.due}</td>
              <td className="dt-td av-td--right dt-td--bold">{r.payable}</td>
              <td className="dt-td av-td--right">{r.financed}</td>
              <td className="dt-td dt-td--left">
                <span className={`av-chip av-chip--${r.tone}`}>{r.status}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </>
);

export const Desktop: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Above 768px the table shows and the cards are hidden. Note the money columns: right ' +
          'aligned with tabular figures, so the digits form a column that can be compared down the ' +
          'page rather than a ragged left edge.',
      },
    },
  },
  render: () => <Pair />,
};

export const Mobile: Story = {
  parameters: {
    viewport: { defaultViewport: 'mobile1' },
    docs: {
      description: {
        story:
          'Below 768px the swap inverts. The card leads with the party name and its status, then ' +
          'the figures as labelled pairs — a phone cannot carry a header row, so every number has ' +
          'to name itself.',
      },
    },
  },
  render: () => <Pair />,
};

export const NumericAlignment: Story = {
  name: 'Why tabular figures',
  parameters: {
    docs: {
      description: {
        story:
          'The same column with and without `font-variant-numeric: tabular-nums`. Both are right ' +
          'aligned; only the second lets the thousands separators line up, which is what makes a ' +
          'column of money scannable. This is why the two declarations live on one class.',
      },
    },
  },
  render: () => (
    <div style={{ display: 'flex', gap: 48 }}>
      {[
        { title: 'Proportional (wrong)', style: { fontVariantNumeric: 'normal' as const } },
        { title: 'Tabular (av-td--right)', style: { fontVariantNumeric: 'tabular-nums' as const } },
      ].map(col => (
        <div key={col.title}>
          <p style={{ fontSize: 12, color: '#6b7280', margin: '0 0 8px' }}>{col.title}</p>
          <div style={{ textAlign: 'right', ...col.style }}>
            {['Ksh 1,111,111', 'Ksh 8,888,888', 'Ksh 35,615,532', 'Ksh 640,000'].map(v => (
              <div key={v} style={{ padding: '4px 0' }}>{v}</div>
            ))}
          </div>
        </div>
      ))}
    </div>
  ),
};
