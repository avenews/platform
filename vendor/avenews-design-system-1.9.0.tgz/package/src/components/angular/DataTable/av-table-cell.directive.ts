import { Directive, Input, TemplateRef } from '@angular/core';
import type { DataTableColumn } from './av-data-table.component';

/** Context injected into every avTableCell template. */
export interface AvTableCellContext {
  /** The raw cell value — available as implicit binding (`let-value`). */
  $implicit: unknown;
  /** The full data row. */
  row: Record<string, unknown>;
  /** The column definition for this cell. */
  col: DataTableColumn;
}

/**
 * AvTableCellDirective — custom cell template for AvDataTableComponent.
 *
 * Attach to an `<ng-template>` inside `<av-data-table>` and set
 * `avTableCell` to the column key you want to override.
 *
 * @example
 * ```html
 * <av-data-table [columns]="columns" [rows]="rows">
 *   <!-- Override the "status" column with a DS badge -->
 *   <ng-template avTableCell="status" let-value let-row="row">
 *     <av-status-badge [label]="statusLabel(value)" [color]="statusColor(value)" />
 *   </ng-template>
 *
 *   <!-- Override "amount" column with formatted currency -->
 *   <ng-template avTableCell="amount" let-value>
 *     <strong>{{ value | currency:'KES' }}</strong>
 *   </ng-template>
 * </av-data-table>
 * ```
 *
 * Columns without a matching directive fall back to `{{ cellValue }}` text rendering.
 */
@Directive({
  selector: '[avTableCell]',
  standalone: true,
})
export class AvTableCellDirective {
  /** The column key this template overrides. Must match a `DataTableColumn.key`. */
  @Input({ required: true }) avTableCell!: string;

  constructor(public template: TemplateRef<AvTableCellContext>) {}
}
