import { Component, Input, Output, EventEmitter, ContentChildren, QueryList } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AvTableCellDirective } from './av-table-cell.directive';

export interface DataTableColumn {
  key:            string;
  header:         string;
  mono?:          boolean;
  muted?:         boolean;
  align?:         'left' | 'center' | 'right';
  width?:         string | number;
  sortable?:      boolean;
  sortDirection?: 'asc' | 'desc' | null;
}

/**
 * AvDataTableComponent — a self-contained table driven by a `columns` array.
 *
 * ## Scope: this is NOT the Avenews portal table
 *
 * All three portals (customer, affiliate, ASFo — eight tables between them) render
 * tables from hand-written `.dt-table` markup, styled by the portal layer in
 * `globals.css`. This component emits a different class namespace (`.av-table__*`)
 * with its own visual language, so adopting it inside a portal is a redesign rather
 * than a refactor: every portal-level override — `dt-td--bold`, `dt-muted`,
 * `dt-tr--attention`, clickable-row styling, the sticky header, and the
 * tooltip-bubble edge-anchoring — is written against `.dt-*` and would not apply.
 *
 * Use this for **new, simple tables** that need none of that. For a portal table,
 * follow the existing `.dt-table` pattern.
 *
 * Known gaps if it ever has to serve as the portal table, measured against those
 * eight tables:
 *  - `DataTableColumn.header` is a plain string; 7 of 8 tables put a tooltip in the
 *    header
 *  - no per-row class / `role` / `tabindex` / `aria-label` hook; 4 of 8 make the
 *    whole row the click target
 *  - cell emphasis covers `mono` and `muted` but not bold
 *  - no sticky header
 *  - `rows: Record<string, unknown>[]` trades away the typed rows the portals have
 *
 * See `docs/design-system-architecture-v1.md` §13.2 in the portals repo.
 */
@Component({
  standalone: true,
  selector: 'av-data-table',
  imports: [CommonModule],
  templateUrl: './av-data-table.component.html',
})
export class AvDataTableComponent {
  @ContentChildren(AvTableCellDirective)
  private cellDefs!: QueryList<AvTableCellDirective>;
  @Input() columns: DataTableColumn[]              = [];
  @Input() rows: Record<string, unknown>[]         = [];
  @Input() emptyLabel                              = 'No records found.';
  @Input() card                                    = true;

  @Output() rowClick = new EventEmitter<Record<string, unknown>>();
  @Output() sort     = new EventEmitter<string>();

  get tableClasses(): string {
    return ['av-table', this.card ? 'av-table--card' : ''].filter(Boolean).join(' ');
  }

  thClasses(col: DataTableColumn): string {
    return ['av-table__th',
      col.sortable ? 'av-table__th--sortable' : '',
      col.align    ? `av-table__th--${col.align}` : '',
    ].filter(Boolean).join(' ');
  }

  tdClasses(col: DataTableColumn): string {
    return ['av-table__td',
      col.mono  ? 'av-table__mono'  : '',
      col.muted ? 'av-table__muted' : '',
      col.align ? `av-table__td--${col.align}` : '',
    ].filter(Boolean).join(' ');
  }

  colStyle(col: DataTableColumn): Record<string, string> {
    return col.width ? { width: typeof col.width === 'number' ? `${col.width}px` : col.width } : {};
  }

  cellValue(row: Record<string, unknown>, key: string): unknown {
    return row[key];
  }

  /** Returns the custom template for `key`, or null for default text rendering. */
  getCellTemplate(key: string): AvTableCellDirective['template'] | null {
    return this.cellDefs?.find(d => d.avTableCell === key)?.template ?? null;
  }

  onSort(col: DataTableColumn): void {
    if (col.sortable) this.sort.emit(col.key);
  }

  onRowClick(row: Record<string, unknown>): void {
    this.rowClick.emit(row);
  }
}
