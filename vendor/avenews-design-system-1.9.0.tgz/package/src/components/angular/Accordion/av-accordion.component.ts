import {
  Component, Input, Output, EventEmitter, ContentChildren, QueryList,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AvAccordionContentDirective } from './av-accordion-content.directive';

export interface AccordionItem {
  value:     string;
  label:     string;
  /**
   * Plain-text body. Optional — supply an `<ng-template avAccordionContent>`
   * instead when the section needs markup (a table, a card list, a data list).
   */
  content?:  string;
  disabled?: boolean;
}

/**
 * Visual treatment.
 *  - `list` (default) — full-bleed rows divided by hairlines, for an Ionic-style
 *    settings list.
 *  - `card` — each item is a bordered, rounded, subtly raised container. Use this
 *    when the accordion sits beside other cards (`.av-data-list`, `.dt-wrapper`)
 *    and would otherwise read as an unstyled stray row.
 */
export type AccordionVariant = 'list' | 'card';

@Component({
  standalone: true,
  selector: 'av-accordion',
  imports: [CommonModule],
  templateUrl: './av-accordion.component.html',
})
export class AvAccordionComponent {
  @ContentChildren(AvAccordionContentDirective)
  private contentDefs!: QueryList<AvAccordionContentDirective>;

  @Input() items: AccordionItem[] = [];
  @Input() multiple               = false;
  @Input() openValues: string[]   = [];
  @Input() variant: AccordionVariant = 'list';
  /**
   * Removes the content's default padding so a table or list can meet the
   * container edges instead of being double-indented inside it.
   */
  @Input() flushContent = false;

  @Output() itemToggle = new EventEmitter<string[]>();

  get rootClasses(): string {
    return ['av-accordion',
      this.variant === 'card' ? 'av-accordion--card' : '',
    ].filter(Boolean).join(' ');
  }

  get contentClasses(): string {
    return ['av-accordion__content',
      this.flushContent ? 'av-accordion__content--flush' : '',
    ].filter(Boolean).join(' ');
  }

  /** Returns the projected template for `value`, or null for plain-text content. */
  getContentTemplate(value: string): AvAccordionContentDirective['template'] | null {
    return this.contentDefs?.find(d => d.avAccordionContent === value)?.template ?? null;
  }

  isOpen(value: string): boolean {
    return this.openValues.includes(value);
  }

  itemClasses(item: AccordionItem): string {
    return ['av-accordion__item',
      this.isOpen(item.value) ? 'av-accordion__item--open'     : '',
      item.disabled           ? 'av-accordion__item--disabled' : '',
    ].filter(Boolean).join(' ');
  }

  toggle(item: AccordionItem): void {
    if (item.disabled) return;
    let next: string[];
    if (this.isOpen(item.value)) {
      next = this.openValues.filter(v => v !== item.value);
    } else {
      next = this.multiple ? [...this.openValues, item.value] : [item.value];
    }
    this.openValues = next;
    this.itemToggle.emit(next);
  }
}
