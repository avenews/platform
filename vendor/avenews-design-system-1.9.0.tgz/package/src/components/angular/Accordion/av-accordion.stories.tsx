/**
 * CSS-contract stories for AvAccordionComponent.
 * Renders the same `.av-accordion` markup the Angular `<av-accordion>` emits, via
 * the React Accordion component (their output is identical), so the Angular
 * surface is documented alongside the web one.
 */
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Accordion } from '../../web/Accordion';

const meta: Meta = {
  title: 'Avenews/Angular/Accordion',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvAccordionComponent` (`<av-accordion>`) — Angular standalone collapsible sections. ' +
          'Inputs: `items` (`AccordionItem[]`), `multiple`, `openValues`, `variant` ' +
          '(`list` | `card`), `flushContent`; emits the open set via `(itemToggle)`.\n\n' +
          '**Rich content.** `AccordionItem.content` is a plain string. For markup — a table, ' +
          'a data list, a card stack — supply an `<ng-template avAccordionContent="{item.value}">` ' +
          'instead (`AvAccordionContentDirective`), the same pattern `AvDataTableComponent` uses ' +
          'for custom cells. Items without a matching template fall back to the string. This ' +
          'brings the Angular component to parity with the web `<Accordion>`, whose `content` is ' +
          'already a `ReactNode`.\n\n' +
          '**Variants.** `list` (default) is a full-bleed Ionic-style row divided by hairlines. ' +
          '`card` gives each item a bordered, rounded, subtly raised container and drops the ' +
          'header hover tint — use it when the accordion sits beside other cards ' +
          '(`.av-data-list`, `.dt-wrapper`), where the default reads as an unstyled stray row. ' +
          'Pair with `flushContent` so a nested table meets the container edges instead of being ' +
          'double-indented.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

const COPY_ITEMS = [
  {
    value: 'what-is',
    label: 'What is a supplier payment period?',
    content:
      'Invoices you upload are grouped by supplier and payment due date. Each group is one ' +
      'payment period, and it is what you settle on the due date.',
  },
  {
    value: 'when-pay',
    label: 'When do I pay?',
    content: 'On the due date shown against the period. The amount and date do not change.',
  },
];

export const List: Story = {
  name: 'List (default)',
  render: () => <Accordion items={COPY_ITEMS} value="what-is" />,
};

export const Card: Story = {
  name: 'Card variant',
  render: () => (
    <div className="av-accordion av-accordion--card">
      {[
        { label: 'Associated Invoices', count: 7, open: true },
        { label: 'Financing Activity', count: 3, open: false },
      ].map((s) => (
        <div
          key={s.label}
          className={`av-accordion__item${s.open ? ' av-accordion__item--open' : ''}`}
        >
          <button type="button" className="av-accordion__header" aria-expanded={s.open}>
            <span className="av-accordion__label">
              {s.label} <span className="av-section-header__count">{s.count}</span>
            </span>
            <span
              className={`av-accordion__chevron${s.open ? ' av-accordion__chevron--open' : ''}`}
              aria-hidden
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </span>
          </button>
          {s.open && (
            <div className="av-accordion__content av-accordion__content--flush" role="region">
              <div className="av-data-list av-data-list--compact">
                <div className="av-data-list__fields">
                  <InvoiceRow id="82000134" date="14 May 2026" amount="Ksh 1,175,000.00" />
                  <InvoiceRow id="82000129" date="14 May 2026" amount="Ksh 1,390,000.50" />
                  <div className="av-info-row av-info-row--total">
                    <span className="av-info-row__label">Total</span>
                    <div className="av-info-row__end">
                      <span className="av-info-row__value">Ksh 2,565,000.50</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  ),
};

export const CardCollapsed: Story = {
  name: 'Card variant — both collapsed',
  render: () => (
    <div className="av-accordion av-accordion--card">
      {['Associated Invoices', 'Financing Activity'].map((label, i) => (
        <div key={label} className="av-accordion__item">
          <button type="button" className="av-accordion__header" aria-expanded={false}>
            <span className="av-accordion__label">
              {label} <span className="av-section-header__count">{i === 0 ? 7 : 3}</span>
            </span>
            <span className="av-accordion__chevron" aria-hidden>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </span>
          </button>
        </div>
      ))}
    </div>
  ),
};

function InvoiceRow({ id, date, amount }: { id: string; date: string; amount: string }) {
  return (
    <div className="av-info-row">
      <span className="av-info-row__label" style={{ display: 'grid', gap: 2 }}>
        <strong style={{ color: 'var(--av-color-text-heading)' }}>{id}</strong>
        <small style={{ fontSize: 'var(--av-font-size-xs)', color: 'var(--av-color-text-muted)' }}>
          Invoiced {date}
        </small>
      </span>
      <div className="av-info-row__end">
        <span className="av-info-row__value">{amount}</span>
      </div>
    </div>
  );
}
