import { Directive, Input, TemplateRef } from '@angular/core';

/** Context injected into every avAccordionContent template. */
export interface AvAccordionContentContext {
  /** The item's `value` — available as implicit binding (`let-value`). */
  $implicit: string;
  /** Whether this item is currently open. */
  open: boolean;
}

/**
 * AvAccordionContentDirective — rich content template for AvAccordionComponent.
 *
 * `AccordionItem.content` is a plain `string`, which is fine for copy but cannot
 * hold markup. The React `<Accordion>` accepts a `ReactNode` there, so without
 * this the Angular component was the weaker of the pair and consumers had to
 * hand-roll `.av-accordion` markup to put a table or a card list inside a
 * section. Attach an `<ng-template>` per item instead.
 *
 * Follows the same pattern as `AvTableCellDirective`: match on the item key, and
 * fall back to the plain-text `content` when no template is supplied.
 *
 * @example
 * ```html
 * <av-accordion [items]="sections" [openValues]="open" (itemToggle)="open = $event">
 *   <ng-template avAccordionContent="invoices">
 *     <table class="dt-table">…</table>
 *   </ng-template>
 *
 *   <ng-template avAccordionContent="activity" let-value let-open="open">
 *     <p>Section {{ value }} is {{ open ? 'open' : 'closed' }}</p>
 *   </ng-template>
 * </av-accordion>
 * ```
 */
@Directive({
  selector: '[avAccordionContent]',
  standalone: true,
})
export class AvAccordionContentDirective {
  /** The item this template renders. Must match an `AccordionItem.value`. */
  @Input({ required: true }) avAccordionContent!: string;

  constructor(public template: TemplateRef<AvAccordionContentContext>) {}
}
