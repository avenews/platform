import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { AvInfoRowComponent } from './av-info-row.component';
import type { InfoRowVariant } from './av-info-row.component';
import type { StatusBadgeColor } from '../StatusBadge/av-status-badge.component';

export type DataListVariant = 'default' | 'compact' | 'two-column';

export interface DataField {
  key?:         string;
  label:        string;
  value?:       string;
  variant?:     InfoRowVariant;
  badgeColor?:  StatusBadgeColor;
}

/**
 * AvDataListComponent — bordered label / value panel for read-only detail.
 *
 * Mirrors the React <DataList> 1:1. Takes a `DataField[]` and renders one
 * `<av-info-row>` per field, so a detail panel is data rather than markup —
 * which is what makes it safe to gate individual rows behind a flag in the
 * calling component.
 *
 * Styled with .av-data-list from the shared stylesheet (styles-angular.css).
 * `compact` tightens row height to 40 px for dense panels (profile cards,
 * modal detail); `two-column` lays the rows out in a 2-up grid.
 *
 * Usage:
 *   <av-data-list variant="compact" [fields]="detailFields" />
 */
@Component({
  standalone: true,
  selector: 'av-data-list',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [AvInfoRowComponent],
  templateUrl: './av-data-list.component.html',
})
export class AvDataListComponent {
  @Input({ required: true }) fields: DataField[] = [];
  @Input() variant: DataListVariant = 'default';
  /** Optional heading rendered above the rows. */
  @Input() title?: string;
  @Input() loading = false;
  /** Placeholder rows rendered while loading. */
  @Input() skeletonCount = 4;

  get listClasses(): string {
    return [
      'av-data-list',
      this.variant !== 'default' ? `av-data-list--${this.variant}` : '',
    ].filter(Boolean).join(' ');
  }

  get skeletonRows(): number[] {
    return Array.from({ length: this.skeletonCount }, (_, i) => i);
  }

  trackField(index: number, field: DataField): string {
    return field.key ?? field.label ?? String(index);
  }
}
