/**
 * CSS-contract stories for AvDataListComponent and AvInfoRowComponent.
 * Renders the same `.av-data-list` / `.av-info-row` markup the Angular
 * `<av-data-list>` and `<av-info-row>` emit, via the React DataList and InfoRow
 * components (their output is identical), so the Angular surface is documented
 * alongside the web one.
 */
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { DataList } from '../../web/DataList';
import { InfoRow } from '../../web/InfoRow';

const meta: Meta = {
  title: 'Avenews/Angular/DataList',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvDataListComponent` (`<av-data-list>`) — Angular standalone bordered label / value panel ' +
          'for read-only detail. Inputs: `fields` (`DataField[]`), `variant` (`default` | `compact` | ' +
          '`two-column`), `title`, `loading`, `skeletonCount`. It renders one `<av-info-row>` per ' +
          'field, so a detail panel is data rather than markup — which is what makes it safe to gate ' +
          'individual rows behind a feature flag in the calling component. ' +
          '`AvInfoRowComponent` (`<av-info-row>`) is the row itself: inputs `label`, `value`, ' +
          '`variant` (`default` | `stacked` | `with-copy` | `with-badge`), `badgeColor`, `loading`; ' +
          'emits `(copied)`. A missing value renders an em dash rather than collapsing the row, so ' +
          'the panel keeps a stable height while data loads.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

const PERIOD_FIELDS = [
  { label: 'Supplier',             value: 'supplier 1' },
  { label: 'Due Date',             value: '15 Jun 2026' },
  { label: 'Eligible Receivables', value: 'Ksh 5,440,001' },
  { label: 'Rebate Earned',        value: 'Ksh 0' },
  { label: 'Last Upload',          value: '19 May 2026' },
  { label: 'Uploaded By',          value: 'kofi.mensah@quickmart.co.ke' },
];

export const Compact: Story = {
  name: 'Compact — modal / profile detail',
  render: () => (
    <div style={{ maxWidth: 520 }}>
      <DataList variant="compact" fields={PERIOD_FIELDS} />
    </div>
  ),
};

export const Default: Story = {
  name: 'Default',
  render: () => (
    <div style={{ maxWidth: 520 }}>
      <DataList fields={PERIOD_FIELDS.slice(0, 4)} />
    </div>
  ),
};

export const WithTitle: Story = {
  name: 'With title',
  render: () => (
    <div style={{ maxWidth: 520 }}>
      <DataList title="My Details" variant="compact" fields={[
        { label: 'Full name', value: 'Kofi Mensah' },
        { label: 'Email',     value: 'kofi.mensah@quickmart.co.ke' },
        { label: 'Phone',     value: '+254723456789' },
        { label: 'Role',      value: 'Buyer Admin' },
      ]} />
    </div>
  ),
};

export const TwoColumn: Story = {
  name: 'Two column',
  render: () => (
    <div style={{ maxWidth: 640 }}>
      <DataList variant="two-column" fields={PERIOD_FIELDS} />
    </div>
  ),
};

export const Loading: Story = {
  name: 'Loading skeleton',
  render: () => (
    <div style={{ maxWidth: 520 }}>
      <DataList fields={[]} loading skeletonCount={5} />
    </div>
  ),
};

export const MissingValues: Story = {
  name: 'Missing values render an em dash',
  render: () => (
    <div style={{ maxWidth: 520 }}>
      <DataList variant="compact" fields={[
        { label: 'Rebate Due',  value: undefined },
        { label: 'Last Upload', value: undefined },
        { label: 'Uploaded By', value: 'kofi.mensah@quickmart.co.ke' },
      ]} />
    </div>
  ),
};

export const InfoRowVariants: Story = {
  name: 'InfoRow variants',
  render: () => (
    <div style={{ maxWidth: 520, display: 'grid', gap: 16 }}>
      <div className="av-data-list">
        <div className="av-data-list__fields">
          <InfoRow label="Default" value="15 Jun 2026" />
          <InfoRow label="Stacked" value="Invoices grouped by supplier and due date" variant="stacked" />
          <InfoRow label="With badge" value="Open" variant="with-badge" badgeVariant="success" />
          <InfoRow label="With copy" value="82000134" variant="with-copy" onCopy={() => {}} />
        </div>
      </div>
    </div>
  ),
};
