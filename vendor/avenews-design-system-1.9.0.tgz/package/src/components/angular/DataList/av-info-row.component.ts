import {
  Component, Input, Output, EventEmitter, ChangeDetectionStrategy,
} from '@angular/core';
import { AvStatusBadgeComponent } from '../StatusBadge/av-status-badge.component';
import type { StatusBadgeColor } from '../StatusBadge/av-status-badge.component';

export type InfoRowVariant = 'default' | 'stacked' | 'with-copy' | 'with-badge';

/**
 * AvInfoRowComponent — one label / value row inside an `<av-data-list>`.
 *
 * Mirrors the React <InfoRow> 1:1. Usable standalone, but normally composed by
 * `<av-data-list>` from a `DataField[]`.
 *
 * Styled with .av-info-row from the shared stylesheet (styles-angular.css).
 * A missing value renders an em dash rather than collapsing the row, so a
 * detail panel keeps a stable height while data loads.
 *
 * Usage:
 *   <av-info-row label="Due Date" value="15 Jun 2026" />
 *   <av-info-row label="Status" variant="with-badge" value="Open" badgeColor="success" />
 */
@Component({
  standalone: true,
  selector: 'av-info-row',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [AvStatusBadgeComponent],
  templateUrl: './av-info-row.component.html',
})
export class AvInfoRowComponent {
  @Input({ required: true }) label!: string;
  @Input() value?: string;
  @Input() variant: InfoRowVariant = 'default';
  /** Only used when variant is 'with-badge'. */
  @Input() badgeColor: StatusBadgeColor = 'default';
  @Input() loading = false;

  @Output() copied = new EventEmitter<void>();

  get rowClasses(): string {
    return [
      'av-info-row',
      this.variant !== 'default' ? `av-info-row--${this.variant}` : '',
      this.loading ? 'av-info-row--loading' : '',
    ].filter(Boolean).join(' ');
  }

  get displayValue(): string {
    return this.value ?? '—';
  }
}
