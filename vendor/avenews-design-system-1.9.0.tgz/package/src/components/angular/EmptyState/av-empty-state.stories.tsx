/**
 * CSS-contract stories for AvEmptyStateComponent.
 * Renders the same `.avenews-empty-state` markup the Angular `<av-empty-state>`
 * emits, via the React EmptyState component (their output is identical), so the
 * Angular surface is documented alongside the web one.
 */
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { EmptyState } from '../../web/EmptyState';
import { Icon } from '../../web/Icon';

const meta: Meta = {
  title: 'Avenews/Angular/EmptyState',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvEmptyStateComponent` (`<av-empty-state>`) — Angular standalone centred icon + title + ' +
          'copy + actions for a screen or section with nothing to show. Inputs: `variant` ' +
          '(`no-content` | `no-results` | `error` | `offline`), `icon`, `title`, `description`, ' +
          '`actionLabel` / `actionVariant` / `actionHref`, and the `secondaryAction*` equivalents; ' +
          'emits `(action)` and `(secondaryAction)`. Pass `actionHref` to render the action as a ' +
          'link instead of a button — needed when the action leaves the portal, e.g. an external ' +
          'uploader. Not a loading state (use `<av-loader>`) and not a recoverable error inside a ' +
          'populated screen (use `<av-inline-banner>`).',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

export const NoContent: Story = {
  name: 'No content — first run',
  render: () => (
    <EmptyState
      variant="no-content"
      icon={<Icon name="upload" size={40} aria-hidden />}
      title="No supplier payment periods yet"
      description="Upload a supplier invoice export to get started. Avenews groups the invoices by supplier and payment due date, and the periods appear here."
      action={{ label: 'Upload Invoices', onClick: () => {} }}
    />
  ),
};

export const NoResults: Story = {
  name: 'No results — filters applied',
  render: () => (
    <EmptyState
      variant="no-results"
      title="No matching invoices"
      description="Try adjusting or resetting your filters."
      action={{ label: 'Reset filters', onClick: () => {}, variant: 'outline' }}
    />
  ),
};

export const ErrorState: Story = {
  name: 'Error',
  render: () => (
    <EmptyState
      variant="error"
      title="We couldn't load this page"
      description="Something went wrong on our side. Try again in a moment."
      action={{ label: 'Retry', onClick: () => {} }}
      secondaryAction={{ label: 'Contact support', onClick: () => {} }}
    />
  ),
};

export const Offline: Story = {
  name: 'Offline',
  render: () => (
    <EmptyState
      variant="offline"
      title="You're offline"
      description="Check your connection and try again."
      action={{ label: 'Retry', onClick: () => {} }}
    />
  ),
};
