import {
  Component, Input, Output, EventEmitter, ChangeDetectionStrategy,
} from '@angular/core';
import { AvIconComponent } from '../Icon/av-icon.component';
import { AvButtonDirective } from '../Button/av-button.directive';
import type { ButtonVariant } from '../Button/av-button.component';

export type EmptyStateVariant = 'no-content' | 'no-results' | 'error' | 'offline';

/** Default icon per variant — override with the `icon` input. */
const DEFAULT_ICONS: Record<EmptyStateVariant, string> = {
  'no-content': 'document',
  'no-results': 'search',
  'error':      'alert-circle',
  'offline':    'warning',
};

/**
 * AvEmptyStateComponent — centred icon + title + copy + actions for a screen or
 * section with nothing to show.
 *
 * Mirrors the React <EmptyState> 1:1. Use it for first-run states and
 * no-search-results states; it is deliberately not a loading state (use
 * `<av-loader>`) and not an error banner (use `<av-inline-banner>` for a
 * recoverable failure inside an otherwise populated screen).
 *
 * Styled with .avenews-empty-state from the shared stylesheet
 * (styles-angular.css). `error` and `offline` tint the icon danger-red.
 *
 * Usage:
 *   <av-empty-state
 *     variant="no-content"
 *     icon="upload"
 *     title="No supplier payment periods yet"
 *     description="Upload a supplier invoice export to get started."
 *     actionLabel="Upload Invoices"
 *     (action)="openUploader()"
 *   />
 */
@Component({
  standalone: true,
  selector: 'av-empty-state',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [AvIconComponent, AvButtonDirective],
  templateUrl: './av-empty-state.component.html',
})
export class AvEmptyStateComponent {
  @Input() variant: EmptyStateVariant = 'no-content';
  /** Icon name; falls back to the variant default. */
  @Input() icon?: string;
  @Input({ required: true }) title!: string;
  @Input() description?: string;

  @Input() actionLabel?: string;
  @Input() actionVariant: ButtonVariant = 'primary';
  /** Renders the primary action as a link instead of a button. */
  @Input() actionHref?: string;

  @Input() secondaryActionLabel?: string;
  @Input() secondaryActionVariant: ButtonVariant = 'ghost';
  @Input() secondaryActionHref?: string;

  @Output() action          = new EventEmitter<void>();
  @Output() secondaryAction = new EventEmitter<void>();

  get containerClasses(): string {
    return `avenews-empty-state avenews-empty-state--${this.variant}`;
  }

  get resolvedIcon(): string {
    return this.icon ?? DEFAULT_ICONS[this.variant];
  }

  /** Error-ish variants tint the icon red; the rest stay muted. */
  get iconColor(): string {
    return this.variant === 'error' || this.variant === 'offline'
      ? 'var(--av-color-danger)'
      : 'var(--av-color-text-muted)';
  }

  get hasActions(): boolean {
    return Boolean(this.actionLabel || this.secondaryActionLabel);
  }
}
