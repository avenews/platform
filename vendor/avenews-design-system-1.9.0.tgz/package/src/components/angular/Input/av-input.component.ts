import {
  Component, Input, Output, EventEmitter, OnInit, OnChanges,
  SimpleChanges, forwardRef, ChangeDetectionStrategy, ChangeDetectorRef, inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

export type InputType =
  | 'date' | 'datetime-local' | 'email' | 'month' | 'number'
  | 'password' | 'search' | 'tel' | 'text' | 'time' | 'url' | 'week';
export type InputLabelPlacement = 'stacked' | 'floating' | 'start' | 'fixed';

let nextId = 0;

@Component({
  standalone: true,
  selector: 'av-input',
  imports: [CommonModule, FormsModule],
  templateUrl: './av-input.component.html',
  changeDetection: ChangeDetectionStrategy.Default,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AvInputComponent),
    multi: true,
  }],
})
export class AvInputComponent implements OnInit, OnChanges, ControlValueAccessor {
  @Input() label?:                  string;
  @Input() labelPlacement: InputLabelPlacement = 'stacked';
  @Input() placeholder?:            string;
  @Input() value?:                  string;
  @Input() type: InputType          = 'text';
  @Input() required                 = false;
  @Input() disabled                 = false;
  @Input() loading                  = false;
  @Input() error?:                  string;
  @Input() success                  = false;
  @Input() helperText?:             string;
  @Input() counter                  = false;
  @Input() maxlength?:              number;
  @Input() clearInput               = false;
  @Input() multiline                = false;
  @Input() rows                     = 4;
  /**
   * Native `autocomplete` token, e.g. `email`, `tel`, `current-password`.
   *
   * Without this the component could not be used for a sign-in field at all:
   * password managers and browser autofill key off this attribute, and every
   * portal login was hand-rolling `.av-input` markup partly to keep it.
   */
  @Input() autocomplete?:           string;
  @Input() phonePrefix?:            string;
  @Input() phoneFlagEmoji           = '🇰🇪';

  @Output() valueChange = new EventEmitter<string>();
  @Output() inputBlur   = new EventEmitter<void>();
  @Output() inputFocus  = new EventEmitter<void>();

  readonly inputId:  string;
  readonly helperId: string;
  internalValue      = '';
  focused            = false;

  private onChange: (v: string) => void = () => {};
  private onTouched: () => void         = () => {};

  constructor() {
    const id = ++nextId;
    this.inputId  = `av-input-${id}`;
    this.helperId = `av-input-help-${id}`;
  }

  ngOnInit(): void {
    if (this.value !== undefined) this.internalValue = this.value;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['value'] && this.value !== undefined) {
      this.internalValue = this.value;
    }
  }

  get current(): string { return this.internalValue; }
  get isFloating(): boolean { return this.labelPlacement === 'floating'; }
  get isInline(): boolean   { return this.labelPlacement === 'start' || this.labelPlacement === 'fixed'; }
  get charCount(): number   { return this.internalValue.length; }

  get rootClasses(): string {
    return [
      'av-input',
      `av-input--${this.labelPlacement}`,
      this.error                  ? 'av-input--error'    : '',
      this.success && !this.error ? 'av-input--success'  : '',
      this.focused                ? 'av-input--focused'  : '',
      this.disabled               ? 'av-input--disabled' : '',
      this.multiline              ? 'av-input--multiline': '',
      this.phonePrefix != null    ? 'av-input--phone'    : '',
      this.isInline               ? 'av-input--inline'   : '',
    ].filter(Boolean).join(' ');
  }

  get labelClasses(): string {
    return [
      'av-input__label',
      this.isFloating ? 'av-input__label--floating' : '',
      this.isFloating && (this.focused || this.internalValue) ? 'av-input__label--lifted' : '',
    ].filter(Boolean).join(' ');
  }

  handleInput(v: string): void {
    this.internalValue = v;
    this.onChange(v);
    this.valueChange.emit(v);
  }

  handleFocus(): void { this.focused = true;  this.onTouched(); this.inputFocus.emit(); }
  handleBlur(): void  { this.focused = false; this.inputBlur.emit(); }

  clearValue(): void {
    this.internalValue = '';
    this.onChange('');
    this.valueChange.emit('');
  }

  writeValue(v: string): void                       { this.internalValue = v ?? ''; }
  registerOnChange(fn: (v: string) => void): void   { this.onChange = fn; }
  registerOnTouched(fn: () => void): void           { this.onTouched = fn; }
  setDisabledState(d: boolean): void                { this.disabled = d; }
}
