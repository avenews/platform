import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface SegmentOption {
  value:     string;
  label:     string;
  disabled?: boolean;
}

@Component({
  standalone: true,
  selector: 'av-segment',
  imports: [CommonModule],
  templateUrl: './av-segment.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AvSegmentComponent {
  @Input({ required: true }) options!: SegmentOption[];
  @Input() value = '';

  @Output() valueChange = new EventEmitter<string>();

  select(val: string): void {
    this.valueChange.emit(val);
  }
}
