import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

export type AvatarSize = 'sm' | 'md' | 'lg';

@Component({
  standalone: true,
  selector: 'av-avatar',
  templateUrl: './av-avatar.component.html',
  styleUrl: './av-avatar.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AvAvatarComponent {
  @Input({ required: true }) initials!: string;
  @Input() size: AvatarSize = 'md';

  get hostClasses(): string {
    return `avenews-avatar av-avatar--${this.size}`;
  }
}
