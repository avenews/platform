import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface TabItem {
  value:     string;
  label?:    string;
  badge?:    number;
  disabled?: boolean;
}
export type TabsVariant = 'underline' | 'pill' | 'bar';

@Component({
  standalone: true,
  selector: 'av-tabs',
  imports: [CommonModule],
  templateUrl: './av-tabs.component.html',
})
export class AvTabsComponent {
  @Input() tabs: TabItem[]          = [];
  @Input() value?:   string;
  @Input() variant: TabsVariant     = 'underline';
  @Input() stretch                  = false;

  @Output() tabChange = new EventEmitter<string>();

  get hostClasses(): string {
    return ['av-tabs', `av-tabs--${this.variant}`,
      this.stretch ? 'av-tabs--stretch' : ''].filter(Boolean).join(' ');
  }

  tabClasses(tab: TabItem): string {
    return ['av-tabs__tab',
      tab.value === this.value ? 'av-tabs__tab--active'   : '',
      tab.disabled             ? 'av-tabs__tab--disabled' : ''].filter(Boolean).join(' ');
  }

  select(tab: TabItem): void {
    if (!tab.disabled) this.tabChange.emit(tab.value);
  }
}
