import type { StatusBadgeColor } from './av-status-badge.component';

/**
 * Semantic status tokens used by Avenews portals.
 *
 * Tokens are domain-neutral (success/danger/info…) and map to the
 * DS StatusBadge color palette. Use `statusTokenToColor()` to resolve
 * a token to the correct `StatusBadgeColor` for `AvStatusBadgeComponent`.
 */
export type StatusToken =
  | 'success'   // paid, validated, good standing
  | 'danger'    // rejected, overdue, error states
  | 'info'      // submitted, pending, in-progress
  | 'warning'   // missing documents, action required
  | 'neutral'   // inactive, not eligible, cancelled
  | 'action'    // financed, active — brand teal
  | 'accent';   // partially financed, processing — orange

const TOKEN_TO_COLOR: Record<StatusToken, StatusBadgeColor> = {
  success: 'success',
  danger:  'danger',
  info:    'info',
  warning: 'warning',
  neutral: 'cancelled',
  action:  'primary',
  accent:  'processing',
};

/**
 * Resolve a domain status token to the DS `StatusBadgeColor` value.
 *
 * @example
 *   <av-status-badge [label]="status.label" [color]="statusTokenToColor(status.token)" />
 */
export function statusTokenToColor(token: StatusToken): StatusBadgeColor {
  return TOKEN_TO_COLOR[token] ?? 'default';
}
