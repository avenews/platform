import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

export type StatusBadgeColor =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger' | 'info'
  | 'live' | 'repaid' | 'processing' | 'overdue' | 'declined' | 'cancelled';
export type StatusBadgeFill = 'solid' | 'outline';

@Component({
  standalone: true,
  selector: 'av-status-badge',
  imports: [CommonModule],
  templateUrl: './av-status-badge.component.html',
})
export class AvStatusBadgeComponent {
  @Input() label                     = '';
  @Input() color: StatusBadgeColor   = 'default';
  @Input() fill: StatusBadgeFill     = 'solid';
  @Input() disabled                  = false;

  get chipClasses(): string {
    return ['av-chip', `av-chip--${this.color}`, `av-chip--${this.fill}`,
      this.disabled ? 'av-chip--disabled' : ''].filter(Boolean).join(' ');
  }
}
