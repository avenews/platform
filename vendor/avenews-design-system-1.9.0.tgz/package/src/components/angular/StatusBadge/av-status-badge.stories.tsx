/**
 * CSS contract stories for AvStatusBadgeComponent.
 * The component renders: <span class="av-chip av-chip--{color} av-chip--{fill}">label</span>
 */
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta = {
  title: 'Avenews/Angular/StatusBadge',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvStatusBadgeComponent` — Angular status badge. Renders a `<span>` using `av-chip--*` ' +
          'classes. Covers all loan/application lifecycle states used in the Affiliate Portal.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

type Color = 'default'|'primary'|'secondary'|'tertiary'|'success'|'warning'|'danger'|'info'
           | 'live'|'repaid'|'processing'|'overdue'|'declined'|'cancelled';
type Fill  = 'solid' | 'outline';

function Badge({ color, fill = 'solid', label }: { color: Color; fill?: Fill; label?: string }) {
  const cls = ['av-chip', `av-chip--${color}`, `av-chip--${fill}`].filter(Boolean).join(' ');
  return <span className={cls}>{label ?? color.charAt(0).toUpperCase() + color.slice(1)}</span>;
}

const ALL_COLORS: Color[] = [
  'default','primary','secondary','tertiary',
  'success','warning','danger','info',
  'live','repaid','processing','overdue','declined','cancelled',
];

const LOAN_STATUSES: { color: Color; label: string }[] = [
  { color: 'live',       label: 'Active'     },
  { color: 'processing', label: 'Processing' },
  { color: 'repaid',     label: 'Repaid'     },
  { color: 'overdue',    label: 'Overdue'    },
  { color: 'declined',   label: 'Declined'   },
  { color: 'cancelled',  label: 'Cancelled'  },
];

// ─── Stories ──────────────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'All colors — solid',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
      {ALL_COLORS.map(c => <Badge key={c} color={c} />)}
    </div>
  ),
};

export const AllOutline: Story = {
  name: 'All colors — outline',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
      {ALL_COLORS.map(c => <Badge key={c} color={c} fill="outline" />)}
    </div>
  ),
};

export const LoanLifecycle: Story = {
  name: 'Loan lifecycle states',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, fontFamily: 'var(--av-font-body)', fontSize: 13 }}>
      {LOAN_STATUSES.map(({ color, label }) => (
        <div key={color} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 80, color: 'var(--av-color-text-muted)' }}>{label}</div>
          <Badge color={color} label={label} />
          <Badge color={color} label={label} fill="outline" />
        </div>
      ))}
    </div>
  ),
};

export const InContext: Story = {
  name: 'In a table row',
  render: () => (
    <div className="av-table av-table--card" style={{ maxWidth: 520 }}>
      <table className="av-table__table">
        <thead className="av-table__head">
          <tr>
            <th className="av-table__th av-table__th--left">Applicant</th>
            <th className="av-table__th av-table__th--right">Amount</th>
            <th className="av-table__th av-table__th--center">Status</th>
          </tr>
        </thead>
        <tbody className="av-table__body">
          {[
            { name: 'Acme Agri Ltd',   amount: '1,200,000', color: 'live'       as Color, label: 'Active'     },
            { name: 'Savanah Feeds',   amount: '450,000',   color: 'processing' as Color, label: 'Processing' },
            { name: 'Green Valley',    amount: '2,800,000', color: 'overdue'    as Color, label: 'Overdue'    },
          ].map(row => (
            <tr key={row.name} className="av-table__row">
              <td className="av-table__td av-table__td--left">{row.name}</td>
              <td className="av-table__td av-table__td--right av-table__mono">{row.amount}</td>
              <td className="av-table__td av-table__td--center">
                <Badge color={row.color} label={row.label} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  ),
};
