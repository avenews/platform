import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

export type ProgressType  = 'determinate' | 'indeterminate' | 'buffer';
export type ProgressColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

@Component({
  standalone: true,
  selector: 'av-progress-tracker',
  imports: [CommonModule],
  templateUrl: './av-progress-tracker.component.html',
})
export class AvProgressTrackerComponent {
  /** 0–1 for determinate */
  @Input() value    = 0;
  /** 0–1 buffer fill — only for type 'buffer' */
  @Input() buffer   = 0;
  @Input() type: ProgressType   = 'determinate';
  @Input() color: ProgressColor = 'primary';
  @Input() reversed             = false;
  /** Shorthand for type='indeterminate' */
  @Input() loading              = false;
  /** Shorthand for color='danger' + value=1 */
  @Input() error                = false;

  get resolvedType(): ProgressType {
    return this.loading ? 'indeterminate' : this.type;
  }

  get resolvedColor(): ProgressColor {
    return this.error ? 'danger' : this.color;
  }

  get resolvedValue(): number {
    return this.error ? 1 : Math.min(1, Math.max(0, this.value));
  }

  get pct(): number { return Math.round(this.resolvedValue * 100); }

  get trackClasses(): string {
    return ['av-progress',
      `av-progress--${this.resolvedColor}`,
      this.resolvedType === 'indeterminate' ? 'av-progress--indeterminate' : '',
      this.resolvedType === 'buffer'        ? 'av-progress--buffer'        : '',
      this.reversed                         ? 'av-progress--reversed'      : '',
    ].filter(Boolean).join(' ');
  }

  get fillStyle(): Record<string, string> {
    return {
      transform:       `scaleX(${this.resolvedValue})`,
      transformOrigin: this.reversed ? 'right' : 'left',
    };
  }

  get bufferStyle(): Record<string, string> {
    return {
      transform:       `scaleX(${this.buffer})`,
      transformOrigin: this.reversed ? 'right' : 'left',
    };
  }

  get isDeterminate(): boolean { return this.resolvedType === 'determinate'; }
  get isBuffer(): boolean      { return this.resolvedType === 'buffer'; }
  get isIndeterminate(): boolean { return this.resolvedType === 'indeterminate'; }
}
