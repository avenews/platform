import {
  Component, Input, Output, EventEmitter,
  OnChanges, SimpleChanges, OnDestroy,
} from '@angular/core';
import { CommonModule } from '@angular/common';

export type ToastVariant  = 'neutral' | 'success' | 'warning' | 'danger' | 'info';
export type ToastPosition =
  | 'top' | 'top-start' | 'top-end'
  | 'bottom' | 'bottom-start' | 'bottom-end';

export interface ToastAction {
  label:   string;
}

@Component({
  standalone: true,
  selector: 'av-toast',
  imports: [CommonModule],
  templateUrl: './av-toast.component.html',
})
export class AvToastComponent implements OnChanges, OnDestroy {
  @Input() message                       = '';
  @Input() visible                       = false;
  @Input() variant: ToastVariant         = 'neutral';
  @Input() position: ToastPosition       = 'bottom';
  /** Auto-dismiss delay in ms. 0 = persistent. */
  @Input() duration                      = 3500;
  @Input() dismissible                   = false;
  /** Hides the default variant icon. */
  @Input() hideIcon                      = false;
  @Input() action?: ToastAction;

  @Output() dismissed  = new EventEmitter<void>();
  @Output() actionFired = new EventEmitter<void>();

  private timer: ReturnType<typeof setTimeout> | null = null;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['visible'] || changes['duration']) {
      this.clearTimer();
      if (this.visible && this.duration > 0) {
        this.timer = setTimeout(() => this.dismissed.emit(), this.duration);
      }
    }
  }

  ngOnDestroy(): void { this.clearTimer(); }

  private clearTimer(): void {
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
  }

  get toastClasses(): string {
    return ['av-toast', `av-toast--${this.variant}`].join(' ');
  }

  get viewportClasses(): string {
    return ['av-toast-viewport', `av-toast-viewport--${this.position}`].join(' ');
  }

  /** Whether the leading variant icon should render (neutral has none). */
  get showIcon(): boolean {
    return !this.hideIcon && this.variant !== 'neutral';
  }

  dismiss(): void { this.dismissed.emit(); }
  fireAction(): void { this.actionFired.emit(); }
}
