/**
 * Angular standalone components for Avenews web portals.
 *
 * Preferred import (barrel — all components + types):
 *   import { AvButtonComponent, AvIconComponent } from 'avenews-design-system/src/components/angular';
 *
 * Direct import (tree-shake a single component):
 *   import { AvButtonComponent } from 'avenews-design-system/src/components/angular/Button/av-button.component';
 *
 * Import the shared stylesheet once in angular.json:
 *   "styles": ["node_modules/avenews-design-system/src/styles-angular.css"]
 *
 * Component classes require @angular/core from the consuming project.
 * Types are plain TypeScript — safe in any environment.
 */

// ─── Component classes ────────────────────────────────────────────────────────

export { AvButtonComponent }         from './Button/av-button.component';
export { AvButtonDirective }         from './Button/av-button.directive';
export { AvInputComponent }          from './Input/av-input.component';
export { AvSelectComponent }         from './Select/av-select.component';
export { AvStatusBadgeComponent }    from './StatusBadge/av-status-badge.component';
export { AvIconComponent }           from './Icon/av-icon.component';
export { AvFilterSelectComponent }   from './FilterSelect/av-filter-select.component';
export { AvCardComponent }           from './Card/av-card.component';
export { AvAccordionComponent }      from './Accordion/av-accordion.component';
export { AvAccordionContentDirective } from './Accordion/av-accordion-content.directive';
export { AvTabsComponent }           from './Tabs/av-tabs.component';
export { AvModalComponent }          from './Modal/av-modal.component';
export { AvToastComponent }          from './Toast/av-toast.component';
export { AvProgressTrackerComponent } from './ProgressTracker/av-progress-tracker.component';
export { AvAvatarComponent }         from './Avatar/av-avatar.component';
export { AvLoaderComponent }         from './Loader/av-loader.component';
export { AvSegmentComponent }        from './Segment/av-segment.component';
export { AvInlineBannerComponent }   from './InlineBanner/av-inline-banner.component';
export { AvDataTableComponent }      from './DataTable/av-data-table.component';
export { AvTableCellDirective }      from './DataTable/av-table-cell.directive';
export { AvPaginationComponent }     from './Pagination/av-pagination.component';
export { AvSearchbarComponent }      from './Searchbar/av-searchbar.component';
export { AvTooltipComponent }        from './Tooltip/av-tooltip.component';
export { AvEmptyStateComponent }     from './EmptyState/av-empty-state.component';
export { AvInfoRowComponent }        from './DataList/av-info-row.component';
export { AvDataListComponent }       from './DataList/av-data-list.component';

// ─── Types ────────────────────────────────────────────────────────────────────

export type { ButtonVariant, ButtonSize, ButtonExpand }        from './Button/av-button.component';
export type { CardColor, CardLayout, CardAction }              from './Card/av-card.component';
export type { InputType, InputLabelPlacement }                 from './Input/av-input.component';
export type { SelectOption }                                   from './Select/av-select.component';
export type { StatusBadgeColor, StatusBadgeFill }              from './StatusBadge/av-status-badge.component';
export { statusTokenToColor, type StatusToken }                from './StatusBadge/status-token.utils';
export type { FilterSelectOption }                             from './FilterSelect/av-filter-select.component';
export type { DataTableColumn }                                from './DataTable/av-data-table.component';
export type { AvTableCellContext }                             from './DataTable/av-table-cell.directive';
export type { AccordionItem, AccordionVariant }                 from './Accordion/av-accordion.component';
export type { AvAccordionContentContext }                       from './Accordion/av-accordion-content.directive';
export type { TabItem, TabsVariant }                           from './Tabs/av-tabs.component';
export type { ModalVariant, ModalSize, ModalButton }           from './Modal/av-modal.component';
export type { ToastVariant, ToastPosition, ToastAction }       from './Toast/av-toast.component';
export type { ProgressType, ProgressColor }                    from './ProgressTracker/av-progress-tracker.component';
export type { AvatarSize }                                     from './Avatar/av-avatar.component';
export type { SegmentOption }                                  from './Segment/av-segment.component';
export type { InlineBannerVariant }                            from './InlineBanner/av-inline-banner.component';
export type { PaginationToken }                                from './Pagination/av-pagination.component';
export type { SearchbarCancelButton, SearchbarClearButton }    from './Searchbar/av-searchbar.component';
export type { EmptyStateVariant }                              from './EmptyState/av-empty-state.component';
export type { InfoRowVariant }                                 from './DataList/av-info-row.component';
export type { DataListVariant, DataField }                     from './DataList/av-data-list.component';
