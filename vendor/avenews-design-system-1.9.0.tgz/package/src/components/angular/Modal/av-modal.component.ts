import {
  Component, Input, Output, EventEmitter, HostListener,
  ElementRef, SimpleChanges, OnChanges, inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';

export type ModalVariant = 'dialog' | 'sheet';
export type ModalSize    = 'sm' | 'default' | 'lg' | 'full';

export interface ModalButton {
  text: string;
  /**
   * `confirm` is the primary action. `cancel` is an outline button that also
   * dismisses the modal. `secondary` is an outline button that does **not**
   * dismiss — use it for a second real action alongside `confirm`, where
   * `cancel`'s automatic dismissal would undo whatever the handler did (a
   * navigation, most often). `destructive` is the danger variant.
   */
  role?:     'confirm' | 'secondary' | 'cancel' | 'destructive';
  disabled?: boolean;
}

@Component({
  standalone: true,
  selector: 'av-modal',
  imports: [CommonModule],
  templateUrl: './av-modal.component.html',
})
export class AvModalComponent implements OnChanges {
  private host = inject(ElementRef<HTMLElement>);

  @Input() open                          = false;
  @Input() title?:             string;
  @Input() variant: ModalVariant         = 'dialog';
  @Input() size: ModalSize               = 'default';
  @Input() closeButton                   = false;
  @Input() showHandle                    = false;
  @Input() buttons: ModalButton[]        = [];

  @Output() dismissed   = new EventEmitter<void>();
  /** Alias for (dismissed) — used by portals that bind (closed). */
  @Output() closed      = new EventEmitter<void>();
  @Output() buttonClick = new EventEmitter<ModalButton>();

  get boxClasses(): string {
    return ['avenews-modal__box',
      `avenews-modal__box--${this.variant}`,
      `avenews-modal__box--${this.size}`,
    ].join(' ');
  }

  get hasDestructive(): boolean {
    return this.buttons.some(b => b.role === 'destructive');
  }

  buttonClasses(btn: ModalButton): string {
    const variantMap: Record<string, string> = {
      confirm:     'primary',
      secondary:   'outline',
      cancel:      'outline',
      destructive: 'danger',
    };
    return `av-btn av-btn--${variantMap[btn.role ?? 'confirm']}`;
  }

  /**
   * Start every opening at the top of the body.
   *
   * The box takes `tabindex="-1"` and receives focus on open; in `sheet` mode it
   * is taller than the viewport, so the browser scrolls the inner container to
   * reveal the focused element and the sheet lands part-way down its own content.
   * Browsers also restore a previous scroll offset on same-URL history
   * navigation. Reset on the frame after paint so both land first.
   */
  ngOnChanges(changes: SimpleChanges): void {
    const openChange = changes['open'];
    if (!openChange || !this.open) return;

    const reset = () => {
      const body = (this.host.nativeElement as HTMLElement)
        .querySelector<HTMLElement>('.avenews-modal__content');
      if (body) body.scrollTop = 0;
    };
    reset();
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(reset);
  }

  dismiss(): void {
    this.dismissed.emit();
    this.closed.emit();
  }

  handleButton(btn: ModalButton): void {
    if (!btn.disabled) {
      this.buttonClick.emit(btn);
      if (btn.role === 'cancel') this.dismiss();
    }
  }

  @HostListener('document:keydown.escape')
  onEscape(): void { if (this.open) this.dismiss(); }
}
