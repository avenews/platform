/**
 * CSS contract stories for AvFilterSelectComponent.
 * Uses av-filter-bar__* CSS classes — same as the React FilterBar component.
 */
import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta = {
  title: 'Avenews/Angular/FilterSelect',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvFilterSelectComponent` — Angular filter bar using native `<select>` elements. ' +
          'Emits `filterChange: { id, value }` per interaction; emits `clearAll` when the ' +
          'clear button is clicked. The parent owns filter state.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

// ─── Helper ───────────────────────────────────────────────────────────────────

interface Opt    { label: string; value: string; }
interface Filter { id: string; label: string; value: string; options: Opt[]; }

function FilterBar({
  filters: initial,
  clearable = true,
}: {
  filters:   Filter[];
  clearable?: boolean;
}) {
  const [filters, setFilters] = useState(initial);

  const hasActive = filters.some(f => f.value !== '' && f.value !== f.options[0]?.value);

  const onChange = (id: string, value: string) =>
    setFilters(prev => prev.map(f => f.id === id ? { ...f, value } : f));

  const onClear = () =>
    setFilters(prev => prev.map(f => ({ ...f, value: f.options[0]?.value ?? '' })));

  return (
    <div className="av-filter-bar">
      <div className="av-filter-bar__filters">
        {filters.map(f => (
          <div key={f.id} className="av-filter-bar__item">
            <label htmlFor={`filter-${f.id}`} className="av-filter-bar__label">
              {f.label}
            </label>
            <select
              id={`filter-${f.id}`}
              className="av-filter-bar__select"
              value={f.value}
              onChange={e => onChange(f.id, e.target.value)}
            >
              {f.options.map(o => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        ))}
      </div>
      {clearable && hasActive && (
        <button
          type="button"
          className="av-filter-bar__clear"
          onClick={onClear}
          aria-label="Clear all filters"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"
            strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <line x1="18" y1="6"  x2="6"  y2="18"/>
            <line x1="6"  y1="6"  x2="18" y2="18"/>
          </svg>
          Clear all
        </button>
      )}
    </div>
  );
}

// ─── Shared filter data ───────────────────────────────────────────────────────

const AFFILIATE_FILTERS: Filter[] = [
  {
    id: 'region', label: 'Region',
    value: '',
    options: [
      { value: '', label: 'All regions' },
      { value: 'nairobi',  label: 'Nairobi'  },
      { value: 'kisumu',   label: 'Kisumu'   },
      { value: 'mombasa',  label: 'Mombasa'  },
      { value: 'nakuru',   label: 'Nakuru'   },
    ],
  },
  {
    id: 'status', label: 'Status',
    value: '',
    options: [
      { value: '',           label: 'All statuses' },
      { value: 'active',     label: 'Active'       },
      { value: 'processing', label: 'Processing'   },
      { value: 'overdue',    label: 'Overdue'      },
      { value: 'repaid',     label: 'Repaid'       },
    ],
  },
  {
    id: 'agent', label: 'Agent',
    value: '',
    options: [
      { value: '',          label: 'All agents'   },
      { value: 'mary',      label: 'Mary Njeri'   },
      { value: 'david',     label: 'David Ouma'   },
      { value: 'james',     label: 'James Karimi' },
    ],
  },
];

// ─── Stories ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  render: () => <FilterBar filters={AFFILIATE_FILTERS} />,
};

export const WithActiveFilters: Story = {
  name: 'With active filters (clear visible)',
  render: () => (
    <FilterBar
      filters={AFFILIATE_FILTERS.map((f, i) => ({
        ...f,
        value: i === 0 ? 'nairobi' : i === 1 ? 'active' : f.value,
      }))}
    />
  ),
};

export const SingleFilter: Story = {
  name: 'Single filter',
  render: () => (
    <FilterBar
      filters={[{
        id: 'period', label: 'Period',
        value: '',
        options: [
          { value: '', label: 'All time' },
          { value: '7d',  label: 'Last 7 days'  },
          { value: '30d', label: 'Last 30 days' },
          { value: '90d', label: 'Last 90 days' },
        ],
      }]}
    />
  ),
};

export const AboveTable: Story = {
  name: 'Above a table',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <FilterBar filters={AFFILIATE_FILTERS} />
      <div className="av-table av-table--card">
        <table className="av-table__table">
          <thead className="av-table__head">
            <tr>
              <th className="av-table__th av-table__th--left">Business</th>
              <th className="av-table__th av-table__th--left">Region</th>
              <th className="av-table__th av-table__th--right">Amount (KES)</th>
              <th className="av-table__th av-table__th--center">Status</th>
            </tr>
          </thead>
          <tbody className="av-table__body">
            {[
              { name: 'Acme Agri Ltd',  region: 'Nairobi', amount: '1,200,000', status: 'Active',  color: 'live'       },
              { name: 'Savanah Feeds',  region: 'Kisumu',  amount: '450,000',   status: 'Overdue', color: 'overdue'    },
              { name: 'Green Valley',   region: 'Mombasa', amount: '2,800,000', status: 'Repaid',  color: 'repaid'     },
            ].map(row => (
              <tr key={row.name} className="av-table__row">
                <td className="av-table__td av-table__td--left">{row.name}</td>
                <td className="av-table__td av-table__td--left av-table__muted">{row.region}</td>
                <td className="av-table__td av-table__td--right av-table__mono">{row.amount}</td>
                <td className="av-table__td av-table__td--center">
                  <span className={`av-chip av-chip--${row.color}`}>{row.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  ),
};
