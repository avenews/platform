import {
  Component, Input, Output, EventEmitter, OnInit,
  ChangeDetectionStrategy,
} from '@angular/core';

export interface FilterSelectOption {
  value: string;
  label: string;
}

/**
 * AvFilterSelectComponent — single native-select filter.
 *
 * Renders a native <select> styled with .filter-select / .filter-select__control
 * to match the customer portal's React FilterSelect 1:1. Native select means
 * free keyboard handling, accessible dropdown on mobile, and no custom listbox
 * to maintain.
 *
 * Usage:
 *   <av-filter-select
 *     label="Status"
 *     [options]="statusOptions"
 *     [value]="activeStatus"
 *     (valueChange)="activeStatus = $event"
 *   />
 */
@Component({
  standalone: true,
  selector: 'av-filter-select',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './av-filter-select.component.html',
})
export class AvFilterSelectComponent implements OnInit {
  @Input({ required: true }) label!:   string;
  /** Fallback label shown when no option is selected. Defaults to "All {label}". */
  @Input() allLabel                   = '';
  @Input({ required: true }) options!: FilterSelectOption[];
  /** Currently selected value. Pass `null` to show the "All" option. */
  @Input() value: string | null       = null;

  @Output() valueChange = new EventEmitter<string | null>();

  ngOnInit(): void {
    if (!this.allLabel) this.allLabel = `All ${this.label.toLowerCase()}`;
  }

  onChange(event: Event): void {
    const v = (event.target as HTMLSelectElement).value;
    this.valueChange.emit(v === '' ? null : v);
  }
}
