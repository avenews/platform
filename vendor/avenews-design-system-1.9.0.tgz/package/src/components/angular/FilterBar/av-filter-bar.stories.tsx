/**
 * CSS-contract stories for the `av-filter-bar` pattern (v1.8.0).
 *
 * A class contract rather than a component: the selects, search box and count
 * inside it are whatever the consumer already uses (`<av-filter-select>`,
 * `<av-searchbar>`, plain `<select>`). The bar only owns the arrangement and
 * the mobile disclosure.
 */
import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta = {
  title: 'Avenews/Angular/FilterBar',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'The bar above a list screen: selects, a search box, a result count.\n\n' +
          'Above 768px everything sits inline. Below it the selects collapse behind a **Filters** ' +
          'disclosure, because stacking them full-width fills the entire first screen with controls ' +
          'before any data — four selects plus a search box pushed the first row of a list past ' +
          '560px on a 375px viewport.\n\n' +
          '**Search stays outside the panel.** It is the control most reached for, and unlike a ' +
          'select it shows its own state at a glance.\n\n' +
          '**The toggle carries a count.** A collapsed panel would otherwise hide an active filter, ' +
          'leaving the list looking wrong for no visible reason. Count only what the panel holds — ' +
          'including search would report a filter the button does not control.\n\n' +
          '**Markup order is desktop order** — panel, search, toggle, reset, count — and the mobile ' +
          'grid re-sequences with `order`, so one DOM serves both breakpoints.',
      },
    },
  },
};

export default meta;
type Story = StoryObj;

const Select: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <label style={{ display: 'grid', gap: 4, minWidth: 0 }}>
    <span style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.04em', color: '#6b7280' }}>
      {label}
    </span>
    <select defaultValue={value} style={{ minWidth: 200, height: 40, borderRadius: 8, border: '1px solid #d0d7df', padding: '0 10px' }}>
      <option>{value}</option>
    </select>
  </label>
);

const Search = () => (
  <input
    className="av-filter-bar__search"
    type="search"
    placeholder="Search invoice or supplier"
    style={{ height: 40, borderRadius: 8, border: '1px solid #d0d7df', padding: '0 12px', minWidth: 260 }}
  />
);

/** The full bar. `open` drives the mobile panel; on desktop the panel is always laid out inline. */
const Bar: React.FC<{ open?: boolean; active?: number }> = ({ open = false, active = 0 }) => {
  const [isOpen, setOpen] = useState(open);
  return (
    <div className="av-filter-bar">
      <div className={`av-filter-bar__panel${isOpen ? ' av-filter-bar__panel--open' : ''}`} id="demo-panel">
        <Select label="Supplier" value="All suppliers" />
        <Select label="Avenews financing" value="All financing statuses" />
        <Select label="Due date" value="All due dates" />
        <Select label="Period link" value="All supplier payment periods" />
        <div className="av-filter-bar__panel-actions">
          <button type="button" className="av-btn av-btn--secondary">Clear all</button>
          <button type="button" className="av-btn av-btn--primary" onClick={() => setOpen(false)}>Apply</button>
        </div>
      </div>

      <Search />

      <button
        type="button"
        className="av-btn av-btn--secondary av-filter-bar__toggle"
        aria-expanded={isOpen}
        aria-controls="demo-panel"
        onClick={() => setOpen(o => !o)}
      >
        Filters{active > 0 && ` (${active})`}
      </button>

      {active > 0 && (
        <button type="button" className="av-btn av-btn--secondary av-btn--sm av-filter-bar__reset">
          Reset filters
        </button>
      )}

      <span className="av-filter-bar__count">Showing 6 of 78</span>
    </div>
  );
};

export const Desktop: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Above 768px the panel is transparent — a flex row carrying the bar\'s own gap — so the ' +
          'selects sit exactly where they would as direct children. The disclosure button and the ' +
          'panel footer are `display: none`, and the bar\'s own Reset button is the clear action.',
      },
    },
  },
  render: () => <Bar active={2} />,
};

export const MobileCollapsed: Story = {
  name: 'Mobile — collapsed',
  parameters: {
    viewport: { defaultViewport: 'mobile1' },
    docs: {
      description: {
        story:
          'Search and the disclosure share the first row; the count spans beneath. This is the state ' +
          'a list screen opens in, so the first record is visible without scrolling. The `(2)` is ' +
          'what stops the collapsed panel hiding an active filter.',
      },
    },
  },
  render: () => <Bar active={2} />,
};

export const MobileExpanded: Story = {
  name: 'Mobile — expanded',
  parameters: {
    viewport: { defaultViewport: 'mobile1' },
    docs: {
      description: {
        story:
          'The panel reads as a surface that opened over the list rather than more bar. **Apply does ' +
          'not commit anything** — the controls inside filter live, as they do on desktop, and the ' +
          'button only closes the panel to reveal the results behind it. If a consumer needs Apply ' +
          'to mean what it says, that is a second copy of the filter state written on tap rather ' +
          'than on change, and it belongs in the consumer, not here.',
      },
    },
  },
  render: () => <Bar open active={2} />,
};
