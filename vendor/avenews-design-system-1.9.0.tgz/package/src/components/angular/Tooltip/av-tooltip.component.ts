import {
  Component, Input, ViewChild, ElementRef, HostListener, ChangeDetectionStrategy,
  ChangeDetectorRef, inject,
} from '@angular/core';
import { AvIconComponent } from '../Icon/av-icon.component';

/**
 * AvTooltipComponent — inline help trigger with a hover / focus / tap bubble.
 *
 * Renders the `help-circle` icon as a button. The bubble shows on hover and
 * keyboard focus (driven by CSS `:hover` / `:focus-within`, so it can never get
 * stuck open on touch) and pins open on click/tap for touch devices. Escape or a
 * tap elsewhere dismisses a pinned bubble, and only one is ever pinned at a time.
 *
 * The bubble is centred on the icon, then nudged horizontally so it never spills
 * past the viewport edge. It measures against `documentElement.clientWidth` — the
 * true layout width — rather than `window.innerWidth`, which is wrong under
 * viewport emulation and let the bubble clip on mobile.
 *
 * ## Hit area
 *
 * The icon is 14px, which with line-height renders a 17px button — far below a
 * usable touch target. The button therefore carries an invisible expanded hit
 * area via `::after` rather than a larger box: these triggers sit inline beside
 * table headers and metric labels, where a 44px element would break the
 * alignment of everything next to it.
 *
 * Styled with `.av-tooltip` from the shared stylesheet (styles-angular.css).
 *
 * Usage:
 *   <av-tooltip text="Total of every invoice you have submitted." />
 */
@Component({
  standalone: true,
  selector: 'av-tooltip',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [AvIconComponent],
  template: `
    <span
      class="av-tooltip"
      [class.av-tooltip--pinned]="pinned"
      (mouseenter)="scheduleClamp()"
    >
      <button
        type="button"
        class="av-tooltip__btn"
        [attr.aria-label]="ariaLabel || 'More information'"
        [attr.aria-expanded]="pinned"
        (click)="toggle($event)"
        (focus)="scheduleClamp()"
        (keydown.escape)="onDocumentClick()"
      >
        <av-icon name="help-circle" [size]="14" aria-hidden="true" />
      </button>
      <span #bubble class="av-tooltip__bubble" role="tooltip">{{ text }}</span>
    </span>
  `,
})
export class AvTooltipComponent {
  /** Tooltip copy. Phrase it directly to the reader. */
  @Input({ required: true }) text!: string;
  /** Accessible label for the trigger button. */
  @Input() ariaLabel = '';

  @ViewChild('bubble') private bubbleRef?: ElementRef<HTMLElement>;

  private cdr = inject(ChangeDetectorRef);

  pinned = false;

  /** Gap to keep between the bubble and the viewport edge, in px. */
  private static readonly EDGE_GAP = 8;

  /** The single tooltip currently pinned open — opening another closes it, so
   *  only one bubble is ever pinned at a time. */
  private static openTip: AvTooltipComponent | null = null;

  /** Tap/click toggles a pinned bubble — the touch-friendly affordance. */
  toggle(event: Event): void {
    event.stopPropagation();
    if (this.pinned) {
      this.unpin();
      return;
    }
    AvTooltipComponent.openTip?.unpin();
    this.pinned = true;
    AvTooltipComponent.openTip = this;
    this.scheduleClamp();
  }

  /** Close this tooltip and clear it from the shared registry. */
  private unpin(): void {
    this.pinned = false;
    if (AvTooltipComponent.openTip === this) AvTooltipComponent.openTip = null;
    this.cdr.markForCheck();
  }

  /** Any click elsewhere on the page dismisses a pinned bubble. */
  @HostListener('document:click')
  onDocumentClick(): void {
    if (this.pinned) this.unpin();
  }

  /** Re-clamp on resize so a rotated / resized viewport stays correct. */
  @HostListener('window:resize')
  onResize(): void {
    this.scheduleClamp();
  }

  /** After layout settles, nudge the bubble horizontally to stay on-screen. */
  scheduleClamp(): void {
    requestAnimationFrame(() => {
      const el = this.bubbleRef?.nativeElement;
      if (!el) return;

      // Edge-anchored bubbles opt out entirely. The stylesheet anchors a bubble
      // to its cell edge inside table columns (see `--av-tooltip-anchor` in
      // styles-angular.css) so it cannot overhang a scrolling table and inflate
      // its scrollWidth. Centring it here would undo that — and because this
      // writes an inline transform, the stylesheet could never win it back,
      // which is why consumers previously had to override with `!important`.
      const anchor = getComputedStyle(el)
        .getPropertyValue('--av-tooltip-anchor')
        .trim();
      if (anchor === 'start' || anchor === 'end') {
        el.style.transform = '';
        return;
      }

      // Reset to the centred baseline before measuring.
      el.style.transform = 'translateX(-50%)';
      const rect = el.getBoundingClientRect();
      const doc = el.ownerDocument;
      const vw = doc.documentElement.clientWidth
        || doc.defaultView?.innerWidth
        || rect.right;
      const gap = AvTooltipComponent.EDGE_GAP;
      let shift = 0;
      if (rect.right > vw - gap)      shift = vw - gap - rect.right;   // pull left
      else if (rect.left < gap)       shift = gap - rect.left;         // push right
      if (shift !== 0) el.style.transform = `translateX(calc(-50% + ${Math.round(shift)}px))`;
    });
  }
}
