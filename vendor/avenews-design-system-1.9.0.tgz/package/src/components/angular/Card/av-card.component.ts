import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

export type CardColor =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light' | 'medium' | 'dark';
export type CardLayout = 'default' | 'media' | 'list';

export interface CardAction {
  label:    string;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success' | 'warning';
  /** Passed back verbatim in the actionClick event so callers can identify which action fired */
  data?:    unknown;
}

@Component({
  standalone: true,
  selector: 'av-card',
  imports: [CommonModule],
  templateUrl: './av-card.component.html',
})
export class AvCardComponent {
  @Input() title                 = '';
  @Input() subtitle?:  string;
  @Input() body?:      string;
  @Input() color: CardColor      = 'default';
  @Input() layout: CardLayout    = 'default';
  @Input() imageUrl?:  string;
  @Input() imageAlt              = '';
  @Input() actions: CardAction[] = [];
  @Input() tappable              = false;
  @Input() disabled              = false;
  @Input() loading               = false;
  @Input() error?:     string;
  @Input() href?:      string;

  @Output() cardClick   = new EventEmitter<void>();
  @Output() actionClick = new EventEmitter<CardAction>();

  get isColored(): boolean { return this.color !== 'default'; }

  get rootClasses(): string {
    const c = ['av-card'];
    if (this.isColored) c.push(`av-card--${this.color}`);
    if (this.tappable || this.cardClick.observed) c.push('av-card--tappable');
    if (this.disabled) c.push('av-card--disabled');
    if (this.href)     c.push('av-card--link');
    return c.join(' ');
  }

  get showImage(): boolean {
    return this.layout === 'media' && !!this.imageUrl;
  }

  actionClasses(variant = 'primary'): string {
    return `av-btn av-btn--${variant} av-btn--sm`;
  }

  onClick(): void {
    if (!this.disabled) this.cardClick.emit();
  }

  onActionClick(action: CardAction): void {
    this.actionClick.emit(action);
  }
}
