import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  standalone: true,
  selector: 'av-loader',
  templateUrl: './av-loader.component.html',
  styleUrl: './av-loader.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AvLoaderComponent {
  /** Optional accessible label announced to screen readers. */
  @Input() label = '';
}
