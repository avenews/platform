import {
  Component, Input, Output, EventEmitter, HostListener,
  ElementRef, forwardRef, OnChanges, SimpleChanges, ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

export interface SelectOption {
  value:     string;
  label:     string;
  disabled?: boolean;
}

let nextId = 0;

@Component({
  standalone: true,
  selector: 'av-select',
  imports: [CommonModule],
  templateUrl: './av-select.component.html',
  changeDetection: ChangeDetectionStrategy.Default,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AvSelectComponent),
    multi: true,
  }],
})
export class AvSelectComponent implements OnChanges, ControlValueAccessor {
  @Input() label?:       string;
  @Input() placeholder   = 'Select an option';
  @Input() value?:       string;
  @Input() options: SelectOption[] = [];
  @Input() disabled      = false;
  @Input() required      = false;
  @Input() error?:       string;
  @Input() helperText?:  string;

  @Output() valueChange = new EventEmitter<string>();

  readonly selectId: string;
  readonly helperId: string;
  readonly listId:   string;

  open      = false;
  focused   = false;
  highlight = -1;

  private onChange: (v: string) => void = () => {};
  private onTouched: () => void         = () => {};

  constructor(private elRef: ElementRef) {
    const id = ++nextId;
    this.selectId = `av-select-${id}`;
    this.helperId = `av-select-help-${id}`;
    this.listId   = `av-select-list-${id}`;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['value'] && this.open) this.syncHighlight();
  }

  get selected(): SelectOption | undefined {
    return this.options.find(o => o.value === this.value);
  }

  get wrapClasses(): string {
    return ['av-select__wrap',
      this.open    ? 'av-select__wrap--open'    : '',
      this.focused ? 'av-select__wrap--focused' : '',
    ].filter(Boolean).join(' ');
  }

  get rootClasses(): string {
    return ['av-select',
      this.error    ? 'av-select--error'    : '',
      this.disabled ? 'av-select--disabled' : '',
    ].filter(Boolean).join(' ');
  }

  optionClasses(opt: SelectOption, i: number): string {
    return ['av-select__option',
      opt.value === this.value ? 'av-select__option--selected'    : '',
      i === this.highlight     ? 'av-select__option--highlighted' : '',
      opt.disabled             ? 'av-select__option--disabled'    : '',
    ].filter(Boolean).join(' ');
  }

  toggleOpen(): void {
    if (this.disabled) return;
    this.open = !this.open;
    if (this.open) this.syncHighlight();
  }

  selectOption(opt: SelectOption): void {
    if (opt.disabled) return;
    this.value = opt.value;
    this.onChange(opt.value);
    this.onTouched();
    this.valueChange.emit(opt.value);
    this.open = false;
  }

  private syncHighlight(): void {
    const idx = this.options.findIndex(o => o.value === this.value);
    this.highlight = idx >= 0 ? idx : 0;
  }

  onKeyDown(e: KeyboardEvent): void {
    if (this.disabled) return;
    switch (e.key) {
      case 'Enter': case ' ':
        e.preventDefault();
        if (!this.open) { this.open = true; this.syncHighlight(); return; }
        if (this.highlight >= 0 && !this.options[this.highlight]?.disabled) {
          this.selectOption(this.options[this.highlight]);
        }
        break;
      case 'Escape':
        this.open = false;
        break;
      case 'ArrowDown': {
        e.preventDefault();
        if (!this.open) { this.open = true; this.syncHighlight(); return; }
        const next = this.options.findIndex((o, i) => i > this.highlight && !o.disabled);
        if (next >= 0) this.highlight = next;
        break;
      }
      case 'ArrowUp': {
        e.preventDefault();
        const prev = this.options
          .map((o, i) => (!o.disabled && i < this.highlight ? i : -1))
          .filter(i => i >= 0);
        if (prev.length) this.highlight = prev[prev.length - 1];
        break;
      }
    }
  }

  @HostListener('document:mousedown', ['$event'])
  onDocClick(e: MouseEvent): void {
    if (this.open && !this.elRef.nativeElement.contains(e.target)) {
      this.open = false;
    }
  }

  writeValue(v: string): void                       { this.value = v; }
  registerOnChange(fn: (v: string) => void): void   { this.onChange = fn; }
  registerOnTouched(fn: () => void): void           { this.onTouched = fn; }
  setDisabledState(d: boolean): void                { this.disabled = d; }
}
