/**
 * CSS contract stories for AvIconComponent.
 * Uses the same SVG paths as the Angular template — rendered here via the
 * React Icon component (identical paths, identical CSS class).
 */
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Icon } from '../../web/Icon';
import type { IconName } from '../../web/Icon';

const meta: Meta = {
  title: 'Avenews/Angular/Icon',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvIconComponent` — Angular icon. Renders an inline SVG using the same ' +
          '44-icon catalog as the React `Icon` component. ' +
          'Sizes: `xs` (14px) · `sm` (16px) · `md` (20px) · `lg` (24px) · `xl` (32px). ' +
          'Color inherits `currentColor` by default; pass `color` for overrides.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

const ALL_ICONS: IconName[] = [
  'add','arrow-back','arrow-forward','attach','bar-chart',
  'calendar','call','cash','checkmark','checkmark-circle',
  'chevron-back','chevron-down','chevron-forward','chevron-up',
  'close','close-circle','create','document','document-text',
  'download','ellipsis-horizontal','ellipsis-vertical','eye','eye-off',
  'heart','help-circle','home','information-circle','list',
  'mail','menu','notifications','person','receipt','refresh',
  'remove','search','settings','share','shield-checkmark',
  'star','time','trash','upload','wallet','warning',
];

// ─── Stories ──────────────────────────────────────────────────────────────────

export const Catalog: Story = {
  name: 'All icons',
  render: () => (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(80px, 1fr))',
      gap: 12,
    }}>
      {ALL_ICONS.map(name => (
        <div key={name} style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
          padding: '12px 8px',
          borderRadius: 8,
          background: 'var(--av-color-surface)',
          border: '1px solid var(--av-color-neutral-divider)',
        }}>
          <Icon name={name} size="md" />
          <span style={{ fontSize: 10, color: 'var(--av-color-text-muted)', textAlign: 'center', lineHeight: 1.3 }}>
            {name}
          </span>
        </div>
      ))}
    </div>
  ),
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 20, flexWrap: 'wrap' }}>
      {(['xs','sm','md','lg','xl'] as const).map(size => (
        <div key={size} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <Icon name="home" size={size} />
          <span style={{ fontSize: 11, color: 'var(--av-color-text-muted)' }}>{size}</span>
        </div>
      ))}
    </div>
  ),
};

export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <Icon name="information-circle" size="lg" />
        <span style={{ fontSize: 11, color: 'var(--av-color-text-muted)' }}>currentColor</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <Icon name="information-circle" size="lg" color="var(--av-color-action)" />
        <span style={{ fontSize: 11, color: 'var(--av-color-text-muted)' }}>action</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <Icon name="warning" size="lg" color="var(--av-color-warning)" />
        <span style={{ fontSize: 11, color: 'var(--av-color-text-muted)' }}>warning</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <Icon name="checkmark-circle" size="lg" color="var(--av-color-success)" />
        <span style={{ fontSize: 11, color: 'var(--av-color-text-muted)' }}>success</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <Icon name="close-circle" size="lg" color="var(--av-color-danger)" />
        <span style={{ fontSize: 11, color: 'var(--av-color-text-muted)' }}>danger</span>
      </div>
      <div style={{ padding: 8, borderRadius: 8, background: 'var(--av-color-surface-dark)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
        <Icon name="shield-checkmark" size="lg" color="white" />
        <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)' }}>on-dark</span>
      </div>
    </div>
  ),
};

export const InlineUsage: Story = {
  name: 'Inline in UI',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, fontFamily: 'var(--av-font-body)' }}>
      <button className="av-btn av-btn--primary">
        <span className="av-btn__icon"><Icon name="cash" size="sm" /></span>
        <span className="av-btn__label">Request funds</span>
      </button>
      <button className="av-btn av-btn--outline">
        <span className="av-btn__icon"><Icon name="download" size="sm" /></span>
        <span className="av-btn__label">Export CSV</span>
      </button>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--av-color-success)', fontSize: 14 }}>
        <Icon name="checkmark-circle" size="md" color="var(--av-color-success)" />
        Repayment confirmed
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--av-color-warning)', fontSize: 14 }}>
        <Icon name="warning" size="md" color="var(--av-color-warning)" />
        Payment overdue by 3 days
      </div>
    </div>
  ),
};
