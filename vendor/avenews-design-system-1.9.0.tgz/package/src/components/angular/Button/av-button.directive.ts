import {
  Directive, Input, ElementRef, HostListener, inject,
} from '@angular/core';
import type { ButtonVariant, ButtonSize, ButtonExpand } from './av-button.component';

/**
 * AvButtonDirective — directive-based button API.
 *
 * Apply Avenews DS button styling to **native** elements:
 *
 *   <button avButton variant="primary">Submit</button>
 *   <a      avButton variant="secondary" href="/path">View my business</a>
 *
 * Why a directive (vs the `<av-button>` component)?
 *  - Preserves native semantics: a `<button>` stays a button, an `<a href>`
 *    stays a real link (right-click, middle-click, keyboard Enter, prefetch
 *    behavior, screen-reader role) without re-implementation.
 *  - Plays nicely with `routerLink`, form `type="submit"`, file <label>s,
 *    download attributes, and any other native DOM API you'd reach for.
 *  - No wrapper element, no content-projection quirks.
 *
 * The directive only owns the **styling** layer. Click/href behaviour is
 * delegated to the host element; we just guard clicks while disabled/loading.
 *
 * For an inline spinner during loading, render
 * `<span class="av-btn__spinner" aria-hidden="true"></span>` yourself inside
 * the host element. The directive sets `aria-busy="true"` and applies the
 * `av-btn--loading` class so the CSS spinner styling kicks in.
 */
@Directive({
  selector: '[avButton]',
  standalone: true,
  host: {
    '[class]':              'classes',
    '[attr.aria-busy]':     'loading ? "true" : null',
    '[attr.disabled]':      'nativeDisabled',
    '[attr.aria-disabled]': 'isAnchor && blocked ? "true" : null',
    '[attr.tabindex]':      'isAnchor && blocked ? -1 : null',
  },
})
export class AvButtonDirective {
  /** Visual variant — same values as the existing AvButtonComponent. */
  @Input() variant: ButtonVariant = 'primary';

  /** Visual size — `sm` (34px) / `md` (44px, default) / `lg` (54px). */
  @Input() size: ButtonSize = 'md';

  /** Stretch the button: `block` = full width, `full` = full width + square corners. */
  @Input() expand?: ButtonExpand;

  /** Disabled state. On `<button>` this sets the native attribute;
   *  on `<a>` it applies `aria-disabled`, removes from tab order, and the
   *  `av-btn--disabled` class disables pointer events via CSS. */
  @Input()
  set disabled(value: boolean | '' | null | undefined) {
    this._disabled = value === '' ? true : Boolean(value);
  }
  get disabled(): boolean { return this._disabled; }
  private _disabled = false;

  /** Loading state. Applies `av-btn--loading` and `aria-busy="true"`. Treated
   *  as disabled for interaction purposes. */
  @Input()
  set loading(value: boolean | '' | null | undefined) {
    this._loading = value === '' ? true : Boolean(value);
  }
  get loading(): boolean { return this._loading; }
  private _loading = false;

  private readonly el = inject<ElementRef<HTMLElement>>(ElementRef);

  /** Is the host element an `<a>`? */
  get isAnchor(): boolean {
    return this.el.nativeElement.tagName.toLowerCase() === 'a';
  }

  /** Disabled OR loading — both block interaction. */
  get blocked(): boolean { return this._disabled || this._loading; }

  /** Native `disabled` attribute value (buttons only — anchors ignore it). */
  get nativeDisabled(): true | null {
    return !this.isAnchor && this.blocked ? true : null;
  }

  /** Computed class string applied via [class] host binding. */
  get classes(): string {
    return [
      'av-btn',
      `av-btn--${this.variant}`,
      this.size !== 'md' ? `av-btn--${this.size}` : '',
      this.expand        ? `av-btn--${this.expand}` : '',
      this._loading      ? 'av-btn--loading' : '',
      // Anchors don't honour [disabled]; surface a class so CSS can disable
      // pointer-events / opacity exactly like native `:disabled`.
      this.isAnchor && this.blocked ? 'av-btn--disabled' : '',
    ].filter(Boolean).join(' ');
  }

  /** Belt-and-braces: swallow clicks while disabled/loading. Native button
   *  `disabled` handles this for buttons; for anchors with `aria-disabled`
   *  we have to prevent default so the link doesn't navigate. */
  @HostListener('click', ['$event'])
  onClick(event: Event): void {
    if (this.blocked) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }
}
