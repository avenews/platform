import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

export type ButtonVariant =
  | 'primary' | 'secondary' | 'outline' | 'ghost'
  | 'danger'  | 'success'   | 'warning'
  | 'inverted'| 'inverted-outline';
export type ButtonSize   = 'sm' | 'md' | 'lg';
export type ButtonExpand = 'block' | 'full';

@Component({
  standalone: true,
  selector:   'av-button',
  imports:    [CommonModule],
  templateUrl: './av-button.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AvButtonComponent {
  @Input() variant:  ButtonVariant                    = 'primary';
  @Input() size:     ButtonSize                       = 'md';
  @Input() expand?:  ButtonExpand;
  @Input() disabled                                   = false;
  @Input() loading                                    = false;
  @Input() type:     'button' | 'submit' | 'reset'   = 'button';
  @Input() href?:    string;
  @Input() target?:  string;
  @Input() rel?:     string;
  @Input() ariaLabel?: string;

  @Output() clicked = new EventEmitter<void>();

  get classes(): string {
    return [
      'av-btn',
      `av-btn--${this.variant}`,
      this.size !== 'md'         ? `av-btn--${this.size}`   : '',
      this.expand                ? `av-btn--${this.expand}` : '',
      this.loading               ? 'av-btn--loading'         : '',
    ].filter(Boolean).join(' ');
  }

  handleClick(): void {
    if (this.disabled || this.loading) return;
    if (this.href) {
      const target = this.target ?? '_self';
      if (target === '_blank') {
        // Always include noopener for _blank; merge any caller-supplied rel values
        const rel = this.rel ? `${this.rel} noopener` : 'noopener noreferrer';
        window.open(this.href, '_blank', rel);
      } else {
        window.location.href = this.href;
      }
      return;
    }
    this.clicked.emit();
  }
}
