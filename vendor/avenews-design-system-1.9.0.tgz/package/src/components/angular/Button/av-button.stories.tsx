/**
 * CSS contract stories for AvButtonComponent.
 * The Angular component renders these exact class combinations via buttonClasses().
 */
import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta = {
  title: 'Avenews/Angular/Button',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvButtonComponent` — Angular standalone button. ' +
          'All visual states are driven by `av-btn--*` CSS classes; ' +
          'no inline styles. Icon content is projected via `<ng-content select="[slot=icon]">`.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function Btn({
  variant = 'primary',
  size,
  expand,
  loading = false,
  disabled = false,
  iconSlot,
  label = 'Continue',
}: {
  variant?:  string;
  size?:     string;
  expand?:   string;
  loading?:  boolean;
  disabled?: boolean;
  iconSlot?: 'start' | 'end' | 'icon-only';
  label?:    string;
}) {
  const cls = [
    'av-btn',
    `av-btn--${variant}`,
    size   ? `av-btn--${size}`   : '',
    expand ? `av-btn--${expand}` : '',
    loading            ? 'av-btn--loading'   : '',
    iconSlot === 'icon-only' ? 'av-btn--icon-only' : '',
  ].filter(Boolean).join(' ');

  const chevron = (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="9 18 15 12 9 6"/>
    </svg>
  );

  return (
    <button type="button" className={cls} disabled={disabled || loading}>
      {loading ? (
        <span className="av-btn__spinner" aria-hidden="true" />
      ) : (
        <>
          {iconSlot === 'start'     && <span className="av-btn__icon">{chevron}</span>}
          {iconSlot !== 'icon-only' && <span className="av-btn__label">{label}</span>}
          {iconSlot === 'end'       && <span className="av-btn__icon">{chevron}</span>}
          {iconSlot === 'icon-only' && chevron}
        </>
      )}
    </button>
  );
}

// ─── Stories ──────────────────────────────────────────────────────────────────

export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
      {(['primary','secondary','outline','ghost','danger','success','warning','inverted','inverted-outline'] as const).map(v => (
        <Btn key={v} variant={v} label={v.charAt(0).toUpperCase() + v.slice(1)} />
      ))}
    </div>
  ),
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
      <Btn size="sm"  label="Small" />
      <Btn            label="Default (md)" />
      <Btn size="lg"  label="Large" />
    </div>
  ),
};

export const States: Story = {
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
      <Btn label="Default" />
      <Btn label="Loading" loading />
      <Btn label="Disabled" disabled />
      <Btn variant="outline" label="Outline disabled" disabled />
    </div>
  ),
};

export const WithIcons: Story = {
  name: 'With icons',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
      <Btn iconSlot="start" label="Next step" />
      <Btn iconSlot="end"   label="Continue" />
      <Btn iconSlot="icon-only" variant="outline" label="Icon only" />
    </div>
  ),
};

export const Expand: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 400 }}>
      <Btn expand="block" label="Block (parent width)" />
      <Btn expand="full"  label="Full (viewport width)" />
    </div>
  ),
};

export const AllVariantsGrid: Story = {
  name: 'All variants × sizes',
  render: () => (
    <table style={{ borderCollapse: 'collapse', fontSize: 13, fontFamily: 'var(--av-font-body)' }}>
      <thead>
        <tr>
          {['', 'sm', 'md', 'lg', 'loading', 'disabled'].map(h => (
            <th key={h} style={{ padding: '6px 12px', textAlign: 'left', color: 'var(--av-color-text-muted)', fontWeight: 600 }}>{h}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {(['primary','secondary','outline','ghost','danger','success','warning'] as const).map(v => (
          <tr key={v}>
            <td style={{ padding: '8px 12px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-mono)', fontSize: 11 }}>{v}</td>
            <td style={{ padding: '8px 12px' }}><Btn variant={v} size="sm"  label={v} /></td>
            <td style={{ padding: '8px 12px' }}><Btn variant={v}            label={v} /></td>
            <td style={{ padding: '8px 12px' }}><Btn variant={v} size="lg"  label={v} /></td>
            <td style={{ padding: '8px 12px' }}><Btn variant={v} loading    label={v} /></td>
            <td style={{ padding: '8px 12px' }}><Btn variant={v} disabled   label={v} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  ),
};
