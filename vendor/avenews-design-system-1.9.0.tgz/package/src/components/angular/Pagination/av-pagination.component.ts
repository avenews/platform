import {
  Component, Input, Output, EventEmitter,
  ChangeDetectionStrategy,
} from '@angular/core';

/** A page token in the control: a 1-based page number, or a collapsed gap (…). */
export type PaginationToken = number | 'gap';

/**
 * AvPaginationComponent — footer pagination for data tables and card lists.
 *
 * Mirrors the React <Pagination> 1:1 so both web portals read identically.
 * Pagination is client-side: the parent owns the page index and slices its own
 * list; this component renders the summary line + page controls and emits the
 * requested page through `pageChange`. Renders nothing when everything fits on
 * a single page.
 *
 * Styled with .dt-pagination from the shared stylesheet (styles-angular.css) so
 * it sits cleanly beneath the .dt-table / .dt-wrapper table family.
 *
 * Usage:
 *   <av-pagination
 *     [page]="page"
 *     [pageSize]="pageSize"
 *     [total]="filtered.length"
 *     itemLabel="invoices"
 *     (pageChange)="page = $event"
 *   />
 */
@Component({
  standalone: true,
  selector: 'av-pagination',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './av-pagination.component.html',
})
export class AvPaginationComponent {
  /** 1-based current page. */
  @Input({ required: true }) page = 1;
  @Input() pageSize = 10;
  /** Total number of items across all pages. */
  @Input({ required: true }) total = 0;
  /** Plural noun for the summary line, e.g. "invoices". */
  @Input() itemLabel = 'items';

  @Output() pageChange = new EventEmitter<number>();

  get pageCount(): number {
    return Math.max(1, Math.ceil(this.total / this.pageSize));
  }

  get current(): number {
    return Math.min(Math.max(1, this.page), this.pageCount);
  }

  get firstItem(): number {
    return (this.current - 1) * this.pageSize + 1;
  }

  get lastItem(): number {
    return Math.min(this.current * this.pageSize, this.total);
  }

  /** Page tokens to render, collapsing long ranges with 'gap' (rendered as …). */
  get tokens(): PaginationToken[] {
    const count = this.pageCount;
    const current = this.current;
    if (count <= 7) {
      return Array.from({ length: count }, (_, i) => i + 1);
    }
    const tokens: PaginationToken[] = [1];
    const start = Math.max(2, current - 1);
    const end = Math.min(count - 1, current + 1);
    if (start > 2) tokens.push('gap');
    for (let p = start; p <= end; p++) tokens.push(p);
    if (end < count - 1) tokens.push('gap');
    tokens.push(count);
    return tokens;
  }

  isGap(token: PaginationToken): token is 'gap' {
    return token === 'gap';
  }

  go(p: number): void {
    const next = Math.min(Math.max(1, p), this.pageCount);
    if (next !== this.current) this.pageChange.emit(next);
  }
}
