/**
 * CSS-contract stories for AvPaginationComponent.
 * Renders the same `.dt-pagination` markup the Angular `<av-pagination>` emits,
 * via the React Pagination component (their output is identical), so the
 * Angular surface is documented alongside the web one.
 */
import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Pagination } from '../../web/Pagination';

const meta: Meta = {
  title: 'Avenews/Angular/Pagination',
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          '`AvPaginationComponent` (`<av-pagination>`) — Angular standalone footer pagination for ' +
          'the `.dt-table` data-table family. Inputs: `page`, `pageSize`, `total`, `itemLabel`; ' +
          'emits the requested page via `(pageChange)`. Client-side: the parent owns the page index ' +
          'and slices its own list. Renders nothing when everything fits on one page. The markup and ' +
          '`.dt-pagination` styling are identical to the web `<Pagination>` shown here.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

function Interactive({
  pageSize = 10,
  total,
  itemLabel,
}: {
  pageSize?: number;
  total: number;
  itemLabel?: string;
}) {
  const [page, setPage] = useState(1);
  return (
    <Pagination
      page={page}
      pageSize={pageSize}
      total={total}
      itemLabel={itemLabel}
      onPageChange={setPage}
    />
  );
}

export const Default: Story = {
  name: 'Default — 12 items',
  render: () => <Interactive total={12} itemLabel="invoices" />,
};

export const ManyPages: Story = {
  name: 'Many pages — ellipsis windowing',
  render: () => <Interactive total={240} itemLabel="records" />,
};

export const MobileTouchTargets: Story = {
  name: 'Mobile — 44px touch targets',
  parameters: { viewport: { defaultViewport: 'mobileM' } },
  render: () => <Interactive total={120} itemLabel="invoices" />,
};
