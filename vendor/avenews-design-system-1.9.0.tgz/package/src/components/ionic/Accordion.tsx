import React from 'react';
import {
  IonAccordion,
  IonAccordionGroup,
  IonIcon,
  IonItem,
  IonLabel,
} from '@ionic/react';
import { chevronDownOutline } from 'ionicons/icons';

export interface AccordionItem {
  value: string;
  label: string;
  content: React.ReactNode;
  disabled?: boolean;
  leftArrow?: boolean;
}

export interface AccordionProps {
  items: AccordionItem[];
  multiple?: boolean;
  value?: string | string[];
  onIonChange?: (value: string | string[] | undefined) => void;
  className?: string;
}

export const Accordion: React.FC<AccordionProps> = ({
  items,
  multiple = false,
  value,
  onIonChange,
  className,
}) => (
  <IonAccordionGroup
    className={['avenews-accordion', className].filter(Boolean).join(' ')}
    multiple={multiple}
    value={value}
    onIonChange={(e) => onIonChange?.(e.detail.value)}
    animated
  >
    {items.map((item) => (
      <IonAccordion key={item.value} value={item.value} disabled={item.disabled}>
        <IonItem slot="header" lines="none" className="avenews-accordion__header">
          {item.leftArrow && <IonIcon slot="start" icon={chevronDownOutline} className="avenews-accordion__chevron" />}
          <IonLabel>{item.label}</IonLabel>
          {!item.leftArrow && <IonIcon slot="end" icon={chevronDownOutline} className="avenews-accordion__chevron" />}
        </IonItem>
        <div slot="content" className="avenews-accordion__content">{item.content}</div>
      </IonAccordion>
    ))}
  </IonAccordionGroup>
);

export default Accordion;
