import React from 'react';
import { IonDatetime } from '@ionic/react';

export type DatetimeColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

export type DatetimePresentation =
  | 'date' | 'date-time' | 'time' | 'time-date'
  | 'month-year' | 'month' | 'year';

export interface DatetimeProps {
  color?: DatetimeColor;
  value?: string;
  min?: string;
  max?: string;
  presentation?: DatetimePresentation;
  isDateEnabled?: (isoString: string) => boolean;
  showDefaultButtons?: boolean;
  showDefaultTitle?: boolean;
  locale?: string;
  onIonChange?: (value: string) => void;
  className?: string;
}

export const Datetime: React.FC<DatetimeProps> = ({
  color               = 'primary',
  value,
  min,
  max,
  presentation        = 'date-time',
  isDateEnabled,
  showDefaultButtons  = false,
  showDefaultTitle    = false,
  locale              = 'en-US',
  onIonChange,
  className,
}) => {
  const handleChange = (e: CustomEvent) => {
    const raw = e.detail.value;
    const resolved = Array.isArray(raw) ? raw[0] : raw;
    if (resolved) onIonChange?.(resolved);
  };

  return (
    <IonDatetime
      color={color}
      value={value}
      min={min}
      max={max}
      presentation={presentation}
      isDateEnabled={isDateEnabled}
      showDefaultButtons={showDefaultButtons}
      showDefaultTitle={showDefaultTitle}
      locale={locale}
      onIonChange={handleChange}
      className={['avenews-datetime', `avenews-datetime--${color}`, className].filter(Boolean).join(' ')}
    />
  );
};

export default Datetime;
