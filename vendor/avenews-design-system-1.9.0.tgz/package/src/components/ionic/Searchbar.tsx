import React from 'react';
import { IonSearchbar, IonSkeletonText } from '@ionic/react';

export type SearchbarCancelButton = 'never' | 'focus' | 'always';
export type SearchbarClearButton  = 'never' | 'focus' | 'always';

export interface SearchbarProps {
  placeholder?: string;
  value?: string;
  debounce?: number;
  showCancelButton?: SearchbarCancelButton;
  showClearButton?: SearchbarClearButton;
  disabled?: boolean;
  loading?: boolean;
  error?: boolean;
  autoFocus?: boolean;
  onIonInput?: (value: string) => void;
  onIonClear?: () => void;
  onIonCancel?: () => void;
  className?: string;
}

export const Searchbar: React.FC<SearchbarProps> = ({
  placeholder      = 'Search',
  value,
  debounce         = 300,
  showCancelButton = 'focus',
  showClearButton  = 'focus',
  disabled         = false,
  loading          = false,
  error            = false,
  autoFocus        = false,
  onIonInput,
  onIonClear,
  onIonCancel,
  className,
}) => {
  if (loading) {
    return <IonSkeletonText animated style={{ height: '36px', borderRadius: '20px', margin: '8px 16px' }} />;
  }
  return (
    <IonSearchbar
      placeholder={placeholder}
      value={value}
      debounce={debounce}
      showCancelButton={showCancelButton}
      showClearButton={showClearButton}
      disabled={disabled || error}
      autoFocus={autoFocus}
      color={error ? 'danger' : undefined}
      className={`avenews-searchbar${className ? ` ${className}` : ''}`}
      onIonInput={(e) => onIonInput?.(e.detail.value ?? '')}
      onIonClear={() => onIonClear?.()}
      onIonCancel={() => onIonCancel?.()}
    />
  );
};

export default Searchbar;
