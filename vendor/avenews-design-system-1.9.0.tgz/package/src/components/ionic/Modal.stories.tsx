import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Modal } from './Modal';
import { Button } from './Button';
import { Input } from './Input';
import { Segment } from './Segment';
import { InlineBanner } from './InlineBanner';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Modal> = {
  title: 'Avenews/Ionic/Modal',
  component: Modal,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Overlay modal with two layout variants:',
          '**Dialog** — centered card with configurable width (sm 320 px / default 480 px / lg 600 px / full).',
          '**Sheet** — bottom sheet anchored to the viewport floor with optional drag handle.',
          'Supports an optional header (title + × close button), a scrollable body slot, and a footer that',
          'accepts either a `footer` render-prop or a convenience `buttons` array.',
          'Traps focus while open and closes on Escape.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
};

export default meta;
type Story = StoryObj<typeof Modal>;

// ─── Helpers ──────────────────────────────────────────────────────────────────

// ─── Static box helper (for visual showcase — no backdrop/overlay) ────────────

/**
 * Renders just the modal box in normal document flow, with no backdrop or
 * fixed positioning. Used only in the AllVariants showcase story.
 */
const ModalBox: React.FC<{
  title?: string;
  leftAction?: string;  // just the text label for showcase
  closeButton?: boolean;
  showHandle?: boolean;
  variant?: 'dialog' | 'sheet';
  size?: 'sm' | 'default' | 'lg' | 'full';
  label?: string;
  buttons?: Array<{ text: string; role?: 'confirm' | 'cancel' | 'destructive' }>;
  children?: React.ReactNode;
}> = ({
  title,
  leftAction,
  closeButton = false,
  showHandle = false,
  variant = 'dialog',
  size = 'default',
  label,
  buttons = [],
  children,
}) => {
  const boxClass = [
    'avenews-modal__box',
    `avenews-modal__box--${variant}`,
    `avenews-modal__box--${size}`,
  ].join(' ');

  const hasDestructive = buttons.some((b) => b.role === 'destructive');
  const footerClass = [
    'avenews-modal__footer',
    hasDestructive ? 'avenews-modal__footer--stacked' : '',
  ].filter(Boolean).join(' ');

  const showHeader = Boolean(title) || Boolean(leftAction) || closeButton;
  const centredTitle = Boolean(leftAction);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
      {label && (
        <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '11px', fontWeight: 600, color: '#93a1b0', letterSpacing: '0.05em', textTransform: 'uppercase', margin: 0 }}>
          {label}
        </p>
      )}
      {/* Inline box — override position so it sits in normal document flow */}
      <div className={boxClass} style={{ position: 'relative', maxWidth: size === 'full' ? '100%' : undefined }}>
        {showHandle && <div className="avenews-modal__handle" aria-hidden="true" />}
        {showHeader && (
          <div className={['avenews-modal__header', centredTitle ? 'avenews-modal__header--toolbar' : ''].filter(Boolean).join(' ')}>
            {leftAction && (
              <button type="button" className="avenews-modal__toolbar-action avenews-modal__toolbar-action--left">
                {leftAction}
              </button>
            )}
            {title && (
              <h2 className={['avenews-modal__title', centredTitle ? 'avenews-modal__title--centred' : ''].filter(Boolean).join(' ')} style={{ margin: 0 }}>
                {title}
              </h2>
            )}
            {closeButton && (
              <button type="button" className="avenews-modal__close" aria-label="Close">
                <span style={{ fontSize: '18px', lineHeight: 1 }}>✕</span>
              </button>
            )}
          </div>
        )}
        {children && <div className="avenews-modal__body">{children}</div>}
        {buttons.length > 0 && (
          <div className={footerClass}>
            {buttons.map((btn, i) => {
              const role = btn.role ?? 'confirm';
              return (
                <button key={i} type="button" className={[
                  'avenews-modal__btn',
                  role === 'confirm'     ? 'avenews-modal__btn--confirm'     : '',
                  role === 'cancel'      ? 'avenews-modal__btn--cancel'      : '',
                  role === 'destructive' ? 'avenews-modal__btn--destructive' : '',
                ].filter(Boolean).join(' ')}>
                  {btn.text}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Body text helper ─────────────────────────────────────────────────────────

const Body: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0, lineHeight: 1.5 }}>
    {children}
  </p>
);

// ─── All Variants (visual showcase) ──────────────────────────────────────────

export const AllVariants: Story = {
  name: 'All Variants',
  parameters: { layout: 'padded' },
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '48px', padding: '24px', fontFamily: 'Poppins, sans-serif', maxWidth: '900px' }}>

      {/* ── Section: Figma types — toolbar header (leftAction pattern) ────── */}
      <section>
        <h3 style={{ fontFamily: 'Poppins, sans-serif', fontSize: '13px', fontWeight: 700, color: '#0d343f', letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 4px' }}>
          Figma · Toolbar header (leftAction pattern)
        </h3>
        <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '12px', color: '#93a1b0', margin: '0 0 16px' }}>
          Default / Card / Sheet / Avenews Navigation — Cancel text left, title centred
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <ModalBox label="Default (full-height panel)" size="full" title="Text" leftAction="Cancel">
            <Body>Full-height panel — used for page-level navigation overlays. Content fills the height.</Body>
          </ModalBox>
          <ModalBox label="Sheet (bottom sheet + handle)" variant="sheet" size="default" title="Text" leftAction="Cancel" showHandle
            buttons={[{ text: 'Done', role: 'confirm' }]}>
            <Body>Bottom sheet with drag handle — slides up from the floor of the screen.</Body>
          </ModalBox>
        </div>
      </section>

      {/* ── Section: Figma types — close icon header ──────────────────────── */}
      <section>
        <h3 style={{ fontFamily: 'Poppins, sans-serif', fontSize: '13px', fontWeight: 700, color: '#0d343f', letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 4px' }}>
          Figma · Close icon header (closeButton pattern)
        </h3>
        <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '12px', color: '#93a1b0', margin: '0 0 16px' }}>
          Navigation More / Filter & Sort — title left, × close icon right
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <ModalBox label="Navigation More" variant="sheet" title="Text" closeButton showHandle>
            <Body>Short list of navigation items with chevron arrows. Title left, × right.</Body>
          </ModalBox>
          <ModalBox label="Filter & Sort" variant="sheet" title="Filter" closeButton showHandle
            buttons={[{ text: 'Apply', role: 'confirm' }]}>
            <Body>Radio list of filter options with an Apply button at the bottom.</Body>
          </ModalBox>
        </div>
      </section>

      {/* ── Section: Dialog sizes ──────────────────────────────────────────── */}
      <section>
        <h3 style={{ fontFamily: 'Poppins, sans-serif', fontSize: '13px', fontWeight: 700, color: '#0d343f', letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 16px' }}>
          Dialog · Sizes
        </h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <ModalBox label="sm — 320 px" size="sm" title="Small dialog" leftAction="Cancel"
            buttons={[{ text: 'OK', role: 'confirm' }]}>
            <Body>Compact 320 px dialog, ideal for simple yes/no prompts.</Body>
          </ModalBox>
          <ModalBox label="default — 480 px" size="default" title="Default dialog" leftAction="Cancel"
            buttons={[{ text: 'Confirm', role: 'confirm' }]}>
            <Body>The standard 480 px dialog — used for confirmations and form overlays.</Body>
          </ModalBox>
          <ModalBox label="lg — 600 px" size="lg" title="Large dialog" closeButton
            buttons={[{ text: 'Close', role: 'cancel' }]}>
            <Body>Wide 600 px dialog for richer content — tables, multi-column layouts, detail views.</Body>
          </ModalBox>
        </div>
      </section>

      {/* ── Section: Footer button roles ──────────────────────────────────── */}
      <section>
        <h3 style={{ fontFamily: 'Poppins, sans-serif', fontSize: '13px', fontWeight: 700, color: '#0d343f', letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 16px' }}>
          Footer · Button roles
        </h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <ModalBox label="Confirm only (full width)" title="Loan approved" leftAction="Cancel"
            buttons={[{ text: 'Got it', role: 'confirm' }]}>
            <Body>Single confirm button — spans full footer width.</Body>
          </ModalBox>
          <ModalBox label="Cancel + Confirm (inline)" title="Save changes" leftAction="Cancel"
            buttons={[{ text: 'Confirm', role: 'confirm' }]}>
            <Body>Left Cancel text action + right confirm footer. Standard two-action pattern.</Body>
          </ModalBox>
          <ModalBox label="Destructive + Cancel (stacked)" title="Delete account" leftAction="Cancel"
            buttons={[{ text: 'Delete account', role: 'destructive' }]}>
            <Body>Destructive action stacks full-width. Footer cancel provided via leftAction.</Body>
          </ModalBox>
        </div>
      </section>

      {/* ── Section: Sheet variants ───────────────────────────────────────── */}
      <section>
        <h3 style={{ fontFamily: 'Poppins, sans-serif', fontSize: '13px', fontWeight: 700, color: '#0d343f', letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 16px' }}>
          Sheet · Variants
        </h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <ModalBox label="Sheet — leftAction + handle (Figma Default)" variant="sheet" title="Text" leftAction="Cancel" showHandle
            buttons={[{ text: 'Confirm', role: 'confirm' }]}>
            <Body>Figma-exact sheet: drag handle, CANCEL left, centred title.</Body>
          </ModalBox>
          <ModalBox label="Sheet — closeButton + handle (Figma Navigation More)" variant="sheet" title="Options" closeButton showHandle>
            <Body>Close icon right, title left — used for navigation and filter sheets.</Body>
          </ModalBox>
          <ModalBox label="Sheet — handle only (no header)" variant="sheet" showHandle
            buttons={[{ text: 'Cancel', role: 'cancel' }, { text: 'Apply', role: 'confirm' }]}>
            <Body>Headerless sheet — context is clear from preceding content.</Body>
          </ModalBox>
        </div>
      </section>

    </div>
  ),
};

// ─── Controlled wrapper so Storybook stories stay interactive ────────────────

/** Controlled wrapper so Storybook stories stay interactive */
const Trigger: React.FC<{
  label?: string;
  children: (props: { open: boolean; onDismiss: () => void }) => React.ReactNode;
}> = ({ label = 'Open modal', children }) => {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button label={label} onClick={() => setOpen(true)} />
      {children({ open, onDismiss: () => setOpen(false) })}
    </>
  );
};

// ─── Dialog — default ─────────────────────────────────────────────────────────

export const DialogDefault: Story = {
  name: 'Dialog / Default',
  render: () => (
    <Trigger>
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Confirm action"
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[
            { text: 'Confirm', role: 'confirm', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            Are you sure you want to proceed? This action will be saved to your account.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── Dialog — sizes ───────────────────────────────────────────────────────────

export const DialogSmall: Story = {
  name: 'Dialog / Small (320 px)',
  render: () => (
    <Trigger label="Open sm">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Small dialog"
          size="sm"
          closeButton
          onDismiss={onDismiss}
          buttons={[
            { text: 'Cancel',  role: 'cancel',  handler: onDismiss },
            { text: 'OK',      role: 'confirm', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            Compact 320 px dialog, ideal for simple yes/no prompts.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const DialogLarge: Story = {
  name: 'Dialog / Large (600 px)',
  render: () => (
    <Trigger label="Open lg">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Large dialog"
          size="lg"
          closeButton
          onDismiss={onDismiss}
          buttons={[
            { text: 'Close', role: 'cancel', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            Wide 600 px dialog for richer content — tables, multi-column layouts, detail views.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const DialogFull: Story = {
  name: 'Dialog / Fullscreen',
  render: () => (
    <Trigger label="Open fullscreen">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Full-screen modal"
          size="full"
          closeButton
          onDismiss={onDismiss}
          buttons={[
            { text: 'Close', role: 'cancel', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            Full-screen variant — covers the entire viewport. Use for immersive flows (e.g. onboarding, document preview).
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── Dialog — button variants ─────────────────────────────────────────────────

export const DialogDestructive: Story = {
  name: 'Dialog / Destructive action',
  render: () => (
    <Trigger label="Delete account">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Delete account"
          closeButton
          onDismiss={onDismiss}
          buttons={[
            { text: 'Delete account', role: 'destructive', handler: onDismiss },
            { text: 'Cancel',         role: 'cancel',      handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            This will permanently delete your account and all associated data. This action cannot be undone.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const DialogNoHeader: Story = {
  name: 'Dialog / No header',
  render: () => (
    <Trigger>
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          onDismiss={onDismiss}
          buttons={[
            { text: 'Cancel',  role: 'cancel',  handler: onDismiss },
            { text: 'Proceed', role: 'confirm', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            A minimal dialog with no header — just body text and footer buttons.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const DialogNoFooter: Story = {
  name: 'Dialog / No footer',
  render: () => (
    <Trigger>
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Information"
          closeButton
          onDismiss={onDismiss}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            An informational dialog that is dismissed only via the × button. No footer actions.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── Sheet variants ───────────────────────────────────────────────────────────

export const SheetDefault: Story = {
  name: 'Sheet / Default',
  render: () => (
    <Trigger label="Open sheet">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          variant="sheet"
          title="Sheet modal"
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[
            { text: 'Confirm', role: 'confirm', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            Slides up from the bottom edge of the screen. Height is content-driven — no set breakpoints.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const SheetWithHandle: Story = {
  name: 'Sheet / With drag handle',
  render: () => (
    <Trigger label="Open sheet">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          variant="sheet"
          title="Drag me"
          showHandle
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[
            { text: 'Done', role: 'confirm', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            The pill drag handle at the top signals to users that the sheet can be swiped down to close.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

export const SheetNoHeader: Story = {
  name: 'Sheet / No header + handle',
  render: () => (
    <Trigger label="Open sheet">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          variant="sheet"
          showHandle
          onDismiss={onDismiss}
          buttons={[
            { text: 'Cancel',  role: 'cancel',  handler: onDismiss },
            { text: 'Apply',   role: 'confirm', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: '0 0 8px' }}>
            A headerless sheet — use when the context is clear from preceding content.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── Custom footer ────────────────────────────────────────────────────────────

export const CustomFooter: Story = {
  name: 'Dialog / Custom footer slot',
  render: () => (
    <Trigger>
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Custom footer"
          closeButton
          onDismiss={onDismiss}
          footer={
            <div style={{ display: 'flex', gap: '8px', width: '100%' }}>
              <Button label="Cancel"       variant="outline" expand="block" onClick={onDismiss} />
              <Button label="Save changes" expand="block"   onClick={onDismiss} />
            </div>
          }
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            Pass a <code>footer</code> render-prop for complete layout control over the bottom action area.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanConfirmation: Story = {
  name: 'App / Loan confirmation',
  render: () => (
    <Trigger label="Apply for loan">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Confirm loan application"
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[
            { text: 'Confirm', role: 'confirm', handler: onDismiss },
          ]}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontFamily: 'Poppins, sans-serif' }}>
            {[
              { label: 'Loan amount',   value: 'KES 500,000' },
              { label: 'Duration',      value: '12 months' },
              { label: 'Monthly repay', value: 'KES 46,250' },
              { label: 'Interest rate', value: '8.5% p.a.' },
              { label: 'Purpose',       value: 'Working capital' },
            ].map(({ label, value }) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px' }}>
                <span style={{ color: '#6c7a8b' }}>{label}</span>
                <span style={{ color: '#0d343f', fontWeight: 600 }}>{value}</span>
              </div>
            ))}
          </div>
        </Modal>
      )}
    </Trigger>
  ),
};

export const AppDocumentUpload: Story = {
  name: 'App / Document upload sheet',
  render: () => (
    <Trigger label="Upload document">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          variant="sheet"
          title="Upload document"
          showHandle
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[
            { text: 'Upload', role: 'confirm', handler: onDismiss },
          ]}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <Input label="Document name" placeholder="e.g. Bank statement" labelPlacement="stacked" />
            <Input label="Document type" placeholder="Select type" labelPlacement="stacked" />
            <InlineBanner
              variant="info"
              message="Accepted formats: PDF, JPG, PNG. Max size 10 MB."
            />
          </div>
        </Modal>
      )}
    </Trigger>
  ),
};

export const AppFilterSheet: Story = {
  name: 'App / Filter sheet',
  render: () => (
    <Trigger label="Filter loans">
      {({ open, onDismiss }) => {
        const [tab, setTab] = React.useState('status');
        return (
          <Modal
            open={open}
            variant="sheet"
            title="Filter"
            showHandle
            closeButton
            leftAction={{ text: 'Reset', handler: onDismiss }}
            onDismiss={onDismiss}
            buttons={[
              { text: 'Apply', role: 'confirm', handler: onDismiss },
            ]}
          >
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <Segment
                value={tab}
                options={[
                  { value: 'status', label: 'Status' },
                  { value: 'date',   label: 'Date' },
                  { value: 'amount', label: 'Amount' },
                ]}
                onIonChange={(value) => setTab(value)}
              />
              <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
                Filter options for <strong>{tab}</strong> would render here.
              </p>
            </div>
          </Modal>
        );
      }}
    </Trigger>
  ),
};

export const AppEditProfile: Story = {
  name: 'App / Edit profile dialog',
  render: () => (
    <Trigger label="Edit profile">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Edit profile"
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[
            { text: 'Save changes', role: 'confirm', handler: onDismiss },
          ]}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <Input label="Full name"     placeholder="Jane Muthoni"    labelPlacement="stacked" />
            <Input label="Phone number"  placeholder="+254 700 000 000" labelPlacement="stacked" />
            <Input label="Email"         placeholder="jane@avenews.io"  labelPlacement="stacked" type="email" />
          </div>
        </Modal>
      )}
    </Trigger>
  ),
};

export const AppDeleteConfirm: Story = {
  name: 'App / Delete confirmation',
  render: () => (
    <Trigger label="Remove document">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          title="Remove document?"
          size="sm"
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[
            { text: 'Remove document', role: 'destructive', handler: onDismiss },
          ]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            "KRA PIN certificate" will be permanently removed. You'll need to upload it again if required.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

// ─── Figma types — interactive versions ──────────────────────────────────────

/** Figma: Type=Default — full-height panel, CANCEL left, title centred */
export const FigmaDefault: Story = {
  name: 'Figma / Type=Default',
  render: () => (
    <Trigger label="Open Default">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          variant="sheet"
          size="full"
          title="Text"
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            Full-height panel. CANCEL text button left, centred title. Matches Figma Type=Default / Avenews Navigation.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

/** Figma: Type=Sheet — bottom sheet + handle, CANCEL left, title centred */
export const FigmaSheet: Story = {
  name: 'Figma / Type=Sheet',
  render: () => (
    <Trigger label="Open Sheet">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          variant="sheet"
          title="Text"
          showHandle
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[{ text: 'Done', role: 'confirm', handler: onDismiss }]}
        >
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360', margin: 0 }}>
            Bottom sheet with drag handle. CANCEL left, centred title. Matches Figma Type=Sheet.
          </p>
        </Modal>
      )}
    </Trigger>
  ),
};

/** Figma: Type=Navigation More — sheet + handle, title left, × close right */
export const FigmaNavigationMore: Story = {
  name: 'Figma / Type=Navigation More',
  render: () => (
    <Trigger label="Open Navigation More">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          variant="sheet"
          title="Text"
          showHandle
          closeButton
          onDismiss={onDismiss}
        >
          <div style={{ fontFamily: 'Poppins, sans-serif' }}>
            {['Dashboard', 'My loans', 'Documents', 'Cards', 'Settings'].map((item) => (
              <div key={item} style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '14px 24px', borderBottom: '0.55px solid #d0d7df',
                fontSize: '16px', color: '#0d343f',
              }}>
                <span>{item}</span>
                <span style={{ color: '#b7c1cc', fontSize: '18px' }}>›</span>
              </div>
            ))}
          </div>
        </Modal>
      )}
    </Trigger>
  ),
};

/** Figma: Type=Filter & Sort — sheet + handle, title left, × close right, radio list + apply button */
export const FigmaFilterSort: Story = {
  name: 'Figma / Type=Filter & Sort',
  render: () => {
    const [selected, setSelected] = React.useState('newest');
    return (
      <Trigger label="Open Filter & Sort">
        {({ open, onDismiss }) => (
          <Modal
            open={open}
            variant="sheet"
            title="Filter"
            showHandle
            closeButton
            onDismiss={onDismiss}
            buttons={[{ text: 'Apply', role: 'confirm', handler: onDismiss }]}
          >
            <div style={{ fontFamily: 'Poppins, sans-serif' }}>
              {[
                { value: 'newest',   label: 'Newest first' },
                { value: 'oldest',   label: 'Oldest first' },
                { value: 'amount',   label: 'Highest amount' },
                { value: 'status',   label: 'By status' },
                { value: 'name',     label: 'Alphabetical' },
              ].map(({ value, label }) => (
                <label key={value} onClick={() => setSelected(value)} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '13px 16px', borderBottom: '0.55px solid #d0d7df',
                  fontSize: '16px', color: '#0d343f', cursor: 'pointer',
                }}>
                  <span>{label}</span>
                  <span style={{
                    width: '20px', height: '20px', borderRadius: '50%',
                    border: `2px solid ${selected === value ? 'var(--av-color-action)' : '#b7c1cc'}`,
                    background: selected === value ? 'var(--av-color-action)' : 'transparent',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0,
                  }}>
                    {selected === value && <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#fff' }} />}
                  </span>
                </label>
              ))}
            </div>
          </Modal>
        )}
      </Trigger>
    );
  },
};

/** Figma: Type=Invoice Action Sheet — sheet + handle, CANCEL left, title centred, share actions + list */
export const FigmaInvoiceActionSheet: Story = {
  name: 'Figma / Type=Invoice Action Sheet',
  render: () => (
    <Trigger label="Share invoice">
      {({ open, onDismiss }) => (
        <Modal
          open={open}
          variant="sheet"
          title="Send Invoice"
          showHandle
          leftAction={{ text: 'Cancel', handler: onDismiss }}
          onDismiss={onDismiss}
          buttons={[{ text: 'Send', role: 'confirm', handler: onDismiss }]}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', fontFamily: 'Poppins, sans-serif' }}>
            {/* Share via row */}
            <div>
              <p style={{ fontSize: '16px', fontWeight: 600, color: '#0d343f', margin: '0 0 16px' }}>Send To</p>
              <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                {[
                  { label: 'WhatsApp', bg: '#25D366' },
                  { label: 'Email',    bg: 'var(--av-color-action)' },
                  { label: 'Message',  bg: 'var(--av-color-action)' },
                  { label: 'Copy Link', bg: 'var(--av-color-action)' },
                ].map(({ label, bg }) => (
                  <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                    <div style={{
                      width: '40px', height: '40px', borderRadius: '20px',
                      background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center',
                      boxShadow: '0px 3px 8px rgba(0,0,0,0.07)',
                    }} />
                    <span style={{ fontSize: '12px', color: '#4a5360' }}>{label}</span>
                  </div>
                ))}
              </div>
            </div>
            {/* Fund requests list */}
            <div>
              <p style={{ fontSize: '16px', fontWeight: 600, color: '#0d343f', margin: '0 0 8px' }}>Fund Requests</p>
              {['Invoice #001 — KES 120,000', 'Invoice #002 — KES 85,500', 'Invoice #003 — KES 200,000'].map((item) => (
                <div key={item} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '12px 0', borderBottom: '0.55px solid #d0d7df',
                  fontSize: '14px', color: '#0d343f',
                }}>
                  <span>{item}</span>
                  <span style={{ color: '#b7c1cc' }}>›</span>
                </div>
              ))}
            </div>
          </div>
        </Modal>
      )}
    </Trigger>
  ),
};
