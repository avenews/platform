import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { DataList } from './DataList';

const meta: Meta<typeof DataList> = {
  title: 'Avenews/Ionic/DataList',
  component: DataList,
  parameters: { layout: 'fullscreen' },
  argTypes: {
    variant: { control: 'select', options: ['default', 'compact'] },
  },
};

export default meta;
type Story = StoryObj<typeof DataList>;

const loanFields = [
  { label: 'Loan amount',    value: 'KES 150,000' },
  { label: 'Interest rate',  value: '2.5% per month' },
  { label: 'Tenor',          value: '12 months' },
  { label: 'Monthly repayment', value: 'KES 14,375' },
  { label: 'Reference',      value: 'AV-2024-001-KE', variant: 'with-copy' as const, onCopy: () => {} },
  { label: 'Status',         value: 'Active', variant: 'with-badge' as const, badgeVariant: 'success' as const },
];

export const Default: Story = {
  args: { fields: loanFields, title: 'Loan details' },
};

export const Compact: Story = {
  args: { fields: loanFields, title: 'Loan details', variant: 'compact' },
};

export const Loading: Story = {
  args: { fields: [], loading: true, skeletonCount: 5, title: 'Loan details' },
};

export const NoTitle: Story = {
  args: { fields: loanFields },
};
