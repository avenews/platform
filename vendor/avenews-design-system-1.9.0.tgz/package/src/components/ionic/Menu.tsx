import React from 'react';
import {
  IonMenu,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
} from '@ionic/react';

export type MenuSide = 'start' | 'end';
export type MenuType = 'overlay' | 'push' | 'reveal';

export interface MenuProps {
  menuId?: string;
  contentId: string;
  side?: MenuSide;
  type?: MenuType;
  title?: string;
  disabled?: boolean;
  maxEdgeStart?: number;
  children?: React.ReactNode;
  onIonDidOpen?: () => void;
  onIonDidClose?: () => void;
  className?: string;
}

export const Menu: React.FC<MenuProps> = ({
  menuId,
  contentId,
  side         = 'start',
  type         = 'overlay',
  title,
  disabled,
  maxEdgeStart,
  children,
  onIonDidOpen,
  onIonDidClose,
  className,
}) => (
  <IonMenu
    menuId={menuId}
    contentId={contentId}
    side={side}
    type={type}
    disabled={disabled}
    maxEdgeStart={maxEdgeStart}
    onIonDidOpen={onIonDidOpen}
    onIonDidClose={onIonDidClose}
    className={['avenews-menu', `avenews-menu--${side}`, `avenews-menu--${type}`, className].filter(Boolean).join(' ')}
  >
    <IonHeader className="avenews-menu__header">
      <IonToolbar className="avenews-menu__toolbar">
        <IonTitle className="avenews-menu__title">{title}</IonTitle>
      </IonToolbar>
    </IonHeader>
    <IonContent className="avenews-menu__content">{children}</IonContent>
  </IonMenu>
);

export default Menu;
