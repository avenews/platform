import React from 'react';
import { IonSpinner } from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────

export type LoaderVariant   = 'inline' | 'centered' | 'overlay';
export type LoaderSize      = 'sm' | 'md' | 'lg';
export type LoaderColor     =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';
export type SpinnerType     =
  | 'bubbles' | 'circles' | 'circular' | 'crescent'
  | 'dots'    | 'lines'   | 'lines-sharp';

export interface LoaderProps {
  variant?:  LoaderVariant;
  size?:     LoaderSize;
  color?:    LoaderColor;
  /** IonSpinner animation name */
  spinner?:  SpinnerType;
  label?:    string;
  visible?:  boolean;
  className?: string;
}

const SIZE_PX: Record<LoaderSize, number> = {
  sm: 20,
  md: 36,
  lg: 52,
};

// ─── Component ────────────────────────────────────────────────────────────────

export const Loader: React.FC<LoaderProps> = ({
  variant = 'inline',
  size    = 'md',
  color   = 'primary',
  spinner = 'circular',
  label,
  visible = true,
  className,
}) => {
  if (!visible) return null;

  const dim = SIZE_PX[size];

  const containerStyle: React.CSSProperties =
    variant === 'overlay'
      ? {
          position:       'fixed',
          inset:          0,
          zIndex:         9999,
          background:     'rgba(0,0,0,0.45)',
          display:        'flex',
          flexDirection:  'column',
          alignItems:     'center',
          justifyContent: 'center',
          gap:            '12px',
        }
      : variant === 'centered'
      ? {
          display:        'flex',
          flexDirection:  'column',
          alignItems:     'center',
          justifyContent: 'center',
          gap:            '10px',
          padding:        '32px',
          width:          '100%',
        }
      : {
          display:    'inline-flex',
          alignItems: 'center',
          gap:        '8px',
        };

  const labelStyle: React.CSSProperties = {
    fontFamily: 'var(--font-family, Poppins, sans-serif)',
    fontSize:   '13px',
    color:      variant === 'overlay' ? '#ffffff' : 'var(--ion-color-medium, #6b7280)',
    fontWeight: 500,
  };

  return (
    <div
      className={[
        'avenews-loader',
        `avenews-loader--${variant}`,
        `avenews-loader--${size}`,
        className,
      ].filter(Boolean).join(' ')}
      style={containerStyle}
      role="status"
      aria-label={label ?? 'Loading'}
      aria-live="polite"
    >
      <IonSpinner
        name={spinner}
        color={color}
        style={{ width: dim, height: dim }}
        aria-hidden="true"
      />
      {label && (
        <span style={labelStyle}>{label}</span>
      )}
    </div>
  );
};

export default Loader;
