/**
 * Ionic components — wrap @ionic/react primitives. For the Android app.
 *
 * AUTO-GENERATED INDEX. Re-exports every component in this folder so
 * consumers can `import { X } from '@avenews/design-system/ionic'`
 * without knowing the underlying file structure.
 */

export { Accordion } from './Accordion';
export type { AccordionItem, AccordionProps } from './Accordion';
export { ActionSheet } from './ActionSheet';
export type { ActionSheetButton, ActionSheetProps } from './ActionSheet';
export { Alert } from './Alert';
export { Badge } from './Badge';
export type { BadgeProps, BadgeVariant } from './Badge';
export { Button } from './Button';
export type { ButtonExpand, ButtonProps, ButtonSize, ButtonVariant } from './Button';
export { Card } from './Card';
export type { CardAction, CardColor, CardLayout, CardProps } from './Card';
export { Checkbox } from './Checkbox';
export type { CheckboxColor, CheckboxProps } from './Checkbox';
export { Chip } from './Chip';
export type { ChipColor, ChipFill, ChipProps, ChipVariant } from './Chip';
export { DataList } from './DataList';
export type { DataField, DataListProps, DataListVariant } from './DataList';
export { Datetime } from './Datetime';
export type { DatetimeColor, DatetimePresentation, DatetimeProps } from './Datetime';
export { DocumentCategoryCard } from './DocumentCategoryCard';
export { DocumentRow } from './DocumentRow';
export { EmptyState } from './EmptyState';
export type { EmptyStateAction, EmptyStateProps, EmptyStateVariant } from './EmptyState';
export { Fab } from './Fab';
export type { FabColor, FabProps, FabSize } from './Fab';
export { Footer } from './Footer';
export type { FooterAction, FooterColor, FooterFill, FooterProps } from './Footer';
export { Header } from './Header';
export type { HeaderProps, HeaderSize, HeaderVariant } from './Header';
export { Icon } from './Icon';
export type { IconProps, IconSize } from './Icon';
export { InfoRow } from './InfoRow';
export type { InfoRowLines, InfoRowProps, InfoRowVariant } from './InfoRow';
export { InlineBanner } from './InlineBanner';
export type { InlineBannerProps, InlineBannerVariant } from './InlineBanner';
export { Input } from './Input';
export type { InputLabelPlacement, InputProps, InputType } from './Input';
export { Item, ItemDivider } from './Item';
export type { ItemColor, ItemDividerProps, ItemLines, ItemProps, ItemVariant } from './Item';
export { List, ListHeader } from './List';
export type { ListColor, ListHeaderProps, ListHeaderSize, ListLines, ListProps } from './List';
export { Loader } from './Loader';
export type { LoaderColor, LoaderProps, LoaderSize, LoaderVariant, SpinnerType } from './Loader';
export { Avatar, MediaIcon, Thumbnail } from './Media';
export type { AvatarProps, AvatarSize, MediaIconColor, MediaIconProps, MediaIconSize, ThumbnailProps, ThumbnailSize } from './Media';
export { Menu } from './Menu';
export type { MenuProps, MenuSide, MenuType } from './Menu';
export { Modal } from './Modal';
export type { ModalButton, ModalProps, ModalSize, ModalVariant } from './Modal';
export { Note } from './Note';
export type { NoteAlign, NoteColor, NoteProps } from './Note';
export { Picker } from './Picker';
export type { PickerColumnDef, PickerOption, PickerProps } from './Picker';
export { Popover } from './Popover';
export { ProgressBar } from './ProgressBar';
export type { ProgressBarColor, ProgressBarProps, ProgressBarSegment, ProgressBarSize } from './ProgressBar';
export { ProgressTracker } from './ProgressTracker';
export type { ProgressColor, ProgressTrackerProps, ProgressType } from './ProgressTracker';
export { RadioGroup } from './Radio';
export type { RadioColor, RadioGroupProps, RadioLayout, RadioOption } from './Radio';
export { Searchbar } from './Searchbar';
export type { SearchbarCancelButton, SearchbarClearButton, SearchbarProps } from './Searchbar';
export { SectionHeader } from './SectionHeader';
export { Segment } from './Segment';
export type { SegmentOption, SegmentProps } from './Segment';
export { Select } from './Select';
export type { SelectOption, SelectProps } from './Select';
export { StepIndicator } from './StepIndicator';
export { Tabs } from './Tabs';
export type { TabItem, TabsProps, TabsSlot } from './Tabs';
export { Textarea } from './Textarea';
export type { TextareaLabelPlacement, TextareaProps } from './Textarea';
export { Toast } from './Toast';
export type { ToastButton, ToastColor, ToastPosition, ToastProps, ToastVariant } from './Toast';
export { Toggle } from './Toggle';
export type { ToggleProps } from './Toggle';
export { Toolbar } from './Toolbar';
export type { ToolbarAction, ToolbarColor, ToolbarProps } from './Toolbar';
export { UploadCard } from './UploadCard';

// The 6 cross-platform components (Alert, Popover, DocumentRow,
// DocumentCategoryCard, StepIndicator, SectionHeader) are re-exported via
// the local thin shim files in this folder, which forward from
// ../cross-platform — that keeps imports stable for ionic consumers.
