import React from 'react';
import { IonNote } from '@ionic/react';

export type NoteColor =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light'   | 'medium'  | 'dark';

export type NoteAlign = 'left' | 'center' | 'right';

export interface NoteProps {
  label: string;
  color?: NoteColor;
  slot?: 'start' | 'end';
  align?: NoteAlign;
  className?: string;
}

export const Note: React.FC<NoteProps> = ({
  label,
  color = 'default',
  slot,
  align = 'left',
  className,
}) => (
  <IonNote
    color={color === 'default' ? undefined : color}
    slot={slot}
    className={['avenews-note', color !== 'default' && `avenews-note--${color}`, align !== 'left' && `avenews-note--align-${align}`, className].filter(Boolean).join(' ')}
  >
    {label}
  </IonNote>
);

export default Note;
