import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import { checkmarkOutline, warningOutline, informationCircleOutline, closeCircleOutline } from 'ionicons/icons';
import { Toast } from './Toast';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Toast> = {
  title: 'Avenews/Ionic/Toast',
  component: Toast,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Toast built on `IonToast`. Supports top/bottom/middle positions, ' +
          'Ionic color tokens, icon, and action/cancel buttons. ' +
          'Control visibility with `isOpen` + `onDidDismiss`.',
      },
    },
    layout: 'centered',
  },
  argTypes: {
    color:    { control: 'select', options: ['primary', 'secondary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] },
    position: { control: 'radio',  options: ['top', 'bottom', 'middle'] },
    duration: { control: { type: 'number', min: 0, step: 500 } },
    message:  { control: 'text' },
  },
  args: {
    message:  'Your application has been submitted.',
    position: 'bottom',
    duration: 3500,
  },
};

export default meta;
type Story = StoryObj<typeof Toast>;

// ─── Helper ───────────────────────────────────────────────────────────────────

const Demo: React.FC<React.ComponentProps<typeof Toast>> = (props) => {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
      <button
        onClick={() => setOpen(true)}
        style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 14, fontWeight: 600,
          padding: '10px 20px', borderRadius: 8, border: 'none',
          background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer',
        }}
      >
        Show toast
      </button>
      <Toast {...props} isOpen={open} onDidDismiss={() => setOpen(false)} />
    </div>
  );
};

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  render: (args) => <Demo {...args} />,
  args: { message: 'Document uploaded successfully.', duration: 3000 },
};

// ─── Colors ──────────────────────────────────────────────────────────────────

export const ColorSuccess: Story = {
  name: 'Color / Success',
  render: (args) => <Demo {...args} />,
  args: { message: 'Loan application submitted.', color: 'success', icon: checkmarkOutline, duration: 3000 },
};

export const ColorWarning: Story = {
  name: 'Color / Warning',
  render: (args) => <Demo {...args} />,
  args: { message: 'Session expires in 5 minutes.', color: 'warning', icon: warningOutline, duration: 0 },
};

export const ColorDanger: Story = {
  name: 'Color / Danger',
  render: (args) => <Demo {...args} />,
  args: { message: 'Upload failed. Please try again.', color: 'danger', icon: closeCircleOutline, duration: 0 },
};

export const ColorPrimary: Story = {
  name: 'Color / Primary',
  render: (args) => <Demo {...args} />,
  args: { message: 'Repayment scheduled for tomorrow.', color: 'primary', icon: informationCircleOutline, duration: 4000 },
};

// ─── Positions ───────────────────────────────────────────────────────────────

export const PositionTop: Story = {
  name: 'Position / Top',
  render: (args) => <Demo {...args} />,
  args: { message: 'Changes saved.', color: 'success', position: 'top', duration: 2500 },
};

export const PositionMiddle: Story = {
  name: 'Position / Middle',
  render: (args) => <Demo {...args} />,
  args: { message: 'Processing your request…', position: 'middle', duration: 2000 },
};

// ─── With buttons ─────────────────────────────────────────────────────────────

export const WithDismiss: Story = {
  name: 'Feature / With dismiss button',
  render: (args) => <Demo {...args} />,
  args: {
    message:  'Document deleted.',
    duration: 0,
    buttons:  [{ text: 'Close', role: 'cancel' }],
  },
};

export const WithAction: Story = {
  name: 'Feature / With undo action',
  render: (args) => <Demo {...args} />,
  args: {
    message:  'Document removed.',
    duration: 5000,
    buttons:  [{ text: 'Undo' }, { text: 'Close', role: 'cancel' }],
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanSubmitted: Story = {
  name: 'App / Loan submitted',
  render: (args) => <Demo {...args} />,
  args: {
    message:  'Your loan application has been submitted for review.',
    color:    'success',
    icon:     checkmarkOutline,
    position: 'bottom',
    duration: 4000,
  },
};

export const AppUploadError: Story = {
  name: 'App / Upload error',
  render: (args) => <Demo {...args} />,
  args: {
    message:  'File too large. Maximum 10 MB.',
    color:    'danger',
    icon:     closeCircleOutline,
    duration: 0,
    buttons:  [{ text: 'Dismiss', role: 'cancel' }],
  },
};
