import React from 'react';
import { IonList } from '@ionic/react';
import { InfoRow } from './InfoRow';
import type { InfoRowVariant } from './InfoRow';
import type { BadgeVariant } from './Badge';
import { SectionHeader } from '../cross-platform/SectionHeader';
import { cn } from '../shared/utils';

export type DataListVariant = 'default' | 'compact';

export interface DataField {
  key?:          string;
  label:         string;
  value?:        string;
  variant?:      InfoRowVariant;
  badgeVariant?: BadgeVariant;
  onCopy?:       () => void;
}

export interface DataListProps {
  fields:         DataField[];
  variant?:       DataListVariant;
  title?:         string;
  loading?:       boolean;
  skeletonCount?: number;
  inset?:         boolean;
  className?:     string;
}

export const DataList: React.FC<DataListProps> = ({
  fields,
  variant       = 'default',
  title,
  loading       = false,
  skeletonCount = 4,
  inset         = false,
  className,
}) => {
  const rows = loading
    ? Array.from({ length: skeletonCount }, (_, i) => (
        <InfoRow key={i} label="" loading />
      ))
    : fields.map((f, i) => (
        <InfoRow
          key={f.key ?? f.label ?? i}
          label={f.label}
          value={f.value}
          variant={f.variant}
          badgeVariant={f.badgeVariant}
          onCopy={f.onCopy}
        />
      ));

  return (
    <div className={cn('avenews-data-list', variant !== 'default' && `avenews-data-list--${variant}`, className)}>
      {title && <SectionHeader title={title} />}
      <IonList inset={inset} lines="inset">
        {rows}
      </IonList>
    </div>
  );
};

export default DataList;
