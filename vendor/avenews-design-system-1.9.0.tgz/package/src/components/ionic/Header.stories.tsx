import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact, IonButton } from '@ionic/react';
import { Header } from './Header';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Header> = {
  title: 'Avenews/Ionic/Header',
  component: Header,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Content-level page section header — rendered inside `IonContent`, NOT as a nav bar. ' +
          'Distinct from the `Toolbar` component (which uses `IonHeader`). ' +
          'Supports title, `IonNote` subtitle, description, avatar, and actions.',
      },
    },
    layout: 'fullscreen',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '100%', maxWidth: 420, margin: '0 auto' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    variant: { control: 'radio', options: ['default', 'subtle', 'dark'] },
    size:    { control: 'radio', options: ['sm', 'md', 'lg'] },
    title:    { control: 'text' },
    subtitle: { control: 'text' },
    description: { control: 'text' },
  },
  args: {
    title:   'My Loans',
    variant: 'default',
    size:    'md',
  },
};

export default meta;
type Story = StoryObj<typeof Header>;

// ─── Shared helpers ───────────────────────────────────────────────────────────

const AvatarPlaceholder: React.FC<{ initials: string; color?: string }> = ({ initials, color = 'var(--av-color-action)' }) => (
  <div style={{
    width: 48, height: 48, borderRadius: 12, background: color, color: '#fff',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'var(--av-font-heading)', fontWeight: 700, fontSize: 18, flexShrink: 0,
  }}>
    {initials}
  </div>
);

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { title: 'My Loans', subtitle: '3 active loans' },
};

// ─── Variants ────────────────────────────────────────────────────────────────

export const VariantSubtle: Story = {
  name: 'Variant / Subtle',
  args: { title: 'Documents', subtitle: '12 files uploaded', variant: 'subtle' },
};

export const VariantDark: Story = {
  name: 'Variant / Dark',
  args: { title: 'Welcome back', subtitle: 'Avenews Capital', variant: 'dark' },
};

// ─── Sizes ───────────────────────────────────────────────────────────────────

export const SizeSm: Story = {
  name: 'Size / Small',
  args: { title: 'Section title', subtitle: '4 items', size: 'sm' },
};

export const SizeLg: Story = {
  name: 'Size / Large',
  args: { title: 'Dashboard', subtitle: 'Welcome back, John', size: 'lg' },
};

// ─── Features ─────────────────────────────────────────────────────────────────

export const WithAvatar: Story = {
  name: 'Feature / With avatar',
  args: {
    title:    'Acacia Trading Ltd',
    subtitle: 'Business account · Nairobi',
    avatar:   <AvatarPlaceholder initials="AT" />,
  },
};

export const WithDescription: Story = {
  name: 'Feature / With description',
  args: {
    title:       'Working Capital Loan',
    subtitle:    'Loan #AV-2024-001',
    description: 'Short-term financing for operational expenses. Disbursed 12 Jan 2024.',
  },
};

export const WithActions: Story = {
  name: 'Feature / With actions',
  args: {
    title:    'My Loans',
    subtitle: '3 active loans',
    actions: (
      <IonButton size="small" fill="solid" color="primary">
        Apply
      </IonButton>
    ),
  },
};

export const WithAvatarActionsDescription: Story = {
  name: 'Feature / Full — avatar + description + actions',
  args: {
    title:       'Acacia Trading Ltd',
    subtitle:    'KRA PIN: A123456789B',
    description: 'Registered 2018 · Retail & trade · 12 employees',
    avatar:      <AvatarPlaceholder initials="AT" />,
    actions: (
      <IonButton size="small" fill="outline" color="primary">
        Edit
      </IonButton>
    ),
  },
};

// ─── App use-cases ─────────────────────────────────────────────────────────────

export const AppDashboardGreeting: Story = {
  name: 'App / Dashboard greeting',
  args: {
    title:    'Good morning, John',
    subtitle: 'You have 2 pending documents',
    size:     'lg',
    avatar:   <AvatarPlaceholder initials="JK" color="#0f4b6b" />,
  },
};

export const AppLoanDetail: Story = {
  name: 'App / Loan detail header',
  args: {
    title:       'Working Capital Loan',
    subtitle:    'Loan #AV-2024-001',
    description: 'Disbursed 12 Jan 2024 · 12-month term · KES 500,000',
    actions: (
      <IonButton size="small" fill="solid" color="primary">
        Repay
      </IonButton>
    ),
  },
};
