import type { Meta, StoryObj } from '@storybook/react';
import { personOutline } from 'ionicons/icons';
import { Chip } from './Chip';
import type { ChipColor } from './Chip';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Chip> = {
  title: 'Avenews/Ionic/Chip',
  component: Chip,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Pill-shaped status / filter / selection chip. Supports 11 colour tokens × 2 fill modes (solid / outline), plus selected and dismissible states.',
      },
    },
  },
  argTypes: {
    color: {
      control: 'select',
      options: [
        'default','primary','secondary','tertiary',
        'success','warning','danger',
        'light','medium','dark','accent',
      ] satisfies ChipColor[],
      description: 'Chip colour token.',
    },
    fill: {
      control: 'radio',
      options: ['solid', 'outline'],
      description: 'Solid = tinted bg only. Outline = tinted bg + border.',
    },
    variant: { table: { disable: true } }, // deprecated — hide from controls
  },
  decorators: [
    (Story) => (
      <div style={{ padding: '16px', display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
        <Story />
      </div>
    ),
  ],
  args: {
    label: 'Status',
    color: 'primary',
    fill:  'solid',
  },
};

export default meta;
type Story = StoryObj<typeof Chip>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  args: { label: 'In Progress', color: 'primary' },
};

// ─── Fill modes ───────────────────────────────────────────────────────────────

export const Solid: Story = {
  name: 'Fill / Solid',
  args: { label: 'Requested', color: 'primary', fill: 'solid' },
};

export const Outline: Story = {
  name: 'Fill / Outline',
  args: { label: 'Requested', color: 'primary', fill: 'outline' },
};

export const SolidVsOutline: Story = {
  name: 'Fill / Solid vs Outline (all colors)',
  render: () => {
    const COLORS: ChipColor[] = [
      'default','primary','secondary','tertiary',
      'success','warning','danger',
      'light','medium','dark','accent',
    ];
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
          {COLORS.map((c) => <Chip key={c} label={c} color={c} fill="solid" />)}
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', alignItems: 'center' }}>
          {COLORS.map((c) => <Chip key={c} label={c} color={c} fill="outline" />)}
        </div>
      </div>
    );
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const Selected: Story = {
  name: 'State / Selected',
  args: { label: 'Active', color: 'primary', selected: true },
};

export const Disabled: Story = {
  name: 'State / Disabled',
  args: { label: 'Inactive', color: 'default', disabled: true },
};

export const Loading: Story = {
  name: 'State / Loading',
  args: { label: 'Loading…', color: 'primary', loading: true },
};

export const Dismissible: Story = {
  name: 'State / Dismissible',
  args: { label: 'Registration Documents', color: 'primary', dismissible: true },
};

// ─── With slots ───────────────────────────────────────────────────────────────

export const WithLeadingIcon: Story = {
  name: 'Slots / Leading icon',
  args: { label: 'Brendan M.', color: 'primary', leadingIcon: personOutline },
};

export const WithAvatar: Story = {
  name: 'Slots / Avatar',
  args: {
    label: 'Brendan Meyer',
    color: 'primary',
    avatarUrl: 'https://i.pravatar.cc/40',
    avatarAlt: 'Brendan Meyer',
    dismissible: true,
  },
};

// ─── Individual colors ────────────────────────────────────────────────────────

export const ColorDefault:   Story = { name: 'Color / Default',   args: { label: 'Default',   color: 'default'   } };
export const ColorPrimary:   Story = { name: 'Color / Primary',   args: { label: 'Primary',   color: 'primary'   } };
export const ColorSecondary: Story = { name: 'Color / Secondary', args: { label: 'Secondary', color: 'secondary' } };
export const ColorTertiary:  Story = { name: 'Color / Tertiary',  args: { label: 'Tertiary',  color: 'tertiary'  } };
export const ColorSuccess:   Story = { name: 'Color / Success',   args: { label: 'Success',   color: 'success'   } };
export const ColorWarning:   Story = { name: 'Color / Warning',   args: { label: 'Warning',   color: 'warning'   } };
export const ColorDanger:    Story = { name: 'Color / Danger',    args: { label: 'Danger',    color: 'danger'    } };
export const ColorLight:     Story = { name: 'Color / Light',     args: { label: 'Light',     color: 'light'     } };
export const ColorMedium:    Story = { name: 'Color / Medium',    args: { label: 'Medium',    color: 'medium'    } };
export const ColorDark:      Story = { name: 'Color / Dark',      args: { label: 'Dark',      color: 'dark'      } };
export const ColorAccent:    Story = { name: 'Color / Accent',    args: { label: 'Accent',    color: 'accent'    } };

// ─── App use-cases ────────────────────────────────────────────────────────────

export const DocumentStatuses: Story = {
  name: 'App / Document status chips',
  render: () => (
    <>
      <Chip label="In Progress"     color="primary"   />
      <Chip label="In Review"       color="secondary" />
      <Chip label="Completed"       color="success"   />
      <Chip label="Action Required" color="warning"   />
      <Chip label="Rejected"        color="danger"    />
      <Chip label="Pending"         color="default"   />
      <Chip label="Optional"        color="default"   fill="outline" />
    </>
  ),
};

export const FundRequestStatuses: Story = {
  name: 'App / Fund request statuses',
  render: () => (
    <>
      <Chip label="Requested" color="secondary" />
      <Chip label="Live"      color="tertiary"  />
      <Chip label="Due Soon"  color="warning"   />
      <Chip label="Overdue"   color="danger"    />
      <Chip label="Repaid"    color="success"   />
    </>
  ),
};

export const SelectableFilter: Story = {
  name: 'App / Selectable filter group',
  render: () => (
    <>
      <Chip label="All"       color="primary" selected />
      <Chip label="Pending"   color="default" fill="outline" />
      <Chip label="In Review" color="default" fill="outline" />
      <Chip label="Completed" color="default" fill="outline" />
    </>
  ),
};
