import React from 'react';
import { IonFooter, IonToolbar, IonButton, IonButtons } from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────

export type FooterColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

export type FooterFill = 'solid' | 'outline' | 'clear' | 'default';

export interface FooterAction {
  label:      string;
  fill?:      FooterFill;
  color?:     FooterColor;
  /** `undefined` / 'block' → full-width inside toolbar.
   *  'start' | 'end'      → placed in an IonButtons slot. */
  slot?:      'start' | 'end';
  expand?:    'block' | 'full';
  disabled?:  boolean;
  onClick?:   () => void;
}

export interface FooterProps {
  /** Supporting text or legal copy above buttons */
  caption?:     string;
  actions?:     FooterAction[];
  /** IonToolbar color token */
  color?:       FooterColor;
  translucent?: boolean;
  className?:   string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Footer: React.FC<FooterProps> = ({
  caption,
  actions     = [],
  color,
  translucent = false,
  className,
}) => {
  const startSlot = actions.filter(a => a.slot === 'start');
  const endSlot   = actions.filter(a => a.slot === 'end');
  const block     = actions.filter(a => !a.slot);

  return (
    <IonFooter
      translucent={translucent}
      className={['avenews-footer', className].filter(Boolean).join(' ')}
    >
      <IonToolbar color={color} className="avenews-footer__bar">

        {caption && (
          <p className="avenews-footer__caption">{caption}</p>
        )}

        {startSlot.length > 0 && (
          <IonButtons slot="start">
            {startSlot.map((a, i) => (
              <IonButton
                key={i}
                fill={a.fill ?? 'clear'}
                color={a.color}
                disabled={a.disabled}
                onClick={a.onClick}
              >
                {a.label}
              </IonButton>
            ))}
          </IonButtons>
        )}

        {endSlot.length > 0 && (
          <IonButtons slot="end">
            {endSlot.map((a, i) => (
              <IonButton
                key={i}
                fill={a.fill ?? 'solid'}
                color={a.color ?? color}
                disabled={a.disabled}
                onClick={a.onClick}
              >
                {a.label}
              </IonButton>
            ))}
          </IonButtons>
        )}

        {block.map((a, i) => (
          <IonButton
            key={i}
            expand={a.expand ?? 'block'}
            fill={a.fill ?? 'solid'}
            color={a.color ?? color}
            disabled={a.disabled}
            onClick={a.onClick}
            className="avenews-footer__btn"
          >
            {a.label}
          </IonButton>
        ))}

      </IonToolbar>
    </IonFooter>
  );
};

export default Footer;
