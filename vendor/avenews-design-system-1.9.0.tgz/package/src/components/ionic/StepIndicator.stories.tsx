/**
 * StepIndicator is a cross-platform component — implementation lives at
 * src/components/web/StepIndicator.tsx. The ionic entry re-exports it.
 *
 * See web/StepIndicator.stories.tsx for the full story catalogue.
 */
import type { Meta, StoryObj } from '@storybook/react';
import { StepIndicator, type Step } from './StepIndicator';

const meta: Meta<typeof StepIndicator> = {
  title: 'Avenews/Ionic/StepIndicator',
  component: StepIndicator,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Cross-platform step indicator for multi-step flows (KYC, application). Implementation shared with the web build — see Avenews/Web/StepIndicator.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof StepIndicator>;

const steps: Step[] = [
  { id: 1, title: 'Account basics',     status: 'completed' },
  { id: 2, title: 'Business details',   status: 'completed' },
  { id: 3, title: 'KYC verification',   status: 'in_progress' },
  { id: 4, title: 'Bank account',       status: 'pending' },
  { id: 5, title: 'Review and submit',  status: 'pending' },
];

export const Default: Story = {
  args: {
    steps,
    currentStep: 3,
    stepDisplay: 'Step 3 of 5',
    label: 'KYC verification',
  },
};

export const ActionRequired: Story = {
  args: {
    steps,
    currentStep: 3,
    stepDisplay: 'Step 3 of 5',
    label: 'KYC verification',
    error: true,
  },
};
