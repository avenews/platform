import React, { useState, useEffect } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import { ProgressBar } from './ProgressBar';
import type { ProgressBarColor, ProgressBarSize } from './ProgressBar';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof ProgressBar> = {
  title: 'Avenews/Ionic/ProgressBar',
  component: ProgressBar,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Progress bar built on `IonProgressBar` with label, value display, and segmented mode. ' +
          'Supports determinate, indeterminate, and buffer types across 3 sizes and 5 colour tokens.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color: {
      control: 'select',
      options: ['primary', 'secondary', 'success', 'warning', 'danger'] satisfies ProgressBarColor[],
    },
    size: {
      control: 'radio',
      options: ['sm', 'md', 'lg'] satisfies ProgressBarSize[],
    },
    value:         { control: { type: 'range', min: 0, max: 1, step: 0.01 } },
    indeterminate: { control: 'boolean' },
    showValue:     { control: 'boolean' },
    label:         { control: 'text' },
  },
  args: {
    value:     0.6,
    color:     'primary',
    size:      'md',
    showValue: false,
  },
};

export default meta;
type Story = StoryObj<typeof ProgressBar>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { value: 0.6 },
};

// ─── Sizes ────────────────────────────────────────────────────────────────────

export const AllSizes: Story = {
  name: 'Size / All sizes',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {(['sm', 'md', 'lg'] as ProgressBarSize[]).map((size) => (
        <ProgressBar key={size} value={0.65} size={size} label={`${size}`} showValue />
      ))}
    </div>
  ),
};

// ─── Colors ───────────────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'Color / All colors',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {(['primary', 'secondary', 'success', 'warning', 'danger'] as ProgressBarColor[]).map((color) => (
        <ProgressBar
          key={color}
          value={0.65}
          color={color}
          size="md"
          label={color.charAt(0).toUpperCase() + color.slice(1)}
          showValue
        />
      ))}
    </div>
  ),
};

// ─── Types ────────────────────────────────────────────────────────────────────

export const TypeDeterminate: Story = {
  name: 'Type / Determinate',
  args: { value: 0.75, label: 'In progress', showValue: true },
};

export const TypeIndeterminate: Story = {
  name: 'Type / Indeterminate',
  args: { indeterminate: true, label: 'Processing…' },
};

export const TypeBuffer: Story = {
  name: 'Type / Buffer',
  args: { value: 0.4, buffer: 0.7, label: 'Buffering', showValue: true },
};

export const TypeReversed: Story = {
  name: 'Type / Reversed',
  args: { value: 0.6, reversed: true, label: 'Reversed fill', showValue: true },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateComplete: Story = {
  name: 'State / Complete',
  args: { value: 1, color: 'success', label: 'Upload complete', showValue: true },
};

export const StateWarning: Story = {
  name: 'State / Warning',
  args: { value: 0.4, color: 'warning', label: 'Action required', showValue: true },
};

export const StateError: Story = {
  name: 'State / Error',
  args: { value: 0.25, color: 'danger', label: 'Upload failed', showValue: true },
};

// ─── Segmented ────────────────────────────────────────────────────────────────

export const SegmentedDefault: Story = {
  name: 'Segmented / 5 steps',
  args: { value: 0.6, segments: 5, label: 'Application progress' },
};

export const SegmentedMultiColor: Story = {
  name: 'Segmented / Multi-color',
  render: () => (
    <ProgressBar
      segmentData={[
        { label: 'Identity',  value: 100, color: 'success' },
        { label: 'Documents', value: 100, color: 'success' },
        { label: 'Business',  value: 50,  color: 'warning' },
        { label: 'Finance',   value: 0 },
        { label: 'Review',    value: 0 },
      ]}
      label="Loan application"
      size="md"
    />
  ),
};

// ─── Animated ────────────────────────────────────────────────────────────────

export const Animated: Story = {
  name: 'Interactive / Animated',
  render: () => {
    const [progress, setProgress] = useState(0);
    const [done, setDone] = useState(false);

    useEffect(() => {
      if (done) return;
      const id = setInterval(() => {
        setProgress((p) => {
          if (p >= 1) { clearInterval(id); setDone(true); return 1; }
          return Math.min(1, p + 0.02);
        });
      }, 80);
      return () => clearInterval(id);
    }, [done]);

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <ProgressBar
          value={progress}
          color={done ? 'success' : 'primary'}
          label={done ? 'Upload complete' : 'Uploading…'}
          showValue
          size="md"
        />
        <button
          onClick={() => { setProgress(0); setDone(false); }}
          style={{ alignSelf: 'flex-start', fontFamily: 'Poppins, sans-serif', fontSize: 13,
            padding: '6px 12px', borderRadius: 6, border: '1px solid #d0d7df',
            background: '#fff', cursor: 'pointer' }}
        >
          Reset
        </button>
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppDocumentUpload: Story = {
  name: 'App / Document upload list',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <ProgressBar value={1}    color="success"  size="md" label="Business registration" showValue />
      <ProgressBar value={1}    color="success"  size="md" label="KRA PIN certificate"   showValue />
      <ProgressBar value={0.65} color="primary"  size="md" label="Bank statement"         showValue />
      <ProgressBar value={0}    color="primary"  size="md" label="Director ID"            showValue />
    </div>
  ),
};

export const AppLoanProgress: Story = {
  name: 'App / Loan application steps',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <ProgressBar
        segmentData={[
          { label: 'Personal',  value: 100, color: 'success' },
          { label: 'Business',  value: 100, color: 'success' },
          { label: 'Documents', value: 100, color: 'success' },
          { label: 'Review',    value: 50,  color: 'warning' },
          { label: 'Approved',  value: 0 },
        ]}
        label="Step 4 of 5"
        size="lg"
      />
      <ProgressBar value={0.8} color="primary" label="Overall completion" showValue size="md" />
    </div>
  ),
};
