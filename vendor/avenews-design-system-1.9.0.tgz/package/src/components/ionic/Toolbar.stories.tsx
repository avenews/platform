import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import {
  searchOutline, notificationsOutline, ellipsisVerticalOutline,
  createOutline, shareOutline,
} from 'ionicons/icons';
import { Toolbar } from './Toolbar';
import type { ToolbarAction } from './Toolbar';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Toolbar> = {
  title: 'Avenews/Ionic/Toolbar',
  component: Toolbar,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Top navigation bar built on `IonHeader` + `IonToolbar`. Supports an optional back button, ' +
          'Ionic color tokens, and up to 3 trailing icon actions.',
      },
    },
    layout: 'fullscreen',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '100%', maxWidth: 420, margin: '0 auto' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color:          { control: 'select', options: ['primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] },
    showBackButton: { control: 'boolean' },
    title:          { control: 'text' },
    backText:       { control: 'text' },
  },
  args: {
    title: 'My Account',
  },
};

export default meta;
type Story = StoryObj<typeof Toolbar>;

const SEARCH_BELL: ToolbarAction[] = [
  { icon: searchOutline,        label: 'Search' },
  { icon: notificationsOutline, label: 'Notifications' },
];

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { title: 'Dashboard' },
};

// ─── Colors ──────────────────────────────────────────────────────────────────

export const ColorPrimary: Story = {
  name: 'Color / Primary',
  args: { title: 'My Loans', color: 'primary', trailingActions: [{ icon: searchOutline, label: 'Search' }] },
};

export const ColorDark: Story = {
  name: 'Color / Dark',
  args: { title: 'Dashboard', color: 'dark', trailingActions: SEARCH_BELL },
};

export const ColorLight: Story = {
  name: 'Color / Light',
  args: { title: 'Documents', color: 'light' },
};

// ─── Back button ──────────────────────────────────────────────────────────────

export const WithBackButton: Story = {
  name: 'Nav / Back button',
  args: {
    title:          'Loan details',
    showBackButton: true,
    trailingActions: [{ icon: ellipsisVerticalOutline, label: 'More' }],
  },
};

export const WithBackText: Story = {
  name: 'Nav / Back with text',
  args: { title: 'Documents', showBackButton: true, backText: 'Loans' },
};

// ─── Trailing actions ─────────────────────────────────────────────────────────

export const OneAction: Story = {
  name: 'Actions / One',
  args: { title: 'Notifications', trailingActions: [{ icon: searchOutline, label: 'Search' }] },
};

export const TwoActions: Story = {
  name: 'Actions / Two',
  args: { title: 'Loan details', trailingActions: [{ icon: createOutline, label: 'Edit' }, { icon: shareOutline, label: 'Share' }] },
};

export const ThreeActions: Story = {
  name: 'Actions / Three',
  args: {
    title: 'Document',
    trailingActions: [
      { icon: searchOutline,            label: 'Search' },
      { icon: createOutline,            label: 'Edit' },
      { icon: ellipsisVerticalOutline,  label: 'More' },
    ],
  },
};

// ─── App use-cases ─────────────────────────────────────────────────────────────

export const AppDashboard: Story = {
  name: 'App / Dashboard',
  args: { title: 'Dashboard', trailingActions: SEARCH_BELL },
};

export const AppLoanDetail: Story = {
  name: 'App / Loan detail',
  args: {
    title:          'Loan #AV-2024-001',
    showBackButton: true,
    color:          'primary',
    trailingActions: [{ icon: ellipsisVerticalOutline, label: 'More' }],
  },
};

export const AppKYCStep: Story = {
  name: 'App / KYC step',
  args: { title: 'Identity verification', showBackButton: true, backText: 'Back' },
};
