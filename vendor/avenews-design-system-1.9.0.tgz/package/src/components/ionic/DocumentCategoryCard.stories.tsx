/**
 * DocumentCategoryCard is a cross-platform component — implementation lives at
 * src/components/web/DocumentCategoryCard.tsx. The ionic entry re-exports it.
 *
 * See web/DocumentCategoryCard.stories.tsx for the full story catalogue.
 */
import type { Meta, StoryObj } from '@storybook/react';
import { DocumentCategoryCard } from './DocumentCategoryCard';

const meta: Meta<typeof DocumentCategoryCard> = {
  title: 'Avenews/Ionic/DocumentCategoryCard',
  component: DocumentCategoryCard,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Cross-platform category card grouping a list of DocumentRow items. Implementation shared with the web build — see Avenews/Web/DocumentCategoryCard.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof DocumentCategoryCard>;

const sampleDocs = [
  { name: 'Certificate of incorporation', status: 'completed' as const },
  { name: 'Director ID', status: 'in_review' as const },
  { name: 'Proof of address', status: 'action_required' as const },
];

export const ActionRequired: Story = {
  args: {
    index: 1,
    title: 'Business documents',
    status: 'action_required',
    docs: sampleDocs,
  },
};

export const Completed: Story = {
  args: {
    index: 2,
    title: 'Personal verification',
    status: 'completed',
    docs: [
      { name: 'National ID', status: 'completed' },
      { name: 'Selfie verification', status: 'completed' },
    ],
  },
};
