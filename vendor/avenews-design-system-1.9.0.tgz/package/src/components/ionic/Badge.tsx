import React from 'react';
import { IonBadge } from '@ionic/react';

export type BadgeVariant =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark'
  | 'info'    | 'neutral'
  | 'success-subtle' | 'warning-subtle' | 'danger-subtle' | 'info-subtle';

export interface BadgeProps {
  count: number | string;
  variant?: BadgeVariant;
  hideOnEmpty?: boolean;
  loading?: boolean;
  className?: string;
  slot?: string;
}

function formatCount(count: number | string): string {
  if (typeof count === 'string') return count;
  if (count >= 1000) return `${Math.round(count / 1000)}k+`;
  return String(count);
}

export const Badge: React.FC<BadgeProps> = ({
  count,
  variant     = 'primary',
  hideOnEmpty = true,
  loading     = false,
  className,
  slot,
}) => {
  const isEmpty = count === 0 || count === '' || count === null || count === undefined;
  if (hideOnEmpty && isEmpty && !loading) return null;
  const resolvedVariant = loading ? 'loading' : variant;
  return (
    <IonBadge
      slot={slot}
      className={['avenews-badge', `avenews-badge--${resolvedVariant}`, className].filter(Boolean).join(' ')}
    >
      {loading ? '…' : formatCount(count)}
    </IonBadge>
  );
};

export default Badge;
