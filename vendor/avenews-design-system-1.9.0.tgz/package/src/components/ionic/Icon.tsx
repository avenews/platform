import React from 'react';
import { IonIcon } from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────

export type IconSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export interface IconProps {
  /** Ionicons icon string — import from 'ionicons/icons' */
  icon:          string;
  size?:         IconSize | number;
  color?:        string;
  className?:    string;
  'aria-label'?: string;
  'aria-hidden'?: boolean;
}

// ─── Size map ─────────────────────────────────────────────────────────────────

const SIZE_PX: Record<IconSize, number> = {
  xs: 14,
  sm: 16,
  md: 20,
  lg: 24,
  xl: 32,
};

// ─── Component ────────────────────────────────────────────────────────────────

export const Icon: React.FC<IconProps> = ({
  icon,
  size           = 'md',
  color,
  className,
  'aria-label':  ariaLabel,
  'aria-hidden': ariaHidden = true,
}) => {
  const px = typeof size === 'number' ? size : SIZE_PX[size];

  return (
    <IonIcon
      icon={icon}
      aria-hidden={ariaHidden ? 'true' : undefined}
      aria-label={ariaLabel}
      className={['avenews-icon', className].filter(Boolean).join(' ')}
      style={{
        fontSize: px,
        color:    color ?? undefined,
        flexShrink: 0,
      }}
    />
  );
};

export default Icon;
