export { StepIndicator, StepIndicator as default } from '../cross-platform/StepIndicator';
export type { StepIndicatorProps, Step, StepStatus } from '../cross-platform/StepIndicator';
