import type { Meta, StoryObj } from '@storybook/react';
import { addOutline, trashOutline, checkmarkOutline } from 'ionicons/icons';
import { Button } from './Button';

const meta: Meta<typeof Button> = {
  title: 'Avenews/Ionic/Button',
  component: Button,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: [
        'primary', 'secondary', 'outline', 'ghost',
        'danger', 'success', 'warning',
        'inverted', 'inverted-outline',
      ],
      description: 'Visual style. Encodes both colour and fill intent.',
    },
    size: {
      control: 'radio',
      options: ['sm', 'md', 'lg'],
      description: 'sm=13px/34px · md=14px/44px · lg=20px/54px',
    },
    expand: {
      control: 'radio',
      options: [undefined, 'block', 'full'],
      description: 'Layout expand. CSS-only — no Ionic expand= prop.',
    },
    iconSlot: {
      control: 'radio',
      options: ['start', 'end', 'icon-only'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof Button>;

// ─── States ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  args: { label: 'Submit Application' },
};

export const Loading: Story = {
  args: { label: 'Submit Application', loading: true },
};

export const Disabled: Story = {
  args: { label: 'Submit Application', disabled: true },
};

// ─── Variants ────────────────────────────────────────────────────────────────

export const Secondary: Story = {
  args: { label: 'Learn More', variant: 'secondary' },
};

export const Outline: Story = {
  args: { label: 'View Details', variant: 'outline' },
};

export const Ghost: Story = {
  args: { label: 'Cancel', variant: 'ghost' },
};

export const Danger: Story = {
  args: { label: 'Delete Document', variant: 'danger' },
};

export const Success: Story = {
  args: { label: 'Approve', variant: 'success' },
};

export const Warning: Story = {
  args: { label: 'Review Required', variant: 'warning' },
};

// ─── Sizes ───────────────────────────────────────────────────────────────────

export const Small: Story = {
  args: { label: 'View', size: 'sm' },
};

export const Large: Story = {
  args: { label: 'Get Started', size: 'lg', expand: 'block' },
};

export const Block: Story = {
  args: { label: 'Continue', expand: 'block' },
};

// ─── Icons ───────────────────────────────────────────────────────────────────

export const WithIconStart: Story = {
  args: { label: 'Add Document', icon: addOutline },
};

export const WithIconEnd: Story = {
  args: { label: 'Delete', variant: 'danger', icon: trashOutline, iconSlot: 'end' },
};

export const IconOnly: Story = {
  args: {
    label: 'Add Document',
    ariaLabel: 'Add document',
    icon: addOutline,
    iconSlot: 'icon-only',
  },
};

// ─── Inverted (for dark backgrounds) ─────────────────────────────────────────

export const Inverted: Story = {
  args: { label: 'Get Started', variant: 'inverted' },
  decorators: [(Story) => (
    <div style={{ background: 'var(--av-color-surface-dark)', padding: '24px', borderRadius: '12px', display: 'inline-flex', gap: '12px' }}>
      <Story />
    </div>
  )],
};

export const InvertedOutline: Story = {
  args: { label: 'Learn More', variant: 'inverted-outline' },
  decorators: [(Story) => (
    <div style={{ background: 'var(--av-color-surface-dark)', padding: '24px', borderRadius: '12px', display: 'inline-flex', gap: '12px' }}>
      <Story />
    </div>
  )],
};

// ─── Full variant matrix ──────────────────────────────────────────────────────

export const AllVariants: Story = {
  name: 'All Variants',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', padding: '16px', alignItems: 'center' }}>
      <Button label="Primary" variant="primary" />
      <Button label="Secondary" variant="secondary" />
      <Button label="Outline" variant="outline" />
      <Button label="Ghost" variant="ghost" />
      <Button label="Danger" variant="danger" />
      <Button label="Success" variant="success" />
      <Button label="Warning" variant="warning" />
    </div>
  ),
};

export const AllSizes: Story = {
  name: 'All Sizes',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', padding: '16px', alignItems: 'center' }}>
      <Button label="Small" size="sm" />
      <Button label="Medium (default)" size="md" />
      <Button label="Large" size="lg" />
    </div>
  ),
};

export const AllStates: Story = {
  name: 'All States',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', padding: '16px', alignItems: 'center' }}>
      <Button label="Default" />
      <Button label="Hover (interact me)" />
      <Button label="Loading" loading />
      <Button label="Disabled" disabled />
      <Button label="With icon" icon={checkmarkOutline} />
    </div>
  ),
};
