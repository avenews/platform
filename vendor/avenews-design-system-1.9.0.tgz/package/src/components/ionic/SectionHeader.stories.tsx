/**
 * SectionHeader is a cross-platform component — implementation lives at
 * src/components/web/SectionHeader.tsx. The ionic entry re-exports it.
 *
 * See web/SectionHeader.stories.tsx for the full story catalogue.
 */
import type { Meta, StoryObj } from '@storybook/react';
import { SectionHeader } from './SectionHeader';

const meta: Meta<typeof SectionHeader> = {
  title: 'Avenews/Ionic/SectionHeader',
  component: SectionHeader,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Cross-platform inline section header — title with optional action link or count badge. Implementation shared with the web build — see Avenews/Web/SectionHeader.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof SectionHeader>;

export const Default: Story = {
  args: { title: 'Recent activity' },
};

export const WithAction: Story = {
  args: { title: 'Open requests', variant: 'with-action', actionLabel: 'View all' },
};

export const WithCount: Story = {
  args: { title: 'Pending tasks', variant: 'with-count', count: 8 },
};
