import React, { useRef } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  IonApp,
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonMenuButton,
  IonButton,
  IonList as IonListNative,
  setupIonicReact,
} from '@ionic/react';
import { menuController } from '@ionic/core';
import {
  homeOutline,
  cashOutline,
  documentTextOutline,
  cardOutline,
  notificationsOutline,
  personOutline,
  settingsOutline,
  helpCircleOutline,
  logOutOutline,
  chevronForwardOutline,
} from 'ionicons/icons';
import { Menu } from './Menu';
import { List, ListHeader } from './List';
import { Item } from './Item';
import { MediaIcon } from './Media';
import { Badge } from './Badge';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Menu> = {
  title: 'Avenews/Ionic/Menu',
  component: Menu,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Wraps `IonMenu` — a side-drawer navigation panel.',
          'Supports `start` (left) and `end` (right) sides with three animation types:',
          '`overlay` (slides over content), `push` (moves content aside), `reveal` (content slides to reveal menu behind).',
          'Requires a `contentId` matching the `id` of your main `IonPage` element.',
          'Open programmatically with `menuController.open(menuId)` or via `IonMenuButton`.',
        ].join(' '),
      },
    },
    layout: 'fullscreen',
  },
};

export default meta;
type Story = StoryObj<typeof Menu>;

// ─── Shared story frame ────────────────────────────────────────────────────────

const CONTENT_ID = 'menu-story-content';

const PageFrame: React.FC<{
  menu: React.ReactNode;
  title?: string;
  note?: string;
}> = ({ menu, title = 'Main content', note }) => (
  <IonApp>
    {menu}
    <IonPage id={CONTENT_ID}>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonMenuButton />
          </IonButtons>
          <IonTitle style={{ fontFamily: 'Poppins, sans-serif', fontSize: '18px', fontWeight: 600, color: '#0d343f' }}>
            {title}
          </IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <div style={{ padding: '24px 16px' }}>
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360' }}>
            {note ?? 'Tap ☰ in the top-left to open the menu.'}
          </p>
        </div>
      </IonContent>
    </IonPage>
  </IonApp>
);

// ─── Overlay (default) ────────────────────────────────────────────────────────

export const OverlayLeft: Story = {
  name: 'Type / Overlay — Left (default)',
  render: () => (
    <PageFrame
      note="Overlay: menu slides over content with a dark backdrop."
      menu={
        <Menu menuId="overlay-left" contentId={CONTENT_ID} side="start" type="overlay" title="Menu">
          <List lines="inset">
            <Item label="Home" startSlot={<MediaIcon icon={homeOutline} color="primary" />} button detailArrow />
            <Item label="Loans" startSlot={<MediaIcon icon={cashOutline} color="primary" />} button detailArrow />
            <Item label="Documents" startSlot={<MediaIcon icon={documentTextOutline} color="primary" />} button detailArrow />
            <Item label="Profile" startSlot={<MediaIcon icon={personOutline} color="primary" />} button detailArrow lines="none" />
          </List>
        </Menu>
      }
    />
  ),
};

export const PushLeft: Story = {
  name: 'Type / Push — Left',
  render: () => (
    <PageFrame
      note="Push: menu slides in and pushes the main content aside."
      menu={
        <Menu menuId="push-left" contentId={CONTENT_ID} side="start" type="push" title="Menu">
          <List lines="inset">
            <Item label="Home" startSlot={<MediaIcon icon={homeOutline} color="primary" />} button detailArrow />
            <Item label="Loans" startSlot={<MediaIcon icon={cashOutline} color="primary" />} button detailArrow />
            <Item label="Documents" startSlot={<MediaIcon icon={documentTextOutline} color="primary" />} button detailArrow />
            <Item label="Profile" startSlot={<MediaIcon icon={personOutline} color="primary" />} button detailArrow lines="none" />
          </List>
        </Menu>
      }
    />
  ),
};

export const RevealLeft: Story = {
  name: 'Type / Reveal — Left',
  render: () => (
    <PageFrame
      note="Reveal: main content slides away to reveal the menu behind."
      menu={
        <Menu menuId="reveal-left" contentId={CONTENT_ID} side="start" type="reveal" title="Menu">
          <List lines="inset">
            <Item label="Home" startSlot={<MediaIcon icon={homeOutline} color="primary" />} button detailArrow />
            <Item label="Loans" startSlot={<MediaIcon icon={cashOutline} color="primary" />} button detailArrow />
            <Item label="Documents" startSlot={<MediaIcon icon={documentTextOutline} color="primary" />} button detailArrow />
            <Item label="Profile" startSlot={<MediaIcon icon={personOutline} color="primary" />} button detailArrow lines="none" />
          </List>
        </Menu>
      }
    />
  ),
};

export const OverlayRight: Story = {
  name: 'Type / Overlay — Right (end)',
  render: () => (
    <IonApp>
      <Menu menuId="overlay-right" contentId="right-content" side="end" type="overlay" title="Options">
        <List lines="inset">
          <Item label="Settings" startSlot={<MediaIcon icon={settingsOutline} color="medium" />} button detailArrow />
          <Item label="Help" startSlot={<MediaIcon icon={helpCircleOutline} color="medium" />} button detailArrow />
          <Item label="Sign out" startSlot={<MediaIcon icon={logOutOutline} color="danger" />} button lines="none" />
        </List>
      </Menu>
      <IonPage id="right-content">
        <IonHeader>
          <IonToolbar>
            <IonTitle style={{ fontFamily: 'Poppins, sans-serif', fontSize: '18px', fontWeight: 600, color: '#0d343f' }}>
              Main content
            </IonTitle>
            <IonButtons slot="end">
              <IonMenuButton menu="overlay-right" />
            </IonButtons>
          </IonToolbar>
        </IonHeader>
        <IonContent>
          <div style={{ padding: '24px 16px' }}>
            <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: '14px', color: '#4a5360' }}>
              Tap ☰ in the top-right to open the end menu.
            </p>
          </div>
        </IonContent>
      </IonPage>
    </IonApp>
  ),
};

// ─── Notifications variant (Figma spec) ───────────────────────────────────────

export const Notifications: Story = {
  name: 'Content / Notifications list',
  render: () => (
    <PageFrame
      title="Dashboard"
      note="Menu with notification items — matches Figma Menu/Left/Notifications."
      menu={
        <Menu menuId="notifications-menu" contentId={CONTENT_ID} side="start" type="overlay" title="Notifications">
          <List lines="inset">
            <Item
              label="Loan approved"
              secondLine="Your KES 500,000 application was approved"
              button detailArrow
              endSlot={<Badge count="New" variant="success" />}
            />
            <Item
              label="Repayment due"
              secondLine="KES 46,250 due on 28 Jan"
              button detailArrow
              endSlot={<Badge count="Due" variant="warning" />}
            />
            <Item
              label="Document required"
              secondLine="Upload your bank statement"
              button detailArrow
              endSlot={<Badge count="Action" variant="danger" />}
            />
            <Item label="Profile updated" secondLine="Your details were saved" button detailArrow />
            <Item label="New loan offer" secondLine="You qualify for KES 750,000" button detailArrow />
            <Item label="Statement ready" secondLine="Jan 2025 statement available" button detailArrow />
            <Item label="Field visit scheduled" secondLine="Agent visit on 3 Feb 2025" button detailArrow />
            <Item label="Application received" secondLine="Reference #AVN-2024-8847" button detailArrow />
            <Item label="KRA verified" secondLine="PIN certificate confirmed" button detailArrow />
            <Item label="Welcome to Avenews" secondLine="Start your application today" button detailArrow lines="none" />
          </List>
        </Menu>
      }
    />
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppNavigationMenu: Story = {
  name: 'App / Navigation menu',
  render: () => (
    <PageFrame
      title="Avenews"
      note="Full navigation drawer with sections, icons and a sign-out action."
      menu={
        <Menu menuId="nav-menu" contentId={CONTENT_ID} side="start" type="overlay" title="Avenews">
          <List lines="none">
            <ListHeader label="Main" />
            <Item label="Dashboard" startSlot={<MediaIcon icon={homeOutline} color="primary" />} button detailArrow />
            <Item label="My loans" startSlot={<MediaIcon icon={cashOutline} color="primary" />} button detailArrow />
            <Item label="Documents" startSlot={<MediaIcon icon={documentTextOutline} color="primary" />} button detailArrow />
            <Item label="Cards" startSlot={<MediaIcon icon={cardOutline} color="primary" />} button detailArrow />
          </List>
          <List lines="none">
            <ListHeader label="Account" />
            <Item
              label="Notifications"
              startSlot={<MediaIcon icon={notificationsOutline} color="medium" />}
              endSlot={<Badge count="3" variant="danger" />}
              button detailArrow
            />
            <Item label="Profile" startSlot={<MediaIcon icon={personOutline} color="medium" />} button detailArrow />
            <Item label="Settings" startSlot={<MediaIcon icon={settingsOutline} color="medium" />} button detailArrow />
            <Item label="Help" startSlot={<MediaIcon icon={helpCircleOutline} color="medium" />} button detailArrow />
          </List>
          <List lines="none">
            <Item label="Sign out" startSlot={<MediaIcon icon={logOutOutline} color="danger" />} button />
          </List>
        </Menu>
      }
    />
  ),
};
