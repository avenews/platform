export { SectionHeader, SectionHeader as default } from '../cross-platform/SectionHeader';
export type { SectionHeaderProps, SectionHeaderVariant } from '../cross-platform/SectionHeader';
