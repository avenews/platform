import React from 'react';
import { IonFabButton, IonIcon } from '@ionic/react';

export type FabColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

export type FabSize = 'main' | 'mini';

export interface FabProps {
  icon: string;
  color?: FabColor;
  size?: FabSize;
  label?: string;
  disabled?: boolean;
  onClick?: () => void;
  className?: string;
}

export const Fab: React.FC<FabProps> = ({
  icon,
  color    = 'primary',
  size     = 'main',
  label,
  disabled = false,
  onClick,
  className,
}) => {
  if (label) {
    return (
      <button
        type="button"
        disabled={disabled}
        onClick={onClick}
        className={['avenews-fab', 'avenews-fab--extended', `avenews-fab--${color}`, className].filter(Boolean).join(' ')}
      >
        <IonIcon icon={icon} className="avenews-fab__icon" />
        <span className="avenews-fab__label">{label}</span>
      </button>
    );
  }

  return (
    <IonFabButton
      color={color}
      size={size === 'mini' ? 'small' : undefined}
      disabled={disabled}
      onClick={onClick}
      className={['avenews-fab', `avenews-fab--${color}`, size === 'mini' && 'avenews-fab--mini', className].filter(Boolean).join(' ')}
    >
      <IonIcon icon={icon} className="avenews-fab__icon" />
    </IonFabButton>
  );
};

export default Fab;
