import React from 'react';
import { IonProgressBar } from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────

export type ProgressBarColor =
  | 'primary' | 'secondary'
  | 'success' | 'warning'  | 'danger';

export type ProgressBarSize  = 'sm' | 'md' | 'lg';

export interface ProgressBarSegment {
  label:  string;
  value:  number;   // 0–100
  color?: ProgressBarColor;
}

export interface ProgressBarProps {
  /** 0–1 for IonProgressBar compatibility */
  value?:         number;
  /** 0–1 buffer fill */
  buffer?:        number;
  indeterminate?: boolean;
  reversed?:      boolean;
  color?:         ProgressBarColor;
  size?:          ProgressBarSize;
  label?:         string;
  showValue?:     boolean;
  /** Divide track into N equal segments */
  segments?:      number;
  /** Explicit segment data — overrides `segments` */
  segmentData?:   ProgressBarSegment[];
  className?:     string;
}

const SIZE_HEIGHT: Record<ProgressBarSize, string> = {
  sm: '4px',
  md: '8px',
  lg: '12px',
};

// ─── Component ────────────────────────────────────────────────────────────────

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value         = 0,
  buffer        = 0,
  indeterminate = false,
  reversed      = false,
  color         = 'primary',
  size          = 'md',
  label,
  showValue     = false,
  segments,
  segmentData,
  className,
}) => {
  const pct = Math.round(Math.min(1, Math.max(0, value)) * 100);
  const isSegmented = Boolean(segments || segmentData);

  const wrapStyle: React.CSSProperties = {
    display:       'flex',
    flexDirection: 'column',
    gap:           '6px',
    width:         '100%',
  };

  const headerStyle: React.CSSProperties = {
    display:        'flex',
    justifyContent: 'space-between',
    alignItems:     'center',
    fontFamily:     'var(--font-family, Poppins, sans-serif)',
    fontSize:       '13px',
  };

  // ── Segmented ─────────────────────────────────────────────────────────────

  if (isSegmented) {
    const segs: ProgressBarSegment[] = segmentData
      ?? Array.from({ length: segments! }, (_, i) => ({
           label: `${i + 1}`,
           value: pct > (i / segments!) * 100 ? 100 : 0,
         }));

    return (
      <div
        className={['avenews-progress-bar', 'avenews-progress-bar--segmented', className].filter(Boolean).join(' ')}
        style={wrapStyle}
      >
        {(label || showValue) && (
          <div style={headerStyle}>
            {label     && <span style={{ fontWeight: 500, color: 'var(--av-color-text)' }}>{label}</span>}
            {showValue && <span style={{ color: 'var(--av-color-text-muted)', fontWeight: 600 }}>{pct}%</span>}
          </div>
        )}
        <div style={{ display: 'flex', gap: '3px' }}>
          {segs.map((seg, i) => (
            <div
              key={i}
              style={{
                flex:         1,
                height:       SIZE_HEIGHT[size],
                borderRadius: '9999px',
                overflow:     'hidden',
                background:   'var(--ion-color-light-shade, #d0d7df)',
              }}
            >
              <IonProgressBar
                value={seg.value / 100}
                color={(seg.color ?? color) as string}
                style={{ '--buffer-background': 'transparent', height: '100%' }}
              />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ── Default ───────────────────────────────────────────────────────────────

  return (
    <div
      className={['avenews-progress-bar', className].filter(Boolean).join(' ')}
      style={wrapStyle}
    >
      {(label || showValue) && (
        <div style={headerStyle}>
          {label     && <span style={{ fontWeight: 500, color: 'var(--av-color-text)' }}>{label}</span>}
          {showValue && !indeterminate && <span style={{ color: 'var(--av-color-text-muted)', fontWeight: 600 }}>{pct}%</span>}
        </div>
      )}

      <div style={{ borderRadius: '9999px', overflow: 'hidden', height: SIZE_HEIGHT[size], background: 'var(--ion-color-light-shade, #d0d7df)' }}>
        <IonProgressBar
          type={indeterminate ? 'indeterminate' : 'determinate'}
          value={value}
          buffer={buffer}
          reversed={reversed}
          color={color as string}
          style={{ '--buffer-background': 'transparent', height: '100%' }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;
