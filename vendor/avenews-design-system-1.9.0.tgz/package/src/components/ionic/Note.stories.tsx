import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  calendarOutline,
  cashOutline,
  documentTextOutline,
  personOutline,
  timeOutline,
  receiptOutline,
} from 'ionicons/icons';
import { IonIcon, IonItem, IonLabel, IonList } from '@ionic/react';
import { Note } from './Note';
import { Item, ItemDivider } from './Item';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Note> = {
  title: 'Avenews/Ionic/Note',
  component: Note,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Wraps `IonNote` — a compact 11px muted label used to show secondary metadata.',
          'Three usage modes: **inline** (`slot="end"` or `slot="start"` inside `IonItem`),',
          '**stacked** (below `IonLabel`, no slot), and **clear/standalone** (outside any item).',
          'Supports 10 color tokens.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '360px', background: 'var(--av-color-surface-subtle, #f3f5f7)', padding: '16px' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'],
    },
    align: { control: 'radio', options: ['left', 'center', 'right'] },
    slot:  { control: 'radio', options: [undefined, 'start', 'end'] },
  },
  args: {
    label: 'Note text',
    color: 'default',
    align: 'left',
  },
};

export default meta;
type Story = StoryObj<typeof Note>;

// ─── Standalone (clear) ───────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (standalone)',
  args: { label: 'Note text' },
};

export const AllColors: Story = {
  name: 'Color / All colors (standalone)',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      {(['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] as const).map((color) => (
        <Note key={color} label={color.charAt(0).toUpperCase() + color.slice(1)} color={color} />
      ))}
    </div>
  ),
};

// ─── Inline (slot="end") ──────────────────────────────────────────────────────

export const InlineEnd: Story = {
  name: 'Inline / End slot (most common)',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          <IonItem>
            <IonIcon slot="start" icon={calendarOutline} />
            <IonLabel>Due date</IonLabel>
            <Note label="28 Jan" slot="end" />
          </IonItem>
          <IonItem>
            <IonIcon slot="start" icon={cashOutline} />
            <IonLabel>Balance</IonLabel>
            <Note label="KES 45,000" slot="end" color="primary" />
          </IonItem>
          <IonItem lines="none">
            <IonIcon slot="start" icon={timeOutline} />
            <IonLabel>Processing time</IonLabel>
            <Note label="2–3 days" slot="end" color="warning" />
          </IonItem>
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

export const InlineStart: Story = {
  name: 'Inline / Start slot',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          <IonItem>
            <Note label="#2847" slot="start" color="primary" />
            <IonLabel>Nairobi Traders Ltd</IonLabel>
          </IonItem>
          <IonItem>
            <Note label="#2801" slot="start" color="default" />
            <IonLabel>Mombasa Suppliers</IonLabel>
          </IonItem>
          <IonItem lines="none">
            <Note label="#2750" slot="start" color="success" />
            <IonLabel>Kisumu Traders</IonLabel>
          </IonItem>
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

export const InlineAllColors: Story = {
  name: 'Inline / All colors in end slot',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          {(['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] as const).map((color, i, arr) => (
            <IonItem key={color} lines={i === arr.length - 1 ? 'none' : 'full'}>
              <IonLabel>{color.charAt(0).toUpperCase() + color.slice(1)}</IonLabel>
              <Note label="Metadata" slot="end" color={color} />
            </IonItem>
          ))}
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

// ─── Stacked (below IonLabel) ─────────────────────────────────────────────────

export const StackedLeft: Story = {
  name: 'Stacked / Left alignment (default)',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          <IonItem>
            <IonIcon slot="start" icon={documentTextOutline} />
            <IonLabel>Business registration</IonLabel>
            <Note label="Uploaded 14 Jan 2025" align="left" />
          </IonItem>
          <IonItem lines="none">
            <IonIcon slot="start" icon={receiptOutline} />
            <IonLabel>Invoice #2847</IonLabel>
            <Note label="Due 28 Jan · KES 45,000" align="left" color="warning" />
          </IonItem>
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

export const StackedCenter: Story = {
  name: 'Stacked / Center alignment',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          <IonItem>
            <IonLabel>Loan status</IonLabel>
            <Note label="Under review" align="center" color="warning" />
          </IonItem>
          <IonItem lines="none">
            <IonLabel>Disbursement</IonLabel>
            <Note label="Completed 3 Feb 2025" align="center" color="success" />
          </IonItem>
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

export const StackedRight: Story = {
  name: 'Stacked / Right alignment',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          <IonItem>
            <IonLabel>Repayment</IonLabel>
            <Note label="28 Jan 2025" align="right" />
          </IonItem>
          <IonItem lines="none">
            <IonLabel>Next review</IonLabel>
            <Note label="Q2 2025" align="right" color="primary" />
          </IonItem>
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

// ─── States (from parent IonItem) ────────────────────────────────────────────

export const StateDisabled: Story = {
  name: 'State / Disabled (inherited from Item)',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          <IonItem>
            <IonLabel>Normal item</IonLabel>
            <Note label="Active" slot="end" color="success" />
          </IonItem>
          <IonItem disabled>
            <IonLabel>Disabled item</IonLabel>
            <Note label="Locked" slot="end" color="danger" />
          </IonItem>
          <IonItem lines="none" disabled>
            <IonLabel>Also disabled</IonLabel>
            <Note label="N/A" slot="end" />
          </IonItem>
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppTransactionDates: Story = {
  name: 'App / Transaction dates',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          <ItemDivider label="Recent activity" />
          <Item
            variant="list3"
            label="Invoice #2847"
            secondLine="Nairobi Traders Ltd"
            thirdLine="KES 45,000"
            startSlot={<IonIcon icon={cashOutline} />}
            endSlot={<Note label="14 Jan" color="default" />}
            detailArrow
            button
          />
          <Item
            variant="list3"
            label="Repayment due"
            secondLine="Avenews Finance"
            thirdLine="KES 120,000"
            startSlot={<IonIcon icon={receiptOutline} />}
            endSlot={<Note label="28 Jan" color="warning" />}
            detailArrow
            button
          />
          <Item
            variant="list3"
            label="Invoice #2801"
            secondLine="Mombasa Suppliers"
            thirdLine="KES 18,500"
            startSlot={<IonIcon icon={cashOutline} />}
            endSlot={<Note label="3 Feb" color="success" />}
            detailArrow
            button
          />
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

export const AppProfileFields: Story = {
  name: 'App / Profile fields with notes',
  decorators: [
    () => (
      <div style={{ width: '360px' }}>
        <IonList style={{ padding: 0 }}>
          <IonItem>
            <IonIcon slot="start" icon={personOutline} />
            <IonLabel>Full name</IonLabel>
            <Note label="Verified" slot="end" color="success" />
          </IonItem>
          <IonItem>
            <IonIcon slot="start" icon={documentTextOutline} />
            <IonLabel>KRA PIN</IonLabel>
            <Note label="A001234567X" slot="end" color="primary" />
          </IonItem>
          <IonItem lines="none">
            <IonIcon slot="start" icon={calendarOutline} />
            <IonLabel>Account opened</IonLabel>
            <Note label="Jan 2024" slot="end" />
          </IonItem>
        </IonList>
      </div>
    ),
  ],
  render: () => <></>,
};

export const AppStandaloneLabels: Story = {
  name: 'App / Standalone (clear) notes',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      <Note label="Last updated 14 Jan 2025" />
      <Note label="Processing · 2–3 business days" color="warning" />
      <Note label="Verified by Avenews" color="success" />
      <Note label="Pending KYC review" color="danger" />
      <Note label="Invoice #2847" color="primary" />
    </div>
  ),
};
