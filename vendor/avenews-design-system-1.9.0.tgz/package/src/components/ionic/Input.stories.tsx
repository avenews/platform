import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  eyeOutline,
  eyeOffOutline,
  searchOutline,
  lockClosedOutline,
  mailOutline,
  personOutline,
  callOutline,
  calendarOutline,
  businessOutline,
  cardOutline,
  chevronDownOutline,
} from 'ionicons/icons';
import { Input } from './Input';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Input> = {
  title: 'Avenews/Ionic/Input',
  component: Input,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Wraps `IonInput` (and `IonTextarea`) with `fill="solid"`.',
          'Matches the Figma flat-field style: `#f6f8fc` background, bottom-border-only hairline.',
          'Supports 4 label placements, 7 states, icon slots, phone prefix, and textarea variant.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '350px', padding: '24px', background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    labelPlacement: {
      control: 'radio',
      options: ['stacked', 'floating', 'fixed', 'start'],
    },
    type: {
      control: 'select',
      options: ['text', 'email', 'number', 'password', 'tel', 'url', 'date'],
    },
  },
  args: {
    label: 'Label',
    placeholder: 'Text',
    labelPlacement: 'stacked',
  },
};

export default meta;
type Story = StoryObj<typeof Input>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { label: 'First name', placeholder: 'Enter your first name' },
};

// ─── Label placements ─────────────────────────────────────────────────────────

export const LabelStacked: Story = {
  name: 'Label / Stacked (default)',
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'stacked' },
};

export const LabelFloating: Story = {
  name: 'Label / Floating',
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'floating' },
};

export const LabelFixed: Story = {
  name: 'Label / Fixed',
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'fixed' },
};

export const LabelInline: Story = {
  name: 'Label / Inline (start)',
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'start' },
};

export const AllLabelPlacements: Story = {
  name: 'Label / All placements',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Input label="Stacked"  placeholder="Text" labelPlacement="stacked"  />
      <Input label="Floating" placeholder="Text" labelPlacement="floating" />
      <Input label="Fixed"    placeholder="Text" labelPlacement="fixed"    />
      <Input label="Inline"   placeholder="Text" labelPlacement="start"    />
    </div>
  ),
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateDefault: Story = {
  name: 'State / Default',
  args: { label: 'Label', placeholder: 'Text' },
};

export const StateFilled: Story = {
  name: 'State / Filled',
  args: { label: 'Label', value: 'Text', placeholder: 'Text' },
};

export const StateDisabled: Story = {
  name: 'State / Disabled',
  args: { label: 'Label', value: 'Text', placeholder: 'Text', disabled: true },
};

export const StateError: Story = {
  name: 'State / Error',
  args: {
    label: 'Email address',
    value: 'not-valid',
    type: 'email',
    error: 'Enter a valid email address.',
  },
};

export const StateSuccess: Story = {
  name: 'State / Success',
  args: {
    label: 'Email address',
    value: 'user@example.com',
    type: 'email',
    success: true,
    helperText: 'Email verified.',
  },
};

export const StateLoading: Story = {
  name: 'State / Loading skeleton',
  args: { label: 'First name', loading: true },
};

export const AllStates: Story = {
  name: 'State / All states',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
      <Input label="Default"  placeholder="Text" />
      <Input label="Filled"   value="Text" />
      <Input label="Error"    value="bad-val" error="This field is required." />
      <Input label="Success"  value="user@example.com" success helperText="Looks good!" />
      <Input label="Disabled" value="Text" disabled />
    </div>
  ),
};

// ─── Features ─────────────────────────────────────────────────────────────────

export const Required: Story = {
  name: 'Feature / Required asterisk',
  args: { label: 'Business name', placeholder: 'e.g. Avenews Ltd', required: true },
};

export const WithHelperText: Story = {
  name: 'Feature / Helper text',
  args: {
    label: 'KRA PIN',
    placeholder: 'e.g. A001234567X',
    helperText: 'Must be a valid 11-character KRA PIN.',
  },
};

export const WithCounter: Story = {
  name: 'Feature / Character counter',
  args: {
    label: 'Business description',
    placeholder: 'Brief description…',
    counter: true,
    maxlength: 140,
  },
};

export const WithClearButton: Story = {
  name: 'Feature / Clear button',
  args: { label: 'Search', placeholder: 'Search…', clearInput: true, value: 'Something typed' },
};

export const Password: Story = {
  name: 'Feature / Password (with reveal icon)',
  args: {
    label: 'Password',
    type: 'password',
    placeholder: '••••••••',
    required: true,
    endIcon: eyeOutline,
  },
};

// ─── Icon slots ───────────────────────────────────────────────────────────────
// Two slot types from Figma:
//   "Icon"        — passive 16px IonIcon  (no onClick)
//   "Icon-button" — interactive 28px <button> (onClick provided)

export const SlotIcon: Story = {
  name: 'Slots / Icon (passive, 16px)',
  args: { label: 'Search', placeholder: 'Search transactions…', startIcon: searchOutline },
};

export const SlotIconButton: Story = {
  name: 'Slots / Icon-button (interactive, 28px)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [show, setShow] = React.useState(false);
    return (
      <Input
        label="Password"
        type={show ? 'text' : 'password'}
        placeholder="••••••••"
        value="hunter2"
        endIcon={show ? eyeOffOutline : eyeOutline}
        onEndIconClick={() => setShow((v) => !v)}
        endIconAriaLabel={show ? 'Hide password' : 'Show password'}
      />
    );
  },
};

export const SlotBothTypes: Story = {
  name: 'Slots / Both — Icon start + Icon-button end',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = React.useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
        <Input
          label="Date"
          placeholder="Select date…"
          startIcon={calendarOutline}
          endIcon={chevronDownOutline}
          onEndIconClick={() => setOpen((v) => !v)}
          endIconAriaLabel="Open date picker"
          value={open ? '12 Jun 2025' : undefined}
        />
        {open && (
          <p style={{
            fontFamily: 'var(--av-font-body)', fontSize: '12px',
            color: 'var(--av-color-text-muted)', padding: '8px 16px',
          }}>
            ↑ Date picker would open here
          </p>
        )}
      </div>
    );
  },
};

export const SlotStartButton: Story = {
  name: 'Slots / Icon-button in start slot',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [active, setActive] = React.useState(false);
    return (
      <Input
        label="Filter"
        placeholder="Filter transactions…"
        startIcon={active ? searchOutline : searchOutline}
        onStartIconClick={() => setActive((v) => !v)}
        startIconAriaLabel="Toggle search filter"
        value={active ? 'Filtered' : undefined}
      />
    );
  },
};

export const SlotGallery: Story = {
  name: 'Slots / Full gallery',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [pwVisible, setPwVisible] = React.useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
        {/* Passive icons (Icon type) */}
        <Input label="Full name"   placeholder="Name"         startIcon={personOutline}    />
        <Input label="Email"       placeholder="Email"        startIcon={mailOutline}      type="email" />
        <Input label="Phone"       placeholder="Number"       startIcon={callOutline}      />
        <Input label="Business"    placeholder="Company"      startIcon={businessOutline}  />
        {/* Interactive icon-buttons (Icon-button type) */}
        <Input
          label="Password"
          type={pwVisible ? 'text' : 'password'}
          placeholder="••••••••"
          endIcon={pwVisible ? eyeOffOutline : eyeOutline}
          onEndIconClick={() => setPwVisible((v) => !v)}
          endIconAriaLabel={pwVisible ? 'Hide password' : 'Show password'}
        />
        <Input
          label="Date"
          placeholder="Select date…"
          startIcon={calendarOutline}
          endIcon={chevronDownOutline}
          onEndIconClick={() => {}}
          endIconAriaLabel="Open picker"
        />
        <Input
          label="Amount"
          type="number"
          placeholder="0.00"
          startIcon={cardOutline}
          endIcon={chevronDownOutline}
          onEndIconClick={() => {}}
          endIconAriaLabel="Select currency"
        />
      </div>
    );
  },
};

// ─── Phone input ──────────────────────────────────────────────────────────────

export const PhoneInput: Story = {
  name: 'Variant / Phone input',
  args: {
    label: 'Phone number',
    placeholder: '700 000 000',
    type: 'tel',
    phonePrefix: '+254',
    phoneFlagEmoji: '🇰🇪',
  },
};

export const PhoneInputFilled: Story = {
  name: 'Variant / Phone input (filled)',
  args: {
    label: 'Phone number',
    value: '722 123 456',
    type: 'tel',
    phonePrefix: '+254',
    phoneFlagEmoji: '🇰🇪',
  },
};

export const PhoneInputError: Story = {
  name: 'Variant / Phone input (error)',
  args: {
    label: 'Phone number',
    value: '123',
    type: 'tel',
    phonePrefix: '+254',
    phoneFlagEmoji: '🇰🇪',
    error: 'Enter a valid Kenyan mobile number.',
  },
};

// ─── Textarea ─────────────────────────────────────────────────────────────────

export const Textarea: Story = {
  name: 'Variant / Textarea (message)',
  args: {
    label: 'Message',
    placeholder: 'Write your message here…',
    multiline: true,
    rows: 4,
  },
};

export const TextareaWithCounter: Story = {
  name: 'Variant / Textarea with counter',
  args: {
    label: 'Notes',
    placeholder: 'Add any additional notes…',
    multiline: true,
    rows: 4,
    counter: true,
    maxlength: 250,
  },
};

export const TextareaError: Story = {
  name: 'Variant / Textarea error',
  args: {
    label: 'Message',
    placeholder: 'Write your message here…',
    multiline: true,
    rows: 4,
    error: 'Message is required.',
  },
};

export const TextareaFilled: Story = {
  name: 'Variant / Textarea filled',
  args: {
    label: 'Message',
    value: 'This is a longer message typed by the user that spans multiple lines to demonstrate the auto-grow behavior.',
    multiline: true,
    autoGrow: true,
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const LoginForm: Story = {
  name: 'App / Login form',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
      <Input
        label="Email address"
        type="email"
        placeholder="you@example.com"
        startIcon={mailOutline}
        required
      />
      <Input
        label="Password"
        type="password"
        placeholder="••••••••"
        endIcon={eyeOutline}
        required
      />
    </div>
  ),
};

export const FundRequestForm: Story = {
  name: 'App / Fund request form',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
      <Input label="Business name" placeholder="e.g. Nairobi Traders Ltd" startIcon={businessOutline} />
      <Input label="Requested amount (KES)" type="number" placeholder="0" startIcon={cardOutline} />
      <Input label="Phone number" type="tel" phonePrefix="+254" phoneFlagEmoji="🇰🇪" placeholder="700 000 000" />
      <Input label="Additional notes" placeholder="Purpose of funding…" multiline rows={3} />
    </div>
  ),
};

export const SignUpForm: Story = {
  name: 'App / Sign-up form',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
      <Input label="Full name"      placeholder="First and last name"  startIcon={personOutline}   required />
      <Input label="Email"          placeholder="you@example.com"      startIcon={mailOutline}     type="email" required />
      <Input label="Phone"          placeholder="700 000 000"          phonePrefix="+254"          phoneFlagEmoji="🇰🇪" />
      <Input label="Password"       placeholder="••••••••"             endIcon={eyeOutline}        type="password" required />
      <Input
        label="Password"
        placeholder="Confirm password"
        endIcon={lockClosedOutline}
        type="password"
        required
        error="Passwords do not match."
      />
    </div>
  ),
};
