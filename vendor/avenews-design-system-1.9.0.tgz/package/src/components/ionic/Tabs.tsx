import React from 'react';
import { IonTabBar, IonTabButton, IonLabel, IonIcon, IonBadge } from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface TabItem {
  value:     string;
  label?:    string;
  /** Ionicons icon string (e.g. homeOutline from 'ionicons/icons') */
  icon?:     string;
  badge?:    number;
  disabled?: boolean;
}

export type TabsSlot = 'top' | 'bottom';

export interface TabsProps {
  tabs:         TabItem[];
  value?:       string;
  slot?:        TabsSlot;
  onIonChange?: (value: string) => void;
  className?:   string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Tabs: React.FC<TabsProps> = ({
  tabs,
  value,
  slot        = 'bottom',
  onIonChange,
  className,
}) => (
  <IonTabBar
    slot={slot}
    // Re-key forces IonTabBar to re-sync its internal selected state
    key={value}
    className={['avenews-tabs', className].filter(Boolean).join(' ')}
  >
    {tabs.map((tab) => (
      <IonTabButton
        key={tab.value}
        tab={tab.value}
        disabled={tab.disabled}
        selected={tab.value === value}
        className={[
          'avenews-tabs__btn',
          tab.value === value ? 'avenews-tabs__btn--selected' : '',
        ].filter(Boolean).join(' ')}
        onClick={() => !tab.disabled && onIonChange?.(tab.value)}
      >
        {tab.icon && <IonIcon icon={tab.icon} aria-hidden="true" />}
        {tab.label && <IonLabel>{tab.label}</IonLabel>}
        {tab.badge !== undefined && tab.badge > 0 && (
          <IonBadge color="danger">{tab.badge}</IonBadge>
        )}
      </IonTabButton>
    ))}
  </IonTabBar>
);

export default Tabs;
