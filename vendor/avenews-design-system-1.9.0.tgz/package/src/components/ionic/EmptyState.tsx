import React from 'react';
import { IonIcon } from '@ionic/react';
import {
  documentOutline,
  searchOutline,
  alertCircleOutline,
  cloudOfflineOutline,
} from 'ionicons/icons';
import { Button } from './Button';

export type EmptyStateVariant = 'no-content' | 'no-results' | 'error' | 'offline';

export interface EmptyStateAction {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'outline' | 'ghost';
}

export interface EmptyStateProps {
  variant?: EmptyStateVariant;
  icon?: string;
  title: string;
  description?: string;
  action?: EmptyStateAction;
  secondaryAction?: EmptyStateAction;
  className?: string;
}

const DEFAULT_ICONS: Record<EmptyStateVariant, string> = {
  'no-content': documentOutline,
  'no-results': searchOutline,
  'error':      alertCircleOutline,
  'offline':    cloudOfflineOutline,
};

export const EmptyState: React.FC<EmptyStateProps> = ({
  variant   = 'no-content',
  icon,
  title,
  description,
  action,
  secondaryAction,
  className,
}) => {
  const resolvedIcon = icon ?? DEFAULT_ICONS[variant];
  const isError = variant === 'error' || variant === 'offline';

  return (
    <div className={['avenews-empty-state', `avenews-empty-state--${variant}`, className].filter(Boolean).join(' ')}>
      <div className="avenews-empty-state__icon-wrap">
        <IonIcon
          icon={resolvedIcon}
          className="avenews-empty-state__icon"
          style={{ color: isError ? 'var(--av-color-danger)' : 'var(--av-color-text-muted)' }}
        />
      </div>
      <h3 className="avenews-empty-state__title">{title}</h3>
      {description && <p className="avenews-empty-state__description">{description}</p>}
      {(action || secondaryAction) && (
        <div className="avenews-empty-state__actions">
          {action && <Button label={action.label} variant={action.variant ?? 'primary'} onClick={action.onClick} expand="block" />}
          {secondaryAction && <Button label={secondaryAction.label} variant={secondaryAction.variant ?? 'ghost'} onClick={secondaryAction.onClick} expand="block" />}
        </div>
      )}
    </div>
  );
};

export default EmptyState;
