import React from 'react';
import { IonIcon, IonInput, IonSkeletonText, IonTextarea } from '@ionic/react';

export type InputLabelPlacement = 'stacked' | 'floating' | 'fixed' | 'start';
export type InputType =
  | 'text' | 'email' | 'number' | 'password'
  | 'search' | 'tel' | 'url' | 'date';

export interface InputProps {
  label?: string;
  labelPlacement?: InputLabelPlacement;
  placeholder?: string;
  value?: string;
  type?: InputType;
  required?: boolean;
  disabled?: boolean;
  loading?: boolean;
  error?: string;
  success?: boolean;
  helperText?: string;
  counter?: boolean;
  maxlength?: number;
  clearInput?: boolean;
  startIcon?: string;
  onStartIconClick?: () => void;
  startIconAriaLabel?: string;
  endIcon?: string;
  onEndIconClick?: () => void;
  endIconAriaLabel?: string;
  multiline?: boolean;
  rows?: number;
  autoGrow?: boolean;
  phonePrefix?: string;
  phoneFlagEmoji?: string;
  onIonInput?: (value: string) => void;
  onIonChange?: (value: string) => void;
  onIonBlur?: () => void;
  onIonFocus?: () => void;
  className?: string;
  /** @deprecated */
  continuation?: boolean;
}

export const Input: React.FC<InputProps> = ({
  label,
  labelPlacement   = 'stacked',
  placeholder,
  value,
  type             = 'text',
  required         = false,
  disabled         = false,
  loading          = false,
  error,
  success          = false,
  helperText,
  counter          = false,
  maxlength,
  clearInput       = false,
  startIcon,
  onStartIconClick,
  startIconAriaLabel,
  endIcon,
  onEndIconClick,
  endIconAriaLabel,
  multiline        = false,
  rows             = 4,
  autoGrow         = true,
  phonePrefix,
  phoneFlagEmoji   = '🇰🇪',
  onIonInput,
  onIonChange,
  onIonBlur,
  onIonFocus,
  className,
}) => {
  if (loading) {
    return (
      <div className="avenews-input-skeleton">
        <IonSkeletonText animated style={{ width: '35%', height: '12px', marginBottom: '6px' }} />
        <IonSkeletonText animated style={{ width: '100%', height: '22px' }} />
      </div>
    );
  }

  const rootClass = ['avenews-input', error && 'avenews-input--error', success && !error && 'avenews-input--success', multiline && 'avenews-input--multiline', phonePrefix != null && 'avenews-input--phone', className].filter(Boolean).join(' ');
  const handleIonInput  = (e: CustomEvent) => onIonInput?.((e.detail.value as string) ?? '');
  const handleIonChange = (e: CustomEvent) => onIonChange?.((e.detail.value as string) ?? '');
  const labelContent = label ? `${label}${required ? '\u200A*' : ''}` : undefined;

  const startSlot = startIcon
    ? onStartIconClick
      ? <button type="button" slot="start" onClick={onStartIconClick} aria-label={startIconAriaLabel} className="avenews-input__icon-btn"><IonIcon icon={startIcon} className="avenews-input__icon avenews-input__icon--btn" /></button>
      : <IonIcon icon={startIcon} slot="start" className="avenews-input__icon avenews-input__icon--start" />
    : null;

  const endSlot = endIcon
    ? onEndIconClick
      ? <button type="button" slot="end" onClick={onEndIconClick} aria-label={endIconAriaLabel} className="avenews-input__icon-btn"><IonIcon icon={endIcon} className="avenews-input__icon avenews-input__icon--btn" /></button>
      : <IonIcon icon={endIcon} slot="end" className="avenews-input__icon avenews-input__icon--end" />
    : null;

  if (multiline) {
    return (
      <IonTextarea fill="solid" label={labelContent} labelPlacement={labelPlacement} placeholder={placeholder} value={value} disabled={disabled} rows={rows} autoGrow={autoGrow} counter={counter} maxlength={maxlength} helperText={!error ? helperText : undefined} errorText={error} className={rootClass} onIonInput={handleIonInput as never} onIonChange={handleIonChange as never} onIonBlur={() => onIonBlur?.()} onIonFocus={() => onIonFocus?.()} />
    );
  }

  if (phonePrefix != null) {
    return (
      <IonInput fill="solid" label={labelContent} labelPlacement={labelPlacement} placeholder={placeholder} value={value} type="tel" disabled={disabled} clearInput={clearInput} counter={counter} maxlength={maxlength} helperText={!error ? helperText : undefined} errorText={error} className={rootClass} onIonInput={handleIonInput as never} onIonChange={handleIonChange as never} onIonBlur={() => onIonBlur?.()} onIonFocus={() => onIonFocus?.()}>
        <span slot="start" className="avenews-input__phone-prefix">
          <span className="avenews-input__phone-flag" aria-hidden="true">{phoneFlagEmoji}</span>
          <span className="avenews-input__phone-code">{phonePrefix}</span>
        </span>
        {endSlot}
      </IonInput>
    );
  }

  return (
    <IonInput fill="solid" label={labelContent} labelPlacement={labelPlacement} placeholder={placeholder} value={value} type={type} required={required} disabled={disabled} clearInput={clearInput} counter={counter} maxlength={maxlength} helperText={!error ? helperText : undefined} errorText={error} className={rootClass} onIonInput={handleIonInput as never} onIonChange={handleIonChange as never} onIonBlur={() => onIonBlur?.()} onIonFocus={() => onIonFocus?.()}>
    {startSlot}
    {endSlot}
  </IonInput>
  );
};

export default Input;
