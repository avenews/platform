import React, { useEffect, useRef } from 'react';
import { IonIcon } from '@ionic/react';
import { closeOutline } from 'ionicons/icons';

export type ModalVariant = 'dialog' | 'sheet';
export type ModalSize    = 'sm' | 'default' | 'lg' | 'full';

export interface ModalButton {
  text: string;
  role?: 'confirm' | 'cancel' | 'destructive';
  handler?: () => void;
  disabled?: boolean;
}

export interface ModalProps {
  open?: boolean;
  title?: string;
  leftAction?: { text: string; handler?: () => void };
  closeButton?: boolean;
  variant?: ModalVariant;
  size?: ModalSize;
  showHandle?: boolean;
  onDismiss?: () => void;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  buttons?: ModalButton[];
  className?: string;
}

export const Modal: React.FC<ModalProps> = ({
  open        = false,
  title,
  leftAction,
  closeButton = false,
  variant     = 'dialog',
  size        = 'default',
  showHandle  = false,
  onDismiss,
  children,
  footer,
  buttons     = [],
  className,
}) => {
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    boxRef.current?.focus();
    return () => { prev?.focus(); };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onDismiss?.(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open, onDismiss]);

  if (!open) return null;

  const isSheet      = variant === 'sheet';
  const showHeader   = Boolean(title) || Boolean(leftAction) || closeButton;
  const centredTitle = Boolean(leftAction);
  const hasDestructive = buttons.some((b) => b.role === 'destructive');

  return (
    <div
      className={['avenews-modal', isSheet ? 'avenews-modal--sheet' : ''].filter(Boolean).join(' ')}
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? 'avenews-modal-title' : undefined}
    >
      <div className="avenews-modal__backdrop" onClick={onDismiss} aria-hidden="true" />
      <div ref={boxRef} className={['avenews-modal__box', `avenews-modal__box--${variant}`, `avenews-modal__box--${size}`, className].filter(Boolean).join(' ')} tabIndex={-1}>
        {isSheet && showHandle && <div className="avenews-modal__handle" aria-hidden="true" />}
        {showHeader && (
          <div className={['avenews-modal__header', centredTitle ? 'avenews-modal__header--toolbar' : ''].filter(Boolean).join(' ')}>
            {leftAction && (
              <button type="button" className="avenews-modal__toolbar-action avenews-modal__toolbar-action--left" onClick={leftAction.handler ?? onDismiss}>
                {leftAction.text}
              </button>
            )}
            {title && (
              <h2 id="avenews-modal-title" className={['avenews-modal__title', centredTitle ? 'avenews-modal__title--centred' : ''].filter(Boolean).join(' ')}>
                {title}
              </h2>
            )}
            {closeButton && (
              <button type="button" className="avenews-modal__close" onClick={onDismiss} aria-label="Close">
                <IonIcon icon={closeOutline} aria-hidden="true" />
              </button>
            )}
          </div>
        )}
        {children && <div className="avenews-modal__body">{children}</div>}
        {(footer || buttons.length > 0) && (
          <div className={['avenews-modal__footer', hasDestructive ? 'avenews-modal__footer--stacked' : ''].filter(Boolean).join(' ')}>
            {footer ?? buttons.map((btn, i) => {
              const role = btn.role ?? 'confirm';
              return (
                <button
                  key={i}
                  type="button"
                  className={['avenews-modal__btn', `avenews-modal__btn--${role}`, btn.disabled && 'avenews-modal__btn--disabled'].filter(Boolean).join(' ')}
                  onClick={btn.disabled ? undefined : btn.handler}
                  disabled={btn.disabled}
                >
                  {btn.text}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;
