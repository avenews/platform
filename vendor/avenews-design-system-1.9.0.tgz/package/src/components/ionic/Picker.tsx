import React from 'react';
import { IonPicker, IonPickerColumn, IonPickerColumnOption } from '@ionic/react';

export interface PickerOption {
  text: string;
  value: string | number;
  disabled?: boolean;
}

export interface PickerColumnDef {
  name: string;
  options: PickerOption[];
  value?: string | number;
}

export interface PickerProps {
  columns: PickerColumnDef[];
  showButtons?: boolean;
  onConfirm?: (values: Record<string, string | number>) => void;
  onCancel?: () => void;
  onColumnChange?: (columnName: string, value: string | number) => void;
  className?: string;
}

export const Picker: React.FC<PickerProps> = ({
  columns,
  showButtons = false,
  onConfirm,
  onCancel,
  onColumnChange,
  className,
}) => {
  const [currentValues, setCurrentValues] = React.useState<Record<string, string | number>>(() =>
    Object.fromEntries(columns.map((col) => [col.name, col.value ?? col.options[0]?.value ?? '']))
  );

  const handleColumnChange = (name: string, e: CustomEvent) => {
    const val = e.detail.value as string | number;
    setCurrentValues((prev) => ({ ...prev, [name]: val }));
    onColumnChange?.(name, val);
  };

  return (
    <div className={['avenews-picker', className].filter(Boolean).join(' ')}>
      {showButtons && (
        <div className="avenews-picker__actions">
          <button type="button" className="avenews-picker__btn avenews-picker__btn--cancel" onClick={onCancel}>CANCEL</button>
          <button type="button" className="avenews-picker__btn avenews-picker__btn--confirm" onClick={() => onConfirm?.(currentValues)}>CONFIRM</button>
        </div>
      )}
      <div className="avenews-picker__columns">
        <IonPicker className="avenews-picker__ion">
          {columns.map((col) => (
            <IonPickerColumn key={col.name} value={currentValues[col.name]} onIonChange={(e) => handleColumnChange(col.name, e)}>
              {col.options.map((opt) => (
                <IonPickerColumnOption key={String(opt.value)} value={opt.value} disabled={opt.disabled}>
                  {opt.text}
                </IonPickerColumnOption>
              ))}
            </IonPickerColumn>
          ))}
        </IonPicker>
      </div>
    </div>
  );
};

export default Picker;
