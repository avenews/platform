import React, { useRef } from 'react';
import {
  IonCard,
  IonCardContent,
  IonIcon,
  IonProgressBar,
  IonSpinner,
} from '@ionic/react';
import {
  cloudUploadOutline,
  documentOutline,
  checkmarkCircleOutline,
  closeCircleOutline,
  trashOutline,
  refreshOutline,
} from 'ionicons/icons';
import type { UploadCardProps, UploadStatus } from '../shared/types';
import { cn, formatFileSize, clamp, uploadStatusLabel } from '../shared/utils';

export type { UploadCardProps, UploadStatus };

// ─── Status config ────────────────────────────────────────────────────────────

const STATUS_ICON: Record<UploadStatus, string> = {
  empty:     cloudUploadOutline,
  uploading: documentOutline,
  uploaded:  checkmarkCircleOutline,
  approved:  checkmarkCircleOutline,
  rejected:  closeCircleOutline,
};

// ─── Component ────────────────────────────────────────────────────────────────

export const UploadCard: React.FC<UploadCardProps> = ({
  title,
  status   = 'empty',
  fileName,
  fileSize,
  progress = 0,
  required = false,
  disabled = false,
  accept   = '*/*',
  onUpload,
  onRemove,
  className,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pct = clamp(progress, 0, 1);

  const openPicker = () => {
    if (disabled || status === 'uploading' || status === 'approved') return;
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) onUpload?.(file);
    e.target.value = '';
  };

  const showZone     = status === 'empty' || status === 'rejected';
  const showProgress = status === 'uploading';
  const showFile     = (status === 'uploaded' || status === 'approved' || status === 'rejected') && !!fileName;

  return (
    <IonCard
      className={cn(
        'av-ionic-upload-card',
        `av-ionic-upload-card--${status}`,
        disabled && 'av-ionic-upload-card--disabled',
        className,
      )}
    >
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <div className="av-ionic-upload-card__header">
        <span className="av-ionic-upload-card__title">
          {title}
          {required && <span className="av-ionic-upload-card__required" aria-hidden="true">{'\u200A'}*</span>}
        </span>
        <span className={cn('av-ionic-upload-card__badge', `av-ionic-upload-card__badge--${status}`)}>
          <IonIcon icon={STATUS_ICON[status]} className="av-ionic-upload-card__badge-icon" />
          {uploadStatusLabel(status, required)}
        </span>
      </div>

      <IonCardContent className="av-ionic-upload-card__body">

        {/* ── Empty / rejected — upload zone ─────────────────────────── */}
        {showZone && (
          <button
            type="button"
            className="av-upload-zone"
            onClick={openPicker}
            disabled={disabled}
            aria-label={`Upload ${title}`}
          >
            <IonIcon icon={cloudUploadOutline} className="av-upload-zone__icon" />
            <span className="av-upload-zone__label">
              {status === 'rejected' ? 'Re-upload document' : 'Tap to upload'}
            </span>
            <span className="av-upload-zone__hint">PDF, JPG, PNG — max 10 MB</span>
          </button>
        )}

        {/* ── Uploading — progress ────────────────────────────────────── */}
        {showProgress && (
          <div className="av-upload-progress">
            <div className="av-upload-progress__row">
              <IonSpinner name="crescent" className="av-upload-progress__spinner" />
              <span className="av-upload-progress__name">{fileName ?? 'Uploading…'}</span>
              <span className="av-upload-progress__pct">{Math.round(pct * 100)}%</span>
            </div>
            <IonProgressBar value={pct} className="av-upload-progress__bar" />
          </div>
        )}

        {/* ── File info ───────────────────────────────────────────────── */}
        {showFile && (
          <div className="av-upload-file">
            <IonIcon icon={documentOutline} className="av-upload-file__icon" />
            <div className="av-upload-file__meta">
              <span className="av-upload-file__name">{fileName}</span>
              {fileSize != null && (
                <span className="av-upload-file__size">{formatFileSize(fileSize)}</span>
              )}
            </div>
            {onRemove && status !== 'approved' && (
              <button
                type="button"
                className="av-upload-file__remove"
                onClick={onRemove}
                aria-label="Remove file"
              >
                <IonIcon icon={trashOutline} />
              </button>
            )}
          </div>
        )}

        {/* ── Rejected — replace action ───────────────────────────────── */}
        {status === 'rejected' && (
          <button
            type="button"
            className="av-upload-replace"
            onClick={openPicker}
            disabled={disabled}
          >
            <IonIcon icon={refreshOutline} />
            Replace file
          </button>
        )}

      </IonCardContent>

      <input
        ref={fileInputRef}
        type="file"
        accept={accept}
        hidden
        aria-hidden="true"
        onChange={handleFileChange}
      />
    </IonCard>
  );
};

export default UploadCard;
