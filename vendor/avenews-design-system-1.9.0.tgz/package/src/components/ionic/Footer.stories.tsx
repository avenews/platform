import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import { Footer } from './Footer';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Footer> = {
  title:     'Avenews/Ionic/Footer',
  component: Footer,
  tags:      ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Bottom action bar built on `IonFooter` + `IonToolbar`. ' +
          'Supports a caption, full-width block buttons, and slotted start/end buttons. ' +
          'Accepts Ionic color tokens and `translucent` for iOS-style blur.',
      },
    },
    layout: 'fullscreen',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '100%', maxWidth: 420, margin: '0 auto' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color:       { control: 'select', options: ['primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] },
    translucent: { control: 'boolean' },
    caption:     { control: 'text' },
  },
};

export default meta;
type Story = StoryObj<typeof Footer>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: {
    actions: [{ label: 'Continue' }],
  },
};

// ─── Single CTA ───────────────────────────────────────────────────────────────

export const SingleCTA: Story = {
  name: 'CTA / Single block button',
  args: {
    color:   'primary',
    actions: [{ label: 'Submit application' }],
  },
};

export const SingleWithCaption: Story = {
  name: 'CTA / With caption',
  args: {
    caption: 'By continuing you agree to Avenews Terms & Privacy Policy.',
    color:   'primary',
    actions: [{ label: 'Submit application' }],
  },
};

// ─── Slotted actions ─────────────────────────────────────────────────────────

export const SlottedCancelConfirm: Story = {
  name: 'Actions / Cancel + Confirm (slotted)',
  args: {
    actions: [
      { label: 'Cancel',  slot: 'start', fill: 'clear'   },
      { label: 'Confirm', slot: 'end',   fill: 'solid', color: 'primary' },
    ],
  },
};

export const SlottedWithBlock: Story = {
  name: 'Actions / Block + skip',
  args: {
    color:   'light',
    actions: [
      { label: 'Continue',    expand: 'block', fill: 'solid', color: 'primary' },
      { label: 'Skip for now', slot: 'end',    fill: 'clear'  },
    ],
  },
};

// ─── Colors ──────────────────────────────────────────────────────────────────

export const ColorPrimary: Story = {
  name: 'Color / Primary',
  args: { color: 'primary', actions: [{ label: 'Apply for loan' }] },
};

export const ColorDark: Story = {
  name: 'Color / Dark',
  args: { color: 'dark', actions: [{ label: 'Submit securely' }] },
};

export const ColorLight: Story = {
  name: 'Color / Light',
  args: {
    color:   'light',
    actions: [
      { label: 'Cancel',   fill: 'clear', slot: 'start' },
      { label: 'Continue', fill: 'solid', color: 'primary', slot: 'end' },
    ],
  },
};

// ─── Translucent (iOS) ────────────────────────────────────────────────────────

export const Translucent: Story = {
  name: 'Style / Translucent (iOS)',
  args: {
    translucent: true,
    actions:     [{ label: 'Continue', color: 'primary' }],
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanApplication: Story = {
  name: 'App / Loan application',
  args: {
    color:   'primary',
    caption: 'This will not affect your credit score.',
    actions: [{ label: 'Submit application' }],
  },
};

export const AppRepayment: Story = {
  name: 'App / Repayment confirm',
  args: {
    caption: 'KES 25,000 will be debited on 20 Apr 2026.',
    actions: [
      { label: 'Cancel',          slot: 'start', fill: 'clear'                     },
      { label: 'Confirm payment', slot: 'end',   fill: 'solid', color: 'primary' },
    ],
  },
};

export const AppKYCStep: Story = {
  name: 'App / KYC step navigation',
  args: {
    actions: [
      { label: 'Back',  slot: 'start', fill: 'clear'                     },
      { label: 'Next',  slot: 'end',   fill: 'solid', color: 'primary' },
    ],
  },
};

export const AppDocumentUpload: Story = {
  name: 'App / Document upload',
  args: {
    color:   'primary',
    actions: [{ label: 'Upload document' }],
  },
};
