/**
 * Alert is a cross-platform component — its implementation lives in
 * src/components/web/Alert.tsx and the ionic entry simply re-exports it.
 *
 * This story file mirrors the web stories under the Ionic Storybook tree so
 * the component is discoverable from both surfaces. See web/Alert.stories.tsx
 * for the full story set.
 */
import type { Meta, StoryObj } from '@storybook/react';
import { Alert } from './Alert';

const meta: Meta<typeof Alert> = {
  title: 'Avenews/Ionic/Alert',
  component: Alert,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Cross-platform dialog overlay. Implementation is shared with the web build — see Avenews/Web/Alert for the full story catalogue.',
      },
    },
    layout: 'fullscreen',
  },
};

export default meta;
type Story = StoryObj<typeof Alert>;

export const Default: Story = {
  args: {
    open: true,
    header: 'Heads up',
    message: 'This is the cross-platform Alert. Open the Web/Alert stories for variants and inputs.',
    buttons: [{ text: 'OK', role: 'cancel' }],
  },
};
