import React from 'react';
import { IonIcon } from '@ionic/react';

export interface ActionSheetButton {
  text: string;
  icon?: string;
  destructive?: boolean;
  onClick?: () => void;
  disabled?: boolean;
  role?: string;
}

export interface ActionSheetProps {
  open?: boolean;
  header?: string;
  subheader?: string;
  buttons: ActionSheetButton[];
  onDismiss?: () => void;
  className?: string;
}

const ActionSheetItem: React.FC<{ button: ActionSheetButton }> = ({ button }) => {
  const { text, icon, destructive = false, onClick, disabled = false } = button;
  return (
    <button
      className={['avenews-action-sheet__item', destructive && 'avenews-action-sheet__item--destructive', disabled && 'avenews-action-sheet__item--disabled'].filter(Boolean).join(' ')}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      type="button"
    >
      {icon && <IonIcon icon={icon} className="avenews-action-sheet__item-icon" aria-hidden="true" />}
      <span className="avenews-action-sheet__item-text">{text}</span>
    </button>
  );
};

export const ActionSheet: React.FC<ActionSheetProps> = ({
  open = false,
  header,
  subheader,
  buttons = [],
  onDismiss,
  className,
}) => {
  if (!open) return null;
  return (
    <div className="avenews-action-sheet" role="dialog" aria-modal="true" aria-label={header ?? 'Action sheet'}>
      <div className="avenews-action-sheet__backdrop" onClick={onDismiss} aria-hidden="true" />
      <div className={['avenews-action-sheet__box', className].filter(Boolean).join(' ')}>
        {(header || subheader) && (
          <div className="avenews-action-sheet__header">
            {header    && <p className="avenews-action-sheet__header-title">{header}</p>}
            {subheader && <p className="avenews-action-sheet__header-subtitle">{subheader}</p>}
          </div>
        )}
        <div className="avenews-action-sheet__actions">
          {buttons.map((btn, i) => <ActionSheetItem key={i} button={btn} />)}
        </div>
      </div>
    </div>
  );
};

export default ActionSheet;
