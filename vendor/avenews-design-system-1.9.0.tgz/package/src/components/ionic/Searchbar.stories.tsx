import type { Meta, StoryObj } from '@storybook/react';
import { IonHeader, IonTitle, IonToolbar } from '@ionic/react';
import { Searchbar } from './Searchbar';

const meta: Meta<typeof Searchbar> = {
  title: 'Avenews/Ionic/Searchbar',
  component: Searchbar,
  tags: ['autodocs'],
  argTypes: {
    showCancelButton: {
      control: 'radio',
      options: ['never', 'focus', 'always'],
    },
    showClearButton: {
      control: 'radio',
      options: ['never', 'focus', 'always'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof Searchbar>;

// ─── States ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  args: {
    placeholder: 'Search documents',
    debounce: 300,
    showCancelButton: 'focus',
  },
};

export const Loading: Story = {
  args: {
    placeholder: 'Search documents',
    loading: true,
  },
};

export const Error: Story = {
  args: {
    placeholder: 'Search documents',
    error: true,
  },
};

export const Filled: Story = {
  args: {
    placeholder: 'Search documents',
    value: 'National ID',
    showCancelButton: 'always',
    showClearButton: 'always',
  },
};

// ─── In context: Header toolbar ──────────────────────────────────────────────

export const InHeader: Story = {
  name: 'In Header (canonical placement)',
  args: {
    placeholder: 'Search documents',
    showCancelButton: 'focus',
    debounce: 300,
  },
  render: (args) => (
    <IonHeader>
      <IonToolbar>
        <IonTitle>Documents</IonTitle>
      </IonToolbar>
      <IonToolbar>
        <Searchbar {...args} />
      </IonToolbar>
    </IonHeader>
  ),
};
