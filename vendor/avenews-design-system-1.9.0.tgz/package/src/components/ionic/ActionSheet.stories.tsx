import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  createOutline,
  trashOutline,
  shareOutline,
  downloadOutline,
  flagOutline,
} from 'ionicons/icons';
import { ActionSheet } from './ActionSheet';

const meta: Meta<typeof ActionSheet> = {
  title: 'Avenews/Ionic/ActionSheet',
  component: ActionSheet,
  tags: ['autodocs'],
  args: {
    buttons: [],
  },
  argTypes: {
    open: { control: 'boolean' },
    header: { control: 'text' },
    subheader: { control: 'text' },
    buttons: { control: false },
  },
  parameters: {
    layout: 'fullscreen',
  },
};

export default meta;
type Story = StoryObj<typeof ActionSheet>;

// ─── Interactive wrapper ──────────────────────────────────────────────────────

function InteractiveSheet(props: React.ComponentProps<typeof ActionSheet>) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ padding: '24px' }}>
      <button
        onClick={() => setOpen(true)}
        style={{
          padding: '12px 24px',
          background: 'var(--av-color-action)',
          color: '#fff',
          border: 'none',
          borderRadius: 'var(--av-radius-md)',
          cursor: 'pointer',
          fontFamily: 'var(--av-font-body)',
          fontSize: '14px',
          fontWeight: 500,
        }}
      >
        Open Action Sheet
      </button>
      <ActionSheet
        {...props}
        open={open}
        onDismiss={() => setOpen(false)}
        buttons={props.buttons.map((btn) => ({
          ...btn,
          onClick: () => {
            btn.onClick?.();
            setOpen(false);
          },
        }))}
      />
    </div>
  );
}

// ─── Default ─────────────────────────────────────────────────────────────────

export const Default: Story = {
  render: (args) => <InteractiveSheet {...args} />,
  args: {
    header: 'Document options',
    buttons: [
      { text: 'Edit', icon: createOutline },
      { text: 'Share', icon: shareOutline },
      { text: 'Download', icon: downloadOutline },
    ],
  },
};

// ─── With destructive action ──────────────────────────────────────────────────

export const WithDestructive: Story = {
  name: 'With Destructive Action',
  render: (args) => <InteractiveSheet {...args} />,
  args: {
    header: 'Document options',
    buttons: [
      { text: 'Edit', icon: createOutline },
      { text: 'Share', icon: shareOutline },
      { text: 'Delete', icon: trashOutline, destructive: true },
    ],
  },
};

// ─── With subheader ───────────────────────────────────────────────────────────

export const WithSubheader: Story = {
  name: 'With Subheader',
  render: (args) => <InteractiveSheet {...args} />,
  args: {
    header: 'Loan agreement',
    subheader: 'Select an action to apply to this document.',
    buttons: [
      { text: 'View', icon: downloadOutline },
      { text: 'Share', icon: shareOutline },
      { text: 'Flag for review', icon: flagOutline },
      { text: 'Delete', icon: trashOutline, destructive: true },
    ],
  },
};

// ─── No header ────────────────────────────────────────────────────────────────

export const NoHeader: Story = {
  name: 'No Header',
  render: (args) => <InteractiveSheet {...args} />,
  args: {
    buttons: [
      { text: 'Edit' },
      { text: 'Share' },
      { text: 'Download' },
      { text: 'Delete', destructive: true },
    ],
  },
};

// ─── Static preview (always open) ────────────────────────────────────────────

export const StaticPreview: Story = {
  name: 'Static Preview',
  render: () => (
    <div style={{ position: 'relative', height: '500px', background: 'var(--av-color-surface-subtle)', overflow: 'hidden' }}>
      <ActionSheet
        open
        header="Document options"
        subheader="Choose what to do with this file."
        buttons={[
          { text: 'Edit', icon: createOutline },
          { text: 'Share', icon: shareOutline },
          { text: 'Download', icon: downloadOutline },
          { text: 'Delete', icon: trashOutline, destructive: true },
        ]}
      />
    </div>
  ),
};

// ─── All states ───────────────────────────────────────────────────────────────

export const AllStates: Story = {
  name: 'Item States (Hover & Destructive)',
  render: () => (
    <div style={{ display: 'flex', gap: '24px', flexWrap: 'wrap', padding: '24px' }}>
      {/* Normal item */}
      <div>
        <p style={{ fontFamily: 'var(--av-font-body)', fontSize: '12px', color: 'var(--av-color-text-muted)', marginBottom: '8px' }}>
          Default
        </p>
        <div style={{ background: 'var(--av-color-surface)', borderRadius: 'var(--av-radius-lg)', overflow: 'hidden', width: '280px' }}>
          <button className="avenews-action-sheet__item" style={{ width: '100%' }}>
            <span className="avenews-action-sheet__item-text">Edit document</span>
          </button>
          <button className="avenews-action-sheet__item" style={{ width: '100%' }}>
            <span className="avenews-action-sheet__item-text">Share</span>
          </button>
          <button className="avenews-action-sheet__item avenews-action-sheet__item--destructive" style={{ width: '100%' }}>
            <span className="avenews-action-sheet__item-text">Delete</span>
          </button>
          <button className="avenews-action-sheet__item avenews-action-sheet__item--disabled" style={{ width: '100%' }} disabled>
            <span className="avenews-action-sheet__item-text">Disabled action</span>
          </button>
        </div>
      </div>
    </div>
  ),
};
