/**
 * DocumentRow is a cross-platform component — implementation lives at
 * src/components/web/DocumentRow.tsx. The ionic entry re-exports it.
 *
 * See web/DocumentRow.stories.tsx for the full story catalogue.
 */
import type { Meta, StoryObj } from '@storybook/react';
import { DocumentRow } from './DocumentRow';

const meta: Meta<typeof DocumentRow> = {
  title: 'Avenews/Ionic/DocumentRow',
  component: DocumentRow,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Cross-platform document row used inside DocumentCategoryCard. Implementation shared with the web build — see Avenews/Web/DocumentRow.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof DocumentRow>;

export const ActionRequired: Story = {
  args: { name: 'Proof of address', status: 'action_required' },
};
export const InReview: Story = {
  args: { name: 'KYC document', status: 'in_review' },
};
export const Completed: Story = {
  args: { name: 'Bank statement', status: 'completed' },
};
export const Optional: Story = {
  args: { name: 'Trade reference', status: 'optional' },
};
export const Loading: Story = {
  args: { name: '', status: 'optional', loading: true },
};
