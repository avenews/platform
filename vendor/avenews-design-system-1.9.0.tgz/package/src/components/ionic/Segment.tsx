import React from 'react';
import { IonSegment, IonSegmentButton, IonLabel, IonIcon } from '@ionic/react';

export interface SegmentOption {
  value: string;
  label?: string;
  icon?: string;
  iconPosition?: 'start' | 'end' | 'top' | 'bottom' | 'icon-only';
  disabled?: boolean;
}

export interface SegmentProps {
  options: SegmentOption[];
  value?: string;
  scrollable?: boolean;
  onIonChange?: (value: string) => void;
  className?: string;
}

export const Segment: React.FC<SegmentProps> = ({
  options,
  value,
  scrollable = false,
  onIonChange,
  className,
}) => (
  <IonSegment
    className={['avenews-segment', className].filter(Boolean).join(' ')}
    value={value}
    scrollable={scrollable}
    onIonChange={(e) => onIonChange?.(e.detail.value as string)}
  >
    {options.map((opt) => {
      const showIcon  = opt.icon && opt.iconPosition !== undefined;
      const showLabel = opt.label && opt.iconPosition !== 'icon-only';
      return (
        <IonSegmentButton key={opt.value} value={opt.value} disabled={opt.disabled} className="avenews-segment__button">
          {showIcon && (opt.iconPosition === 'start' || opt.iconPosition === 'top')   && <IonIcon icon={opt.icon} />}
          {showLabel && <IonLabel>{opt.label}</IonLabel>}
          {showIcon && (opt.iconPosition === 'end'   || opt.iconPosition === 'bottom') && <IonIcon icon={opt.icon} />}
          {opt.iconPosition === 'icon-only' && opt.icon && <IonIcon icon={opt.icon} aria-label={opt.label} />}
        </IonSegmentButton>
      );
    })}
  </IonSegment>
);

export default Segment;
