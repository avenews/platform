import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  cashOutline,
  documentTextOutline,
  receiptOutline,
  timeOutline,
  personOutline,
  callOutline,
  mailOutline,
  businessOutline,
  locationOutline,
  cardOutline,
  checkmarkCircleOutline,
  alertCircleOutline,
  chevronForwardOutline,
} from 'ionicons/icons';
import { IonIcon } from '@ionic/react';
import { List, ListHeader } from './List';
import { Item, ItemDivider } from './Item';
import { Badge } from './Badge';
import { Note } from './Note';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof List> = {
  title: 'Avenews/Ionic/List',
  component: List,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Wraps `IonList` — a container for `Item`, `ItemDivider`, and other row components.',
          'Supports inset mode (16px margin + 8px radius), full/inset/none divider lines,',
          'and 10 color tokens. Use `ListHeader` for section headings in default (16px) or large (20px) sizes.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '390px', background: 'var(--av-color-surface-subtle, #f3f5f7)', padding: '24px 0' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    lines: {
      control: 'select',
      options: ['full', 'inset', 'none'],
    },
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'],
    },
    inset: { control: 'boolean' },
  },
  args: {
    inset: false,
    lines: 'inset',
  },
};

export default meta;
type Story = StoryObj<typeof List>;

// ─── Default ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  render: (args) => (
    <List {...args}>
      <Item label="First item" />
      <Item label="Second item" />
      <Item label="Third item" lines="none" />
    </List>
  ),
};

// ─── ListHeader sizes ─────────────────────────────────────────────────────────

export const HeaderDefault: Story = {
  name: 'ListHeader / Default (16px)',
  render: () => (
    <List>
      <ListHeader label="Section heading" />
      <Item label="First item" />
      <Item label="Second item" />
      <Item label="Third item" lines="none" />
    </List>
  ),
};

export const HeaderLarge: Story = {
  name: 'ListHeader / Large (20px)',
  render: () => (
    <List>
      <ListHeader label="Section heading" size="large" />
      <Item label="First item" />
      <Item label="Second item" />
      <Item label="Third item" lines="none" />
    </List>
  ),
};

// ─── Lines variants ───────────────────────────────────────────────────────────

export const LinesInset: Story = {
  name: 'Lines / Inset (default)',
  render: () => (
    <List lines="inset">
      <Item label="Item one" startSlot={<IonIcon icon={personOutline} />} />
      <Item label="Item two" startSlot={<IonIcon icon={mailOutline} />} />
      <Item label="Item three" startSlot={<IonIcon icon={callOutline} />} lines="none" />
    </List>
  ),
};

export const LinesFull: Story = {
  name: 'Lines / Full',
  render: () => (
    <List lines="full">
      <Item label="Item one" />
      <Item label="Item two" />
      <Item label="Item three" lines="none" />
    </List>
  ),
};

export const LinesNone: Story = {
  name: 'Lines / None',
  render: () => (
    <List lines="none">
      <Item label="Item one" />
      <Item label="Item two" />
      <Item label="Item three" />
    </List>
  ),
};

// ─── Inset mode ───────────────────────────────────────────────────────────────

export const InsetMode: Story = {
  name: 'Inset / Rounded container',
  render: () => (
    <div style={{ padding: '0 16px' }}>
      <List inset lines="none">
        <Item label="Full name" startSlot={<IonIcon icon={personOutline} />} />
        <Item label="Email address" startSlot={<IonIcon icon={mailOutline} />} />
        <Item label="Phone number" startSlot={<IonIcon icon={callOutline} />} lines="none" />
      </List>
    </div>
  ),
};

export const InsetWithHeader: Story = {
  name: 'Inset / With header',
  render: () => (
    <div style={{ padding: '0 16px' }}>
      <List inset lines="none">
        <ListHeader label="Account details" />
        <Item label="Full name" startSlot={<IonIcon icon={personOutline} />} />
        <Item label="Business name" startSlot={<IonIcon icon={businessOutline} />} />
        <Item label="Location" startSlot={<IonIcon icon={locationOutline} />} lines="none" />
      </List>
    </div>
  ),
};

// ─── Figma List 1 — large header + icon rows, no lines ────────────────────────

export const AvenewsList1: Story = {
  name: 'Avenews / List 1 — Icon + title + description',
  render: () => (
    <List lines="none">
      <ListHeader label="Loan requirements" size="large" />
      <Item
        label="Business registration"
        secondLine="Upload your certificate of incorporation"
        startSlot={<IonIcon icon={documentTextOutline} />}
        button
        detailArrow
      />
      <Item
        label="Bank statements"
        secondLine="Last 6 months required"
        startSlot={<IonIcon icon={cardOutline} />}
        button
        detailArrow
      />
      <Item
        label="KRA PIN certificate"
        secondLine="Valid government-issued PIN"
        startSlot={<IonIcon icon={receiptOutline} />}
        button
        detailArrow
        lines="none"
      />
    </List>
  ),
};

// ─── Figma List 2 — large header + icon rows, description-only ───────────────

export const AvenewsList2: Story = {
  name: 'Avenews / List 2 — Icon + description only',
  render: () => (
    <List lines="none">
      <ListHeader label="How it works" size="large" />
      <Item
        label="Apply online in minutes"
        startSlot={<IonIcon icon={documentTextOutline} />}
      />
      <Item
        label="Get approval within 24 hours"
        startSlot={<IonIcon icon={timeOutline} />}
      />
      <Item
        label="Funds disbursed directly to your account"
        startSlot={<IonIcon icon={cashOutline} />}
        lines="none"
      />
    </List>
  ),
};

// ─── Figma List 3 — divider header + list3-variant rows ──────────────────────

export const AvenewsList3: Story = {
  name: 'Avenews / List 3 — Divider header + list3 rows',
  render: () => (
    <List lines="full">
      <ItemDivider label="Recent invoices" />
      <Item
        variant="list3"
        label="Invoice #2847"
        secondLine="Nairobi Traders Ltd"
        thirdLine="KES 45,000"
        startSlot={<IonIcon icon={cashOutline} />}
        endSlot={<Note label="14 Jan" color="default" />}
        button
        detailArrow
      />
      <Item
        variant="list3"
        label="Repayment due"
        secondLine="Avenews Finance"
        thirdLine="KES 120,000"
        startSlot={<IonIcon icon={receiptOutline} />}
        endSlot={<Note label="28 Jan" color="warning" />}
        button
        detailArrow
      />
      <Item
        variant="list3"
        label="Invoice #2801"
        secondLine="Mombasa Suppliers"
        thirdLine="KES 18,500"
        startSlot={<IonIcon icon={cashOutline} />}
        endSlot={<Note label="3 Feb" color="success" />}
        button
        detailArrow
        lines="none"
      />
    </List>
  ),
};

// ─── Figma List 4 — large header + 3-line rows ───────────────────────────────

export const AvenewsList4: Story = {
  name: 'Avenews / List 4 — Large header + 3-line rows',
  render: () => (
    <List lines="none">
      <ListHeader label="Active loans" size="large" />
      <Item
        variant="list3"
        label="Working capital"
        secondLine="KES 500,000"
        thirdLine="Due 28 Feb 2025"
        startSlot={<IonIcon icon={cashOutline} />}
        endSlot={<Badge count="Active" variant="success" />}
        button
        detailArrow
      />
      <Item
        variant="list3"
        label="Invoice financing"
        secondLine="KES 120,000"
        thirdLine="Due 14 Mar 2025"
        startSlot={<IonIcon icon={receiptOutline} />}
        endSlot={<Badge count="Review" variant="warning" />}
        button
        detailArrow
      />
      <Item
        variant="list3"
        label="Asset finance"
        secondLine="KES 250,000"
        thirdLine="Due 30 Apr 2025"
        startSlot={<IonIcon icon={cardOutline} />}
        endSlot={<Badge count="Pending" variant="medium" />}
        button
        detailArrow
        lines="none"
      />
    </List>
  ),
};

// ─── ItemDivider sections ─────────────────────────────────────────────────────

export const WithDividers: Story = {
  name: 'Structure / ItemDivider sections',
  render: () => (
    <List lines="inset">
      <ItemDivider label="Personal details" />
      <Item label="Full name" startSlot={<IonIcon icon={personOutline} />} endSlot={<Note label="Verified" color="success" />} />
      <Item label="Phone" startSlot={<IonIcon icon={callOutline} />} />
      <Item label="Email" startSlot={<IonIcon icon={mailOutline} />} lines="none" />
      <ItemDivider label="Business details" />
      <Item label="Company name" startSlot={<IonIcon icon={businessOutline} />} />
      <Item label="Location" startSlot={<IonIcon icon={locationOutline} />} lines="none" />
    </List>
  ),
};

// ─── All colors ───────────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'Color / All colors',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', padding: '0 16px' }}>
      {(['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] as const).map((color) => (
        <List key={color} inset lines="none" color={color !== 'default' ? color : undefined}>
          <ListHeader label={color.charAt(0).toUpperCase() + color.slice(1)} color={color !== 'default' ? color : undefined} />
          <Item label="First item" color={color !== 'default' ? color : undefined} />
          <Item label="Second item" color={color !== 'default' ? color : undefined} lines="none" />
        </List>
      ))}
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppDocumentChecklist: Story = {
  name: 'App / Document checklist',
  render: () => (
    <List lines="inset">
      <ListHeader label="Required documents" />
      <Item
        label="Business registration"
        secondLine="Certificate of incorporation"
        startSlot={<IonIcon icon={checkmarkCircleOutline} color="success" />}
        endSlot={<Badge count="Done" variant="success" />}
        button
        detailArrow
      />
      <Item
        label="Bank statements"
        secondLine="Last 6 months · Missing"
        startSlot={<IonIcon icon={alertCircleOutline} color="warning" />}
        endSlot={<Badge count="Upload" variant="warning" />}
        button
        detailArrow
      />
      <Item
        label="KRA PIN certificate"
        secondLine="Government-issued"
        startSlot={<IonIcon icon={checkmarkCircleOutline} color="success" />}
        endSlot={<Badge count="Done" variant="success" />}
        button
        detailArrow
        lines="none"
      />
    </List>
  ),
};

export const AppLoanSummary: Story = {
  name: 'App / Loan summary',
  render: () => (
    <div style={{ padding: '0 16px' }}>
      <List inset lines="none">
        <ListHeader label="Loan details" size="large" />
        <Item label="Amount" endSlot={<Note label="KES 500,000" color="primary" />} />
        <Item label="Tenure" endSlot={<Note label="12 months" />} />
        <Item label="Interest rate" endSlot={<Note label="1.5% / month" />} />
        <Item label="Monthly repayment" endSlot={<Note label="KES 46,250" color="primary" />} />
        <Item label="Disbursement date" endSlot={<Note label="3 Feb 2025" color="success" />} lines="none" />
      </List>
    </div>
  ),
};

export const AppProfileSettings: Story = {
  name: 'App / Profile settings',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <List lines="inset">
        <ListHeader label="Account" />
        <Item label="Full name" startSlot={<IonIcon icon={personOutline} />} button detailArrow />
        <Item label="Email" startSlot={<IonIcon icon={mailOutline} />} secondLine="info@nairobi.co.ke" button detailArrow />
        <Item label="Phone" startSlot={<IonIcon icon={callOutline} />} secondLine="+254 700 000 000" button detailArrow lines="none" />
      </List>
      <List lines="inset">
        <ListHeader label="Business" />
        <Item label="Company name" startSlot={<IonIcon icon={businessOutline} />} button detailArrow />
        <Item label="Location" startSlot={<IonIcon icon={locationOutline} />} button detailArrow lines="none" />
      </List>
    </div>
  ),
};
