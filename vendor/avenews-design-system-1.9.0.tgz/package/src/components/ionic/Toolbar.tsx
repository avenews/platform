import React from 'react';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonBackButton,
  IonButton,
  IonIcon,
} from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────

export type ToolbarColor = 'primary' | 'secondary' | 'tertiary' | 'success' | 'warning' | 'danger' | 'light' | 'medium' | 'dark';

export interface ToolbarAction {
  /** Ionicons icon string */
  icon:      string;
  label:     string;
  onClick?:  () => void;
  disabled?: boolean;
}

export interface ToolbarProps {
  title?:           string;
  color?:           ToolbarColor;
  showBackButton?:  boolean;
  defaultHref?:     string;
  backText?:        string;
  trailingActions?: ToolbarAction[];
  translucent?:     boolean;
  className?:       string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Toolbar: React.FC<ToolbarProps> = ({
  title,
  color,
  showBackButton  = false,
  defaultHref     = '/',
  backText,
  trailingActions = [],
  translucent     = false,
  className,
}) => (
  <IonHeader
    translucent={translucent}
    className={['avenews-toolbar', className].filter(Boolean).join(' ')}
  >
    <IonToolbar color={color} className="avenews-toolbar__bar">
      {showBackButton && (
        <IonButtons slot="start">
          <IonBackButton
            defaultHref={defaultHref}
            text={backText}
            className="avenews-toolbar__back"
          />
        </IonButtons>
      )}

      {title && (
        <IonTitle className="avenews-toolbar__title">{title}</IonTitle>
      )}

      {trailingActions.length > 0 && (
        <IonButtons slot="end">
          {trailingActions.map((action, i) => (
            <IonButton
              key={i}
              fill="clear"
              disabled={action.disabled}
              onClick={action.onClick}
              aria-label={action.label}
              className="avenews-toolbar__action"
            >
              <IonIcon icon={action.icon} slot="icon-only" />
            </IonButton>
          ))}
        </IonButtons>
      )}
    </IonToolbar>
  </IonHeader>
);

export default Toolbar;
