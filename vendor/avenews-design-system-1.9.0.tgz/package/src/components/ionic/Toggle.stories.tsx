import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { IonList } from '@ionic/react';
import { Toggle } from './Toggle';

const meta: Meta<typeof Toggle> = {
  title: 'Avenews/Ionic/Toggle',
  component: Toggle,
  tags: ['autodocs'],
  argTypes: {
    label: { control: 'text' },
    helperText: { control: 'text' },
    checked: { control: 'boolean' },
    disabled: { control: 'boolean' },
  },
};

export default meta;
type Story = StoryObj<typeof Toggle>;

// ─── States ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  args: {
    label: 'Email notifications',
    checked: false,
  },
};

export const Checked: Story = {
  args: {
    label: 'Email notifications',
    checked: true,
  },
};

export const WithHelperText: Story = {
  args: {
    label: 'SMS updates',
    helperText: 'Receive status updates via text message',
    checked: true,
  },
};

export const Disabled: Story = {
  args: {
    label: 'Push notifications',
    helperText: 'Requires notification permissions',
    checked: false,
    disabled: true,
  },
};

export const DisabledOn: Story = {
  name: 'Disabled (locked on)',
  args: {
    label: 'Two-factor authentication',
    helperText: 'Required by your account security policy',
    checked: true,
    disabled: true,
  },
};

// ─── Interactive ──────────────────────────────────────────────────────────────

export const Interactive: Story = {
  name: 'Interactive (controlled)',
  render: () => {
    const [email, setEmail] = useState(true);
    const [sms, setSms] = useState(false);
    const [push, setPush] = useState(true);
    return (
      <div style={{ maxWidth: '400px' }}>
        <IonList>
          <Toggle
            label="Email notifications"
            checked={email}
            onIonChange={setEmail}
          />
          <Toggle
            label="SMS updates"
            helperText="Receive status updates via text message"
            checked={sms}
            onIonChange={setSms}
          />
          <Toggle
            label="Push notifications"
            checked={push}
            onIonChange={setPush}
          />
        </IonList>
      </div>
    );
  },
};

// ─── Settings list ───────────────────────────────────────────────────────────

export const SettingsList: Story = {
  name: 'Settings List',
  render: () => (
    <div style={{ maxWidth: '400px' }}>
      <IonList>
        <Toggle label="Email notifications" checked={true} />
        <Toggle
          label="SMS updates"
          helperText="Receive status updates via text message"
          checked={false}
        />
        <Toggle label="Push notifications" checked={true} />
        <Toggle
          label="Marketing communications"
          helperText="Offers, tips, and product updates"
          checked={false}
        />
      </IonList>
    </div>
  ),
};
