import React from 'react';
import { IonItem, IonLabel, IonToggle } from '@ionic/react';

export interface ToggleProps {
  label: string;
  helperText?: string;
  checked?: boolean;
  disabled?: boolean;
  onIonChange?: (checked: boolean) => void;
  className?: string;
}

export const Toggle: React.FC<ToggleProps> = ({
  label,
  helperText,
  checked  = false,
  disabled = false,
  onIonChange,
  className,
}) => (
  <IonItem lines="none" className={['avenews-toggle-item', className].filter(Boolean).join(' ')}>
    <IonLabel>
      {label}
      {helperText && (
        <p style={{ fontSize: '12px', color: 'var(--av-color-text-muted)', marginTop: '2px', fontWeight: 400 }}>
          {helperText}
        </p>
      )}
    </IonLabel>
    <IonToggle
      slot="end"
      checked={checked}
      disabled={disabled}
      onIonChange={(e) => onIonChange?.(e.detail.checked)}
      style={{ '--track-background-checked': 'var(--av-color-action)', '--handle-background': '#ffffff' }}
      aria-label={label}
    />
  </IonItem>
);

export default Toggle;
