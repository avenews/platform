import type { Meta, StoryObj } from '@storybook/react';
import { IonButton, IonButtons, IonContent, IonHeader, IonModal, IonTitle, IonToolbar } from '@ionic/react';
import { useRef, useState } from 'react';
import { Picker } from './Picker';
import type { PickerColumnDef } from './Picker';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Picker> = {
  title: 'Avenews/Ionic/Picker',
  component: Picker,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Wraps `IonPicker` + `IonPickerColumn` + `IonPickerColumnOption`.',
          'Supports 1–3 independent scroll-wheel columns with optional Cancel / Confirm action buttons.',
          'Use inline (embedded) or wrap in `IonModal` for the Figma bottom-sheet pattern.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
  args: {
    showButtons: true,
    columns: [
      {
        name: 'month',
        value: 'Jun',
        options: [
          { text: 'Jan', value: 'Jan' },
          { text: 'Feb', value: 'Feb' },
          { text: 'Mar', value: 'Mar' },
          { text: 'Apr', value: 'Apr' },
          { text: 'May', value: 'May' },
          { text: 'Jun', value: 'Jun' },
          { text: 'Jul', value: 'Jul' },
          { text: 'Aug', value: 'Aug' },
          { text: 'Sep', value: 'Sep' },
          { text: 'Oct', value: 'Oct' },
          { text: 'Nov', value: 'Nov' },
          { text: 'Dec', value: 'Dec' },
        ],
      },
    ],
  },
};

export default meta;
type Story = StoryObj<typeof Picker>;

// ─── Sample data ──────────────────────────────────────────────────────────────

const MONTHS: PickerColumnDef = {
  name: 'month',
  value: 'Jun',
  options: [
    { text: 'Jan', value: 'Jan' }, { text: 'Feb', value: 'Feb' },
    { text: 'Mar', value: 'Mar' }, { text: 'Apr', value: 'Apr' },
    { text: 'May', value: 'May' }, { text: 'Jun', value: 'Jun' },
    { text: 'Jul', value: 'Jul' }, { text: 'Aug', value: 'Aug' },
    { text: 'Sep', value: 'Sep' }, { text: 'Oct', value: 'Oct' },
    { text: 'Nov', value: 'Nov' }, { text: 'Dec', value: 'Dec' },
  ],
};

const YEARS: PickerColumnDef = {
  name: 'year',
  value: 2024,
  options: Array.from({ length: 10 }, (_, i) => ({
    text: String(2020 + i),
    value: 2020 + i,
  })),
};

const DAYS: PickerColumnDef = {
  name: 'day',
  value: 12,
  options: Array.from({ length: 31 }, (_, i) => ({
    text: String(i + 1).padStart(2, '0'),
    value: i + 1,
  })),
};

const HOURS: PickerColumnDef = {
  name: 'hour',
  value: 10,
  options: Array.from({ length: 24 }, (_, i) => ({
    text: String(i).padStart(2, '0'),
    value: i,
  })),
};

const MINUTES: PickerColumnDef = {
  name: 'minute',
  value: 0,
  options: Array.from({ length: 60 }, (_, i) => ({
    text: String(i).padStart(2, '0'),
    value: i,
  })),
};

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (single column, month)',
  args: {
    columns: [MONTHS],
    showButtons: true,
  },
};

// ─── Column counts ────────────────────────────────────────────────────────────

export const OneColumn: Story = {
  name: 'Columns / One (year)',
  args: {
    columns: [YEARS],
    showButtons: true,
  },
};

export const TwoColumns: Story = {
  name: 'Columns / Two (month + year)',
  args: {
    columns: [MONTHS, YEARS],
    showButtons: true,
  },
};

export const ThreeColumns: Story = {
  name: 'Columns / Three (day + month + year)',
  args: {
    columns: [DAYS, MONTHS, YEARS],
    showButtons: true,
  },
};

export const TimePicker: Story = {
  name: 'Columns / Time (HH : MM)',
  args: {
    columns: [HOURS, MINUTES],
    showButtons: true,
  },
};

// ─── Without buttons ──────────────────────────────────────────────────────────

export const NoButtons: Story = {
  name: 'Without action buttons',
  args: {
    columns: [MONTHS, YEARS],
    showButtons: false,
  },
};

// ─── Interactive ──────────────────────────────────────────────────────────────

export const WithLogging: Story = {
  name: 'Interactive — logs selected value',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [result, setResult] = useState<string>('(not confirmed yet)');

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', alignItems: 'center' }}>
        <Picker
          columns={[MONTHS, YEARS]}
          showButtons
          onConfirm={(vals) => setResult(`${vals.month} ${vals.year}`)}
          onCancel={() => setResult('(cancelled)')}
        />
        <p style={{
          fontFamily: 'var(--av-font-body)',
          fontSize: '14px',
          color: 'var(--av-color-text-muted)',
          margin: 0,
        }}>
          Selected: <strong>{result}</strong>
        </p>
      </div>
    );
  },
};

// ─── Modal pattern (Figma bottom-sheet) ──────────────────────────────────────

export const InModal: Story = {
  name: 'Bottom-sheet pattern (IonModal)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const modal = useRef<HTMLIonModalElement>(null);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [selected, setSelected] = useState<string>('(none)');

    return (
      <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px', alignItems: 'flex-start' }}>
        <p style={{
          fontFamily: 'var(--av-font-body)',
          fontSize: '14px',
          color: 'var(--av-color-text-muted)',
          margin: 0,
        }}>
          Tap the button to open the picker in a bottom-sheet modal — matching the Figma "Picker" pattern.
        </p>

        <IonButton
          id="open-picker-modal"
          className="avenews-button"
          style={{ '--background': 'var(--av-color-action)', '--color': '#fff' } as React.CSSProperties}
        >
          Select date
        </IonButton>

        <p style={{
          fontFamily: 'var(--av-font-body)',
          fontSize: '14px',
          color: 'var(--av-color-text-heading)',
          margin: 0,
        }}>
          Selected: <strong>{selected}</strong>
        </p>

        <IonModal
          ref={modal}
          trigger="open-picker-modal"
          initialBreakpoint={0.35}
          breakpoints={[0, 0.35]}
          style={{ '--border-radius': '12px 12px 0 0' } as React.CSSProperties}
        >
          <IonHeader>
            <IonToolbar>
              <IonTitle style={{ fontFamily: 'var(--av-font-body)', fontSize: '16px' }}>
                Select date
              </IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => modal.current?.dismiss()}>Done</IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <Picker
              columns={[DAYS, MONTHS, YEARS]}
              showButtons
              onConfirm={(vals) => {
                setSelected(`${String(vals.day).padStart(2, '0')} ${vals.month} ${vals.year}`);
                modal.current?.dismiss();
              }}
              onCancel={() => modal.current?.dismiss()}
            />
          </IonContent>
        </IonModal>
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const RepaymentDatePicker: Story = {
  name: 'App / Repayment date (month + year)',
  args: {
    columns: [MONTHS, YEARS],
    showButtons: true,
  },
};

export const FundRequestAmountPicker: Story = {
  name: 'App / Amount picker (whole + fraction)',
  args: {
    showButtons: true,
    columns: [
      {
        name: 'whole',
        value: 10000,
        options: [5000, 10000, 15000, 20000, 25000, 50000, 75000, 100000].map((v) => ({
          text: v.toLocaleString(),
          value: v,
        })),
      },
      {
        name: 'fraction',
        value: 0,
        options: [0, 25, 50, 75].map((v) => ({
          text: `.${String(v).padStart(2, '0')}`,
          value: v,
        })),
      },
    ],
  },
};
