import React from 'react';
import { IonIcon } from '@ionic/react';
import {
  checkmarkCircleOutline,
  warningOutline,
  informationCircleOutline,
  alertCircleOutline,
  closeOutline,
} from 'ionicons/icons';

export type InlineBannerVariant = 'success' | 'warning' | 'info' | 'danger';

export interface InlineBannerProps {
  message: string;
  variant?: InlineBannerVariant;
  dismissible?: boolean;
  onDismiss?: () => void;
  className?: string;
}

const ICONS: Record<InlineBannerVariant, string> = {
  success: checkmarkCircleOutline,
  warning: warningOutline,
  info:    informationCircleOutline,
  danger:  alertCircleOutline,
};

export const InlineBanner: React.FC<InlineBannerProps> = ({
  message,
  variant     = 'info',
  dismissible = false,
  onDismiss,
  className,
}) => (
  <div
    className={['avenews-inline-banner', `avenews-inline-banner--${variant}`, className].filter(Boolean).join(' ')}
    role="status"
    aria-live="polite"
  >
    <IonIcon icon={ICONS[variant]} style={{ flexShrink: 0, fontSize: '20px' }} />
    <p style={{ flex: 1, margin: 0 }}>{message}</p>
    {dismissible && (
      <IonIcon
        icon={closeOutline}
        onClick={onDismiss}
        style={{ cursor: 'pointer', flexShrink: 0, fontSize: '18px', color: 'var(--av-color-text-muted)' }}
        aria-label="Dismiss"
      />
    )}
  </div>
);

export default InlineBanner;
