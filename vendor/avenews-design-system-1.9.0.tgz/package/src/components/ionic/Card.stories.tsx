import type { Meta, StoryObj } from '@storybook/react';
import { IonBadge, IonChip, IonItem, IonLabel, IonList, IonProgressBar } from '@ionic/react';
import { Card } from './Card';
import type { CardColor } from './Card';

const meta: Meta<typeof Card> = {
  title: 'Avenews/Ionic/Card',
  component: Card,
  tags: ['autodocs'],
  // Required prop default — prevents autodocs silent failure
  args: {
    title: 'Card title',
  },
  argTypes: {
    color: {
      control: 'select',
      options: [
        'default',
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark',
      ] satisfies CardColor[],
      description: 'Background colour variant. Non-default colours render inverted (white) action buttons.',
    },
    layout: {
      control: 'select',
      options: ['default', 'media', 'list'],
      description: 'Content layout — does not affect visual style.',
    },
  },
  decorators: [(Story) => (
    <div style={{ maxWidth: '360px', padding: '16px', background: 'var(--av-color-surface-subtle)' }}>
      <Story />
    </div>
  )],
};

export default meta;
type Story = StoryObj<typeof Card>;

// ─── Base states ──────────────────────────────────────────────────────────────

export const Default: Story = {
  args: {
    subtitle: 'Owner Details',
    title: 'Brendan Meyer',
    body: 'Review the business owner information before submitting your application.',
  },
};

export const Loading: Story = {
  args: {
    title: 'Brendan Meyer',
    loading: true,
    layout: 'media',
    imageUrl: 'https://example.com/placeholder.jpg',
  },
};

export const ErrorState: Story = {
  name: 'Error',
  args: {
    subtitle: 'Owner Details',
    title: 'Owner Details',
    error: 'Failed to load card content. Please try again.',
  },
};

export const Disabled: Story = {
  args: {
    subtitle: 'Document Category',
    title: 'Owner Details',
    body: 'This section is currently unavailable.',
    disabled: true,
  },
};

// ─── Layout variants ──────────────────────────────────────────────────────────

export const Media: Story = {
  args: {
    layout: 'media',
    subtitle: 'Your Application',
    title: 'Business Registration',
    body: 'Complete your business registration documents to proceed.',
    imageUrl: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=400&h=160&fit=crop',
    imageAlt: 'Business documents',
    actions: [
      { label: 'View Details' },
      { label: 'Download', variant: 'outline' },
    ],
  },
};

export const WithList: Story = {
  args: {
    layout: 'list',
    title: 'Required Documents',
    listContent: (
      <IonList lines="none">
        <IonItem><IonLabel>Upload National ID</IonLabel></IonItem>
        <IonItem><IonLabel>Upload KRA Certificate</IonLabel></IonItem>
        <IonItem><IonLabel>Upload Business Permit</IonLabel></IonItem>
      </IonList>
    ),
  },
};

export const Tappable: Story = {
  args: {
    subtitle: 'Document Category',
    title: 'Owner Details',
    body: 'Tap to view the required documents for this category.',
    tappable: true,
  },
};

export const WithActions: Story = {
  args: {
    subtitle: 'Destination',
    title: 'Kenya',
    body: 'Your loan application targets businesses operating in Kenya.',
    actions: [
      { label: 'Apply Now' },
      { label: 'Learn More', variant: 'ghost' },
    ],
  },
};

// ─── Colour variants (one story per Figma colour) ─────────────────────────────

const colorArgs = {
  subtitle: 'Card subtitle',
  title: 'Card title',
  body: 'Text content displayed on this coloured card.',
  actions: [{ label: 'Button text' }, { label: 'Button text' }],
};

export const Primary: Story = {
  args: { ...colorArgs, color: 'primary' },
};

export const Secondary: Story = {
  args: { ...colorArgs, color: 'secondary' },
};

export const Tertiary: Story = {
  args: { ...colorArgs, color: 'tertiary' },
};

export const Success: Story = {
  args: { ...colorArgs, color: 'success' },
};

export const Warning: Story = {
  args: { ...colorArgs, color: 'warning' },
};

export const Danger: Story = {
  args: { ...colorArgs, color: 'danger' },
};

export const Light: Story = {
  args: { ...colorArgs, color: 'light' },
};

export const Medium: Story = {
  args: { ...colorArgs, color: 'medium' },
};

export const Dark: Story = {
  args: { ...colorArgs, color: 'dark' },
};

// ─── All colours — overview grid ──────────────────────────────────────────────

export const AllColors: Story = {
  name: 'All Colour Variants',
  decorators: [(Story) => (
    <div style={{ maxWidth: '760px', padding: '16px', background: 'var(--av-color-surface-subtle)' }}>
      <Story />
    </div>
  )],
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
      {(
        [
          { color: 'default',   label: 'Default'   },
          { color: 'primary',   label: 'Primary'   },
          { color: 'secondary', label: 'Secondary' },
          { color: 'tertiary',  label: 'Tertiary'  },
          { color: 'success',   label: 'Success'   },
          { color: 'warning',   label: 'Warning'   },
          { color: 'danger',    label: 'Danger'    },
          { color: 'light',     label: 'Light'     },
          { color: 'medium',    label: 'Medium'    },
          { color: 'dark',      label: 'Dark'      },
        ] as { color: CardColor; label: string }[]
      ).map(({ color, label }) => (
        <Card
          key={color}
          color={color}
          subtitle="Card subtitle"
          title={label}
          body="Text content on this coloured card."
          actions={[{ label: 'Action' }]}
        />
      ))}
    </div>
  ),
};

// ─── All states ───────────────────────────────────────────────────────────────

export const AllStates: Story = {
  name: 'All States',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Card subtitle="Default"      title="Business Registration" body="Standard card with subtitle and body text." />
      <Card subtitle="With Actions" title="Owner Details"         body="Card with action buttons in the footer." actions={[{ label: 'View' }, { label: 'Edit', variant: 'outline' }]} />
      <Card subtitle="Tappable"     title="Document Category"     body="Tap to navigate." tappable />
      <Card subtitle="Error"        title="Failed to Load"        error="Something went wrong. Please try again." />
      <Card title="Loading skeleton" loading />
    </div>
  ),
};

// ─── Login Flow ───────────────────────────────────────────────────────────────

export const LoginDefault: Story = {
  name: 'Login / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{
        background: '#fff',
        borderRadius: '12px',
        boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)',
        overflow: 'hidden',
        padding: '24px',
      }}>
        <h3 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '22px', fontWeight: 700, textAlign: 'center', margin: '0 0 20px', color: 'var(--av-color-text-heading)' }}>
          Welcome back
        </h3>

        {/* Segment tabs */}
        <div style={{ display: 'flex', borderBottom: '1px solid var(--av-color-surface-border)', marginBottom: '20px' }}>
          <div style={{ flex: 1, textAlign: 'center', paddingBottom: '10px', borderBottom: '2px solid var(--av-aqua-500)', marginBottom: '-1px', color: 'var(--av-aqua-500)', fontWeight: 600, fontSize: '14px', cursor: 'pointer' }}>Phone</div>
          <div style={{ flex: 1, textAlign: 'center', paddingBottom: '10px', color: 'var(--av-color-text-muted)', fontSize: '14px', cursor: 'pointer' }}>Email</div>
        </div>

        {/* Phone input */}
        <div style={{ display: 'flex', alignItems: 'center', border: '1px solid var(--av-color-surface-border)', borderRadius: '8px', padding: '12px', marginBottom: '16px', gap: '10px' }}>
          <span style={{ fontSize: '18px' }}>🇰🇪</span>
          <span style={{ color: 'var(--av-color-text-muted)', fontSize: '14px', fontFamily: 'var(--av-font-body)' }}>+254</span>
          <span style={{ width: '1px', height: '18px', background: 'var(--av-color-surface-border)' }} />
          <span style={{ color: 'var(--av-color-text-disabled)', fontSize: '14px', fontFamily: 'var(--av-font-body)', flex: 1 }}>Phone number</span>
        </div>

        {/* CTA */}
        <div style={{ background: 'var(--av-aqua-500)', color: '#fff', borderRadius: '8px', padding: '14px', textAlign: 'center', fontWeight: 600, fontSize: '16px', fontFamily: 'var(--av-font-body)', marginBottom: '16px', cursor: 'pointer' }}>
          Continue
        </div>

        <p style={{ fontSize: '12px', color: 'var(--av-color-text-muted)', textAlign: 'center', margin: 0, fontFamily: 'var(--av-font-body)' }}>
          By continuing you agree to our{' '}
          <span style={{ color: 'var(--av-aqua-500)', fontWeight: 500 }}>Terms &amp; Conditions</span>
        </p>
      </div>
    </div>
  ),
};

export const LoginError: Story = {
  name: 'Login / Error',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{
        background: '#fff',
        borderRadius: '12px',
        boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)',
        overflow: 'hidden',
        padding: '24px',
      }}>
        <h3 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '22px', fontWeight: 700, textAlign: 'center', margin: '0 0 20px', color: 'var(--av-color-text-heading)' }}>
          Welcome back
        </h3>

        {/* Segment tabs */}
        <div style={{ display: 'flex', borderBottom: '1px solid var(--av-color-surface-border)', marginBottom: '20px' }}>
          <div style={{ flex: 1, textAlign: 'center', paddingBottom: '10px', borderBottom: '2px solid var(--av-aqua-500)', marginBottom: '-1px', color: 'var(--av-aqua-500)', fontWeight: 600, fontSize: '14px', cursor: 'pointer' }}>Phone</div>
          <div style={{ flex: 1, textAlign: 'center', paddingBottom: '10px', color: 'var(--av-color-text-muted)', fontSize: '14px', cursor: 'pointer' }}>Email</div>
        </div>

        {/* Phone input — error state */}
        <div style={{ display: 'flex', alignItems: 'center', border: '1px solid var(--av-danger-500)', borderRadius: '8px', padding: '12px', marginBottom: '6px', gap: '10px' }}>
          <span style={{ fontSize: '18px' }}>🇰🇪</span>
          <span style={{ color: 'var(--av-color-text-muted)', fontSize: '14px', fontFamily: 'var(--av-font-body)' }}>+254</span>
          <span style={{ width: '1px', height: '18px', background: 'var(--av-color-surface-border)' }} />
          <span style={{ color: 'var(--av-color-text)', fontSize: '14px', fontFamily: 'var(--av-font-body)', flex: 1 }}>712 345 678</span>
        </div>
        <p style={{ color: 'var(--av-danger-500)', fontSize: '12px', margin: '0 0 16px', fontFamily: 'var(--av-font-body)' }}>
          This number is not registered. Please sign up first.
        </p>

        {/* CTA */}
        <div style={{ background: 'var(--av-aqua-500)', color: '#fff', borderRadius: '8px', padding: '14px', textAlign: 'center', fontWeight: 600, fontSize: '16px', fontFamily: 'var(--av-font-body)', marginBottom: '16px', cursor: 'pointer' }}>
          Continue
        </div>

        <p style={{ fontSize: '12px', color: 'var(--av-color-text-muted)', textAlign: 'center', margin: 0, fontFamily: 'var(--av-font-body)' }}>
          By continuing you agree to our{' '}
          <span style={{ color: 'var(--av-aqua-500)', fontWeight: 500 }}>Terms &amp; Conditions</span>
        </p>
      </div>
    </div>
  ),
};

// ─── OTP Flow ─────────────────────────────────────────────────────────────────

const OtpBoxes = ({
  values = ['', '', '', '', '', ''],
  borderColor = 'var(--av-color-surface-border)',
  bg = '#fff',
}: {
  values?: string[];
  borderColor?: string;
  bg?: string;
}) => (
  <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', margin: '20px 0' }}>
    {values.map((v, i) => (
      <div
        key={i}
        style={{
          width: 47, height: 47,
          border: `1.5px solid ${borderColor}`,
          borderRadius: '10px',
          background: bg,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '20px', fontWeight: 600,
          color: 'var(--av-color-text)',
          fontFamily: 'var(--av-font-body)',
        }}
      >
        {v}
      </div>
    ))}
  </div>
);

export const OtpDefault: Story = {
  name: 'OTP / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', padding: '24px', textAlign: 'center' }}>
        <h3 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '22px', fontWeight: 700, margin: '0 0 8px', color: 'var(--av-color-text-heading)' }}>Verify your number</h3>
        <p style={{ fontSize: '14px', color: 'var(--av-color-text-muted)', margin: 0, fontFamily: 'var(--av-font-body)' }}>Enter the 6-digit code sent to +254 712 345 678</p>
        <OtpBoxes values={['', '', '', '', '', '']} borderColor="var(--av-neutral-200)" bg="var(--av-neutral-50)" />
        <div style={{ background: 'var(--av-aqua-500)', color: '#fff', borderRadius: '8px', padding: '14px', fontWeight: 600, fontSize: '16px', fontFamily: 'var(--av-font-body)', cursor: 'pointer', marginBottom: '16px' }}>Verify</div>
        <p style={{ fontSize: '13px', color: 'var(--av-color-text-muted)', margin: 0, fontFamily: 'var(--av-font-body)' }}>
          Didn&apos;t receive a code?{' '}
          <span style={{ color: 'var(--av-aqua-500)', fontWeight: 500 }}>Resend</span>
        </p>
      </div>
    </div>
  ),
};

export const OtpFilled: Story = {
  name: 'OTP / Filled',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', padding: '24px', textAlign: 'center' }}>
        <h3 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '22px', fontWeight: 700, margin: '0 0 8px', color: 'var(--av-color-text-heading)' }}>Verify your number</h3>
        <p style={{ fontSize: '14px', color: 'var(--av-color-text-muted)', margin: 0, fontFamily: 'var(--av-font-body)' }}>Enter the 6-digit code sent to +254 712 345 678</p>
        <OtpBoxes values={['4', '8', '3', '1', '9', '2']} borderColor="var(--av-aqua-500)" />
        <div style={{ background: 'var(--av-aqua-500)', color: '#fff', borderRadius: '8px', padding: '14px', fontWeight: 600, fontSize: '16px', fontFamily: 'var(--av-font-body)', cursor: 'pointer', marginBottom: '16px' }}>Verify</div>
        <p style={{ fontSize: '13px', color: 'var(--av-color-text-muted)', margin: 0, fontFamily: 'var(--av-font-body)' }}>
          Didn&apos;t receive a code?{' '}
          <span style={{ color: 'var(--av-aqua-500)', fontWeight: 500 }}>Resend</span>
        </p>
      </div>
    </div>
  ),
};

export const OtpError: Story = {
  name: 'OTP / Error',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', padding: '24px', textAlign: 'center' }}>
        <h3 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '22px', fontWeight: 700, margin: '0 0 8px', color: 'var(--av-color-text-heading)' }}>Verify your number</h3>
        <p style={{ fontSize: '14px', color: 'var(--av-color-text-muted)', margin: 0, fontFamily: 'var(--av-font-body)' }}>Enter the 6-digit code sent to +254 712 345 678</p>
        <OtpBoxes values={['4', '8', '3', '1', '9', '2']} borderColor="var(--av-danger-500)" />
        <p style={{ color: 'var(--av-danger-500)', fontSize: '13px', margin: '-12px 0 16px', fontFamily: 'var(--av-font-body)' }}>
          Incorrect code. Please try again.
        </p>
        <div style={{ background: 'var(--av-aqua-500)', color: '#fff', borderRadius: '8px', padding: '14px', fontWeight: 600, fontSize: '16px', fontFamily: 'var(--av-font-body)', cursor: 'pointer', marginBottom: '16px' }}>Verify</div>
        <p style={{ fontSize: '13px', color: 'var(--av-color-text-muted)', margin: 0, fontFamily: 'var(--av-font-body)' }}>
          Didn&apos;t receive a code?{' '}
          <span style={{ color: 'var(--av-aqua-500)', fontWeight: 500 }}>Resend</span>
        </p>
      </div>
    </div>
  ),
};

export const OtpSuccess: Story = {
  name: 'OTP / Success',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', padding: '24px', textAlign: 'center' }}>
        <h3 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '22px', fontWeight: 700, margin: '0 0 8px', color: 'var(--av-color-text-heading)' }}>Verify your number</h3>
        <p style={{ fontSize: '14px', color: 'var(--av-color-text-muted)', margin: 0, fontFamily: 'var(--av-font-body)' }}>Enter the 6-digit code sent to +254 712 345 678</p>
        <OtpBoxes values={['4', '8', '3', '1', '9', '2']} borderColor="var(--av-success-500)" />
        <p style={{ color: 'var(--av-success-500)', fontSize: '13px', margin: '-12px 0 16px', fontFamily: 'var(--av-font-body)' }}>
          ✓ Code verified successfully!
        </p>
        <div style={{ background: 'var(--av-aqua-500)', color: '#fff', borderRadius: '8px', padding: '14px', fontWeight: 600, fontSize: '16px', fontFamily: 'var(--av-font-body)', cursor: 'pointer' }}>Continue</div>
      </div>
    </div>
  ),
};

// ─── Available Credit ─────────────────────────────────────────────────────────

export const AvailableCredit: Story = {
  name: 'Available Credit / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: 'var(--av-medium-base)', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', padding: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
          <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.75)', margin: 0, fontFamily: 'var(--av-font-body)' }}>Available Credit</p>
          <IonBadge style={{ '--background': 'rgba(255,255,255,0.2)', '--color': '#fff', fontSize: '11px', padding: '4px 8px', borderRadius: '20px' } as React.CSSProperties}>Active</IonBadge>
        </div>
        <h3 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '28px', fontWeight: 700, color: '#fff', margin: '0 0 4px' }}>KES 250,000</h3>
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <span style={{ fontSize: '13px', color: 'rgba(255,255,255,0.75)', fontFamily: 'var(--av-font-body)' }}>Limit: KES 500,000</span>
          <span style={{ width: '14px', height: '14px', borderRadius: '50%', border: '1.5px solid rgba(255,255,255,0.6)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', color: 'rgba(255,255,255,0.8)', cursor: 'pointer' }}>i</span>
        </div>
        <IonProgressBar value={0.5} style={{ '--background': 'rgba(255,255,255,0.25)', '--progress-background': '#fff', borderRadius: '4px', height: '6px', marginTop: '14px' } as React.CSSProperties} />
      </div>
    </div>
  ),
};

// ─── Fund Request Cards ───────────────────────────────────────────────────────

const FundRequestCard = ({
  chipLabel,
  chipColor,
  chipBg,
  invoiceRef,
  amount,
  progress,
  progressColor = 'var(--av-aqua-500)',
}: {
  chipLabel: string;
  chipColor: string;
  chipBg: string;
  invoiceRef: string;
  amount: string;
  progress: number;
  progressColor?: string;
}) => (
  <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', overflow: 'hidden' }}>
    <div style={{ padding: '16px 16px 12px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
        <span style={{ fontSize: '12px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-body)' }}>Fund Request</span>
        <span style={{ background: chipBg, color: chipColor, fontSize: '11px', fontWeight: 600, padding: '3px 10px', borderRadius: '20px', fontFamily: 'var(--av-font-body)' }}>{chipLabel}</span>
      </div>
      <p style={{ fontSize: '13px', color: 'var(--av-aqua-500)', fontFamily: 'var(--av-font-body)', margin: '0 0 6px', fontWeight: 500 }}>
        📎 {invoiceRef}
      </p>
      <h5 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '20px', fontWeight: 700, color: 'var(--av-color-text-heading)', margin: '0 0 10px' }}>
        KES {amount}
      </h5>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-body)', marginBottom: '6px' }}>
        <span>Disbursed</span>
        <span>{Math.round(progress * 100)}%</span>
      </div>
      <IonProgressBar value={progress} style={{ '--background': 'var(--av-neutral-100)', '--progress-background': progressColor, borderRadius: '4px', height: '6px' } as React.CSSProperties} />
    </div>
    <div style={{ display: 'flex', gap: '8px', padding: '12px 16px', borderTop: '1px solid var(--av-color-surface-border)' }}>
      <div style={{ flex: 1, border: '1px solid var(--av-aqua-500)', color: 'var(--av-aqua-500)', borderRadius: '8px', padding: '10px', textAlign: 'center', fontSize: '13px', fontWeight: 600, fontFamily: 'var(--av-font-body)', cursor: 'pointer' }}>Invoice</div>
      <div style={{ flex: 1, background: 'var(--av-aqua-500)', color: '#fff', borderRadius: '8px', padding: '10px', textAlign: 'center', fontSize: '13px', fontWeight: 600, fontFamily: 'var(--av-font-body)', cursor: 'pointer' }}>View FR</div>
    </div>
  </div>
);

export const FundRequestRequested: Story = {
  name: 'Fund Request / Requested',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <FundRequestCard chipLabel="Requested" chipColor="var(--av-darkblue-700)" chipBg="var(--av-color-info-subtle)" invoiceRef="INV-2024-00123" amount="85,000" progress={0} progressColor="var(--av-darkblue-500)" />
    </div>
  ),
};

export const FundRequestLive: Story = {
  name: 'Fund Request / Live',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <FundRequestCard chipLabel="Live" chipColor="#5b21b6" chipBg="#ede9fe" invoiceRef="INV-2024-00098" amount="120,000" progress={0.45} progressColor="var(--av-aqua-500)" />
    </div>
  ),
};

export const FundRequestDueSoon: Story = {
  name: 'Fund Request / Due Soon',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <FundRequestCard chipLabel="Due Soon" chipColor="var(--av-warning-700)" chipBg="var(--av-color-warning-subtle)" invoiceRef="INV-2024-00076" amount="60,000" progress={0.8} progressColor="var(--av-warning-500)" />
    </div>
  ),
};

export const FundRequestOverdue: Story = {
  name: 'Fund Request / Overdue',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <FundRequestCard chipLabel="Overdue" chipColor="var(--av-danger-700)" chipBg="var(--av-color-danger-subtle)" invoiceRef="INV-2024-00054" amount="45,000" progress={1} progressColor="var(--av-danger-500)" />
    </div>
  ),
};

export const FundRequestRepaid: Story = {
  name: 'Fund Request / Repaid',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <FundRequestCard chipLabel="Repaid" chipColor="var(--av-success-700)" chipBg="var(--av-color-success-subtle)" invoiceRef="INV-2024-00031" amount="200,000" progress={1} progressColor="var(--av-success-500)" />
    </div>
  ),
};

// ─── Funds Request Details ────────────────────────────────────────────────────

export const FundsRequestDetails: Story = {
  name: 'Funds Request Details / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', overflow: 'hidden' }}>
        <div style={{ padding: '16px' }}>
          <p style={{ fontSize: '12px', color: 'var(--av-color-text-muted)', margin: '0 0 4px', fontFamily: 'var(--av-font-body)' }}>Fund Request · INV-2024-00098</p>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h5 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '20px', fontWeight: 700, color: 'var(--av-color-text-heading)', margin: 0 }}>KES 120,000</h5>
            <span style={{ background: '#ede9fe', color: '#5b21b6', fontSize: '11px', fontWeight: 600, padding: '3px 10px', borderRadius: '20px' }}>Live</span>
          </div>

          {[
            { label: 'Principal', value: 'KES 120,000' },
            { label: 'Disbursed date', value: '12 Mar 2024' },
            { label: 'Due date', value: '12 Jun 2024' },
            { label: 'Tenor', value: '90 days' },
            { label: 'Interest rate', value: '4.5%' },
            { label: 'Fee', value: 'KES 5,400' },
          ].map(({ label, value }) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--av-color-surface-border)', fontSize: '13px', fontFamily: 'var(--av-font-body)' }}>
              <span style={{ color: 'var(--av-color-text-muted)' }}>{label}</span>
              <span style={{ color: 'var(--av-color-text)', fontWeight: 500 }}>{value}</span>
            </div>
          ))}
        </div>
        <div style={{ padding: '12px 16px', borderTop: '1px solid var(--av-color-surface-border)' }}>
          <div style={{ background: 'var(--av-aqua-500)', color: '#fff', borderRadius: '8px', padding: '12px', textAlign: 'center', fontSize: '14px', fontWeight: 600, fontFamily: 'var(--av-font-body)', cursor: 'pointer' }}>View Repayment Schedule</div>
        </div>
      </div>
    </div>
  ),
};

// ─── Repayment Schedule Card ──────────────────────────────────────────────────

export const RepaymentSchedule: Story = {
  name: 'Repayment Schedule / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', overflow: 'hidden' }}>
        <div style={{ padding: '16px' }}>
          <p style={{ fontSize: '12px', color: 'var(--av-color-text-muted)', margin: '0 0 12px', fontFamily: 'var(--av-font-body)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Repayment Schedule</p>

          {[
            { date: '12 Apr 2024', amount: 'KES 42,300', status: 'Upcoming', statusColor: 'var(--av-color-info)', statusBg: 'var(--av-color-info-subtle)' },
            { date: '12 May 2024', amount: 'KES 42,300', status: 'Upcoming', statusColor: 'var(--av-color-info)', statusBg: 'var(--av-color-info-subtle)' },
            { date: '12 Jun 2024', amount: 'KES 42,300', status: 'Upcoming', statusColor: 'var(--av-color-info)', statusBg: 'var(--av-color-info-subtle)' },
          ].map(({ date, amount, status, statusColor, statusBg }, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: i < 2 ? '1px solid var(--av-color-surface-border)' : undefined }}>
              <div>
                <p style={{ margin: 0, fontSize: '14px', fontWeight: 600, color: 'var(--av-color-text)', fontFamily: 'var(--av-font-body)' }}>{amount}</p>
                <p style={{ margin: 0, fontSize: '12px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-body)' }}>{date}</p>
              </div>
              <span style={{ background: statusBg, color: statusColor, fontSize: '11px', fontWeight: 600, padding: '3px 10px', borderRadius: '20px' }}>{status}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  ),
};

// ─── Repayment Overdue ────────────────────────────────────────────────────────

export const RepaymentOverdue: Story = {
  name: 'Repayment Overdue / Overdue',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', overflow: 'hidden' }}>
        <div style={{ background: 'var(--av-color-danger-subtle)', padding: '12px 16px', borderBottom: '1px solid var(--av-danger-300)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <p style={{ margin: 0, fontSize: '13px', color: 'var(--av-danger-700)', fontFamily: 'var(--av-font-body)', fontWeight: 600 }}>Payment Overdue</p>
            <span style={{ background: 'var(--av-color-danger-subtle)', color: 'var(--av-danger-700)', border: '1px solid var(--av-danger-500)', fontSize: '11px', fontWeight: 600, padding: '3px 10px', borderRadius: '20px' }}>Overdue</span>
          </div>
          <p style={{ margin: '4px 0 0', fontSize: '12px', color: 'var(--av-danger-600)', fontFamily: 'var(--av-font-body)' }}>Due: 12 Mar 2024 · 14 days ago</p>
        </div>

        <div style={{ padding: '16px' }}>
          {[
            { label: 'Original amount', value: 'KES 42,300' },
            { label: 'Late fee (2%)', value: 'KES 846' },
            { label: 'Total due', value: 'KES 43,146', bold: true },
          ].map(({ label, value, bold }) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: label !== 'Total due' ? '1px solid var(--av-color-surface-border)' : undefined, fontSize: '13px', fontFamily: 'var(--av-font-body)' }}>
              <span style={{ color: bold ? 'var(--av-danger-700)' : 'var(--av-color-text-muted)', fontWeight: bold ? 700 : 400 }}>{label}</span>
              <span style={{ color: bold ? 'var(--av-danger-700)' : 'var(--av-color-text)', fontWeight: bold ? 700 : 500 }}>{value}</span>
            </div>
          ))}

          <div style={{ marginTop: '12px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--av-danger-600)', fontFamily: 'var(--av-font-body)', marginBottom: '4px' }}>
              <span>0%</span><span>Fully paid</span>
            </div>
            <IonProgressBar value={0} style={{ '--background': 'var(--av-color-danger-subtle)', '--progress-background': 'var(--av-danger-500)', borderRadius: '4px', height: '6px' } as React.CSSProperties} />
          </div>
        </div>

        <div style={{ padding: '12px 16px', borderTop: '1px solid var(--av-color-surface-border)' }}>
          <div style={{ background: 'var(--av-danger-500)', color: '#fff', borderRadius: '8px', padding: '12px', textAlign: 'center', fontSize: '14px', fontWeight: 600, fontFamily: 'var(--av-font-body)', cursor: 'pointer' }}>Repay Now · KES 43,146</div>
        </div>
      </div>
    </div>
  ),
};

// ─── Repayment Method Card ────────────────────────────────────────────────────

export const RepaymentMethod: Story = {
  name: 'Repayment Method / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', overflow: 'hidden' }}>
        <div style={{ padding: '16px 16px 8px' }}>
          <p style={{ fontSize: '12px', color: 'var(--av-color-text-muted)', margin: '0 0 4px', fontFamily: 'var(--av-font-body)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Bank Transfer Details</p>
          <p style={{ fontSize: '13px', color: 'var(--av-color-text-muted)', margin: 0, fontFamily: 'var(--av-font-body)' }}>Use these details to repay via bank transfer</p>
        </div>

        {[
          { label: 'Bank name', value: 'Equity Bank Kenya' },
          { label: 'Account name', value: 'Avenews GT Ltd' },
          { label: 'Account number', value: '0340299814068' },
          { label: 'Reference', value: 'FR-2024-00098' },
        ].map(({ label, value }) => (
          <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderTop: '1px solid var(--av-color-surface-border)' }}>
            <div>
              <p style={{ margin: 0, fontSize: '11px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-body)' }}>{label}</p>
              <p style={{ margin: 0, fontSize: '14px', fontWeight: 600, color: 'var(--av-color-text)', fontFamily: 'var(--av-font-body)' }}>{value}</p>
            </div>
            <div style={{ border: '1px solid var(--av-aqua-500)', color: 'var(--av-aqua-500)', borderRadius: '6px', padding: '6px 12px', fontSize: '12px', fontWeight: 600, fontFamily: 'var(--av-font-body)', cursor: 'pointer' }}>Copy</div>
          </div>
        ))}
      </div>
    </div>
  ),
};

// ─── Filter Applied Card ──────────────────────────────────────────────────────

export const FilterApplied: Story = {
  name: 'Filter Applied / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', padding: '14px 16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
          <p style={{ margin: 0, fontSize: '13px', fontWeight: 600, color: 'var(--av-color-text)', fontFamily: 'var(--av-font-body)' }}>Active Filters</p>
          <span style={{ color: 'var(--av-aqua-500)', fontSize: '13px', fontWeight: 500, fontFamily: 'var(--av-font-body)', cursor: 'pointer' }}>Clear all</span>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '10px' }}>
          {['Live', 'Overdue', 'Due Soon'].map((label) => (
            <IonChip key={label} style={{ '--background': 'var(--av-color-info-subtle)', '--color': 'var(--av-darkblue-700)', fontSize: '12px', height: '28px', margin: 0 } as React.CSSProperties}>
              {label} ✕
            </IonChip>
          ))}
        </div>
        <div style={{ borderTop: '1px solid var(--av-color-surface-border)', paddingTop: '10px', display: 'flex', gap: '8px' }}>
          <p style={{ margin: 0, fontSize: '12px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-body)', alignSelf: 'center' }}>Sort:</p>
          {['Newest first', 'Amount ↑'].map((label) => (
            <IonChip key={label} style={{ '--background': 'var(--av-neutral-50)', '--color': 'var(--av-color-text)', fontSize: '12px', height: '28px', margin: 0 } as React.CSSProperties}>
              {label}
            </IonChip>
          ))}
        </div>
      </div>
    </div>
  ),
};

// ─── Buyer Card ───────────────────────────────────────────────────────────────

const BuyerCardTemplate = ({ cta = 'View' }: { cta?: string }) => (
  <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0px 3px 1px -2px rgba(0,0,0,0.20), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)', overflow: 'hidden' }}>
    <div style={{ padding: '16px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '14px' }}>
        <div style={{ width: '42px', height: '42px', borderRadius: '10px', background: 'var(--av-color-surface-subtle)', border: '1px solid var(--av-color-surface-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px' }}>🏢</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <h5 style={{ fontFamily: 'var(--av-font-heading)', fontSize: '16px', fontWeight: 700, color: 'var(--av-color-text-heading)', margin: 0 }}>Nairobi Traders Ltd</h5>
            <IonBadge style={{ '--background': 'var(--av-color-success-subtle)', '--color': 'var(--av-success-700)', fontSize: '10px', padding: '2px 6px' } as React.CSSProperties}>Verified</IonBadge>
          </div>
          <p style={{ margin: 0, fontSize: '12px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-body)' }}>Nairobi, Kenya</p>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
        {[
          { label: 'Orders', value: '24' },
          { label: 'Total value', value: 'KES 1.2M' },
          { label: 'On-time rate', value: '96%' },
        ].map(({ label, value }) => (
          <div key={label} style={{ textAlign: 'center' }}>
            <p style={{ margin: 0, fontSize: '16px', fontWeight: 700, color: 'var(--av-color-text-heading)', fontFamily: 'var(--av-font-heading)' }}>{value}</p>
            <p style={{ margin: 0, fontSize: '11px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-body)' }}>{label}</p>
          </div>
        ))}
      </div>

      {/* Credit utilisation */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--av-color-text-muted)', fontFamily: 'var(--av-font-body)', marginBottom: '4px' }}>
          <span>Credit utilisation</span>
          <span>68%</span>
        </div>
        <IonProgressBar value={0.68} style={{ '--background': 'var(--av-neutral-100)', '--progress-background': 'var(--av-aqua-500)', borderRadius: '4px', height: '5px' } as React.CSSProperties} />
      </div>
    </div>

    <div style={{ padding: '12px 16px', borderTop: '1px solid var(--av-color-surface-border)' }}>
      <div style={{ background: cta === 'Select' ? 'var(--av-aqua-500)' : undefined, border: cta === 'View' ? '1px solid var(--av-aqua-500)' : undefined, color: cta === 'View' ? 'var(--av-aqua-500)' : '#fff', borderRadius: '8px', padding: '12px', textAlign: 'center', fontSize: '14px', fontWeight: 600, fontFamily: 'var(--av-font-body)', cursor: 'pointer' }}>
        {cta} Buyer
      </div>
    </div>
  </div>
);

export const BuyerCard: Story = {
  name: 'Buyer Card / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <BuyerCardTemplate cta="View" />
    </div>
  ),
};

export const SelectBuyer: Story = {
  name: 'Select Buyer / Default',
  render: () => (
    <div style={{ maxWidth: '360px', padding: '16px' }}>
      <BuyerCardTemplate cta="Select" />
    </div>
  ),
};
