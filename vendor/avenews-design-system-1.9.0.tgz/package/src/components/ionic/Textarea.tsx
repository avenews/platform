import React from 'react';
import { IonIcon, IonSkeletonText, IonTextarea } from '@ionic/react';

export type TextareaLabelPlacement = 'stacked' | 'floating' | 'fixed' | 'start';

export interface TextareaProps {
  label?: string;
  labelPlacement?: TextareaLabelPlacement;
  placeholder?: string;
  value?: string;
  required?: boolean;
  disabled?: boolean;
  loading?: boolean;
  error?: string;
  success?: boolean;
  helperText?: string;
  counter?: boolean;
  maxlength?: number;
  rows?: number;
  autoGrow?: boolean;
  startIcon?: string;
  onStartIconClick?: () => void;
  startIconAriaLabel?: string;
  endIcon?: string;
  onEndIconClick?: () => void;
  endIconAriaLabel?: string;
  onIonInput?: (value: string) => void;
  onIonChange?: (value: string) => void;
  onIonBlur?: () => void;
  onIonFocus?: () => void;
  className?: string;
}

export const Textarea: React.FC<TextareaProps> = ({
  label,
  labelPlacement = 'stacked',
  placeholder,
  value,
  required       = false,
  disabled       = false,
  loading        = false,
  error,
  success        = false,
  helperText,
  counter        = false,
  maxlength,
  rows           = 3,
  autoGrow       = true,
  startIcon,
  onStartIconClick,
  startIconAriaLabel,
  endIcon,
  onEndIconClick,
  endIconAriaLabel,
  onIonInput,
  onIonChange,
  onIonBlur,
  onIonFocus,
  className,
}) => {
  if (loading) {
    return (
      <div className="avenews-textarea-skeleton">
        <IonSkeletonText animated style={{ width: '35%', height: '12px', marginBottom: '6px' }} />
        <IonSkeletonText animated style={{ width: '100%', height: '60px' }} />
      </div>
    );
  }

  const rootClass    = ['avenews-textarea', error && 'avenews-textarea--error', success && !error && 'avenews-textarea--success', className].filter(Boolean).join(' ');
  const labelContent = label ? `${label}${required ? '\u200A*' : ''}` : undefined;

  const startSlot = startIcon
    ? onStartIconClick
      ? <button type="button" slot="start" onClick={onStartIconClick} aria-label={startIconAriaLabel} className="avenews-textarea__icon-btn"><IonIcon icon={startIcon} className="avenews-textarea__icon avenews-textarea__icon--btn" /></button>
      : <IonIcon icon={startIcon} slot="start" className="avenews-textarea__icon avenews-textarea__icon--start" />
    : null;

  const endSlot = endIcon
    ? onEndIconClick
      ? <button type="button" slot="end" onClick={onEndIconClick} aria-label={endIconAriaLabel} className="avenews-textarea__icon-btn"><IonIcon icon={endIcon} className="avenews-textarea__icon avenews-textarea__icon--btn" /></button>
      : <IonIcon icon={endIcon} slot="end" className="avenews-textarea__icon avenews-textarea__icon--end" />
    : null;

  return (
    <IonTextarea
      fill="solid"
      label={labelContent}
      labelPlacement={labelPlacement}
      placeholder={placeholder}
      value={value}
      disabled={disabled}
      rows={rows}
      autoGrow={autoGrow}
      counter={counter}
      maxlength={maxlength}
      helperText={!error ? helperText : undefined}
      errorText={error}
      className={rootClass}
      onIonInput={(e) => onIonInput?.((e.detail.value as string) ?? '')}
      onIonChange={(e) => onIonChange?.((e.detail.value as string) ?? '')}
      onIonBlur={() => onIonBlur?.()}
      onIonFocus={() => onIonFocus?.()}
    >
      {startSlot}
      {endSlot}
    </IonTextarea>
  );
};

export default Textarea;
