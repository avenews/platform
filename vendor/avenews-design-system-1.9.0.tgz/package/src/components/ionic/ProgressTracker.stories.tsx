import type { Meta, StoryObj } from '@storybook/react';
import { IonHeader, IonTitle, IonToolbar } from '@ionic/react';
import { ProgressTracker } from './ProgressTracker';

const meta: Meta<typeof ProgressTracker> = {
  title: 'Avenews/Ionic/ProgressTracker',
  component: ProgressTracker,
  tags: ['autodocs'],
  argTypes: {
    type: {
      control: 'radio',
      options: ['determinate', 'indeterminate', 'buffer'],
    },
    color: {
      control: 'select',
      options: ['primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'],
    },
    value: {
      control: { type: 'range', min: 0, max: 1, step: 0.05 },
    },
    buffer: {
      control: { type: 'range', min: 0, max: 1, step: 0.05 },
    },
  },
  decorators: [
    (Story) => (
      <div style={{ maxWidth: '420px', padding: '24px', background: '#F3F4F6' }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof ProgressTracker>;

// ─── States ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  args: {
    type: 'determinate',
    value: 0.4,
    color: 'primary',
  },
};

export const Loading: Story = {
  args: {
    loading: true,
    color: 'primary',
  },
};

export const Error: Story = {
  args: {
    error: true,
  },
};

// ─── Variants ────────────────────────────────────────────────────────────────

export const Indeterminate: Story = {
  args: {
    type: 'indeterminate',
    color: 'primary',
  },
};

export const Buffer: Story = {
  args: {
    type: 'buffer',
    value: 0.4,
    buffer: 0.7,
    color: 'primary',
  },
};

export const AllSteps: Story = {
  name: 'Progress Steps (0% → 100%)',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {[0, 0.2, 0.4, 0.6, 0.8, 1].map((v) => (
        <div key={v} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <span
            style={{
              fontFamily: "'Poppins', sans-serif",
              fontSize: '12px',
              width: '36px',
              color: '#6b7280',
            }}
          >
            {Math.round(v * 100)}%
          </span>
          <div style={{ flex: 1 }}>
            <ProgressTracker value={v} />
          </div>
        </div>
      ))}
    </div>
  ),
};

export const InHeader: Story = {
  name: 'In Header (canonical placement)',
  args: {
    value: 0.4,
  },
  render: (args) => (
    <IonHeader>
      <IonToolbar>
        <IonTitle>Upload Documents</IonTitle>
      </IonToolbar>
      <ProgressTracker {...args} color="primary" />
    </IonHeader>
  ),
};
