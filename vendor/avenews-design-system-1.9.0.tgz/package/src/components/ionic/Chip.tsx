import React from 'react';
import { IonChip, IonIcon, IonLabel, IonAvatar } from '@ionic/react';
import { closeCircle } from 'ionicons/icons';

export type ChipColor =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light'   | 'medium'  | 'dark' | 'accent';

export type ChipFill    = 'solid' | 'outline';
export type ChipVariant = ChipColor | 'neutral' | 'outline';

export interface ChipProps {
  label: string;
  color?: ChipColor;
  fill?: ChipFill;
  /** @deprecated Use color + fill instead */
  variant?: ChipVariant;
  leadingIcon?: string;
  dismissible?: boolean;
  avatarUrl?: string;
  avatarAlt?: string;
  selected?: boolean;
  disabled?: boolean;
  loading?: boolean;
  onClick?: () => void;
  onDismiss?: () => void;
  className?: string;
}

function resolveColor(color?: ChipColor, variant?: ChipVariant): ChipColor {
  if (color) return color;
  if (!variant) return 'default';
  if (variant === 'neutral' || variant === 'outline') return 'default';
  return variant as ChipColor;
}

function resolveFill(fill?: ChipFill, variant?: ChipVariant): ChipFill {
  if (fill) return fill;
  return variant === 'outline' ? 'outline' : 'solid';
}

export const Chip: React.FC<ChipProps> = ({
  label,
  color,
  fill,
  variant,
  leadingIcon,
  dismissible = false,
  avatarUrl,
  avatarAlt   = '',
  selected    = false,
  disabled    = false,
  loading     = false,
  onClick,
  onDismiss,
  className,
}) => {
  const resolvedColor = resolveColor(color, variant);
  const isOutline     = resolveFill(fill, variant) === 'outline' && !selected;

  return (
    <IonChip
      outline={isOutline}
      disabled={disabled || loading}
      onClick={(!disabled && !loading) ? onClick : undefined}
      className={['avenews-chip', `avenews-chip--${resolvedColor}`, isOutline && 'avenews-chip--outline', selected && 'avenews-chip--selected', className].filter(Boolean).join(' ')}
    >
      {avatarUrl && !leadingIcon && <IonAvatar><img alt={avatarAlt} src={avatarUrl} /></IonAvatar>}
      {leadingIcon && !avatarUrl && <IonIcon icon={leadingIcon} />}
      <IonLabel>{loading ? 'Loading…' : label}</IonLabel>
      {dismissible && (
        <IonIcon icon={closeCircle} onClick={(e) => { e.stopPropagation(); if (!disabled && !loading) onDismiss?.(); }} />
      )}
    </IonChip>
  );
};

export default Chip;
