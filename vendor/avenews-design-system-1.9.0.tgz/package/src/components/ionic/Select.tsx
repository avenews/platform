import React from 'react';
import { IonSelect, IonSelectOption } from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface SelectOption {
  value:     string;
  label:     string;
  disabled?: boolean;
}

export interface SelectProps {
  label?:       string;
  placeholder?: string;
  value?:       string;
  options:      SelectOption[];
  disabled?:    boolean;
  required?:    boolean;
  multiple?:    boolean;
  error?:       string;
  helperText?:  string;
  onIonChange?: (value: string) => void;
  className?:   string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export const Select: React.FC<SelectProps> = ({
  label,
  placeholder  = 'Select an option',
  value,
  options,
  disabled     = false,
  required     = false,
  multiple     = false,
  error,
  helperText,
  onIonChange,
  className,
}) => {
  const labelContent = label
    ? `${label}${required ? '\u200A*' : ''}`
    : undefined;

  const rootClass = [
    'avenews-select',
    error     && 'avenews-select--error',
    className,
  ].filter(Boolean).join(' ');

  return (
    <IonSelect
      fill="solid"
      label={labelContent}
      labelPlacement="stacked"
      placeholder={placeholder}
      value={value}
      disabled={disabled}
      multiple={multiple}
      helperText={!error ? helperText : undefined}
      errorText={error}
      className={rootClass}
      onIonChange={(e) => onIonChange?.(e.detail.value as string)}
    >
      {options.map((opt) => (
        <IonSelectOption key={opt.value} value={opt.value} disabled={opt.disabled}>
          {opt.label}
        </IonSelectOption>
      ))}
    </IonSelect>
  );
};

export default Select;
