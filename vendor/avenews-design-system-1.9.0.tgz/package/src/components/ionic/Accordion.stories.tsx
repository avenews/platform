import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Accordion } from './Accordion';

const meta: Meta<typeof Accordion> = {
  title: 'Avenews/Ionic/Accordion',
  component: Accordion,
  tags: ['autodocs'],
  argTypes: {
    multiple: {
      control: 'boolean',
      description: 'Allow multiple items open simultaneously.',
    },
  },
  decorators: [(Story) => (
    <div style={{ maxWidth: '400px' }}>
      <Story />
    </div>
  )],
};

export default meta;
type Story = StoryObj<typeof Accordion>;

// ─── Sample items ─────────────────────────────────────────────────────────────

const FAQ_ITEMS = [
  {
    value: 'eligibility',
    label: 'Who is eligible to apply?',
    content: (
      <p>
        To apply you must be a South African resident, 18 years or older, with a valid ID and an
        active bank account. Your business must have been trading for at least 6 months.
      </p>
    ),
  },
  {
    value: 'documents',
    label: 'What documents do I need?',
    content: (
      <p>
        You will need a valid South African ID, proof of address dated within 3 months, and your
        most recent 3 months of bank statements.
      </p>
    ),
  },
  {
    value: 'timeline',
    label: 'How long does approval take?',
    content: (
      <p>
        Most applications are reviewed within 24–48 hours. You will receive an SMS and email
        notification once a decision has been made.
      </p>
    ),
  },
  {
    value: 'repayment',
    label: 'How do repayments work?',
    content: (
      <p>
        Repayments are automatically deducted from your registered bank account on your agreed
        payment date each month. You can view your repayment schedule in the app.
      </p>
    ),
  },
];

const SETTINGS_ITEMS = [
  {
    value: 'personal',
    label: 'Personal Information',
    content: (
      <div>
        <p>Your name, date of birth, and ID number are required to verify your identity.</p>
        <p>Contact support to update your ID number or date of birth.</p>
      </div>
    ),
  },
  {
    value: 'address',
    label: 'Residential Address',
    content: <p>Your registered address must match your proof of address document.</p>,
  },
  {
    value: 'bank',
    label: 'Banking Details',
    content: <p>Your bank account must be in your name. Business accounts are not accepted.</p>,
  },
  {
    value: 'advanced',
    label: 'Advanced Options',
    content: <p>This section is currently unavailable for your account type.</p>,
    disabled: true,
  },
];

// ─── Stories ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  args: {
    items: FAQ_ITEMS,
    multiple: false,
  },
};

export const MultipleOpen: Story = {
  name: 'Multiple Open',
  args: {
    items: FAQ_ITEMS,
    multiple: true,
  },
};

export const WithDisabledItem: Story = {
  name: 'With Disabled Item',
  args: {
    items: SETTINGS_ITEMS,
    multiple: false,
  },
};

export const LeftArrow: Story = {
  name: 'Left Arrow Variant',
  args: {
    items: FAQ_ITEMS.slice(0, 3).map(item => ({ ...item, leftArrow: true })),
    multiple: false,
  },
};

export const Controlled: Story = {
  name: 'Controlled (open first item)',
  render: () => {
    const [openValue, setOpenValue] = useState<string | undefined>('eligibility');
    return (
      <div>
        <p style={{ fontSize: '12px', color: 'var(--av-color-text-muted)', marginBottom: '8px' }}>
          Open: {openValue ?? 'none'}
        </p>
        <Accordion
          items={FAQ_ITEMS}
          value={openValue}
          onIonChange={(v) => setOpenValue(v as string)}
        />
      </div>
    );
  },
};

export const AllVariants: Story = {
  name: 'Full FAQ List',
  render: () => (
    <Accordion items={FAQ_ITEMS} multiple={false} />
  ),
};
