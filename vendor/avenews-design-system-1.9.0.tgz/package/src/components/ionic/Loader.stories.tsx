import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import { Loader } from './Loader';
import type { LoaderVariant, LoaderSize, LoaderColor, SpinnerType } from './Loader';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Loader> = {
  title: 'Avenews/Ionic/Loader',
  component: Loader,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Loading indicator built on `IonSpinner`. Supports three placement variants ' +
          '(`inline`, `centered`, `overlay`), 7 `IonSpinner` animation types, ' +
          '3 sizes, 9 Ionic colour tokens, and an optional text label.',
      },
    },
    layout: 'centered',
  },
  argTypes: {
    variant: {
      control: 'radio',
      options: ['inline', 'centered', 'overlay'] satisfies LoaderVariant[],
    },
    size: {
      control: 'radio',
      options: ['sm', 'md', 'lg'] satisfies LoaderSize[],
    },
    color: {
      control: 'select',
      options: [
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark',
      ] satisfies LoaderColor[],
    },
    spinner: {
      control: 'select',
      options: [
        'bubbles', 'circles', 'circular', 'crescent', 'dots', 'lines', 'lines-sharp',
      ] satisfies SpinnerType[],
    },
    visible: { control: 'boolean' },
    label:   { control: 'text' },
  },
  args: {
    variant: 'inline',
    size:    'md',
    color:   'primary',
    spinner: 'circular',
    visible: true,
  },
};

export default meta;
type Story = StoryObj<typeof Loader>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { variant: 'inline', size: 'md', spinner: 'circular' },
};

// ─── Variants ────────────────────────────────────────────────────────────────

export const VariantInline: Story = {
  name: 'Variant / Inline',
  args: { variant: 'inline', label: 'Loading…' },
};

export const VariantCentered: Story = {
  name: 'Variant / Centered',
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface-subtle)', borderRadius: 12 }}>
        <Story />
      </div>
    ),
  ],
  args: { variant: 'centered', size: 'lg', label: 'Loading your account…' },
};

export const VariantOverlay: Story = {
  name: 'Variant / Overlay (interactive)',
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center' }}>
        <button
          onClick={() => { setOpen(true); setTimeout(() => setOpen(false), 2500); }}
          style={{
            fontFamily: 'Poppins, sans-serif', fontSize: 14, fontWeight: 600,
            padding: '10px 20px', borderRadius: 8, border: 'none',
            background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer',
          }}
        >
          Show overlay loader
        </button>
        <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: 12, color: '#6b7280', margin: 0 }}>
          Auto-dismisses after 2.5 s
        </p>
        <Loader variant="overlay" size="lg" label="Submitting application…" visible={open} />
      </div>
    );
  },
};

// ─── Spinner types ────────────────────────────────────────────────────────────

export const AllSpinners: Story = {
  name: 'Spinner / All types',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 24, justifyContent: 'center' }}>
      {(
        ['bubbles', 'circles', 'circular', 'crescent', 'dots', 'lines', 'lines-sharp'] as SpinnerType[]
      ).map((s) => (
        <div key={s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <Loader spinner={s} size="md" />
          <span style={{ fontFamily: 'Poppins, sans-serif', fontSize: 11, color: '#6b7280' }}>{s}</span>
        </div>
      ))}
    </div>
  ),
};

// ─── Sizes ────────────────────────────────────────────────────────────────────

export const AllSizes: Story = {
  name: 'Size / All sizes',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
      {(['sm', 'md', 'lg'] as LoaderSize[]).map((size) => (
        <div key={size} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <Loader size={size} spinner="circular" />
          <span style={{ fontFamily: 'Poppins, sans-serif', fontSize: 11, color: '#6b7280' }}>{size}</span>
        </div>
      ))}
    </div>
  ),
};

// ─── Colors ───────────────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'Color / All colors',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 20 }}>
      {(
        ['primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'medium', 'dark'] as LoaderColor[]
      ).map((color) => (
        <div key={color} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <Loader color={color} size="md" spinner="circular" />
          <span style={{ fontFamily: 'Poppins, sans-serif', fontSize: 11, color: '#6b7280' }}>{color}</span>
        </div>
      ))}
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppInlineRow: Story = {
  name: 'App / Inline in list row',
  render: () => (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '14px 16px', background: '#fff', borderRadius: 8,
      boxShadow: '0 1px 4px rgba(0,0,0,0.08)', width: 320,
      fontFamily: 'Poppins, sans-serif',
    }}>
      <Loader size="sm" spinner="crescent" />
      <span style={{ fontSize: 14, color: '#0d343f' }}>Uploading document…</span>
    </div>
  ),
};

export const AppPageLoad: Story = {
  name: 'App / Full page load',
  decorators: [
    (Story) => (
      <div style={{ width: 360, height: 240, background: '#f6f8fc',
        borderRadius: 12, position: 'relative', overflow: 'hidden' }}>
        <Story />
      </div>
    ),
  ],
  render: () => (
    <Loader variant="centered" size="lg" label="Loading your dashboard…" spinner="circular" />
  ),
};

export const AppLoanSubmit: Story = {
  name: 'App / Loan submission overlay',
  render: () => {
    const [submitting, setSubmitting] = useState(false);
    const [done, setDone] = useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'center' }}>
        {!done ? (
          <button
            onClick={() => { setSubmitting(true); setTimeout(() => { setSubmitting(false); setDone(true); }, 2000); }}
            style={{
              fontFamily: 'Poppins, sans-serif', fontSize: 14, fontWeight: 600,
              padding: '12px 24px', borderRadius: 8, border: 'none',
              background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer',
            }}
          >
            Submit loan application
          </button>
        ) : (
          <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: 14, color: 'var(--av-color-success)', fontWeight: 600 }}>
            ✓ Application submitted
          </p>
        )}
        <Loader variant="overlay" size="lg" label="Submitting your application…" visible={submitting} />
      </div>
    );
  },
};
