import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  personOutline,
  mailOutline,
  callOutline,
  cardOutline,
  documentTextOutline,
  eyeOutline,
  starOutline,
  chevronForwardOutline,
  checkmarkCircleOutline,
  alertCircleOutline,
  timeOutline,
  cashOutline,
  businessOutline,
  receiptOutline,
  downloadOutline,
  calendarOutline,
  settingsOutline,
  notificationsOutline,
  lockClosedOutline,
  helpCircleOutline,
  logOutOutline,
} from 'ionicons/icons';
import { IonIcon, IonBadge, IonList, IonNote } from '@ionic/react';
import { Item, ItemDivider } from './Item';
import { Badge } from './Badge';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Item> = {
  title: 'Avenews/Ionic/Item',
  component: Item,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Universal list item built on `IonItem`.',
          'Supports 10 color tokens, 3 states (default / hover / disabled), 2 text layout variants,',
          'fully composable start/end slots, and an optional detail chevron.',
          'Pair with `ItemDivider` to create grouped list sections.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '360px', background: 'var(--av-color-surface-subtle, #f3f5f7)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'],
    },
    variant: { control: 'radio', options: ['default', 'list3'] },
    lines: { control: 'radio', options: ['full', 'inset', 'none'] },
  },
  args: {
    label: 'List item',
    color: 'default',
    variant: 'default',
    lines: 'full',
    detailArrow: false,
    disabled: false,
  },
};

export default meta;
type Story = StoryObj<typeof Item>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: {
    label: 'List item',
    startSlot: <IonIcon icon={personOutline} />,
    endSlot: <IonIcon icon={starOutline} />,
    detailArrow: true,
    button: true,
  },
};

// ─── Colors ───────────────────────────────────────────────────────────────────

export const ColorDefault: Story = {
  name: 'Color / Default (white)',
  args: {
    label: 'Default item',
    startSlot: <IonIcon icon={personOutline} />,
    endSlot: <IonIcon icon={starOutline} />,
    detailArrow: true,
    button: true,
    color: 'default',
  },
};

export const ColorPrimary: Story = {
  name: 'Color / Primary',
  args: { label: 'Primary item', color: 'primary', startSlot: <IonIcon icon={personOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const ColorSecondary: Story = {
  name: 'Color / Secondary',
  args: { label: 'Secondary item', color: 'secondary', startSlot: <IonIcon icon={personOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const ColorTertiary: Story = {
  name: 'Color / Tertiary',
  args: { label: 'Tertiary item', color: 'tertiary', startSlot: <IonIcon icon={personOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const ColorSuccess: Story = {
  name: 'Color / Success',
  args: { label: 'Success item', color: 'success', startSlot: <IonIcon icon={checkmarkCircleOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const ColorWarning: Story = {
  name: 'Color / Warning',
  args: { label: 'Warning item', color: 'warning', startSlot: <IonIcon icon={alertCircleOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const ColorDanger: Story = {
  name: 'Color / Danger',
  args: { label: 'Danger item', color: 'danger', startSlot: <IonIcon icon={alertCircleOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const ColorLight: Story = {
  name: 'Color / Light',
  args: { label: 'Light item', color: 'light', startSlot: <IonIcon icon={personOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const ColorMedium: Story = {
  name: 'Color / Medium',
  args: { label: 'Medium item', color: 'medium', startSlot: <IonIcon icon={personOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const ColorDark: Story = {
  name: 'Color / Dark',
  args: { label: 'Dark item', color: 'dark', startSlot: <IonIcon icon={personOutline} />, endSlot: <IonIcon icon={starOutline} />, detailArrow: true, button: true },
};

export const AllColors: Story = {
  name: 'Color / All colors',
  render: () => (
    <IonList style={{ padding: 0 }}>
      {(['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] as const).map((color) => (
        <Item
          key={color}
          label={color.charAt(0).toUpperCase() + color.slice(1)}
          color={color}
          startSlot={<IonIcon icon={personOutline} />}
          endSlot={<IonIcon icon={starOutline} />}
          detailArrow
          button
        />
      ))}
    </IonList>
  ),
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateDefault: Story = {
  name: 'State / Default',
  args: {
    label: 'Default state',
    startSlot: <IonIcon icon={personOutline} />,
    detailArrow: true,
    button: true,
  },
};

export const StateHover: Story = {
  name: 'State / Hover (interactive — hover to see)',
  args: {
    label: 'Hover state — hover me',
    startSlot: <IonIcon icon={personOutline} />,
    endSlot: <IonIcon icon={starOutline} />,
    detailArrow: true,
    button: true,
  },
};

export const StateDisabled: Story = {
  name: 'State / Disabled',
  args: {
    label: 'Disabled item',
    startSlot: <IonIcon icon={personOutline} />,
    endSlot: <IonIcon icon={starOutline} />,
    detailArrow: true,
    disabled: true,
  },
};

export const AllColorsDisabled: Story = {
  name: 'State / All colors disabled',
  render: () => (
    <IonList style={{ padding: 0 }}>
      {(['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] as const).map((color) => (
        <Item
          key={color}
          label={color.charAt(0).toUpperCase() + color.slice(1)}
          color={color}
          startSlot={<IonIcon icon={personOutline} />}
          endSlot={<IonIcon icon={starOutline} />}
          detailArrow
          disabled
        />
      ))}
    </IonList>
  ),
};

// ─── Text lines ───────────────────────────────────────────────────────────────

export const OneLine: Story = {
  name: 'Text / One line',
  args: {
    label: 'Single line item',
    startSlot: <IonIcon icon={personOutline} />,
    detailArrow: true,
    button: true,
  },
};

export const TwoLines: Story = {
  name: 'Text / Two lines',
  args: {
    label: 'Primary text',
    secondLine: 'Secondary text — muted detail',
    startSlot: <IonIcon icon={mailOutline} />,
    detailArrow: true,
    button: true,
  },
};

export const ThreeLines: Story = {
  name: 'Text / Three lines',
  args: {
    label: 'Primary text',
    secondLine: 'Secondary text',
    thirdLine: 'Tertiary text — additional detail',
    startSlot: <IonIcon icon={documentTextOutline} />,
    detailArrow: true,
    button: true,
  },
};

// ─── Variant: List 3 ──────────────────────────────────────────────────────────

export const VariantList3: Story = {
  name: 'Variant / List 3 (card-style text)',
  args: {
    label: 'Invoice #2847',
    secondLine: 'KES 45,000',
    thirdLine: '14 Jan 2025 · Pending',
    variant: 'list3',
    startSlot: <IonIcon icon={receiptOutline} />,
    endSlot: <IonIcon icon={starOutline} />,
    detailArrow: true,
    button: true,
  },
};

export const VariantList3Gallery: Story = {
  name: 'Variant / List 3 — gallery',
  render: () => (
    <IonList style={{ padding: 0 }}>
      <Item
        variant="list3"
        label="Due today"
        secondLine="Nairobi Traders Ltd"
        thirdLine="KES 120,000 · Repayment"
        startSlot={<IonIcon icon={cashOutline} />}
        detailArrow
        button
      />
      <Item
        variant="list3"
        label="Invoice #3901"
        secondLine="Avenews Finance"
        thirdLine="KES 55,000 · Processing"
        startSlot={<IonIcon icon={receiptOutline} />}
        endSlot={<Badge variant="warning" count="Due" />}
        detailArrow
        button
      />
      <Item
        variant="list3"
        label="3 Feb 2025"
        secondLine="Loan disbursed"
        thirdLine="KES 200,000 · Completed"
        startSlot={<IonIcon icon={calendarOutline} />}
        endSlot={<Badge variant="success" count="Paid" />}
        detailArrow
        button
      />
    </IonList>
  ),
};

// ─── Features ─────────────────────────────────────────────────────────────────

export const WithDetailArrow: Story = {
  name: 'Feature / Detail arrow',
  args: {
    label: 'Navigate somewhere',
    startSlot: <IonIcon icon={chevronForwardOutline} />,
    detailArrow: true,
    button: true,
  },
};

export const NoDetailArrow: Story = {
  name: 'Feature / No detail arrow',
  args: {
    label: 'No navigation arrow',
    startSlot: <IonIcon icon={personOutline} />,
    detailArrow: false,
    button: true,
  },
};

export const WithBadgeEndSlot: Story = {
  name: 'Feature / Badge end slot',
  args: {
    label: 'Notifications',
    startSlot: <IonIcon icon={notificationsOutline} />,
    endSlot: <Badge variant="danger" count="3" />,
    detailArrow: true,
    button: true,
  },
};

export const WithNoteEndSlot: Story = {
  name: 'Feature / Note end slot',
  args: {
    label: 'Transaction date',
    startSlot: <IonIcon icon={calendarOutline} />,
    endSlot: <IonNote style={{ fontSize: '14px' }}>14 Jan</IonNote>,
    detailArrow: true,
    button: true,
  },
};

export const LinesInset: Story = {
  name: 'Feature / Lines inset',
  render: () => (
    <IonList style={{ padding: 0 }}>
      <Item label="Item one"   startSlot={<IonIcon icon={personOutline} />}   lines="inset" button />
      <Item label="Item two"   startSlot={<IonIcon icon={mailOutline} />}     lines="inset" button />
      <Item label="Item three" startSlot={<IonIcon icon={callOutline} />}     lines="none"  button />
    </IonList>
  ),
};

export const LinesNone: Story = {
  name: 'Feature / Lines none',
  render: () => (
    <IonList style={{ padding: 0 }}>
      <Item label="Item one"   startSlot={<IonIcon icon={personOutline} />}   lines="none" button />
      <Item label="Item two"   startSlot={<IonIcon icon={mailOutline} />}     lines="none" button />
      <Item label="Item three" startSlot={<IonIcon icon={callOutline} />}     lines="none" button />
    </IonList>
  ),
};

export const Loading: Story = {
  name: 'Feature / Loading skeleton',
  args: { label: 'Loading…', loading: true },
};

// ─── Item Divider ─────────────────────────────────────────────────────────────

export const DividerDefault: Story = {
  name: 'ItemDivider / Default',
  render: () => <ItemDivider label="Section header" />,
};

export const DividerAllColors: Story = {
  name: 'ItemDivider / All colors',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      {(['default', 'primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'light', 'medium', 'dark'] as const).map((color) => (
        <ItemDivider key={color} label={color.charAt(0).toUpperCase() + color.slice(1)} color={color} />
      ))}
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppSettingsList: Story = {
  name: 'App / Settings list',
  render: () => (
    <IonList style={{ padding: 0 }}>
      <ItemDivider label="Account" />
      <Item label="Profile"          startSlot={<IonIcon icon={personOutline} />}       detailArrow button />
      <Item label="Notifications"    startSlot={<IonIcon icon={notificationsOutline} />} endSlot={<Badge variant="danger" count="2" />} detailArrow button />
      <Item label="Security"         startSlot={<IonIcon icon={lockClosedOutline} />}    detailArrow button />
      <ItemDivider label="Support" />
      <Item label="Help & FAQ"       startSlot={<IonIcon icon={helpCircleOutline} />}    detailArrow button />
      <Item label="Sign out"         startSlot={<IonIcon icon={logOutOutline} />}        color="danger"  button />
    </IonList>
  ),
};

export const AppTransactionList: Story = {
  name: 'App / Transaction list',
  render: () => (
    <IonList style={{ padding: 0 }}>
      <ItemDivider label="January 2025" />
      <Item
        variant="list3"
        label="Invoice #2847"
        secondLine="Nairobi Traders Ltd"
        thirdLine="KES 45,000 · Disbursed"
        startSlot={<IonIcon icon={cashOutline} />}
        endSlot={<Badge variant="success" count="Paid" />}
        detailArrow button
      />
      <Item
        variant="list3"
        label="Repayment due"
        secondLine="Avenews Finance"
        thirdLine="KES 120,000 · 28 Jan 2025"
        startSlot={<IonIcon icon={receiptOutline} />}
        endSlot={<Badge variant="warning" count="Due" />}
        detailArrow button
      />
      <Item
        variant="list3"
        label="Invoice #2801"
        secondLine="Mombasa Suppliers"
        thirdLine="KES 18,500 · Processing"
        startSlot={<IonIcon icon={cashOutline} />}
        endSlot={<Badge variant="primary" count="Pending" />}
        detailArrow button
      />
      <ItemDivider label="December 2024" />
      <Item
        variant="list3"
        label="Invoice #2750"
        secondLine="Kisumu Traders"
        thirdLine="KES 32,000 · Completed"
        startSlot={<IonIcon icon={cashOutline} />}
        endSlot={<Badge variant="success" count="Paid" />}
        detailArrow button
      />
    </IonList>
  ),
};

export const AppDocumentList: Story = {
  name: 'App / Document / file list',
  render: () => (
    <IonList style={{ padding: 0 }}>
      <ItemDivider label="Uploaded documents" />
      <Item
        label="Business registration"
        secondLine="PDF · 2.4 MB"
        startSlot={<IonIcon icon={documentTextOutline} />}
        endSlot={<IonIcon icon={eyeOutline} />}
        detailArrow
        button
      />
      <Item
        label="KRA PIN certificate"
        secondLine="PDF · 0.8 MB"
        startSlot={<IonIcon icon={documentTextOutline} />}
        endSlot={<IonIcon icon={eyeOutline} />}
        detailArrow
        button
      />
      <Item
        label="Bank statement"
        secondLine="PDF · 5.1 MB"
        startSlot={<IonIcon icon={documentTextOutline} />}
        endSlot={<IonIcon icon={downloadOutline} />}
        detailArrow
        button
        color="primary"
      />
    </IonList>
  ),
};

export const AppProfileCard: Story = {
  name: 'App / Profile info list',
  render: () => (
    <IonList style={{ padding: 0 }}>
      <ItemDivider label="Business details" />
      <Item label="Business name"   secondLine="Nairobi Traders Ltd"       startSlot={<IonIcon icon={businessOutline} />}  lines="full" />
      <Item label="Email address"   secondLine="admin@nairobitraders.co.ke" startSlot={<IonIcon icon={mailOutline} />}       lines="full" />
      <Item label="Phone number"    secondLine="+254 722 123 456"           startSlot={<IonIcon icon={callOutline} />}       lines="full" />
      <Item label="KRA PIN"         secondLine="A001234567X"                startSlot={<IonIcon icon={cardOutline} />}       lines="none" />
    </IonList>
  ),
};
