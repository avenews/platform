import type { Meta, StoryObj } from '@storybook/react';
import { IonButton, IonButtons, IonContent, IonHeader, IonModal, IonTitle, IonToolbar } from '@ionic/react';
import { useRef } from 'react';
import { Datetime } from './Datetime';
import type { DatetimeColor } from './Datetime';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Datetime> = {
  title: 'Avenews/Ionic/Datetime',
  component: Datetime,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Wraps Ionic `IonDatetime`. Supports 9 colour tokens, 7 presentation modes, and optional',
          'disabled-date filtering. Use standalone (inline) or place inside `IonModal` for the',
          'Figma "Date-modal" pattern.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
  argTypes: {
    color: {
      control: 'select',
      options: [
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark',
      ] satisfies DatetimeColor[],
    },
    presentation: {
      control: 'select',
      options: ['date', 'date-time', 'time', 'time-date', 'month-year', 'month', 'year'],
    },
  },
  args: {
    color:        'primary',
    presentation: 'date-time',
    showDefaultButtons: false,
    showDefaultTitle:   false,
    locale: 'en-US',
  },
};

export default meta;
type Story = StoryObj<typeof Datetime>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (date-time, primary)',
  args: {
    value: '2024-06-12T10:00:00',
  },
};

// ─── Presentation modes ───────────────────────────────────────────────────────

export const DateOnly: Story = {
  name: 'Presentation / Date',
  args: { presentation: 'date', value: '2024-06-12' },
};

export const DateTime: Story = {
  name: 'Presentation / Date + Time',
  args: { presentation: 'date-time', value: '2024-06-12T10:00:00' },
};

export const TimeOnly: Story = {
  name: 'Presentation / Time',
  args: { presentation: 'time', value: '10:00:00' },
};

export const MonthYear: Story = {
  name: 'Presentation / Month + Year',
  args: { presentation: 'month-year', value: '2024-06' },
};

// ─── With action buttons ──────────────────────────────────────────────────────

export const WithButtons: Story = {
  name: 'With Default Buttons (Clear / Today)',
  args: {
    presentation: 'date',
    value: '2024-06-12',
    showDefaultButtons: true,
  },
};

// ─── Date constraints ─────────────────────────────────────────────────────────

export const WithMinMax: Story = {
  name: 'With Min / Max range',
  args: {
    presentation: 'date',
    value: '2024-06-12',
    min: '2024-06-01',
    max: '2024-06-30',
    showDefaultButtons: true,
  },
};

export const WithDisabledDates: Story = {
  name: 'With Disabled Dates (weekends off)',
  args: {
    presentation: 'date',
    value: '2024-06-12',
    isDateEnabled: (iso: string) => {
      const day = new Date(iso).getUTCDay();
      return day !== 0 && day !== 6; // disable Sat & Sun
    },
  },
};

// ─── Color variants ───────────────────────────────────────────────────────────

const SHARED = { presentation: 'date' as const, value: '2024-06-12', showDefaultButtons: true };

export const Primary:   Story = { name: 'Color / Primary',   args: { ...SHARED, color: 'primary'   } };
export const Secondary: Story = { name: 'Color / Secondary', args: { ...SHARED, color: 'secondary' } };
export const Tertiary:  Story = { name: 'Color / Tertiary',  args: { ...SHARED, color: 'tertiary'  } };
export const Success:   Story = { name: 'Color / Success',   args: { ...SHARED, color: 'success'   } };
export const Warning:   Story = { name: 'Color / Warning',   args: { ...SHARED, color: 'warning'   } };
export const Danger:    Story = { name: 'Color / Danger',    args: { ...SHARED, color: 'danger'    } };
export const Light:     Story = { name: 'Color / Light',     args: { ...SHARED, color: 'light'     } };
export const Medium:    Story = { name: 'Color / Medium',    args: { ...SHARED, color: 'medium'    } };
export const Dark:      Story = { name: 'Color / Dark',      args: { ...SHARED, color: 'dark'      } };

export const AllColors: Story = {
  name: 'All Colors',
  render: () => {
    const COLORS: DatetimeColor[] = [
      'primary', 'secondary', 'tertiary',
      'success', 'warning',   'danger',
      'light',   'medium',    'dark',
    ];
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '32px', justifyContent: 'center' }}>
        {COLORS.map((c) => (
          <div key={c} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <Datetime
              color={c}
              presentation="date"
              value="2024-06-12"
              showDefaultButtons
            />
            <span style={{
              fontFamily: 'var(--av-font-body)',
              fontSize:   '12px',
              color:      'var(--av-color-text-muted)',
              textTransform: 'capitalize',
            }}>
              {c}
            </span>
          </div>
        ))}
      </div>
    );
  },
};

// ─── Modal pattern ────────────────────────────────────────────────────────────

export const InModal: Story = {
  name: 'Date-modal pattern (IonModal)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const modal = useRef<HTMLIonModalElement>(null);

    return (
      <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px', alignItems: 'flex-start' }}>
        <p style={{ fontFamily: 'var(--av-font-body)', fontSize: '14px', color: 'var(--av-color-text-muted)', margin: 0 }}>
          Tap the button to open the date picker in a modal — matching the Figma "Date-modal" pattern.
        </p>

        <IonButton
          id="open-datetime-modal"
          className="avenews-button"
          style={{ '--background': 'var(--av-color-action)', '--color': '#fff' } as React.CSSProperties}
        >
          Pick a date
        </IonButton>

        <IonModal
          ref={modal}
          trigger="open-datetime-modal"
          style={{ '--width': '320px', '--height': 'auto', '--border-radius': '4px' } as React.CSSProperties}
        >
          <IonHeader>
            <IonToolbar>
              <IonTitle style={{ fontFamily: 'var(--av-font-body)', fontSize: '16px' }}>Select date</IonTitle>
              <IonButtons slot="end">
                <IonButton onClick={() => modal.current?.dismiss()}>Done</IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <Datetime
              color="primary"
              presentation="date"
              value="2024-06-12"
              showDefaultButtons
              onIonChange={(v) => {
                console.log('Selected:', v);
                modal.current?.dismiss();
              }}
            />
          </IonContent>
        </IonModal>
      </div>
    );
  },
};
