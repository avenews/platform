import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import { RadioGroup } from './Radio';
import type { RadioColor, RadioLayout } from './Radio';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof RadioGroup> = {
  title: 'Avenews/Ionic/Radio',
  component: RadioGroup,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Radio group built on `IonRadioGroup` + `IonRadio`. ' +
          'Supports stacked and inline layouts, optional per-option descriptions, ' +
          '9 colour tokens, error and helper text.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    color: {
      control: 'select',
      options: [
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark',
      ] satisfies RadioColor[],
    },
    layout: {
      control: 'radio',
      options: ['stacked', 'inline'] satisfies RadioLayout[],
    },
    disabled: { control: 'boolean' },
    error:    { control: 'boolean' },
  },
  args: {
    color:  'primary',
    layout: 'stacked',
  },
};

export default meta;
type Story = StoryObj<typeof RadioGroup>;

// ─── Shared options ────────────────────────────────────────────────────────────

const LOAN_OPTIONS = [
  { value: 'working-capital', label: 'Working capital' },
  { value: 'invoice',         label: 'Invoice financing' },
  { value: 'asset',           label: 'Asset finance' },
];

const TENURE_OPTIONS = [
  { value: '3m',  label: '3 months' },
  { value: '6m',  label: '6 months' },
  { value: '12m', label: '12 months' },
  { value: '24m', label: '24 months' },
];

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: {
    name:    'loan-type',
    options: LOAN_OPTIONS,
    value:   'working-capital',
    label:   'Loan type',
  },
};

// ─── Layouts ──────────────────────────────────────────────────────────────────

export const LayoutStacked: Story = {
  name: 'Layout / Stacked',
  args: {
    name:    'tenure-stacked',
    options: TENURE_OPTIONS,
    value:   '6m',
    layout:  'stacked',
    label:   'Loan tenure',
  },
};

export const LayoutInline: Story = {
  name: 'Layout / Inline',
  args: {
    name:    'tenure-inline',
    options: TENURE_OPTIONS,
    value:   '12m',
    layout:  'inline',
    label:   'Loan tenure',
  },
};

// ─── With descriptions ────────────────────────────────────────────────────────

export const WithDescriptions: Story = {
  name: 'Feature / With descriptions',
  args: {
    name:   'loan-desc',
    value:  'working-capital',
    label:  'Select loan product',
    options: [
      { value: 'working-capital', label: 'Working capital',  description: 'Short-term operational funding' },
      { value: 'invoice',         label: 'Invoice financing', description: 'Advance against outstanding invoices' },
      { value: 'asset',           label: 'Asset finance',     description: 'Equipment or vehicle purchases' },
    ],
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateDisabled: Story = {
  name: 'State / Disabled',
  args: {
    name:     'disabled',
    options:  LOAN_OPTIONS,
    value:    'invoice',
    disabled: true,
    label:    'Loan type (disabled)',
  },
};

export const StateError: Story = {
  name: 'State / Error',
  args: {
    name:      'error',
    options:   LOAN_OPTIONS,
    error:     true,
    errorText: 'Please select a loan type to continue.',
    label:     'Loan type',
  },
};

export const StateHelper: Story = {
  name: 'State / Helper text',
  args: {
    name:       'helper',
    options:    LOAN_OPTIONS,
    value:      'asset',
    helperText: 'Your selection determines available loan amounts.',
    label:      'Loan type',
  },
};

// ─── All colors ───────────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'Color / All colors',
  render: () => (
    <div>
      {(
        ['primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'medium', 'dark'] as RadioColor[]
      ).map((color) => (
        <RadioGroup
          key={color}
          name={`color-${color}`}
          color={color}
          value="a"
          options={[
            { value: 'a', label: color.charAt(0).toUpperCase() + color.slice(1) },
            { value: 'b', label: 'Unselected' },
          ]}
        />
      ))}
    </div>
  ),
};

// ─── Interactive ──────────────────────────────────────────────────────────────

export const Interactive: Story = {
  name: 'Interactive / Controlled',
  render: () => {
    const [val, setVal] = useState('working-capital');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <RadioGroup
          name="interactive"
          label="Loan type"
          helperText="Selection updates live."
          options={LOAN_OPTIONS}
          value={val}
          onIonChange={setVal}
        />
        <p style={{ fontFamily: 'Poppins, sans-serif', fontSize: 13, color: '#6b7280', margin: '8px 16px 0', padding: 0 }}>
          Selected: <strong style={{ color: '#0d343f' }}>{val}</strong>
        </p>
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanApplication: Story = {
  name: 'App / Loan application',
  render: () => {
    const [product, setProduct] = useState('working-capital');
    const [tenure,  setTenure]  = useState('12m');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <RadioGroup
          name="product"
          label="Loan product"
          helperText="Select the product that best fits your need."
          value={product}
          onIonChange={setProduct}
          options={[
            { value: 'working-capital', label: 'Working capital',  description: 'Short-term operational funding' },
            { value: 'invoice',         label: 'Invoice financing', description: 'Advance against outstanding invoices' },
            { value: 'asset',           label: 'Asset finance',     description: 'Equipment or vehicle purchases' },
          ]}
        />
        <RadioGroup
          name="tenure"
          label="Loan tenure"
          value={tenure}
          onIonChange={setTenure}
          layout="inline"
          options={TENURE_OPTIONS}
        />
      </div>
    );
  },
};
