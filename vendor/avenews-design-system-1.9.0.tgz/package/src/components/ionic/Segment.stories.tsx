import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { documentOutline, timeOutline, checkmarkOutline, listOutline } from 'ionicons/icons';
import { Segment } from './Segment';

const meta: Meta<typeof Segment> = {
  title: 'Avenews/Ionic/Segment',
  component: Segment,
  tags: ['autodocs'],
  argTypes: {
    scrollable: {
      control: 'boolean',
      description: 'Scrollable mode — use when there are 5+ options or labels are long.',
    },
  },
  decorators: [(Story) => (
    <div style={{ maxWidth: '400px', padding: '16px', background: 'var(--av-color-background)' }}>
      <Story />
    </div>
  )],
};

export default meta;
type Story = StoryObj<typeof Segment>;

// ─── Stories ─────────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Text Only (2 options)',
  render: () => {
    const [val, setVal] = useState('active');
    return (
      <Segment
        value={val}
        onIonChange={setVal}
        options={[
          { value: 'active', label: 'Active' },
          { value: 'completed', label: 'Completed' },
        ]}
      />
    );
  },
};

export const ThreeOptions: Story = {
  name: 'Text Only (3 options)',
  render: () => {
    const [val, setVal] = useState('all');
    return (
      <Segment
        value={val}
        onIonChange={setVal}
        options={[
          { value: 'all', label: 'All' },
          { value: 'pending', label: 'Pending' },
          { value: 'completed', label: 'Completed' },
        ]}
      />
    );
  },
};

export const FourOptions: Story = {
  name: 'Text Only (4 options)',
  render: () => {
    const [val, setVal] = useState('overview');
    return (
      <Segment
        value={val}
        onIonChange={setVal}
        options={[
          { value: 'overview', label: 'Overview' },
          { value: 'documents', label: 'Documents' },
          { value: 'payments', label: 'Payments' },
          { value: 'history', label: 'History' },
        ]}
      />
    );
  },
};

export const WithIconsTop: Story = {
  name: 'With Icons (top)',
  render: () => {
    const [val, setVal] = useState('documents');
    return (
      <Segment
        value={val}
        onIonChange={setVal}
        options={[
          { value: 'documents', label: 'Documents', icon: documentOutline, iconPosition: 'top' },
          { value: 'history', label: 'History', icon: timeOutline, iconPosition: 'top' },
          { value: 'status', label: 'Status', icon: checkmarkOutline, iconPosition: 'top' },
        ]}
      />
    );
  },
};

export const WithDisabledOption: Story = {
  name: 'With Disabled Option',
  render: () => {
    const [val, setVal] = useState('overview');
    return (
      <Segment
        value={val}
        onIonChange={setVal}
        options={[
          { value: 'overview', label: 'Overview' },
          { value: 'documents', label: 'Documents' },
          { value: 'analytics', label: 'Analytics', disabled: true },
        ]}
      />
    );
  },
};

export const Scrollable: Story = {
  name: 'Scrollable (many options)',
  render: () => {
    const [val, setVal] = useState('jan');
    return (
      <Segment
        value={val}
        onIonChange={setVal}
        scrollable
        options={[
          { value: 'jan', label: 'January' },
          { value: 'feb', label: 'February' },
          { value: 'mar', label: 'March' },
          { value: 'apr', label: 'April' },
          { value: 'may', label: 'May' },
          { value: 'jun', label: 'June' },
        ]}
      />
    );
  },
};

export const DocumentFilter: Story = {
  name: 'Document Filter (in-app context)',
  render: () => {
    const [filter, setFilter] = useState('all');
    return (
      <div>
        <Segment
          value={filter}
          onIonChange={setFilter}
          options={[
            { value: 'all', label: 'All', icon: listOutline, iconPosition: 'start' },
            { value: 'pending', label: 'Pending', icon: timeOutline, iconPosition: 'start' },
            { value: 'done', label: 'Uploaded', icon: checkmarkOutline, iconPosition: 'start' },
          ]}
        />
        <p style={{ marginTop: '12px', fontSize: '13px', color: 'var(--av-color-text-muted)' }}>
          Active filter: <strong>{filter}</strong>
        </p>
      </div>
    );
  },
};
