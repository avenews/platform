import React from 'react';
import { IonAvatar, IonThumbnail, IonIcon } from '@ionic/react';

export type MediaIconColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark'
  | 'white'   | 'black';

export type MediaIconSize  = 'sm' | 'default' | 'lg';
export type AvatarSize     = 'sm' | 'md' | 'lg';
export type ThumbnailSize  = 'sm' | 'md' | 'lg';

export interface AvatarProps {
  src?: string;
  alt?: string;
  initials?: string;
  size?: AvatarSize;
  className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({ src, alt = '', initials, size = 'md', className }) => (
  <IonAvatar className={['avenews-avatar', `avenews-avatar--${size}`, className].filter(Boolean).join(' ')}>
    {src ? (
      <img src={src} alt={alt} />
    ) : initials ? (
      <span className="avenews-avatar__initials">{initials.slice(0, 2).toUpperCase()}</span>
    ) : (
      <span className="avenews-avatar__placeholder" aria-hidden="true" />
    )}
  </IonAvatar>
);

export interface ThumbnailProps {
  src?: string;
  alt?: string;
  size?: ThumbnailSize;
  className?: string;
}

export const Thumbnail: React.FC<ThumbnailProps> = ({ src, alt = '', size = 'md', className }) => (
  <IonThumbnail className={['avenews-thumbnail', `avenews-thumbnail--${size}`, className].filter(Boolean).join(' ')}>
    {src ? <img src={src} alt={alt} /> : <span className="avenews-thumbnail__placeholder" aria-hidden="true" />}
  </IonThumbnail>
);

export interface MediaIconProps {
  icon: string;
  color?: MediaIconColor;
  size?: MediaIconSize;
  className?: string;
}

const ICON_SIZES: Record<MediaIconSize, string> = { sm: '18px', default: '24px', lg: '32px' };
const CSS_ONLY   = new Set<MediaIconColor>(['white', 'black']);

export const MediaIcon: React.FC<MediaIconProps> = ({ icon, color = 'primary', size = 'default', className }) => {
  const useIonicColor = !CSS_ONLY.has(color);
  return (
    <IonIcon
      icon={icon}
      color={useIonicColor ? color : undefined}
      className={['avenews-media-icon', `avenews-media-icon--${size}`, !useIonicColor && `avenews-media-icon--${color}`, className].filter(Boolean).join(' ')}
      style={{ fontSize: ICON_SIZES[size] }}
    />
  );
};

export default MediaIcon;
