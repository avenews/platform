import React from 'react';
import { IonList, IonListHeader, IonLabel } from '@ionic/react';

export type ListColor =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light'   | 'medium'  | 'dark';

export type ListLines      = 'full' | 'inset' | 'none';
export type ListHeaderSize = 'default' | 'large';

export interface ListHeaderProps {
  label: string;
  size?: ListHeaderSize;
  color?: ListColor;
  className?: string;
}

export interface ListProps {
  children: React.ReactNode;
  inset?: boolean;
  lines?: ListLines;
  color?: ListColor;
  className?: string;
}

export const ListHeader: React.FC<ListHeaderProps> = ({
  label,
  size = 'default',
  color,
  className,
}) => (
  <IonListHeader
    color={color === 'default' ? undefined : color}
    className={['avenews-list-header', size === 'large' && 'avenews-list-header--large', className].filter(Boolean).join(' ')}
  >
    <IonLabel>{label}</IonLabel>
  </IonListHeader>
);

export const List: React.FC<ListProps> = ({
  children,
  inset = false,
  lines = 'inset',
  color,
  className,
}) => (
  <IonList
    inset={inset}
    lines={lines}
    color={color === 'default' ? undefined : color}
    className={['avenews-list', inset && 'avenews-list--inset', className].filter(Boolean).join(' ')}
  >
    {children}
  </IonList>
);

export default List;
