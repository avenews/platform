import React from 'react';
import {
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonSkeletonText,
} from '@ionic/react';
import { Button } from './Button';

export type CardColor =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light'   | 'medium'  | 'dark';

export type CardLayout = 'default' | 'media' | 'list';

export interface CardAction {
  label: string;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success' | 'warning';
  onClick?: () => void;
}

export interface CardProps {
  color?: CardColor;
  layout?: CardLayout;
  subtitle?: string;
  title: string;
  body?: string;
  imageUrl?: string;
  imageAlt?: string;
  actions?: CardAction[];
  listContent?: React.ReactNode;
  tappable?: boolean;
  disabled?: boolean;
  loading?: boolean;
  error?: string;
  routerLink?: string;
  onClick?: () => void;
  className?: string;
}

const CardSkeleton: React.FC<{ showImage: boolean }> = ({ showImage }) => (
  <IonCard className="avenews-card">
    {showImage && <IonSkeletonText animated style={{ height: '160px', margin: 0 }} />}
    <IonCardHeader>
      <IonSkeletonText animated style={{ width: '40%', height: '14px' }} />
      <IonSkeletonText animated style={{ width: '70%', height: '20px', marginTop: '8px' }} />
    </IonCardHeader>
    <IonCardContent>
      <IonSkeletonText animated style={{ width: '100%', height: '13px' }} />
      <IonSkeletonText animated style={{ width: '80%', height: '13px', marginTop: '4px' }} />
    </IonCardContent>
  </IonCard>
);

export const Card: React.FC<CardProps> = ({
  color    = 'default',
  layout   = 'default',
  subtitle,
  title,
  body,
  imageUrl,
  imageAlt = '',
  actions  = [],
  listContent,
  tappable = false,
  disabled = false,
  loading  = false,
  error,
  routerLink,
  onClick,
  className,
}) => {
  const showImage = layout === 'media' && !!imageUrl;
  const isColored = color !== 'default';
  if (loading) return <CardSkeleton showImage={showImage} />;

  return (
    <IonCard
      button={tappable}
      disabled={disabled}
      routerLink={routerLink}
      onClick={onClick}
      className={['avenews-card', isColored ? `avenews-card--${color}` : '', className].filter(Boolean).join(' ')}
    >
      {showImage && <img alt={imageAlt} src={imageUrl} style={{ height: '160px', objectFit: 'cover', width: '100%', display: 'block' }} />}
      <IonCardHeader>
        {subtitle && <IonCardSubtitle>{subtitle}</IonCardSubtitle>}
        <IonCardTitle>{title}</IonCardTitle>
      </IonCardHeader>
      {(body || listContent || error) && (
        <IonCardContent>
          {error ? <p className="avenews-card__error">{error}</p> : listContent ?? <p style={{ margin: 0 }}>{body}</p>}
        </IonCardContent>
      )}
      {actions.length > 0 && !error && (
        <div className={['avenews-card__actions', isColored ? 'avenews-card__actions--inverted' : ''].filter(Boolean).join(' ')}>
          {actions.slice(0, 3).map((a) => (
            <Button key={a.label} label={a.label} variant={a.variant ?? 'primary'} size="sm" onClick={a.onClick} />
          ))}
        </div>
      )}
    </IonCard>
  );
};

export default Card;
