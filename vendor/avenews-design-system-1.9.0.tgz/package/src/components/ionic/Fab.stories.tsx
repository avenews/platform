import type { Meta, StoryObj } from '@storybook/react';
import {
  addOutline,
  starOutline,
  cardOutline,
  arrowUpOutline,
  pencilOutline,
  shareOutline,
  heartOutline,
  cameraOutline,
  micOutline,
  chevronUpOutline,
} from 'ionicons/icons';
import { Fab } from './Fab';
import type { FabColor } from './Fab';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Fab> = {
  title: 'Avenews/Ionic/Fab',
  component: Fab,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Wraps `IonFabButton`. Supports 9 colour tokens, two sizes (main 56px / mini 40px),',
          'and an extended pill variant with a text label (e.g. the Figma "Repayments Action").',
          'Use standalone or inside `IonFab` + `IonFabList` for a speed-dial group.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
  argTypes: {
    color: {
      control: 'select',
      options: [
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark',
      ] satisfies FabColor[],
    },
    size: {
      control: 'radio',
      options: ['main', 'mini'],
    },
    label: { control: 'text' },
    disabled: { control: 'boolean' },
  },
  args: {
    icon: addOutline,
    color: 'primary',
    size: 'main',
    disabled: false,
  },
};

export default meta;
type Story = StoryObj<typeof Fab>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (primary, main)',
  args: { icon: addOutline, color: 'primary', size: 'main' },
};

// ─── Size variants ────────────────────────────────────────────────────────────

export const Main: Story = {
  name: 'Size / Main (56px)',
  args: { icon: addOutline, size: 'main' },
};

export const Mini: Story = {
  name: 'Size / Mini (40px)',
  args: { icon: addOutline, size: 'mini' },
};

export const MainVsMini: Story = {
  name: 'Size / Main vs Mini',
  render: () => (
    <div style={{ display: 'flex', gap: '24px', alignItems: 'center' }}>
      <Fab icon={addOutline} size="main" color="primary" />
      <Fab icon={addOutline} size="mini" color="primary" />
    </div>
  ),
};

// ─── Extended (labeled) ───────────────────────────────────────────────────────

export const Extended: Story = {
  name: 'Extended / Repayment Action',
  args: {
    icon: cardOutline,
    color: 'primary',
    size: 'main',
    label: 'Repayment',
  },
};

export const ExtendedVariants: Story = {
  name: 'Extended / All colors',
  render: () => {
    const COLORS: FabColor[] = ['primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'medium', 'dark'];
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', alignItems: 'flex-start' }}>
        {COLORS.map((c) => (
          <Fab key={c} icon={cardOutline} color={c} label="Repayment" />
        ))}
      </div>
    );
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const Disabled: Story = {
  name: 'State / Disabled',
  args: { icon: addOutline, color: 'primary', disabled: true },
};

export const DisabledMini: Story = {
  name: 'State / Disabled (mini)',
  args: { icon: addOutline, color: 'primary', size: 'mini', disabled: true },
};

// ─── Color variants ───────────────────────────────────────────────────────────

export const AllColors: Story = {
  name: 'All Colors (main)',
  render: () => {
    const COLORS: FabColor[] = [
      'primary', 'secondary', 'tertiary',
      'success', 'warning', 'danger',
      'light', 'medium', 'dark',
    ];
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', justifyContent: 'center', padding: '16px' }}>
        {COLORS.map((c) => (
          <div key={c} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <Fab icon={starOutline} color={c} />
            <span style={{
              fontFamily: 'var(--av-font-body)',
              fontSize: '11px',
              color: 'var(--av-color-text-muted)',
              textTransform: 'capitalize',
            }}>
              {c}
            </span>
          </div>
        ))}
      </div>
    );
  },
};

export const AllColorsMini: Story = {
  name: 'All Colors (mini)',
  render: () => {
    const COLORS: FabColor[] = [
      'primary', 'secondary', 'tertiary',
      'success', 'warning', 'danger',
      'light', 'medium', 'dark',
    ];
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', justifyContent: 'center', padding: '16px' }}>
        {COLORS.map((c) => (
          <div key={c} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <Fab icon={starOutline} color={c} size="mini" />
            <span style={{
              fontFamily: 'var(--av-font-body)',
              fontSize: '11px',
              color: 'var(--av-color-text-muted)',
              textTransform: 'capitalize',
            }}>
              {c}
            </span>
          </div>
        ))}
      </div>
    );
  },
};

// ─── Individual colors ────────────────────────────────────────────────────────

export const Primary:   Story = { name: 'Color / Primary',   args: { icon: addOutline,    color: 'primary'   } };
export const Secondary: Story = { name: 'Color / Secondary', args: { icon: addOutline,    color: 'secondary' } };
export const Tertiary:  Story = { name: 'Color / Tertiary',  args: { icon: addOutline,    color: 'tertiary'  } };
export const Success:   Story = { name: 'Color / Success',   args: { icon: arrowUpOutline, color: 'success'  } };
export const Warning:   Story = { name: 'Color / Warning',   args: { icon: pencilOutline, color: 'warning'   } };
export const Danger:    Story = { name: 'Color / Danger',    args: { icon: heartOutline,  color: 'danger'    } };
export const Light:     Story = { name: 'Color / Light',     args: { icon: cameraOutline, color: 'light'     } };
export const Medium:    Story = { name: 'Color / Medium',    args: { icon: shareOutline,  color: 'medium'    } };
export const Dark:      Story = { name: 'Color / Dark',      args: { icon: micOutline,    color: 'dark'      } };

// ─── Speed-dial group ─────────────────────────────────────────────────────────

export const SpeedDial: Story = {
  name: 'App / Speed-dial group (main + minis)',
  render: () => (
    <div style={{ position: 'relative', width: '120px', height: '220px' }}>
      {/* Mini actions above */}
      <div style={{
        position: 'absolute', bottom: '72px', left: '8px',
        display: 'flex', flexDirection: 'column', gap: '12px', alignItems: 'center',
      }}>
        <Fab icon={shareOutline}  color="secondary" size="mini" />
        <Fab icon={pencilOutline} color="tertiary"  size="mini" />
        <Fab icon={cameraOutline} color="success"   size="mini" />
      </div>
      {/* Main trigger */}
      <div style={{ position: 'absolute', bottom: '0', left: '0' }}>
        <Fab icon={chevronUpOutline} color="primary" size="main" />
      </div>
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const RepaymentAction: Story = {
  name: 'App / Repayment action (extended)',
  args: {
    icon: cardOutline,
    color: 'primary',
    label: 'Repayment',
  },
};

export const AddFundRequest: Story = {
  name: 'App / Add fund request',
  args: {
    icon: addOutline,
    color: 'primary',
  },
};
