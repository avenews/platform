import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import { Select } from './Select';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Select> = {
  title: 'Avenews/Ionic/Select',
  component: Select,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Select built on `IonSelect` + `IonSelectOption`. Supports stacked label, ' +
          'placeholder, helper/error text, disabled, required, and multi-select mode.',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, padding: 24, background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    disabled:    { control: 'boolean' },
    required:    { control: 'boolean' },
    multiple:    { control: 'boolean' },
    label:       { control: 'text' },
    placeholder: { control: 'text' },
    helperText:  { control: 'text' },
    error:       { control: 'text' },
  },
  args: {
    label:       'Loan type',
    placeholder: 'Select an option',
    options: [
      { value: 'working-capital', label: 'Working capital' },
      { value: 'invoice',         label: 'Invoice financing' },
      { value: 'asset',           label: 'Asset finance' },
    ],
  },
};

export default meta;
type Story = StoryObj<typeof Select>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { value: 'working-capital' },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateEmpty: Story = {
  name: 'State / Unselected',
  args: {},
};

export const StateDisabled: Story = {
  name: 'State / Disabled',
  args: { value: 'asset', disabled: true },
};

export const StateError: Story = {
  name: 'State / Error',
  args: { error: 'Please select a loan type to continue.' },
};

export const StateHelper: Story = {
  name: 'State / Helper text',
  args: { value: 'working-capital', helperText: 'Your selection determines available amounts.' },
};

export const StateRequired: Story = {
  name: 'State / Required',
  args: { required: true },
};

// ─── Multi-select ─────────────────────────────────────────────────────────────

export const MultiSelect: Story = {
  name: 'Feature / Multi-select',
  args: {
    label:       'Industries served',
    placeholder: 'Select industries',
    multiple:    true,
    options: [
      { value: 'retail',         label: 'Retail' },
      { value: 'agriculture',    label: 'Agriculture' },
      { value: 'manufacturing',  label: 'Manufacturing' },
      { value: 'services',       label: 'Professional services' },
      { value: 'technology',     label: 'Technology' },
    ],
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppLoanForm: Story = {
  name: 'App / Loan application form',
  render: () => {
    const [product, setProduct] = useState('');
    const [tenure,  setTenure]  = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <Select
          label="Loan product"
          placeholder="Select a product"
          required
          value={product}
          onIonChange={setProduct}
          options={[
            { value: 'working-capital', label: 'Working capital' },
            { value: 'invoice',         label: 'Invoice financing' },
            { value: 'asset',           label: 'Asset finance' },
          ]}
        />
        <Select
          label="Loan tenure"
          placeholder="Select tenure"
          value={tenure}
          onIonChange={setTenure}
          options={[
            { value: '3m',  label: '3 months' },
            { value: '6m',  label: '6 months' },
            { value: '12m', label: '12 months' },
            { value: '24m', label: '24 months' },
          ]}
        />
      </div>
    );
  },
};

export const AppKYCForm: Story = {
  name: 'App / KYC business form',
  render: () => {
    const [sector,    setSector]    = useState('');
    const [employees, setEmployees] = useState('');
    const [country,   setCountry]   = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <Select
          label="Business sector"
          placeholder="Select sector"
          required
          value={sector}
          onIonChange={setSector}
          options={[
            { value: 'agriculture',   label: 'Agriculture' },
            { value: 'manufacturing', label: 'Manufacturing' },
            { value: 'retail',        label: 'Retail & trade' },
            { value: 'services',      label: 'Professional services' },
            { value: 'technology',    label: 'Technology' },
          ]}
        />
        <Select
          label="Number of employees"
          placeholder="Select range"
          value={employees}
          onIonChange={setEmployees}
          options={[
            { value: '1-5',    label: '1–5 employees' },
            { value: '6-20',   label: '6–20 employees' },
            { value: '21-50',  label: '21–50 employees' },
            { value: '51-200', label: '51–200 employees' },
            { value: '200+',   label: '200+ employees' },
          ]}
        />
        <Select
          label="Country of registration"
          placeholder="Select country"
          required
          value={country}
          onIonChange={setCountry}
          options={[
            { value: 'ke', label: 'Kenya' },
            { value: 'ug', label: 'Uganda' },
            { value: 'tz', label: 'Tanzania' },
            { value: 'rw', label: 'Rwanda' },
            { value: 'et', label: 'Ethiopia' },
          ]}
        />
      </div>
    );
  },
};
