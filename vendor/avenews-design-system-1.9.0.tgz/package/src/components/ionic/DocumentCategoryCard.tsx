export { DocumentCategoryCard, DocumentCategoryCard as default } from '../cross-platform/DocumentCategoryCard';
export type { DocumentCategoryCardProps, CategoryStatus, DocRow } from '../cross-platform/DocumentCategoryCard';
