import React from 'react';
import { IonItem, IonLabel, IonIcon, IonSkeletonText } from '@ionic/react';
import { copyOutline } from 'ionicons/icons';
import { Badge } from './Badge';
import type { BadgeVariant } from './Badge';
import { cn } from '../shared/utils';

export type InfoRowVariant = 'default' | 'stacked' | 'with-copy' | 'with-badge';
export type InfoRowLines   = 'inset' | 'full' | 'none';

export interface InfoRowProps {
  label:         string;
  value?:        string;
  variant?:      InfoRowVariant;
  badgeVariant?: BadgeVariant;
  lines?:        InfoRowLines;
  loading?:      boolean;
  onCopy?:       () => void;
  className?:    string;
}

export const InfoRow: React.FC<InfoRowProps> = ({
  label,
  value,
  variant      = 'default',
  badgeVariant = 'neutral',
  lines        = 'inset',
  loading      = false,
  onCopy,
  className,
}) => {
  if (loading) {
    return (
      <IonItem lines={lines} className={cn('avenews-info-row avenews-info-row--loading', className)}>
        <IonLabel>
          <IonSkeletonText animated style={{ width: '35%', height: '12px' }} />
        </IonLabel>
        <div slot="end">
          <IonSkeletonText animated style={{ width: '120px', height: '14px' }} />
        </div>
      </IonItem>
    );
  }

  if (variant === 'stacked') {
    return (
      <IonItem lines={lines} className={cn('avenews-info-row avenews-info-row--stacked', className)}>
        <IonLabel>
          <p className="avenews-info-row__label">{label}</p>
          <h3 className="avenews-info-row__value">{value ?? '—'}</h3>
        </IonLabel>
      </IonItem>
    );
  }

  return (
    <IonItem
      lines={lines}
      className={cn('avenews-info-row', variant !== 'default' && `avenews-info-row--${variant}`, className)}
    >
      <IonLabel className="avenews-info-row__label">{label}</IonLabel>
      <div slot="end" className="avenews-info-row__end">
        {variant === 'with-badge'
          ? (value
              ? <Badge count={value} variant={badgeVariant} hideOnEmpty={false} />
              : <span className="avenews-info-row__value">—</span>
            )
          : <span className="avenews-info-row__value">{value ?? '—'}</span>
        }
        {variant === 'with-copy' && (
          <button
            type="button"
            onClick={onCopy}
            aria-label={`Copy ${label}`}
            className="avenews-info-row__copy-btn"
          >
            <IonIcon icon={copyOutline} className="avenews-info-row__copy-icon" aria-hidden="true" />
          </button>
        )}
      </div>
    </IonItem>
  );
};

export default InfoRow;
