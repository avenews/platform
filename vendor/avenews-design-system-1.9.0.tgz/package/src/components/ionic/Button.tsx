import React from 'react';
import { IonButton, IonIcon, IonSpinner } from '@ionic/react';

export type ButtonVariant =
  | 'primary' | 'secondary' | 'outline' | 'ghost'
  | 'danger'  | 'success'   | 'warning'
  | 'inverted' | 'inverted-outline';

export type ButtonSize   = 'sm' | 'md' | 'lg';
export type ButtonExpand = 'block' | 'full';

export interface ButtonProps {
  label: string;
  ariaLabel?: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  expand?: ButtonExpand;
  disabled?: boolean;
  loading?: boolean;
  icon?: string;
  iconSlot?: 'start' | 'end' | 'icon-only';
  onClick?: () => void;
}

export const Button: React.FC<ButtonProps> = ({
  label,
  ariaLabel,
  variant  = 'primary',
  size     = 'md',
  expand,
  disabled = false,
  loading  = false,
  icon,
  iconSlot = 'start',
  onClick,
}) => (
  <IonButton
    className={['avenews-button', `avenews-button--${variant}`, size !== 'md' ? `avenews-button--${size}` : '', expand ? `avenews-button--${expand}` : ''].filter(Boolean).join(' ')}
    disabled={disabled || loading}
    onClick={onClick}
    aria-label={ariaLabel ?? label}
  >
    {loading ? (
      <IonSpinner name="crescent" />
    ) : (
      <>
        {icon && <IonIcon icon={icon} slot={iconSlot} />}
        {iconSlot !== 'icon-only' && label}
      </>
    )}
  </IonButton>
);

export default Button;
