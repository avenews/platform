import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import {
  homeOutline, documentOutline, barChartOutline, personOutline,
  walletOutline, settingsOutline,
} from 'ionicons/icons';
import { Tabs } from './Tabs';
import type { TabItem } from './Tabs';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Tabs> = {
  title: 'Avenews/Ionic/Tabs',
  component: Tabs,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Tab bar built on `IonTabBar` + `IonTabButton`. Supports icon + label, ' +
          'badge count, disabled state, and `slot` positioning (`top` or `bottom`).',
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: 360, background: 'var(--av-color-surface)', borderRadius: 12, overflow: 'hidden' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    slot: { control: 'radio', options: ['top', 'bottom'] },
  },
  args: {
    slot: 'bottom',
  },
};

export default meta;
type Story = StoryObj<typeof Tabs>;

// ─── Shared data ──────────────────────────────────────────────────────────────

const NAV_TABS: TabItem[] = [
  { value: 'home',      label: 'Home',      icon: homeOutline },
  { value: 'documents', label: 'Documents', icon: documentOutline },
  { value: 'analytics', label: 'Analytics', icon: barChartOutline },
  { value: 'profile',   label: 'Profile',   icon: personOutline },
];

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  render: () => {
    const [val, setVal] = useState('home');
    return <Tabs tabs={NAV_TABS} value={val} onIonChange={setVal} />;
  },
};

// ─── Icon combinations ────────────────────────────────────────────────────────

export const IconAndLabel: Story = {
  name: 'Icons / Icon + label',
  render: () => {
    const [val, setVal] = useState('home');
    return <Tabs tabs={NAV_TABS} value={val} onIonChange={setVal} />;
  },
};

export const TextOnly: Story = {
  name: 'Text / Text only',
  render: () => {
    const [val, setVal] = useState('overview');
    return (
      <Tabs
        tabs={[
          { value: 'overview',  label: 'Overview' },
          { value: 'documents', label: 'Documents' },
          { value: 'payments',  label: 'Payments' },
          { value: 'activity',  label: 'Activity' },
        ]}
        value={val}
        onIonChange={setVal}
      />
    );
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const WithDisabledTab: Story = {
  name: 'State / Disabled tab',
  render: () => {
    const [val, setVal] = useState('home');
    return (
      <Tabs
        tabs={[
          { value: 'home',      label: 'Home',      icon: homeOutline },
          { value: 'documents', label: 'Documents', icon: documentOutline },
          { value: 'analytics', label: 'Analytics', icon: barChartOutline, disabled: true },
          { value: 'profile',   label: 'Profile',   icon: personOutline },
        ]}
        value={val}
        onIonChange={setVal}
      />
    );
  },
};

// ─── Features ────────────────────────────────────────────────────────────────

export const WithBadge: Story = {
  name: 'Feature / With badge',
  render: () => {
    const [val, setVal] = useState('home');
    return (
      <Tabs
        tabs={[
          { value: 'home',      label: 'Home',      icon: homeOutline },
          { value: 'documents', label: 'Documents', icon: documentOutline, badge: 3 },
          { value: 'wallet',    label: 'Wallet',    icon: walletOutline, badge: 12 },
          { value: 'profile',   label: 'Profile',   icon: personOutline },
        ]}
        value={val}
        onIonChange={setVal}
      />
    );
  },
};

export const SixTabs: Story = {
  name: 'Feature / Six tabs',
  render: () => {
    const [val, setVal] = useState('home');
    return (
      <Tabs
        tabs={[
          { value: 'home',      label: 'Home',     icon: homeOutline },
          { value: 'documents', label: 'Docs',     icon: documentOutline },
          { value: 'analytics', label: 'Reports',  icon: barChartOutline },
          { value: 'wallet',    label: 'Wallet',   icon: walletOutline },
          { value: 'settings',  label: 'Settings', icon: settingsOutline },
          { value: 'profile',   label: 'Profile',  icon: personOutline },
        ]}
        value={val}
        onIonChange={setVal}
      />
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const AppDashboard: Story = {
  name: 'App / Dashboard bottom nav',
  render: () => {
    const [val, setVal] = useState('home');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        <div style={{
          padding: '24px 20px',
          fontFamily: 'Poppins, sans-serif', fontSize: 14,
          color: 'var(--av-color-text-muted)',
          borderBottom: '1px solid var(--av-color-surface-border)',
        }}>
          Active tab: <strong style={{ color: 'var(--av-color-text)' }}>{val}</strong>
        </div>
        <Tabs
          tabs={[
            { value: 'home',      label: 'Home',      icon: homeOutline },
            { value: 'documents', label: 'Documents', icon: documentOutline, badge: 2 },
            { value: 'analytics', label: 'Analytics', icon: barChartOutline },
            { value: 'profile',   label: 'Profile',   icon: personOutline },
          ]}
          value={val}
          onIonChange={setVal}
        />
      </div>
    );
  },
};
