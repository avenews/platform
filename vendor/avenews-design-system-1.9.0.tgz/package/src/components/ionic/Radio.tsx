import React from 'react';
import {
  IonRadioGroup,
  IonRadio,
  IonItem,
  IonLabel,
  IonList,
} from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────

export type RadioColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

export type RadioLayout = 'stacked' | 'inline';

export interface RadioOption {
  value:        string;
  label:        string;
  description?: string;
  disabled?:    boolean;
}

// ─── Radio Group ──────────────────────────────────────────────────────────────

export interface RadioGroupProps {
  name?:        string;
  value?:       string;
  options:      RadioOption[];
  layout?:      RadioLayout;
  color?:       RadioColor;
  disabled?:    boolean;
  label?:       string;
  helperText?:  string;
  errorText?:   string;
  error?:       boolean;
  onIonChange?: (value: string) => void;
  className?:   string;
}

export const RadioGroup: React.FC<RadioGroupProps> = ({
  name,
  value,
  options,
  layout    = 'stacked',
  color     = 'primary',
  disabled  = false,
  label,
  helperText,
  errorText,
  error     = false,
  onIonChange,
  className,
}) => (
  <div
    className={[
      'avenews-radio-group',
      `avenews-radio-group--${layout}`,
      error    && 'avenews-radio-group--error',
      disabled && 'avenews-radio-group--disabled',
      className,
    ].filter(Boolean).join(' ')}
  >
    {label && (
      <p className="avenews-radio-group__label">{label}</p>
    )}

    <IonRadioGroup
      value={value}
      name={name}
      onIonChange={(e) => onIonChange?.(e.detail.value)}
    >
      <IonList
        lines={layout === 'inline' ? 'none' : 'inset'}
        style={
          layout === 'inline'
            ? { display: 'flex', flexWrap: 'wrap', gap: '0 16px', background: 'transparent' }
            : undefined
        }
      >
        {options.map((opt) => (
          <IonItem
            key={opt.value}
            disabled={disabled || Boolean(opt.disabled)}
            lines={layout === 'stacked' ? 'inset' : 'none'}
            style={layout === 'inline' ? { '--padding-start': '0', minWidth: '120px' } : undefined}
          >
            <IonLabel>
              {opt.label}
              {opt.description && <p>{opt.description}</p>}
            </IonLabel>
            <IonRadio
              slot="start"
              value={opt.value}
              color={color}
            />
          </IonItem>
        ))}
      </IonList>
    </IonRadioGroup>

    {(helperText || errorText) && (
      <p
        className={[
          'avenews-radio-group__helper',
          error && 'avenews-radio-group__helper--error',
        ].filter(Boolean).join(' ')}
      >
        {error && errorText ? errorText : helperText}
      </p>
    )}
  </div>
);

export default RadioGroup;
