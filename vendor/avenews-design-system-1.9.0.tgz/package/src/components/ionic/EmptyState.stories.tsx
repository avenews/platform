import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { documentTextOutline, filterOutline } from 'ionicons/icons';
import { EmptyState } from './EmptyState';

const meta: Meta<typeof EmptyState> = {
  title: 'Avenews/Ionic/EmptyState',
  component: EmptyState,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['no-content', 'no-results', 'error', 'offline'],
      description: 'Semantic variant. Determines default icon and icon colour.',
    },
  },
  decorators: [(Story) => (
    <div style={{ maxWidth: '360px', padding: '24px', minHeight: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Story />
    </div>
  )],
};

export default meta;
type Story = StoryObj<typeof EmptyState>;

// ─── Variants ─────────────────────────────────────────────────────────────────

export const NoContent: Story = {
  name: 'No Content (first empty)',
  args: {
    variant: 'no-content',
    title: 'No documents yet',
    description: "You haven't uploaded any documents. Start your application to get going.",
    action: { label: 'Start application', onClick: () => {} },
  },
};

export const NoResults: Story = {
  name: 'No Results (filtered empty)',
  args: {
    variant: 'no-results',
    title: 'No results found',
    description: "We couldn't find any documents matching your search.",
    action: { label: 'Clear search', onClick: () => {}, variant: 'outline' },
  },
};

export const Error: Story = {
  name: 'Error (load failure)',
  args: {
    variant: 'error',
    title: 'Something went wrong',
    description: "We couldn't load your documents. Please check your connection and try again.",
    action: { label: 'Try again', onClick: () => {} },
  },
};

export const Offline: Story = {
  name: 'Offline (no connectivity)',
  args: {
    variant: 'offline',
    title: "You're offline",
    description: 'Check your internet connection and try again.',
    action: { label: 'Retry', onClick: () => {} },
  },
};

// ─── With secondary action ────────────────────────────────────────────────────

export const WithSecondaryAction: Story = {
  name: 'With Secondary Action',
  args: {
    variant: 'no-results',
    title: 'No results found',
    description: "Your filters returned no results. Try adjusting your search.",
    action: { label: 'Clear filters', onClick: () => {}, variant: 'outline' },
    secondaryAction: { label: 'Browse all', onClick: () => {}, variant: 'ghost' },
    icon: filterOutline,
  },
};

// ─── Custom icon ──────────────────────────────────────────────────────────────

export const CustomIcon: Story = {
  name: 'Custom Icon',
  args: {
    variant: 'no-content',
    icon: documentTextOutline,
    title: 'No applications submitted',
    description: 'Complete your profile and submit your first application to get started.',
    action: { label: 'Apply now', onClick: () => {} },
  },
};

// ─── All variants ─────────────────────────────────────────────────────────────

export const AllVariants: Story = {
  name: 'All Variants',
  render: () => (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', padding: '16px', maxWidth: '800px' }}>
      <EmptyState
        variant="no-content"
        title="No documents yet"
        description="Upload documents to start your application."
        action={{ label: 'Upload now', onClick: () => {} }}
      />
      <EmptyState
        variant="no-results"
        title="No results found"
        description="Try a different search."
        action={{ label: 'Clear search', onClick: () => {}, variant: 'outline' }}
      />
      <EmptyState
        variant="error"
        title="Something went wrong"
        description="We couldn't load this content."
        action={{ label: 'Try again', onClick: () => {} }}
      />
      <EmptyState
        variant="offline"
        title="You're offline"
        description="Check your connection."
        action={{ label: 'Retry', onClick: () => {} }}
      />
    </div>
  ),
  decorators: [(Story) => <div style={{ padding: '16px' }}><Story /></div>],
};
