import React from 'react';
import { IonProgressBar } from '@ionic/react';

export type ProgressType  = 'determinate' | 'indeterminate' | 'buffer';
export type ProgressColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark';

export interface ProgressTrackerProps {
  value?: number;
  buffer?: number;
  type?: ProgressType;
  color?: ProgressColor;
  reversed?: boolean;
  loading?: boolean;
  error?: boolean;
  className?: string;
}

export const ProgressTracker: React.FC<ProgressTrackerProps> = ({
  value    = 0,
  buffer   = 0,
  type     = 'determinate',
  color    = 'primary',
  reversed = false,
  loading  = false,
  error    = false,
  className,
}) => {
  const resolvedType  = loading ? 'indeterminate' : type;
  const resolvedColor = error   ? 'danger'        : color;
  const resolvedValue = error   ? 1               : Math.min(1, Math.max(0, value));

  // IonProgressBar.type only accepts "determinate" | "indeterminate" — buffer
  // mode is signalled by passing a `buffer` prop while keeping type
  // determinate. Map our richer ProgressType to Ionic's narrower one.
  const ionType: 'determinate' | 'indeterminate' =
    resolvedType === 'indeterminate' ? 'indeterminate' : 'determinate';

  return (
    <IonProgressBar
      type={ionType}
      value={resolvedType !== 'indeterminate' ? resolvedValue : undefined}
      buffer={resolvedType === 'buffer' ? buffer : undefined}
      color={resolvedColor}
      reversed={reversed}
      className={`avenews-progress${className ? ` ${className}` : ''}`}
      aria-valuenow={resolvedType === 'determinate' ? Math.round(resolvedValue * 100) : undefined}
      aria-valuemin={resolvedType === 'determinate' ? 0 : undefined}
      aria-valuemax={resolvedType === 'determinate' ? 100 : undefined}
    />
  );
};

export default ProgressTracker;
