import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  chatbubbleOutline,
  documentTextOutline,
  pencilOutline,
  informationCircleOutline,
  checkmarkCircleOutline,
} from 'ionicons/icons';
import { Textarea } from './Textarea';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Textarea> = {
  title: 'Avenews/Ionic/Textarea',
  component: Textarea,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Standalone multi-line text area with `fill="solid"` white background.',
          'Distinct from the `Input` multiline variant — uses `IonTextarea` directly.',
          'Supports 4 label placements, 5 states, icon slots, helper text, and character counter.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
  decorators: [
    (Story) => (
      <div style={{ width: '350px', padding: '24px', background: 'var(--av-color-surface-subtle)' }}>
        <Story />
      </div>
    ),
  ],
  argTypes: {
    labelPlacement: {
      control: 'radio',
      options: ['stacked', 'floating', 'fixed', 'start'],
    },
  },
  args: {
    label: 'Label',
    placeholder: 'Text',
    labelPlacement: 'stacked',
  },
};

export default meta;
type Story = StoryObj<typeof Textarea>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { label: 'Message', placeholder: 'Write your message here…' },
};

// ─── Label placements ─────────────────────────────────────────────────────────

export const LabelStacked: Story = {
  name: 'Label / Stacked (default)',
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'stacked' },
};

export const LabelFloating: Story = {
  name: 'Label / Floating',
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'floating' },
};

export const LabelFixed: Story = {
  name: 'Label / Fixed',
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'fixed' },
};

export const LabelInline: Story = {
  name: 'Label / Inline (start)',
  args: { label: 'Label', placeholder: 'Text', labelPlacement: 'start' },
};

export const AllLabelPlacements: Story = {
  name: 'Label / All placements',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Textarea label="Stacked"  placeholder="Text" labelPlacement="stacked"  />
      <Textarea label="Floating" placeholder="Text" labelPlacement="floating" />
      <Textarea label="Fixed"    placeholder="Text" labelPlacement="fixed"    />
      <Textarea label="Inline"   placeholder="Text" labelPlacement="start"    />
    </div>
  ),
};

// ─── States ───────────────────────────────────────────────────────────────────

export const StateDefault: Story = {
  name: 'State / Default',
  args: { label: 'Notes', placeholder: 'Add a note…' },
};

export const StateFilled: Story = {
  name: 'State / Filled',
  args: {
    label: 'Notes',
    value: 'This is a note that the user has typed in. It may span multiple lines.',
  },
};

export const StateDisabled: Story = {
  name: 'State / Disabled',
  args: {
    label: 'Notes',
    value: 'Cannot edit this field.',
    disabled: true,
  },
};

export const StateError: Story = {
  name: 'State / Error',
  args: {
    label: 'Message',
    placeholder: 'Write your message here…',
    error: 'Message is required.',
  },
};

export const StateSuccess: Story = {
  name: 'State / Success',
  args: {
    label: 'Message',
    value: 'Thank you for your detailed response.',
    success: true,
    helperText: 'Message looks good!',
  },
};

export const StateLoading: Story = {
  name: 'State / Loading skeleton',
  args: { label: 'Notes', loading: true },
};

export const AllStates: Story = {
  name: 'State / All states',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
      <Textarea label="Default"  placeholder="Text" />
      <Textarea label="Filled"   value="Some text the user typed." />
      <Textarea label="Error"    value="" error="This field is required." />
      <Textarea label="Success"  value="Valid content entered." success helperText="Looks good!" />
      <Textarea label="Disabled" value="Read-only content." disabled />
    </div>
  ),
};

// ─── Features ─────────────────────────────────────────────────────────────────

export const Required: Story = {
  name: 'Feature / Required asterisk',
  args: { label: 'Comments', placeholder: 'Add your comments…', required: true },
};

export const WithHelperText: Story = {
  name: 'Feature / Helper text',
  args: {
    label: 'Purpose of funding',
    placeholder: 'Describe the business purpose…',
    helperText: 'Be specific — this helps the review team process faster.',
  },
};

export const WithCounter: Story = {
  name: 'Feature / Character counter',
  args: {
    label: 'Notes',
    placeholder: 'Add any additional notes…',
    counter: true,
    maxlength: 250,
  },
};

export const AutoGrow: Story = {
  name: 'Feature / Auto-grow',
  args: {
    label: 'Message',
    value: 'This textarea grows automatically as you type more content. Try adding more lines to see it expand beyond the initial 3 rows.',
    autoGrow: true,
    rows: 3,
  },
};

export const FixedRows: Story = {
  name: 'Feature / Fixed rows (no auto-grow)',
  args: {
    label: 'Comments',
    placeholder: 'Max 5 visible rows, scrollable…',
    rows: 5,
    autoGrow: false,
  },
};

// ─── Icon slots ───────────────────────────────────────────────────────────────

export const SlotStartIcon: Story = {
  name: 'Slots / Start icon (passive)',
  args: {
    label: 'Message',
    placeholder: 'Write your message here…',
    startIcon: chatbubbleOutline,
  },
};

export const SlotEndIcon: Story = {
  name: 'Slots / End icon (passive)',
  args: {
    label: 'Notes',
    placeholder: 'Add notes…',
    endIcon: documentTextOutline,
  },
};

export const SlotStartIconButton: Story = {
  name: 'Slots / Start icon-button (interactive)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [active, setActive] = React.useState(false);
    return (
      <Textarea
        label="Notes"
        placeholder="Click the pencil to enable editing…"
        startIcon={pencilOutline}
        onStartIconClick={() => setActive((v) => !v)}
        startIconAriaLabel="Toggle edit mode"
        disabled={!active}
        value={active ? '' : 'Locked content — click the pencil icon to edit.'}
      />
    );
  },
};

export const SlotEndIconButton: Story = {
  name: 'Slots / End icon-button (interactive)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [showInfo, setShowInfo] = React.useState(false);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
        <Textarea
          label="Business description"
          placeholder="Describe your business…"
          endIcon={informationCircleOutline}
          onEndIconClick={() => setShowInfo((v) => !v)}
          endIconAriaLabel="Show description guidelines"
        />
        {showInfo && (
          <p style={{
            fontFamily: 'var(--av-font-body)', fontSize: '12px',
            color: 'var(--av-color-text-muted)', padding: '8px 16px',
          }}>
            ↑ Include your main products/services, years in operation, and target market.
          </p>
        )}
      </div>
    );
  },
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const FundRequestNotes: Story = {
  name: 'App / Fund request notes',
  args: {
    label: 'Purpose of funding',
    placeholder: 'Describe how the funds will be used…',
    startIcon: documentTextOutline,
    required: true,
    counter: true,
    maxlength: 300,
    helperText: 'Be specific to speed up the review process.',
    rows: 4,
  },
};

export const CustomerMessage: Story = {
  name: 'App / Customer message',
  args: {
    label: 'Message',
    placeholder: 'Write your message to the support team…',
    startIcon: chatbubbleOutline,
    counter: true,
    maxlength: 500,
    rows: 5,
  },
};

export const ErrorWithIcon: Story = {
  name: 'App / Error state with icon',
  args: {
    label: 'Repayment notes',
    placeholder: 'Enter notes…',
    startIcon: pencilOutline,
    error: 'Notes cannot be empty when requesting a repayment extension.',
    required: true,
  },
};

export const SuccessWithCounter: Story = {
  name: 'App / Success with counter',
  args: {
    label: 'Business description',
    value: 'Nairobi Traders Ltd is a wholesale distributor of agricultural produce serving over 200 retailers across Nairobi County.',
    startIcon: checkmarkCircleOutline,
    success: true,
    helperText: 'Great — your description meets the minimum length.',
    counter: true,
    maxlength: 300,
    rows: 4,
  },
};
