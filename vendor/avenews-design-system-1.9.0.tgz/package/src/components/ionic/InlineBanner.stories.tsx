import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { InlineBanner } from './InlineBanner';

const meta: Meta<typeof InlineBanner> = {
  title: 'Avenews/Ionic/InlineBanner',
  component: InlineBanner,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['success', 'warning', 'info', 'danger'],
      description: 'Semantic variant. Controls colour, icon, and background.',
    },
    dismissible: {
      control: 'boolean',
      description: 'Shows a close icon. Only for supplementary info — never for blocking errors.',
    },
    message: {
      control: 'text',
    },
  },
};

export default meta;
type Story = StoryObj<typeof InlineBanner>;

// ─── Variants ────────────────────────────────────────────────────────────────

export const Success: Story = {
  args: {
    variant: 'success',
    message: "Great news! You've passed our eligibility check.",
  },
};

export const Warning: Story = {
  args: {
    variant: 'warning',
    message: 'Your application is borderline. Additional documentation may be required.',
  },
};

export const Info: Story = {
  args: {
    variant: 'info',
    message: "We noticed you've applied before. Please share your details again so we can review your application.",
  },
};

export const Danger: Story = {
  args: {
    variant: 'danger',
    message: 'Your document was rejected. Please upload a valid copy to continue.',
  },
};

// ─── Dismissible ─────────────────────────────────────────────────────────────

export const Dismissible: Story = {
  args: {
    variant: 'info',
    message: "We've pre-filled some fields based on your previous application.",
    dismissible: true,
  },
  render: (args) => {
    const [visible, setVisible] = useState(true);
    return visible ? (
      <InlineBanner {...args} onDismiss={() => setVisible(false)} />
    ) : (
      <p style={{ color: 'var(--av-color-text-muted)', fontSize: '14px' }}>
        Banner dismissed. Refresh to see it again.
      </p>
    );
  },
};

// ─── All variants ─────────────────────────────────────────────────────────────

export const AllVariants: Story = {
  name: 'All Variants',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxWidth: '480px' }}>
      <InlineBanner variant="success" message="Great news! You've passed our eligibility check." />
      <InlineBanner variant="info" message="We noticed you've applied before. Please share your details again." />
      <InlineBanner variant="warning" message="Your application is borderline. Additional documentation may be required." />
      <InlineBanner variant="danger" message="Your document was rejected. Please upload a valid copy to continue." />
    </div>
  ),
};

// ─── In context ──────────────────────────────────────────────────────────────

export const EligibilityResult: Story = {
  name: 'Eligibility Result Context',
  render: () => (
    <div style={{ maxWidth: '480px', padding: '16px', background: 'var(--av-color-background)' }}>
      <InlineBanner
        variant="success"
        message="You're eligible! Continue your application to get funded."
      />
      <div style={{ marginTop: '16px', color: 'var(--av-color-text-muted)', fontSize: '13px' }}>
        ↑ Banner appears at the top of the content area, directly below IonHeader
      </div>
    </div>
  ),
};
