import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  personOutline,
  cashOutline,
  documentTextOutline,
  checkmarkCircleOutline,
  alertCircleOutline,
  notificationsOutline,
  locationOutline,
  callOutline,
  mailOutline,
  businessOutline,
  cardOutline,
  starOutline,
  heartOutline,
  settingsOutline,
  homeOutline,
} from 'ionicons/icons';
import { IonIcon } from '@ionic/react';
import { Avatar, Thumbnail, MediaIcon } from './Media';
import { Item } from './Item';
import { List } from './List';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof MediaIcon> = {
  title: 'Avenews/Ionic/Media',
  component: MediaIcon,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: [
          'Three slot-filling media components matching the Figma Media section.',
          '**Avatar** — circular image (32/48/64 px) wrapping `IonAvatar`.',
          '**Thumbnail** — square image (40/48/64 px) wrapping `IonThumbnail`.',
          '**MediaIcon** — coloured `IonIcon` in 11 colour tokens × 3 sizes (18/24/32 px).',
          'Drop any of these into an `Item` start/end slot.',
        ].join(' '),
      },
    },
    layout: 'centered',
  },
};

export default meta;
type Story = StoryObj<typeof MediaIcon>;

// ─── Avatar stories ───────────────────────────────────────────────────────────

export const AvatarDefault: Story = {
  name: 'Avatar / Default (48px)',
  render: () => (
    <Avatar
      src="https://i.pravatar.cc/96?u=avenews"
      alt="Jane Muthoni"
    />
  ),
};

export const AvatarSizes: Story = {
  name: 'Avatar / All sizes',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
      <div style={{ textAlign: 'center' }}>
        <Avatar src="https://i.pravatar.cc/64?u=sm" alt="SM" size="sm" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>sm 32px</p>
      </div>
      <div style={{ textAlign: 'center' }}>
        <Avatar src="https://i.pravatar.cc/96?u=md" alt="MD" size="md" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>md 48px</p>
      </div>
      <div style={{ textAlign: 'center' }}>
        <Avatar src="https://i.pravatar.cc/128?u=lg" alt="LG" size="lg" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>lg 64px</p>
      </div>
    </div>
  ),
};

export const AvatarInitials: Story = {
  name: 'Avatar / Initials fallback',
  render: () => (
    <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
      <Avatar initials="JM" size="sm" />
      <Avatar initials="AB" size="md" />
      <Avatar initials="KO" size="lg" />
    </div>
  ),
};

export const AvatarPlaceholder: Story = {
  name: 'Avatar / Placeholder (no src)',
  render: () => (
    <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
      <Avatar size="sm" />
      <Avatar size="md" />
      <Avatar size="lg" />
    </div>
  ),
};

// ─── Thumbnail stories ────────────────────────────────────────────────────────

export const ThumbnailDefault: Story = {
  name: 'Thumbnail / Default (48px)',
  render: () => (
    <Thumbnail
      src="https://picsum.photos/96/96?random=1"
      alt="Document preview"
    />
  ),
};

export const ThumbnailSizes: Story = {
  name: 'Thumbnail / All sizes',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
      <div style={{ textAlign: 'center' }}>
        <Thumbnail src="https://picsum.photos/80/80?random=2" alt="sm" size="sm" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>sm 40px</p>
      </div>
      <div style={{ textAlign: 'center' }}>
        <Thumbnail src="https://picsum.photos/96/96?random=3" alt="md" size="md" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>md 48px</p>
      </div>
      <div style={{ textAlign: 'center' }}>
        <Thumbnail src="https://picsum.photos/128/128?random=4" alt="lg" size="lg" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>lg 64px</p>
      </div>
    </div>
  ),
};

// ─── MediaIcon stories ────────────────────────────────────────────────────────

export const IconAllColors: Story = {
  name: 'Icon / All 11 colors (Default 24px)',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {(
        [
          'primary', 'secondary', 'tertiary',
          'success', 'warning', 'danger',
          'light', 'medium', 'dark',
          'white', 'black',
        ] as const
      ).map((color) => (
        <div key={color} style={{
          display: 'flex', alignItems: 'center', gap: '12px',
          background: color === 'white' ? '#1a1a2e' : color === 'light' ? '#0d343f' : 'transparent',
          padding: '4px 8px', borderRadius: '4px',
        }}>
          <MediaIcon icon={starOutline} color={color} />
          <span style={{
            fontSize: '12px', fontFamily: 'Poppins, sans-serif',
            color: color === 'white' ? '#ffffff' : color === 'light' ? '#ffffff' : '#0d343f',
          }}>
            {color}
          </span>
        </div>
      ))}
    </div>
  ),
};

export const IconAllSizes: Story = {
  name: 'Icon / All 3 sizes',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
      <div style={{ textAlign: 'center' }}>
        <MediaIcon icon={cashOutline} color="primary" size="sm" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>sm 18px</p>
      </div>
      <div style={{ textAlign: 'center' }}>
        <MediaIcon icon={cashOutline} color="primary" size="default" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>default 24px</p>
      </div>
      <div style={{ textAlign: 'center' }}>
        <MediaIcon icon={cashOutline} color="primary" size="lg" />
        <p style={{ fontSize: '11px', color: '#93a1b0', marginTop: '4px' }}>lg 32px</p>
      </div>
    </div>
  ),
};

export const IconColorGrid: Story = {
  name: 'Icon / Color × Size grid',
  render: () => {
    const colors = ['primary', 'secondary', 'tertiary', 'success', 'warning', 'danger', 'medium', 'dark'] as const;
    const sizes = ['sm', 'default', 'lg'] as const;
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {colors.map((color) => (
          <div key={color} style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            {sizes.map((size) => (
              <MediaIcon key={size} icon={starOutline} color={color} size={size} />
            ))}
            <span style={{ fontSize: '12px', color: '#93a1b0', fontFamily: 'Poppins, sans-serif' }}>{color}</span>
          </div>
        ))}
      </div>
    );
  },
};

// ─── In-slot usage ────────────────────────────────────────────────────────────

export const InItemStartSlot: Story = {
  name: 'Usage / Icon in Item start slot',
  render: () => (
    <div style={{ width: '390px' }}>
      <List lines="inset">
        <Item label="Notifications" secondLine="Stay updated" startSlot={<MediaIcon icon={notificationsOutline} color="primary" />} button detailArrow />
        <Item label="Location" secondLine="For field validation" startSlot={<MediaIcon icon={locationOutline} color="secondary" />} button detailArrow />
        <Item label="Documents" secondLine="Upload requirements" startSlot={<MediaIcon icon={documentTextOutline} color="tertiary" />} button detailArrow />
        <Item label="Payments" secondLine="Loan repayments" startSlot={<MediaIcon icon={cashOutline} color="success" />} button detailArrow lines="none" />
      </List>
    </div>
  ),
};

export const InItemBothSlots: Story = {
  name: 'Usage / Avatar start + Icon end',
  render: () => (
    <div style={{ width: '390px' }}>
      <List lines="inset">
        <Item
          label="Jane Muthoni"
          secondLine="Account owner"
          startSlot={<Avatar src="https://i.pravatar.cc/96?u=jane" alt="Jane" size="sm" />}
          endSlot={<MediaIcon icon={checkmarkCircleOutline} color="success" />}
          button detailArrow
        />
        <Item
          label="Peter Kamau"
          secondLine="Field agent"
          startSlot={<Avatar src="https://i.pravatar.cc/96?u=peter" alt="Peter" size="sm" />}
          endSlot={<MediaIcon icon={alertCircleOutline} color="warning" />}
          button detailArrow
        />
        <Item
          label="Grace Wanjiku"
          secondLine="Applicant"
          startSlot={<Avatar initials="GW" size="sm" />}
          endSlot={<MediaIcon icon={alertCircleOutline} color="danger" />}
          button detailArrow lines="none"
        />
      </List>
    </div>
  ),
};

export const ThumbnailInSlot: Story = {
  name: 'Usage / Thumbnail in Item start slot',
  render: () => (
    <div style={{ width: '390px' }}>
      <List lines="inset">
        <Item
          label="Business registration"
          secondLine="Certificate of incorporation"
          startSlot={<Thumbnail src="https://picsum.photos/96/96?random=10" alt="doc" size="sm" />}
          button detailArrow
        />
        <Item
          label="Bank statement"
          secondLine="Last 6 months"
          startSlot={<Thumbnail src="https://picsum.photos/96/96?random=11" alt="doc" size="sm" />}
          button detailArrow
        />
        <Item
          label="KRA PIN certificate"
          secondLine="Government issued"
          startSlot={<Thumbnail src="https://picsum.photos/96/96?random=12" alt="doc" size="sm" />}
          button detailArrow lines="none"
        />
      </List>
    </div>
  ),
};

export const AppNavigationIcons: Story = {
  name: 'App / Navigation icon set',
  render: () => (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '24px', padding: '16px' }}>
      {[
        { icon: homeOutline, label: 'Home' },
        { icon: cashOutline, label: 'Loans' },
        { icon: documentTextOutline, label: 'Docs' },
        { icon: cardOutline, label: 'Cards' },
        { icon: notificationsOutline, label: 'Alerts' },
        { icon: personOutline, label: 'Profile' },
        { icon: settingsOutline, label: 'Settings' },
        { icon: heartOutline, label: 'Saved' },
      ].map(({ icon, label }) => (
        <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
          <MediaIcon icon={icon} color="primary" size="lg" />
          <span style={{ fontSize: '11px', color: '#4a5360', fontFamily: 'Poppins, sans-serif' }}>{label}</span>
        </div>
      ))}
    </div>
  ),
};
