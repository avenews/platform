import React from 'react';
import { IonToast } from '@ionic/react';

// ─── Types ────────────────────────────────────────────────────────────────────
// Cross-platform Toast API. The semantic variant set matches the web Toast
// (neutral / success / warning / danger / info) and is mapped internally to
// Ionic's color tokens. Legacy `isOpen` / `color` / `onDidDismiss` / `buttons`
// props are still accepted for backwards compatibility.

export type ToastVariant  = 'neutral' | 'success' | 'warning' | 'danger' | 'info';
export type ToastPosition = 'top' | 'bottom' | 'middle';

/** Legacy Ionic colour names — accepted but should be migrated to ToastVariant. */
export type ToastColor =
  | 'primary' | 'secondary' | 'success' | 'warning' | 'danger'
  | 'light'   | 'medium'    | 'dark';

export interface ToastButton {
  text:     string;
  role?:    'cancel' | 'destructive';
  handler?: () => boolean | void;
}

export interface ToastProps {
  message:        string;

  /** Cross-platform visibility prop (preferred). */
  visible?:       boolean;
  /** Legacy alias for `visible`. */
  isOpen?:        boolean;

  position?:      ToastPosition;

  /** ms; 0 = persistent. Default 3500. */
  duration?:      number;

  /** Cross-platform semantic variant (preferred). */
  variant?:       ToastVariant;
  /** Legacy Ionic colour name — kept for backwards compatibility. */
  color?:         ToastColor;

  /** Ionicons icon string (overrides the default variant icon). */
  icon?:          string;

  /** Single action button (preferred). */
  action?:        ToastButton;
  /** Legacy multi-button array. */
  buttons?:       ToastButton[];

  /** Cross-platform dismiss callback (preferred). */
  onDismiss?:     () => void;
  /** Legacy alias for `onDismiss`. */
  onDidDismiss?:  () => void;

  className?:     string;
}

// ─── Variant → Ionic colour map ───────────────────────────────────────────────

const VARIANT_TO_COLOR: Record<ToastVariant, ToastColor | undefined> = {
  neutral: 'medium',
  success: 'success',
  warning: 'warning',
  danger:  'danger',
  info:    'secondary',   // info maps to ionic secondary (darkblue) per token system
};

// ─── Component ────────────────────────────────────────────────────────────────

export const Toast: React.FC<ToastProps> = ({
  message,
  visible,
  isOpen,
  position    = 'bottom',
  duration    = 3500,
  variant,
  color,
  icon,
  action,
  buttons,
  onDismiss,
  onDidDismiss,
  className,
}) => {
  const isShown      = visible ?? isOpen ?? false;
  const handleDismiss = onDismiss ?? onDidDismiss;

  // Resolve the Ionic colour: explicit `color` wins, otherwise map from variant.
  const resolvedColor = color ?? (variant ? VARIANT_TO_COLOR[variant] : undefined);

  // Resolve action(s): single `action` becomes a one-item buttons array.
  const resolvedButtons =
    buttons ?? (action ? [action] : undefined);

  return (
    <IonToast
      isOpen={isShown}
      message={message}
      position={position}
      duration={duration === 0 ? undefined : duration}
      color={resolvedColor}
      icon={icon}
      buttons={resolvedButtons}
      onDidDismiss={handleDismiss}
      className={['avenews-toast', className].filter(Boolean).join(' ')}
    />
  );
};

export default Toast;
