import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { setupIonicReact } from '@ionic/react';
import * as IonIcons from 'ionicons/icons';
import { Icon } from './Icon';

setupIonicReact();

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Icon> = {
  title:     'Avenews/Ionic/Icon',
  component: Icon,
  tags:      ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Thin wrapper around `IonIcon` that normalises `size` and `color` props. ' +
          'Supports all 1357 ionicons (Filled · Outline · Sharp) plus 90 logo icons. ' +
          'Import icon names from `ionicons/icons` and pass via the `icon` prop.',
      },
    },
    layout: 'padded',
  },
  argTypes: {
    size:  { control: 'radio',  options: ['xs', 'sm', 'md', 'lg', 'xl'] },
    color: { control: 'color' },
  },
  args: {
    icon: IonIcons.homeOutline,
    size: 'md',
  },
};

export default meta;
type Story = StoryObj<typeof Icon>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { icon: IonIcons.homeOutline, size: 'lg' },
};

// ─── Sizes ────────────────────────────────────────────────────────────────────

export const Sizes: Story = {
  name: 'Sizes',
  render: () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 24, flexWrap: 'wrap', padding: 16 }}>
      {(['xs', 'sm', 'md', 'lg', 'xl'] as const).map(size => (
        <div key={size} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <Icon icon={IonIcons.notificationsOutline} size={size} />
          <span style={{ fontFamily: 'Poppins, sans-serif', fontSize: 11, color: '#6c7a8b' }}>{size}</span>
        </div>
      ))}
    </div>
  ),
};

// ─── Colors ──────────────────────────────────────────────────────────────────

export const Colors: Story = {
  name: 'Colors',
  render: () => (
    <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', padding: 16, alignItems: 'center' }}>
      <Icon icon={IonIcons.checkmarkCircleOutline}  size="lg" color="var(--av-color-success)" />
      <Icon icon={IonIcons.warningOutline}           size="lg" color="var(--av-color-warning)" />
      <Icon icon={IonIcons.closeCircleOutline}       size="lg" color="var(--av-color-danger)"  />
      <Icon icon={IonIcons.informationCircleOutline} size="lg" color="var(--av-color-info)"    />
      <Icon icon={IonIcons.shieldCheckmarkOutline}   size="lg" color="var(--av-color-action)"  />
      <Icon icon={IonIcons.starOutline}              size="lg" color="#f4c350"                   />
    </div>
  ),
};

// ─── Styles comparison ────────────────────────────────────────────────────────

export const Styles: Story = {
  name: 'Styles / Filled · Outline · Sharp',
  render: () => {
    const pairs: [string, string, string, string][] = [
      ['home',      IonIcons.home,      IonIcons.homeOutline,      IonIcons.homeSharp],
      ['document',  IonIcons.document,  IonIcons.documentOutline,  IonIcons.documentSharp],
      ['person',    IonIcons.person,    IonIcons.personOutline,    IonIcons.personSharp],
      ['settings',  IonIcons.settings,  IonIcons.settingsOutline,  IonIcons.settingsSharp],
      ['mail',      IonIcons.mail,      IonIcons.mailOutline,      IonIcons.mailSharp],
      ['heart',     IonIcons.heart,     IonIcons.heartOutline,     IonIcons.heartSharp],
    ];
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, padding: 16 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '100px 80px 80px 80px', gap: 8, alignItems: 'center' }}>
          <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 11, color: '#6c7a8b' }}>icon</span>
          <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 11, color: '#6c7a8b', textAlign: 'center' }}>filled</span>
          <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 11, color: '#6c7a8b', textAlign: 'center' }}>outline</span>
          <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 11, color: '#6c7a8b', textAlign: 'center' }}>sharp</span>
        </div>
        {pairs.map(([name, filled, outline, sharp]) => (
          <div key={name} style={{ display: 'grid', gridTemplateColumns: '100px 80px 80px 80px', alignItems: 'center' }}>
            <span style={{ fontFamily: 'Poppins,sans-serif', fontSize: 12, color: '#0d343f' }}>{name}</span>
            <div style={{ display: 'flex', justifyContent: 'center' }}><Icon icon={filled}  size="lg" color="var(--av-color-action)" /></div>
            <div style={{ display: 'flex', justifyContent: 'center' }}><Icon icon={outline} size="lg" /></div>
            <div style={{ display: 'flex', justifyContent: 'center' }}><Icon icon={sharp}   size="lg" /></div>
          </div>
        ))}
      </div>
    );
  },
};

// ─── Gallery helpers ─────────────────────────────────────────────────────────

function ionGallery(entries: [string, string][], desc: string) {
  return (
    <div style={{ padding: 16 }}>
      <p style={{ fontFamily: 'Poppins,sans-serif', fontSize: 12, color: '#6c7a8b', marginBottom: 16 }}>{desc}</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(90px,1fr))', gap: 6 }}>
        {entries.map(([label, iconData]) => (
          <div key={label} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6, padding:'10px 6px', borderRadius:8, background:'var(--av-color-surface-subtle)' }}>
            <Icon icon={iconData} size="lg" />
            <span style={{ fontFamily:'Poppins,sans-serif', fontSize:9, color:'var(--av-color-text-muted)', textAlign:'center', lineHeight:1.3, wordBreak:'break-all' }}>
              {label.replace(/Outline$|Sharp$/, '')}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

const OUTLINE = Object.entries(IonIcons).filter(([k]) => k.endsWith('Outline') && !k.startsWith('logo')) as [string,string][];
const FILLED  = Object.entries(IonIcons).filter(([k]) => !k.endsWith('Outline') && !k.endsWith('Sharp') && !k.startsWith('logo')) as [string,string][];
const SHARP   = Object.entries(IonIcons).filter(([k]) => k.endsWith('Sharp') && !k.startsWith('logo')) as [string,string][];
const LOGOS   = Object.entries(IonIcons).filter(([k]) => k.startsWith('logo')) as [string,string][];

export const GalleryOutline: Story = {
  name: 'Gallery / Outline (421)',
  render: () => ionGallery(OUTLINE, `${OUTLINE.length} outline icons — recommended for UI.`),
};

export const GalleryFilled: Story = {
  name: 'Gallery / Filled (515)',
  render: () => ionGallery(FILLED, `${FILLED.length} filled icons.`),
};

export const GallerySharp: Story = {
  name: 'Gallery / Sharp (421)',
  render: () => ionGallery(SHARP, `${SHARP.length} sharp icons — squared corners, Android style.`),
};

export const GalleryLogos: Story = {
  name: 'Gallery / Logos (90)',
  render: () => ionGallery(LOGOS, `${LOGOS.length} brand & logo icons.`),
};

// ─── In context ──────────────────────────────────────────────────────────────

export const InContext: Story = {
  name: 'Usage / In context',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 16, maxWidth: 320 }}>
      {[
        { icon: IonIcons.documentTextOutline,    label: 'Business registration', note: 'Uploaded · 2 Jan 2024', color: undefined },
        { icon: IonIcons.checkmarkCircleOutline, label: 'KRA PIN certificate',   note: 'Approved',              color: 'var(--av-color-success)' },
        { icon: IonIcons.warningOutline,         label: 'Director ID',           note: 'Action required',       color: 'var(--av-color-warning)' },
      ].map(row => (
        <div key={row.label} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Icon icon={row.icon} size="lg" color={row.color} />
          <div>
            <div style={{ fontFamily: 'Poppins,sans-serif', fontSize: 14, fontWeight: 600, color: '#0d343f' }}>{row.label}</div>
            <div style={{ fontFamily: 'Poppins,sans-serif', fontSize: 12, color: '#6c7a8b' }}>{row.note}</div>
          </div>
        </div>
      ))}
    </div>
  ),
};
