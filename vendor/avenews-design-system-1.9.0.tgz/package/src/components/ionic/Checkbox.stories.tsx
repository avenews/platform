import type { Meta, StoryObj } from '@storybook/react';
import { IonList } from '@ionic/react';
import { Checkbox } from './Checkbox';
import type { CheckboxColor } from './Checkbox';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Checkbox> = {
  title: 'Avenews/Ionic/Checkbox',
  component: Checkbox,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Wraps Ionic `IonCheckbox`. Supports checked, indeterminate, and disabled states across 11 color variants. Use standalone (no label) or in a labelled row with configurable placement and justification.',
      },
    },
  },
  argTypes: {
    color: {
      control: 'select',
      options: [
        'primary','secondary','tertiary',
        'success','warning','danger',
        'light','medium','dark',
        'white','black',
      ] satisfies CheckboxColor[],
    },
    labelPlacement: { control: 'select', options: ['start', 'end', 'stacked'] },
    justify:        { control: 'select', options: ['space-between', 'start', 'end'] },
  },
  // Required-prop defaults for autodocs safety
  args: {
    label:          'Accept terms and conditions',
    checked:        false,
    indeterminate:  false,
    disabled:       false,
    color:          'primary',
    labelPlacement: 'start',
    justify:        'space-between',
  },
};

export default meta;
type Story = StoryObj<typeof Checkbox>;

// ─── Core states ──────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default (unchecked)',
};

export const Checked: Story = {
  name: 'Checked',
  args: { checked: true },
};

export const Indeterminate: Story = {
  name: 'Indeterminate',
  args: { indeterminate: true },
};

export const Disabled: Story = {
  name: 'Disabled (unchecked)',
  args: { disabled: true },
};

export const DisabledChecked: Story = {
  name: 'Disabled (checked)',
  args: { checked: true, disabled: true },
};

export const DisabledIndeterminate: Story = {
  name: 'Disabled (indeterminate)',
  args: { indeterminate: true, disabled: true },
};

// ─── All states grid ──────────────────────────────────────────────────────────

export const AllStates: Story = {
  name: 'All States',
  render: () => (
    <IonList lines="full" style={{ maxWidth: '380px' }}>
      <Checkbox label="Default — unchecked"    checked={false}      />
      <Checkbox label="Checked"                checked={true}       />
      <Checkbox label="Indeterminate"          indeterminate={true} />
      <Checkbox label="Disabled — unchecked"   disabled={true}      />
      <Checkbox label="Disabled — checked"     checked={true}  disabled={true} />
      <Checkbox label="Disabled — indeterminate" indeterminate={true} disabled={true} />
    </IonList>
  ),
};

// ─── Label placement variants ─────────────────────────────────────────────────

export const LabelStart: Story = {
  name: 'Label Placement / Start (label left, checkbox right)',
  args: { checked: true, labelPlacement: 'start', justify: 'space-between' },
};

export const LabelEnd: Story = {
  name: 'Label Placement / End (checkbox left, label right)',
  args: { checked: true, labelPlacement: 'end', justify: 'start' },
};

export const LabelStacked: Story = {
  name: 'Label Placement / Stacked',
  args: { checked: true, labelPlacement: 'stacked' },
};

export const JustifyStart: Story = {
  name: 'Justify / Start',
  args: { checked: true, labelPlacement: 'start', justify: 'start' },
};

export const JustifyEnd: Story = {
  name: 'Justify / End',
  args: { checked: true, labelPlacement: 'start', justify: 'end' },
};

// ─── Standalone (no label) ────────────────────────────────────────────────────

export const Standalone: Story = {
  name: 'Standalone (no label)',
  render: () => (
    <div style={{ display: 'flex', gap: '16px', padding: '16px', alignItems: 'center' }}>
      <Checkbox />
      <Checkbox checked />
      <Checkbox indeterminate />
      <Checkbox disabled />
    </div>
  ),
};

// ─── Color variants ───────────────────────────────────────────────────────────

const COLORS: CheckboxColor[] = [
  'primary','secondary','tertiary',
  'success','warning','danger',
  'light','medium','dark',
  'white','black',
];

export const AllColors: Story = {
  name: 'All Colors (checked)',
  render: () => (
    <IonList lines="full" style={{ maxWidth: '380px' }}>
      {COLORS.map((color) => (
        <Checkbox
          key={color}
          label={color.charAt(0).toUpperCase() + color.slice(1)}
          checked={true}
          color={color}
        />
      ))}
    </IonList>
  ),
};

export const AllColorsIndeterminate: Story = {
  name: 'All Colors (indeterminate)',
  render: () => (
    <IonList lines="full" style={{ maxWidth: '380px' }}>
      {COLORS.map((color) => (
        <Checkbox
          key={color}
          label={color.charAt(0).toUpperCase() + color.slice(1)}
          indeterminate={true}
          color={color}
        />
      ))}
    </IonList>
  ),
};

// Individual color stories for the docs panel
export const Primary:   Story = { name: 'Color / Primary',   args: { checked: true, color: 'primary' } };
export const Secondary: Story = { name: 'Color / Secondary', args: { checked: true, color: 'secondary' } };
export const Tertiary:  Story = { name: 'Color / Tertiary',  args: { checked: true, color: 'tertiary' } };
export const Success:   Story = { name: 'Color / Success',   args: { checked: true, color: 'success' } };
export const Warning:   Story = { name: 'Color / Warning',   args: { checked: true, color: 'warning' } };
export const Danger:    Story = { name: 'Color / Danger',    args: { checked: true, color: 'danger' } };
export const Light:     Story = { name: 'Color / Light',     args: { checked: true, color: 'light' } };
export const Medium:    Story = { name: 'Color / Medium',    args: { checked: true, color: 'medium' } };
export const Dark:      Story = { name: 'Color / Dark',      args: { checked: true, color: 'dark' } };
export const White:     Story = { name: 'Color / White',     args: { checked: true, color: 'white' } };
export const Black:     Story = { name: 'Color / Black',     args: { checked: true, color: 'black' } };
