import React from 'react';
import { IonIcon, IonItem, IonItemDivider, IonLabel, IonSkeletonText } from '@ionic/react';
import { chevronForwardOutline } from 'ionicons/icons';

export type ItemColor =
  | 'default' | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light'   | 'medium'  | 'dark';

export type ItemLines   = 'full' | 'inset' | 'none';
export type ItemVariant = 'default' | 'list3';

export interface ItemProps {
  label: string;
  secondLine?: string;
  thirdLine?: string;
  variant?: ItemVariant;
  color?: ItemColor;
  disabled?: boolean;
  lines?: ItemLines;
  detailArrow?: boolean;
  button?: boolean;
  href?: string;
  startSlot?: React.ReactNode;
  endSlot?: React.ReactNode;
  onClick?: () => void;
  loading?: boolean;
  className?: string;
}

export interface ItemDividerProps {
  label: string;
  color?: ItemColor;
  loading?: boolean;
  className?: string;
}

export const Item: React.FC<ItemProps> = ({
  label,
  secondLine,
  thirdLine,
  variant     = 'default',
  color       = 'default',
  disabled    = false,
  lines       = 'full',
  detailArrow = false,
  button,
  href,
  startSlot,
  endSlot,
  onClick,
  loading     = false,
  className,
}) => {
  if (loading) {
    return (
      <div className="avenews-item-skeleton">
        <IonSkeletonText animated style={{ width: '40%', height: '12px', marginBottom: '6px' }} />
        <IonSkeletonText animated style={{ width: '70%', height: '16px' }} />
      </div>
    );
  }

  const isInteractive = Boolean(button || onClick || href);
  const ionColor = color === 'default' ? undefined : color;
  const rootClass = ['avenews-item', color !== 'default' && `avenews-item--${color}`, variant === 'list3' && 'avenews-item--list3', className].filter(Boolean).join(' ');

  const labelNode = variant === 'list3' ? (
    <IonLabel className="avenews-item__label">
      <p className="avenews-item__top">{label}</p>
      {secondLine && <h2 className="avenews-item__main">{secondLine}</h2>}
      {thirdLine  && <p  className="avenews-item__sub">{thirdLine}</p>}
    </IonLabel>
  ) : (
    <IonLabel className="avenews-item__label">
      <h2 className="avenews-item__main">{label}</h2>
      {secondLine && <p className="avenews-item__sub">{secondLine}</p>}
      {thirdLine  && <p className="avenews-item__sub">{thirdLine}</p>}
    </IonLabel>
  );

  return (
    <IonItem className={rootClass} color={ionColor} disabled={disabled} lines={lines} detail={detailArrow} detailIcon={chevronForwardOutline} button={isInteractive} href={href} onClick={onClick}>
      {startSlot && <div slot="start" className="avenews-item__slot avenews-item__slot--start">{startSlot}</div>}
      {labelNode}
      {endSlot && <div slot="end" className="avenews-item__slot avenews-item__slot--end">{endSlot}</div>}
    </IonItem>
  );
};

export const ItemDivider: React.FC<ItemDividerProps> = ({
  label,
  color   = 'default',
  loading = false,
  className,
}) => {
  if (loading) {
    return <div className="avenews-item-divider-skeleton"><IonSkeletonText animated style={{ width: '30%', height: '12px' }} /></div>;
  }
  const ionColor = color === 'default' ? undefined : color;
  return (
    <IonItemDivider className={['avenews-item-divider', color !== 'default' && `avenews-item-divider--${color}`, className].filter(Boolean).join(' ')} color={ionColor}>
      <IonLabel className="avenews-item-divider__label">{label}</IonLabel>
    </IonItemDivider>
  );
};

export default Item;
