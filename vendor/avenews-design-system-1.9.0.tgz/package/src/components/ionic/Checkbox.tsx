import React from 'react';
import { IonCheckbox } from '@ionic/react';

export type CheckboxColor =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning'   | 'danger'
  | 'light'   | 'medium'    | 'dark'
  | 'white'   | 'black';

export interface CheckboxProps {
  checked?: boolean;
  indeterminate?: boolean;
  disabled?: boolean;
  label?: string;
  labelPlacement?: 'start' | 'end' | 'stacked';
  justify?: 'space-between' | 'start' | 'end';
  color?: CheckboxColor;
  onIonChange?: (checked: boolean) => void;
  className?: string;
}

export const Checkbox: React.FC<CheckboxProps> = ({
  checked        = false,
  indeterminate  = false,
  disabled       = false,
  label,
  labelPlacement = 'start',
  justify        = 'space-between',
  color          = 'primary',
  onIonChange,
  className,
}) => (
  <IonCheckbox
    className={['avenews-checkbox', `avenews-checkbox--${color}`, !label && 'avenews-checkbox--standalone', className].filter(Boolean).join(' ')}
    checked={checked}
    indeterminate={indeterminate}
    disabled={disabled}
    labelPlacement={label ? labelPlacement : undefined}
    justify={label ? justify : undefined}
    onIonChange={(e) => onIonChange?.(e.detail.checked)}
    aria-label={label ?? 'Checkbox'}
  >
    {label}
  </IonCheckbox>
);

export default Checkbox;
