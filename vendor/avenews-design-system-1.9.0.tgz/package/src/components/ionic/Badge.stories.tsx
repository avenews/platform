import type { Meta, StoryObj } from '@storybook/react';
import { IonItem, IonLabel } from '@ionic/react';
import { Badge } from './Badge';

const meta: Meta<typeof Badge> = {
  title: 'Avenews/Ionic/Badge',
  component: Badge,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: [
        // Solid — Figma palette
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark',
        'info', 'neutral',
        // Subtle
        'success-subtle', 'warning-subtle', 'danger-subtle', 'info-subtle',
      ],
      description: 'Colour variant. Subtle variants use tinted bg + coloured text.',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Badge>;

// ─── States ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  args: { count: 3, variant: 'primary' },
};

export const Loading: Story = {
  args: { count: 0, loading: true, hideOnEmpty: false },
};

// ─── Figma palette (all 9 colours) ───────────────────────────────────────────

export const AllColors: Story = {
  name: 'All Colours (Figma Palette)',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', padding: '16px', alignItems: 'center' }}>
      <Badge count="Primary"   variant="primary" />
      <Badge count="Secondary" variant="secondary" />
      <Badge count="Tertiary"  variant="tertiary" />
      <Badge count="Success"   variant="success" />
      <Badge count="Warning"   variant="warning" />
      <Badge count="Danger"    variant="danger" />
      <Badge count="Light"     variant="light" />
      <Badge count="Medium"    variant="medium" />
      <Badge count="Dark"      variant="dark" />
    </div>
  ),
};

// ─── Subtle variants ──────────────────────────────────────────────────────────

export const AllSubtle: Story = {
  name: 'All Subtle Variants',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', padding: '16px', alignItems: 'center' }}>
      <Badge count="Success" variant="success-subtle" />
      <Badge count="Warning" variant="warning-subtle" />
      <Badge count="Danger"  variant="danger-subtle" />
      <Badge count="Info"    variant="info-subtle" />
    </div>
  ),
};

// ─── Count formats ────────────────────────────────────────────────────────────

export const LargeCount: Story = {
  args: { count: 1450, variant: 'primary' },
};

export const NonNumeric: Story = {
  args: { count: 'New', variant: 'success' },
};

export const HiddenOnEmpty: Story = {
  args: { count: 0, hideOnEmpty: true },
  render: (args) => (
    <div style={{ display: 'flex', gap: '12px', alignItems: 'center', padding: '8px', fontSize: '14px' }}>
      <span style={{ color: 'var(--av-color-text-muted)' }}>Hidden when zero:</span>
      <Badge {...args} />
      <span style={{ color: 'var(--av-color-text-muted)' }}>(nothing here)</span>
    </div>
  ),
};

// ─── In list items (right badge) ──────────────────────────────────────────────

export const InListItem: Story = {
  name: 'In List Item — Right Badge',
  render: () => (
    <div style={{ maxWidth: '350px' }}>
      <IonItem>
        <IonLabel>Notifications</IonLabel>
        <Badge count={5}     variant="danger"         slot="end" />
      </IonItem>
      <IonItem>
        <IonLabel>Documents</IonLabel>
        <Badge count={2}     variant="warning-subtle" slot="end" />
      </IonItem>
      <IonItem>
        <IonLabel>Messages</IonLabel>
        <Badge count="New"   variant="secondary"      slot="end" />
      </IonItem>
      <IonItem>
        <IonLabel>Status</IonLabel>
        <Badge count="Dark"  variant="dark"           slot="end" />
      </IonItem>
      <IonItem>
        <IonLabel>Completed</IonLabel>
        <Badge count={0} hideOnEmpty slot="end" />
      </IonItem>
    </div>
  ),
};

// ─── In list items (left badge) ───────────────────────────────────────────────

export const InListItemLeft: Story = {
  name: 'In List Item — Left Badge',
  render: () => (
    <div style={{ maxWidth: '350px' }}>
      <IonItem>
        <Badge count={3}   variant="primary"  slot="start" />
        <IonLabel>Loan applications</IonLabel>
      </IonItem>
      <IonItem>
        <Badge count="!"   variant="danger"   slot="start" />
        <IonLabel>Action required</IonLabel>
      </IonItem>
      <IonItem>
        <Badge count="New" variant="tertiary" slot="start" />
        <IonLabel>Feature update</IonLabel>
      </IonItem>
    </div>
  ),
};

// ─── Disabled style ───────────────────────────────────────────────────────────

export const Disabled: Story = {
  name: 'Disabled (via IonItem)',
  render: () => (
    <div style={{ maxWidth: '350px' }}>
      <IonItem disabled>
        <IonLabel>Disabled item</IonLabel>
        <Badge count={4} variant="primary" slot="end" />
      </IonItem>
      <IonItem disabled>
        <Badge count={2} variant="danger" slot="start" />
        <IonLabel>Disabled with left badge</IonLabel>
      </IonItem>
    </div>
  ),
};
