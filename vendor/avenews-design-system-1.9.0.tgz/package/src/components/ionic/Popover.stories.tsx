/**
 * Popover is a cross-platform component — implementation lives at
 * src/components/web/Popover.tsx. The ionic entry re-exports it.
 *
 * This story file mirrors the web stories under the Ionic Storybook tree so
 * the component is discoverable from both surfaces. See web/Popover.stories.tsx
 * for the full story set.
 */
import React, { useRef, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Popover } from './Popover';

const meta: Meta<typeof Popover> = {
  title: 'Avenews/Ionic/Popover',
  component: Popover,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Cross-platform contextual popover. Implementation is shared with the web build — see Avenews/Web/Popover for the full story catalogue.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Popover>;

const Demo: React.FC = () => {
  const triggerRef = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);
  return (
    <>
      <button ref={triggerRef} type="button" onClick={() => setOpen((v) => !v)}>
        Open popover
      </button>
      <Popover
        open={open}
        triggerRef={triggerRef}
        onDismiss={() => setOpen(false)}
        items={[
          { label: 'Edit', onClick: () => setOpen(false) },
          { label: 'Share', onClick: () => setOpen(false) },
          { label: 'Delete', onClick: () => setOpen(false) },
        ]}
      />
    </>
  );
};

export const Default: Story = {
  render: () => <Demo />,
};
