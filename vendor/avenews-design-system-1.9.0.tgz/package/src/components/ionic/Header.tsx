import React from 'react';

// ─── Types ────────────────────────────────────────────────────────────────────

export type HeaderVariant = 'default' | 'subtle' | 'dark';
export type HeaderSize    = 'sm' | 'md' | 'lg';

export interface HeaderProps {
  title:         string;
  subtitle?:     string;
  description?:  string;
  variant?:      HeaderVariant;
  size?:         HeaderSize;
  /** Avatar / logo / icon element */
  avatar?:       React.ReactNode;
  /** Trailing action slot — ReactNode */
  actions?:      React.ReactNode;
  /** Breadcrumb / back nav rendered above the header row — ReactNode */
  breadcrumb?:   React.ReactNode;
  className?:    string;
}

// ─── Component ────────────────────────────────────────────────────────────────
// Intentionally NOT IonHeader — that is the nav bar.
// This is a content-level page section header rendered inside IonContent.

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  description,
  variant    = 'default',
  size       = 'md',
  avatar,
  actions,
  breadcrumb,
  className,
}) => (
  <div
    className={[
      'avenews-header',
      `avenews-header--${variant}`,
      `avenews-header--${size}`,
      className,
    ].filter(Boolean).join(' ')}
  >
    {breadcrumb && (
      <div className="avenews-header__breadcrumb">{breadcrumb}</div>
    )}

    <div className="avenews-header__row">
      {avatar && (
        <div className="avenews-header__avatar">{avatar}</div>
      )}

      <div className="avenews-header__content">
        <h1 className="avenews-header__title">{title}</h1>
        {subtitle && (
          <p className="avenews-header__subtitle">{subtitle}</p>
        )}
        {description && (
          <p className="avenews-header__description">{description}</p>
        )}
      </div>

      {actions && (
        <div className="avenews-header__actions">{actions}</div>
      )}
    </div>
  </div>
);

export default Header;
