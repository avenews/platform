import type { UploadStatus } from './types';

/** Join class names, filtering falsy values. */
export function cn(
  ...classes: (string | boolean | undefined | null)[]
): string {
  return classes.filter(Boolean).join(' ');
}

/** Human-readable file size — B / KB / MB. */
export function formatFileSize(bytes: number): string {
  if (bytes < 1_024)     return `${bytes} B`;
  if (bytes < 1_048_576) return `${(bytes / 1_024).toFixed(1)} KB`;
  return `${(bytes / 1_048_576).toFixed(1)} MB`;
}

/** Clamp a number within [min, max]. */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

/**
 * Shared UploadCard status labels.
 * `empty` label depends on `required` — pass the prop to get correct label.
 */
export function uploadStatusLabel(status: UploadStatus, required: boolean): string {
  if (status === 'empty') return required ? 'Required' : 'Optional';
  return UPLOAD_STATUS_LABELS[status];
}

const UPLOAD_STATUS_LABELS: Record<Exclude<UploadStatus, 'empty'>, string> = {
  uploading: 'Uploading',
  uploaded:  'Uploaded',
  approved:  'Approved',
  rejected:  'Rejected',
};
