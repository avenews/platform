/**
 * Shared utilities and types — framework-agnostic code used by both ionic
 * and web component implementations.
 *
 * Pure TypeScript only. No React, no Ionic, no DOM dependencies.
 */

export { cn, formatFileSize, clamp, uploadStatusLabel } from './utils';
export type {
  // Cross-cutting semantic types — canonical source for variant/size unions
  SemanticColor,
  StatusVariant,
  Size,
  SizeXL,
  // Button
  ButtonVariant,
  ButtonSize,
  ButtonExpand,
  // Input
  InputLabelPlacement,
  InputType,
  // UploadCard
  UploadStatus,
  UploadCardProps,
} from './types';
