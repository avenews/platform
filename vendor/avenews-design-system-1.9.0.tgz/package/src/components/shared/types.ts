// ─── Cross-cutting semantic types ─────────────────────────────────────────────
// These unions appear in 12+ components (Badge, Chip, Card, Item, List, Note,
// Toast, Toolbar, ProgressBar, Loader, Header, Footer, …). Keep them defined
// here as the canonical source so they don't drift between component-local
// copies. Components may still re-export local aliases for back-compat.

/** Avenews semantic colour palette — maps 1:1 to the `--ion-color-*` Ionic
 *  theme variables and the `--av-color-*` semantic tokens. */
export type SemanticColor =
  | 'primary'
  | 'secondary'
  | 'tertiary'
  | 'success'
  | 'warning'
  | 'danger'
  | 'light'
  | 'medium'
  | 'dark';

/** Same as SemanticColor plus `info` (mapped to secondary/darkblue) and the
 *  status-tinted "subtle" variants used by Badge and InlineBanner. */
export type StatusVariant =
  | SemanticColor
  | 'info'
  | 'neutral'
  | 'success-subtle'
  | 'warning-subtle'
  | 'danger-subtle'
  | 'info-subtle';

/** Standard component size scale used by Button, Loader, ProgressBar, Header,
 *  Avatar, Thumbnail, MediaIcon, etc. */
export type Size = 'sm' | 'md' | 'lg';

/** Extended size scale used where a smaller / larger step is needed
 *  (Icon, EmptyState illustration, etc.). */
export type SizeXL = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

// ─── Button ───────────────────────────────────────────────────────────────────

export type ButtonVariant =
  | 'primary'
  | 'secondary'
  | 'outline'
  | 'ghost'
  | 'danger'
  | 'success'
  | 'warning'
  | 'inverted'
  | 'inverted-outline';

export type ButtonSize   = 'sm' | 'md' | 'lg';
export type ButtonExpand = 'block' | 'full';

// ─── Input ────────────────────────────────────────────────────────────────────

export type InputLabelPlacement = 'stacked' | 'floating' | 'fixed' | 'start';

export type InputType =
  | 'text'
  | 'email'
  | 'number'
  | 'password'
  | 'search'
  | 'tel'
  | 'url'
  | 'date';

// ─── UploadCard ───────────────────────────────────────────────────────────────

export type UploadStatus = 'empty' | 'uploading' | 'uploaded' | 'approved' | 'rejected';

export interface UploadCardProps {
  /** Document label / section title */
  title: string;
  /** Current upload state */
  status?: UploadStatus;
  /** Name of the uploaded file */
  fileName?: string;
  /** File size in bytes — displayed as human-readable string */
  fileSize?: number;
  /** Upload progress 0–1 (used when status = "uploading") */
  progress?: number;
  /** Marks the field as required — appends asterisk to title */
  required?: boolean;
  disabled?: boolean;
  /** File type filter for the hidden input */
  accept?: string;
  /** Called with the chosen File when user selects one */
  onUpload?: (file: File) => void;
  /** Called when user taps the remove/trash button */
  onRemove?: () => void;
  className?: string;
}
