import React, { useRef, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Popover } from './Popover';

const meta: Meta<typeof Popover> = {
  title: 'Avenews/Cross-Platform/Popover',
  component: Popover,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Lightweight floating overlay anchored to a trigger element. ' +
          'Supports text and list content variants. ' +
          'Closes on backdrop click or Escape key.',
      },
    },
    layout: 'centered',
  },
};

export default meta;
type Story = StoryObj<typeof Popover>;

// ─── Shared trigger button style ─────────────────────────────────────────────

const triggerStyle: React.CSSProperties = {
  fontFamily: 'var(--av-font-body)',
  fontSize: 14,
  fontWeight: 600,
  padding: '10px 20px',
  borderRadius: 8,
  border: 'none',
  background: 'var(--av-color-action)',
  color: '#fff',
  cursor: 'pointer',
};

// ─── List variants ────────────────────────────────────────────────────────────

export const ListDefault: Story = {
  name: 'List / Default',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const ref = useRef<HTMLButtonElement>(null);
    return (
      <div style={{ padding: 80, display: 'flex', justifyContent: 'center' }}>
        <button ref={ref} style={triggerStyle} onClick={() => setOpen(true)}>
          Open menu
        </button>
        <Popover
          open={open}
          content="list"
          triggerRef={ref}
          onDismiss={() => setOpen(false)}
          items={[
            { label: 'Edit',   onClick: () => setOpen(false) },
            { label: 'Share',  onClick: () => setOpen(false) },
            { label: 'Delete', onClick: () => setOpen(false) },
          ]}
        />
      </div>
    );
  },
};

export const ListWithHeader: Story = {
  name: 'List / With header',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const ref = useRef<HTMLButtonElement>(null);
    return (
      <div style={{ padding: 80, display: 'flex', justifyContent: 'center' }}>
        <button ref={ref} style={triggerStyle} onClick={() => setOpen(true)}>
          More actions
        </button>
        <Popover
          open={open}
          content="list"
          header="Document actions"
          triggerRef={ref}
          onDismiss={() => setOpen(false)}
          items={[
            { label: 'View details',  onClick: () => setOpen(false) },
            { label: 'Download PDF',  onClick: () => setOpen(false) },
            { label: 'Send reminder', onClick: () => setOpen(false) },
          ]}
        />
      </div>
    );
  },
};

export const ListWithDisabled: Story = {
  name: 'List / With disabled item',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const ref = useRef<HTMLButtonElement>(null);
    return (
      <div style={{ padding: 80, display: 'flex', justifyContent: 'center' }}>
        <button ref={ref} style={triggerStyle} onClick={() => setOpen(true)}>
          Actions
        </button>
        <Popover
          open={open}
          content="list"
          triggerRef={ref}
          onDismiss={() => setOpen(false)}
          items={[
            { label: 'Approve',  onClick: () => setOpen(false) },
            { label: 'Reject',   onClick: () => setOpen(false), disabled: true },
            { label: 'Escalate', onClick: () => setOpen(false) },
          ]}
        />
      </div>
    );
  },
};

// ─── Text variant ─────────────────────────────────────────────────────────────

export const TextContent: Story = {
  name: 'Text / Tooltip-style',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const ref = useRef<HTMLButtonElement>(null);
    return (
      <div style={{ padding: 80, display: 'flex', justifyContent: 'center' }}>
        <button ref={ref} style={triggerStyle} onClick={() => setOpen(true)}>
          What is a repayment reference?
        </button>
        <Popover
          open={open}
          content="text"
          triggerRef={ref}
          onDismiss={() => setOpen(false)}
          text="A repayment reference is the unique ID assigned to each loan repayment transaction. You'll find it on your statement or confirmation email."
        />
      </div>
    );
  },
};

// ─── Sides ────────────────────────────────────────────────────────────────────

export const SideTop: Story = {
  name: 'Side / Top',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const ref = useRef<HTMLButtonElement>(null);
    return (
      <div style={{ padding: 120, display: 'flex', justifyContent: 'center' }}>
        <button ref={ref} style={triggerStyle} onClick={() => setOpen(true)}>
          Opens above
        </button>
        <Popover
          open={open}
          content="list"
          side="top"
          triggerRef={ref}
          onDismiss={() => setOpen(false)}
          items={[
            { label: 'Option A', onClick: () => setOpen(false) },
            { label: 'Option B', onClick: () => setOpen(false) },
          ]}
        />
      </div>
    );
  },
};

// ─── Cover size ───────────────────────────────────────────────────────────────

export const SizeCover: Story = {
  name: 'Size / Cover (full-width)',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const ref = useRef<HTMLButtonElement>(null);
    return (
      <div style={{ padding: 80, display: 'flex', justifyContent: 'center', width: 300 }}>
        <button ref={ref} style={{ ...triggerStyle, width: '100%' }} onClick={() => setOpen(true)}>
          Select repayment type
        </button>
        <Popover
          open={open}
          content="list"
          size="cover"
          triggerRef={ref}
          onDismiss={() => setOpen(false)}
          items={[
            { label: 'Full repayment',    onClick: () => setOpen(false) },
            { label: 'Partial repayment', onClick: () => setOpen(false) },
            { label: 'Restructure loan',  onClick: () => setOpen(false) },
          ]}
        />
      </div>
    );
  },
};

// ─── App use-case ─────────────────────────────────────────────────────────────

export const DocumentActions: Story = {
  name: 'App / Document row actions',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [lastAction, setLastAction] = useState<string | null>(null);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const ref = useRef<HTMLButtonElement>(null);
    const act = (label: string) => { setLastAction(label); setOpen(false); };
    return (
      <div style={{ padding: 40, fontFamily: 'var(--av-font-body)', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, background: 'var(--av-surface-base)', borderRadius: 12, padding: '12px 16px', boxShadow: '0 1px 4px rgba(0,0,0,.06)' }}>
          <span style={{ flex: 1, fontSize: 14, fontWeight: 500 }}>Bank_Statement_Dec23.pdf</span>
          <button ref={ref} style={{ ...triggerStyle, padding: '6px 12px', fontSize: 13 }} onClick={() => setOpen(true)}>
            ⋯
          </button>
        </div>
        {lastAction && (
          <p style={{ fontSize: 13, color: 'var(--av-color-action)' }}>Action: {lastAction}</p>
        )}
        <Popover
          open={open}
          content="list"
          header="Document options"
          triggerRef={ref}
          onDismiss={() => setOpen(false)}
          items={[
            { label: 'Preview',         onClick: () => act('Preview') },
            { label: 'Re-upload',        onClick: () => act('Re-upload') },
            { label: 'Remove document',  onClick: () => act('Remove document') },
          ]}
        />
      </div>
    );
  },
};
