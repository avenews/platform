import React from 'react';
import { statusLabels, StatusKey } from '../../tokens/colours';

export type DocumentStatus = Extract<StatusKey, 'action_required' | 'in_review' | 'completed' | 'optional'>;

export interface DocumentRowProps {
  name:       string;
  status:     DocumentStatus;
  loading?:   boolean;
  error?:     boolean;
  disabled?:  boolean;
  className?: string;
}

function statusClass(s: DocumentStatus): string {
  return {
    action_required: 'status-action-required',
    in_review:       'status-in-review',
    completed:       'status-completed',
    optional:        'status-optional',
  }[s];
}

const RowSkeleton: React.FC = () => (
  <div className="avenews-doc-row status-pending" style={{ alignItems: 'center' }}>
    <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'var(--av-neutral-200)', flexShrink: 0 }} />
    <div style={{ flex: 1, height: '12px', background: 'var(--av-neutral-200)', borderRadius: '4px' }} />
    <div style={{ width: '64px', height: '20px', background: 'var(--av-neutral-200)', borderRadius: 'var(--av-radius-pill)' }} />
  </div>
);

export const DocumentRow: React.FC<DocumentRowProps> = ({
  name,
  status,
  loading  = false,
  error    = false,
  disabled = false,
  className,
}) => {
  if (loading) return <RowSkeleton />;

  const resolvedStatus: DocumentStatus = error ? 'action_required' : status;
  const pillLabel = error ? 'Error' : statusLabels[resolvedStatus];

  return (
    <div
      className={`avenews-doc-row ${statusClass(resolvedStatus)}${className ? ` ${className}` : ''}`}
      style={{ opacity: disabled ? 0.5 : 1 }}
      aria-label={`${name}: ${pillLabel}`}
    >
      <span className="avenews-doc-row__dot" aria-hidden="true">•</span>
      <span className="avenews-doc-row__name">{name}</span>
      <span className="avenews-doc-row__pill">{pillLabel}</span>
    </div>
  );
};

export default DocumentRow;
