import React from 'react';
import { Badge } from './Badge';
import { cn } from '../shared/utils';

export type SectionHeaderVariant = 'default' | 'with-action' | 'with-count';

export interface SectionHeaderProps {
  title:         string;
  variant?:      SectionHeaderVariant;
  actionLabel?:  string;
  count?:        number;
  onAction?:     () => void;
  className?:    string;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({
  title,
  variant     = 'default',
  actionLabel = 'View all',
  count,
  onAction,
  className,
}) => (
  <div className={cn('av-section-header', className)}>
    <span className="av-section-header__title">{title}</span>
    {variant === 'with-action' && (
      <button type="button" className="av-section-header__action" onClick={onAction}>
        {actionLabel}
      </button>
    )}
    {variant === 'with-count' && count !== undefined && (
      <Badge count={count} variant="neutral" hideOnEmpty={false} className="av-section-header__count" />
    )}
  </div>
);

export default SectionHeader;
