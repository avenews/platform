import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { StepIndicator, Step } from './StepIndicator';

const meta: Meta<typeof StepIndicator> = {
  title: 'Avenews/Cross-Platform/StepIndicator',
  component: StepIndicator,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Collapsible progress bar that shows application or onboarding steps. ' +
          'Tap / click the bar to expand the step drawer. ' +
          'Supports completed, in-progress, action-required, and pending statuses.',
      },
    },
    layout: 'padded',
  },
};

export default meta;
type Story = StoryObj<typeof StepIndicator>;

// ─── Shared step fixtures ─────────────────────────────────────────────────────

const steps5Early: Step[] = [
  { id: 1, title: 'Business details',       status: 'completed' },
  { id: 2, title: 'Director information',   status: 'in_progress' },
  { id: 3, title: 'Financial documents',    status: 'pending', subtitle: 'Upload required docs' },
  { id: 4, title: 'Bank account linking',   status: 'pending', subtitle: 'Verify your account' },
  { id: 5, title: 'Review & submit',        status: 'pending' },
];

const steps5Late: Step[] = [
  { id: 1, title: 'Business details',       status: 'completed' },
  { id: 2, title: 'Director information',   status: 'completed' },
  { id: 3, title: 'Financial documents',    status: 'completed' },
  { id: 4, title: 'Bank account linking',   status: 'in_progress' },
  { id: 5, title: 'Review & submit',        status: 'pending' },
];

const stepsComplete: Step[] = [
  { id: 1, title: 'Business details',       status: 'completed' },
  { id: 2, title: 'Director information',   status: 'completed' },
  { id: 3, title: 'Financial documents',    status: 'completed' },
  { id: 4, title: 'Bank account linking',   status: 'completed' },
  { id: 5, title: 'Review & submit',        status: 'completed' },
];

const stepsAction: Step[] = [
  { id: 1, title: 'Business details',       status: 'completed' },
  { id: 2, title: 'Director information',   status: 'completed' },
  { id: 3, title: 'Financial documents',    status: 'action_required' },
  { id: 4, title: 'Bank account linking',   status: 'pending' },
  { id: 5, title: 'Review & submit',        status: 'pending' },
];

// ─── Default ──────────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default / Step 2 of 5',
  args: {
    steps:       steps5Early,
    currentStep: 2,
    stepDisplay: 'Step 2 of 5',
    label:       'Director information',
  },
};

// ─── Progress states ──────────────────────────────────────────────────────────

export const LateProgress: Story = {
  name: 'State / Step 4 of 5',
  args: {
    steps:       steps5Late,
    currentStep: 4,
    stepDisplay: 'Step 4 of 5',
    label:       'Bank account linking',
  },
};

export const AllComplete: Story = {
  name: 'State / All complete',
  args: {
    steps:       stepsComplete,
    currentStep: 5,
    stepDisplay: 'Step 5 of 5',
    label:       'Review & submit',
  },
};

export const ActionRequired: Story = {
  name: 'State / Action required',
  args: {
    steps:       stepsAction,
    currentStep: 3,
    stepDisplay: 'Step 3 of 5',
    label:       'Financial documents',
  },
};

export const ErrorState: Story = {
  name: 'State / Error override',
  args: {
    steps:       steps5Early,
    currentStep: 2,
    stepDisplay: 'Step 2 of 5',
    label:       'Director information',
    error:       true,
  },
};

// ─── Loading ──────────────────────────────────────────────────────────────────

export const Loading: Story = {
  name: 'State / Loading skeleton',
  args: {
    steps:       [],
    currentStep: 0,
    stepDisplay: '',
    label:       '',
    loading:     true,
  },
};

// ─── Interactive ──────────────────────────────────────────────────────────────

export const Interactive: Story = {
  name: 'Interactive / Advancing steps',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [current, setCurrent] = useState(1);
    const total = 5;

    const buildSteps = (active: number): Step[] => [
      { id: 1, title: 'Business details',     status: active > 1 ? 'completed' : active === 1 ? 'in_progress' : 'pending' },
      { id: 2, title: 'Director information', status: active > 2 ? 'completed' : active === 2 ? 'in_progress' : 'pending' },
      { id: 3, title: 'Financial documents',  status: active > 3 ? 'completed' : active === 3 ? 'in_progress' : 'pending' },
      { id: 4, title: 'Bank account linking', status: active > 4 ? 'completed' : active === 4 ? 'in_progress' : 'pending' },
      { id: 5, title: 'Review & submit',      status: active > 5 ? 'completed' : active === 5 ? 'in_progress' : 'pending' },
    ];

    const btnStyle: React.CSSProperties = {
      padding: '8px 16px', borderRadius: 8, border: 'none', cursor: 'pointer',
      fontSize: 13, fontFamily: 'var(--av-font-body)', fontWeight: 600,
    };

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 360, fontFamily: 'var(--av-font-body)' }}>
        <StepIndicator
          steps={buildSteps(current)}
          currentStep={current}
          stepDisplay={`Step ${current} of ${total}`}
          label={buildSteps(current)[current - 1]?.title ?? ''}
        />
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => setCurrent((c) => Math.max(1, c - 1))} disabled={current === 1}
            style={{ ...btnStyle, background: 'var(--av-neutral-200)', color: 'var(--av-neutral-700)' }}>
            ← Back
          </button>
          <button onClick={() => setCurrent((c) => Math.min(total, c + 1))} disabled={current === total}
            style={{ ...btnStyle, background: 'var(--av-color-action)', color: '#fff' }}>
            Next →
          </button>
        </div>
      </div>
    );
  },
};

// ─── App use-case ─────────────────────────────────────────────────────────────

export const LoanApplication: Story = {
  name: 'App / Loan application flow',
  render: () => (
    <div style={{ width: 360, borderRadius: 16, background: 'var(--av-surface-base)', overflow: 'hidden', boxShadow: '0 2px 12px rgba(0,0,0,.08)' }}>
      <StepIndicator
        steps={steps5Early}
        currentStep={2}
        stepDisplay="Step 2 of 5"
        label="Director information"
      />
    </div>
  ),
};
