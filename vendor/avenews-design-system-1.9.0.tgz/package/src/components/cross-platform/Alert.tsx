import React from 'react';

export type AlertButtonRole = 'confirm' | 'cancel' | 'destructive';

export interface AlertButton {
  text: string;
  role?: AlertButtonRole;
  handler?: () => void;
}

export interface AlertInput {
  type?: 'text' | 'textarea' | 'email' | 'password' | 'number';
  placeholder?: string;
  value?: string;
  name?: string;
  onChange?: (value: string) => void;
}

export interface AlertCheckbox {
  label: string;
  value?: string;
  checked?: boolean;
  onChange?: (checked: boolean) => void;
}

export interface AlertRadio {
  label: string;
  value: string;
}

export interface AlertProps {
  open?: boolean;
  header: string;
  subHeader?: string;
  message?: string;
  buttons?: AlertButton[];
  inputs?: AlertInput[];
  checkboxes?: AlertCheckbox[];
  radios?: AlertRadio[];
  radioValue?: string;
  onRadioChange?: (value: string) => void;
  onDismiss?: () => void;
  className?: string;
}

function isStackedLayout(buttons: AlertButton[]): boolean {
  return buttons.some((b) => b.role === 'destructive');
}

export const Alert: React.FC<AlertProps> = ({
  open = false,
  header,
  subHeader,
  message,
  buttons = [],
  inputs = [],
  checkboxes = [],
  radios = [],
  radioValue,
  onRadioChange,
  onDismiss,
  className,
}) => {
  if (!open) return null;

  const stacked = isStackedLayout(buttons);
  const hasContent = message || inputs.length > 0 || checkboxes.length > 0 || radios.length > 0;

  return (
    <div
      className={['avenews-alert', className].filter(Boolean).join(' ')}
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="avenews-alert-title"
    >
      <div className="avenews-alert__backdrop" onClick={onDismiss} aria-hidden="true" />

      <div className={['avenews-alert__box', stacked ? 'avenews-alert__box--wide' : ''].filter(Boolean).join(' ')}>

        <div className="avenews-alert__header">
          <p id="avenews-alert-title" className="avenews-alert__title">{header}</p>
          {subHeader && <p className="avenews-alert__subtitle">{subHeader}</p>}
        </div>

        {hasContent && (
          <div className="avenews-alert__content">
            {message && !inputs.length && !checkboxes.length && !radios.length && (
              <p className="avenews-alert__message">{message}</p>
            )}

            {inputs.length > 0 && (
              <div className="avenews-alert__inputs">
                {inputs.map((input, i) =>
                  input.type === 'textarea' ? (
                    <textarea
                      key={i}
                      className="avenews-alert__input avenews-alert__input--textarea"
                      placeholder={input.placeholder}
                      value={input.value}
                      name={input.name}
                      onChange={(e) => input.onChange?.(e.target.value)}
                    />
                  ) : (
                    <input
                      key={i}
                      className="avenews-alert__input"
                      type={input.type ?? 'text'}
                      placeholder={input.placeholder}
                      value={input.value}
                      name={input.name}
                      onChange={(e) => input.onChange?.(e.target.value)}
                    />
                  )
                )}
              </div>
            )}

            {radios.length > 0 && (
              <div className="avenews-alert__list" role="radiogroup">
                {radios.map((radio) => (
                  <label key={radio.value} className="avenews-alert__list-item">
                    <input
                      type="radio"
                      className="avenews-alert__radio"
                      value={radio.value}
                      checked={radioValue === radio.value}
                      onChange={() => onRadioChange?.(radio.value)}
                    />
                    <span className="avenews-alert__list-label">{radio.label}</span>
                  </label>
                ))}
              </div>
            )}

            {checkboxes.length > 0 && (
              <div className="avenews-alert__list">
                {checkboxes.map((cb, i) => (
                  <label key={i} className="avenews-alert__list-item">
                    <input
                      type="checkbox"
                      className="avenews-alert__checkbox"
                      checked={cb.checked}
                      onChange={(e) => cb.onChange?.(e.target.checked)}
                    />
                    <span className="avenews-alert__list-label">{cb.label}</span>
                  </label>
                ))}
              </div>
            )}
          </div>
        )}

        {buttons.length > 0 && (
          <div className={['avenews-alert__footer', stacked ? 'avenews-alert__footer--stacked' : ''].filter(Boolean).join(' ')}>
            {buttons.map((btn, i) => {
              const role = btn.role ?? 'confirm';
              let btnClass = 'avenews-alert__btn';
              if (stacked && role === 'confirm')    btnClass += ' avenews-alert__btn--solid';
              else if (role === 'destructive')      btnClass += ' avenews-alert__btn--destructive';
              else                                  btnClass += ' avenews-alert__btn--clear';
              return (
                <button key={i} type="button" className={btnClass} onClick={btn.handler}>
                  {btn.text}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Alert;
