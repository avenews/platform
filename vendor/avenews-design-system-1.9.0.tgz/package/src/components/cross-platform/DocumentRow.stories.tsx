import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { DocumentRow } from './DocumentRow';

const meta: Meta<typeof DocumentRow> = {
  title: 'Avenews/Cross-Platform/DocumentRow',
  component: DocumentRow,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Single document list row with a status dot, file name, and status pill. ' +
          'Supports action-required, in-review, completed, and optional statuses, ' +
          'plus loading skeleton, error override, and disabled opacity.',
      },
    },
    layout: 'padded',
  },
};

export default meta;
type Story = StoryObj<typeof DocumentRow>;

// ─── Statuses ─────────────────────────────────────────────────────────────────

export const ActionRequired: Story = {
  name: 'Status / Action required',
  args: {
    name:   'Bank Statement (last 3 months)',
    status: 'action_required',
  },
};

export const InReview: Story = {
  name: 'Status / In review',
  args: {
    name:   'Director ID (passport)',
    status: 'in_review',
  },
};

export const Completed: Story = {
  name: 'Status / Completed',
  args: {
    name:   'Certificate of Incorporation',
    status: 'completed',
  },
};

export const Optional: Story = {
  name: 'Status / Optional',
  args: {
    name:   'Audited financial statements',
    status: 'optional',
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const Loading: Story = {
  name: 'State / Loading skeleton',
  args: {
    name:    'Document name',
    status:  'action_required',
    loading: true,
  },
};

export const ErrorState: Story = {
  name: 'State / Error override',
  args: {
    name:   'Tax Certificate 2023',
    status: 'in_review',
    error:  true,
  },
};

export const Disabled: Story = {
  name: 'State / Disabled',
  args: {
    name:     'Audited financial statements',
    status:   'optional',
    disabled: true,
  },
};

// ─── All statuses ─────────────────────────────────────────────────────────────

export const AllStatuses: Story = {
  name: 'Overview / All statuses',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, width: 360 }}>
      <DocumentRow name="Bank Statement"          status="action_required" />
      <DocumentRow name="Director ID"             status="in_review" />
      <DocumentRow name="Certificate of Inc."     status="completed" />
      <DocumentRow name="Audited Financials"      status="optional" />
    </div>
  ),
};

// ─── App use-case ─────────────────────────────────────────────────────────────

export const DocumentChecklist: Story = {
  name: 'App / Application checklist',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0, width: 360, borderRadius: 12, overflow: 'hidden', background: 'var(--av-surface-base)', boxShadow: '0 2px 12px rgba(0,0,0,.06)', fontFamily: 'var(--av-font-body)' }}>
      <div style={{ padding: '12px 16px 8px', borderBottom: '1px solid var(--av-neutral-100)' }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--av-neutral-700)' }}>Required documents</span>
      </div>
      <div style={{ padding: '4px 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        <DocumentRow name="Bank Statement (last 3 months)"  status="completed" />
        <DocumentRow name="Director ID (passport or NID)"   status="completed" />
        <DocumentRow name="Certificate of Incorporation"    status="in_review" />
        <DocumentRow name="KRA PIN Certificate"             status="action_required" />
        <DocumentRow name="Audited Financial Statements"    status="optional" />
      </div>
    </div>
  ),
};

export const LoadingList: Story = {
  name: 'App / Loading list',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, width: 360, padding: '8px 0' }}>
      <DocumentRow name="" status="action_required" loading />
      <DocumentRow name="" status="action_required" loading />
      <DocumentRow name="" status="action_required" loading />
    </div>
  ),
};
