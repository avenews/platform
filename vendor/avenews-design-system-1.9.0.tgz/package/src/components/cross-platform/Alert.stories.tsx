import React, { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Alert } from './Alert';

const meta: Meta<typeof Alert> = {
  title: 'Avenews/Cross-Platform/Alert',
  component: Alert,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Dialog overlay for confirmations, prompts, and choices. ' +
          'Supports plain message, form inputs, radio list, and checkbox list. ' +
          'Stacked footer layout is triggered automatically when a destructive button is present.',
      },
    },
    layout: 'fullscreen',
  },
};

export default meta;
type Story = StoryObj<typeof Alert>;

const Trigger: React.FC<{
  label?: string;
  children: (open: boolean, setOpen: (v: boolean) => void) => React.ReactNode;
}> = ({ label = 'Open alert', children }) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const [open, setOpen] = useState(false);
  return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}>
      <button
        style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
          padding: '10px 20px', borderRadius: 8, border: 'none',
          background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer' }}
        onClick={() => setOpen(true)}
      >
        {label}
      </button>
      {children(open, setOpen)}
    </div>
  );
};

// ─── Basic message ────────────────────────────────────────────────────────────

export const SimpleConfirm: Story = {
  name: 'Basic / Confirm',
  render: () => (
    <Trigger label="Open confirm alert">
      {(open, setOpen) => (
        <Alert
          open={open}
          header="Confirm action"
          message="Are you sure you want to proceed? This cannot be undone."
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Cancel',  role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Confirm', role: 'confirm', handler: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

export const WithSubHeader: Story = {
  name: 'Basic / With sub-header',
  render: () => (
    <Trigger>
      {(open, setOpen) => (
        <Alert
          open={open}
          header="Session expired"
          subHeader="You have been signed out"
          message="Your session timed out for security. Please sign in again to continue."
          onDismiss={() => setOpen(false)}
          buttons={[{ text: 'Sign in', role: 'confirm', handler: () => setOpen(false) }]}
        />
      )}
    </Trigger>
  ),
};

// ─── Destructive (stacked) ────────────────────────────────────────────────────

export const Destructive: Story = {
  name: 'Variant / Destructive (stacked)',
  render: () => (
    <Trigger label="Open delete alert">
      {(open, setOpen) => (
        <Alert
          open={open}
          header="Delete document?"
          message="Invoice_Q3.pdf will be permanently removed from your account."
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Delete',    role: 'destructive', handler: () => setOpen(false) },
            { text: 'Keep file', role: 'cancel',      handler: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

// ─── Form input ───────────────────────────────────────────────────────────────

export const WithInput: Story = {
  name: 'Form / Text input',
  render: () => (
    <Trigger label="Open input alert">
      {(open, setOpen) => (
        <Alert
          open={open}
          header="Enter repayment reference"
          onDismiss={() => setOpen(false)}
          inputs={[{ type: 'text', placeholder: 'e.g. AVN-2024-00123' }]}
          buttons={[
            { text: 'Cancel', role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Submit', role: 'confirm', handler: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

export const WithTextarea: Story = {
  name: 'Form / Textarea',
  render: () => (
    <Trigger label="Open textarea alert">
      {(open, setOpen) => (
        <Alert
          open={open}
          header="Add a note"
          onDismiss={() => setOpen(false)}
          inputs={[{ type: 'textarea', placeholder: 'Describe the purpose of this request…' }]}
          buttons={[
            { text: 'Cancel', role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Save',   role: 'confirm', handler: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

// ─── Radio list ───────────────────────────────────────────────────────────────

export const WithRadioList: Story = {
  name: 'Form / Radio selection',
  render: () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [open, setOpen] = useState(false);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [selected, setSelected] = useState('monthly');
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}>
        <button
          style={{ fontFamily: 'var(--av-font-body)', fontSize: 14, fontWeight: 600,
            padding: '10px 20px', borderRadius: 8, border: 'none',
            background: 'var(--av-color-action)', color: '#fff', cursor: 'pointer' }}
          onClick={() => setOpen(true)}>
          Choose repayment schedule
        </button>
        <Alert
          open={open}
          header="Repayment schedule"
          onDismiss={() => setOpen(false)}
          radios={[
            { label: 'Weekly',    value: 'weekly' },
            { label: 'Monthly',   value: 'monthly' },
            { label: 'Quarterly', value: 'quarterly' },
          ]}
          radioValue={selected}
          onRadioChange={setSelected}
          buttons={[
            { text: 'Cancel', role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Select', role: 'confirm', handler: () => setOpen(false) },
          ]}
        />
      </div>
    );
  },
};

// ─── Checkbox list ────────────────────────────────────────────────────────────

export const WithCheckboxes: Story = {
  name: 'Form / Checkboxes',
  render: () => (
    <Trigger label="Select documents">
      {(open, setOpen) => (
        <Alert
          open={open}
          header="Select documents to submit"
          onDismiss={() => setOpen(false)}
          checkboxes={[
            { label: 'Bank statement', checked: true },
            { label: 'Director ID',    checked: true },
            { label: 'Tax certificate', checked: false },
          ]}
          buttons={[
            { text: 'Cancel', role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Submit', role: 'confirm', handler: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const RepaymentConfirm: Story = {
  name: 'App / Repayment confirmation',
  render: () => (
    <Trigger label="Confirm KES 12,500 repayment">
      {(open, setOpen) => (
        <Alert
          open={open}
          header="Confirm repayment"
          subHeader="KES 12,500"
          message="This will be processed today. Funds will be deducted from your linked account."
          onDismiss={() => setOpen(false)}
          buttons={[
            { text: 'Cancel',  role: 'cancel',  handler: () => setOpen(false) },
            { text: 'Pay now', role: 'confirm', handler: () => setOpen(false) },
          ]}
        />
      )}
    </Trigger>
  ),
};
