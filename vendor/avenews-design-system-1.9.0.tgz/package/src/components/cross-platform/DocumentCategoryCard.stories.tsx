import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { DocumentCategoryCard, DocRow } from './DocumentCategoryCard';

const meta: Meta<typeof DocumentCategoryCard> = {
  title: 'Avenews/Cross-Platform/DocumentCategoryCard',
  component: DocumentCategoryCard,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Card grouping a category of documents with a header status pill and a list of DocumentRow items. ' +
          'Supports action-required, in-review, completed, and optional statuses, ' +
          'plus loading skeleton, error override, and an optional hint line.',
      },
    },
    layout: 'padded',
  },
};

export default meta;
type Story = StoryObj<typeof DocumentCategoryCard>;

// ─── Shared fixtures ──────────────────────────────────────────────────────────

const identityDocs: DocRow[] = [
  { name: 'Director ID (passport or NID)', status: 'completed' },
  { name: 'Proof of address',               status: 'in_review' },
  { name: 'Director selfie',                status: 'action_required' },
];

const financialDocs: DocRow[] = [
  { name: 'Bank Statement (last 3 months)', status: 'completed' },
  { name: 'Audited financial statements',   status: 'optional' },
  { name: 'KRA PIN Certificate',            status: 'completed' },
];

const businessDocs: DocRow[] = [
  { name: 'Certificate of Incorporation', status: 'action_required' },
  { name: 'Business permit',              status: 'pending' as any },
  { name: 'Memorandum of Association',    status: 'optional' },
];

// ─── Statuses ─────────────────────────────────────────────────────────────────

export const ActionRequired: Story = {
  name: 'Status / Action required',
  args: {
    index:  1,
    title:  'Director identity',
    status: 'action_required',
    docs:   identityDocs,
  },
};

export const InReview: Story = {
  name: 'Status / In review',
  args: {
    index:  2,
    title:  'Financial documents',
    status: 'in_review',
    docs:   financialDocs,
  },
};

export const Completed: Story = {
  name: 'Status / Completed',
  args: {
    index:  2,
    title:  'Financial documents',
    status: 'completed',
    docs:   financialDocs,
  },
};

export const Optional: Story = {
  name: 'Status / Optional',
  args: {
    index:  3,
    title:  'Supporting documents',
    status: 'optional',
    docs:   [
      { name: 'Audited financial statements', status: 'optional' },
      { name: 'Business plan',                status: 'optional' },
    ],
  },
};

// ─── With hint ────────────────────────────────────────────────────────────────

export const WithHint: Story = {
  name: 'Variant / With hint text',
  args: {
    index:  1,
    title:  'Business registration',
    status: 'action_required',
    docs:   businessDocs,
    hint:   'Upload clear, unobstructed scans. Blurry or partial documents will be rejected.',
  },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const Loading: Story = {
  name: 'State / Loading skeleton',
  args: {
    index:   1,
    title:   'Director identity',
    status:  'action_required',
    docs:    identityDocs,
    loading: true,
  },
};

export const ErrorState: Story = {
  name: 'State / Error override',
  args: {
    index:  2,
    title:  'Financial documents',
    status: 'in_review',
    docs:   financialDocs,
    error:  true,
  },
};

// ─── App use-case ─────────────────────────────────────────────────────────────

export const FullApplicationChecklist: Story = {
  name: 'App / Full application checklist',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: 380, fontFamily: 'var(--av-font-body)' }}>
      <DocumentCategoryCard
        index={1}
        title="Director identity"
        status="completed"
        docs={[
          { name: 'Director ID (passport or NID)', status: 'completed' },
          { name: 'Proof of address',               status: 'completed' },
        ]}
      />
      <DocumentCategoryCard
        index={2}
        title="Business registration"
        status="action_required"
        docs={businessDocs}
        hint="Ensure documents are not expired."
      />
      <DocumentCategoryCard
        index={3}
        title="Financial documents"
        status="in_review"
        docs={financialDocs}
      />
    </div>
  ),
};

export const LoadingChecklist: Story = {
  name: 'App / Loading checklist',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: 380 }}>
      <DocumentCategoryCard index={1} title="" status="action_required" docs={[]} loading />
      <DocumentCategoryCard index={2} title="" status="action_required" docs={[]} loading />
    </div>
  ),
};
