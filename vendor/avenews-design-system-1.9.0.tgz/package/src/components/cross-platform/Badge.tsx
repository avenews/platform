import React from 'react';
import { cn } from '../shared/utils';

export type BadgeVariant =
  | 'primary' | 'secondary' | 'tertiary'
  | 'success' | 'warning' | 'danger'
  | 'light' | 'medium' | 'dark' | 'info' | 'neutral'
  | 'success-subtle' | 'warning-subtle' | 'danger-subtle' | 'info-subtle'
  | 'accent-subtle' | 'aqua-subtle';

export interface BadgeProps {
  count:        number | string;
  variant?:     BadgeVariant;
  hideOnEmpty?: boolean;
  loading?:     boolean;
  className?:   string;
}

function formatCount(count: number | string): string {
  if (typeof count === 'string') return count;
  if (count >= 1000) return `${Math.round(count / 1000)}k+`;
  return String(count);
}

export const Badge: React.FC<BadgeProps> = ({
  count,
  variant     = 'primary',
  hideOnEmpty = true,
  loading     = false,
  className,
}) => {
  const isEmpty = count === 0 || count === '' || count === null || count === undefined;
  if (hideOnEmpty && isEmpty && !loading) return null;

  const resolvedVariant = loading ? 'loading' : variant;
  const label = loading ? '\u00A0' : formatCount(count);

  return (
    <span className={cn('av-badge', `av-badge--${resolvedVariant}`, className)}>
      {label}
    </span>
  );
};

export default Badge;
