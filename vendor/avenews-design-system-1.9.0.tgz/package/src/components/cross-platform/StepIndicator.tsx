import React, { useState } from 'react';
import { statusLabels, StatusKey } from '../../tokens/colours';

export type StepStatus = Extract<StatusKey, 'completed' | 'in_progress' | 'action_required' | 'pending'>;

export interface Step {
  id:        number;
  title:     string;
  subtitle?: string;
  status:    StepStatus;
}

export interface StepIndicatorProps {
  steps:       Step[];
  currentStep: number;
  stepDisplay: string;
  label:       string;
  loading?:    boolean;
  error?:      boolean;
  className?:  string;
}

function segmentClass(step: Step, currentStep: number): string {
  if (step.status === 'completed') return 'avenews-step-indicator__segment--completed';
  if (step.id === currentStep)     return 'avenews-step-indicator__segment--active';
  return '';
}

function iconClass(s: StepStatus): string {
  return {
    completed:       'avenews-step-indicator__step-icon--completed',
    in_progress:     'avenews-step-indicator__step-icon--active',
    action_required: 'avenews-step-indicator__step-icon--action-required',
    pending:         'avenews-step-indicator__step-icon--pending',
  }[s];
}

function titleClass(s: StepStatus): string {
  return {
    completed:       'avenews-step-indicator__step-title--completed',
    in_progress:     'avenews-step-indicator__step-title--active',
    action_required: 'avenews-step-indicator__step-title--active',
    pending:         'avenews-step-indicator__step-title--pending',
  }[s];
}

function badgeStyle(s: StepStatus): React.CSSProperties {
  return {
    completed:       { background: 'var(--av-status-completed-bg)',       color: 'var(--av-status-completed-fg)' },
    in_progress:     { background: 'var(--av-status-in-progress-bg)',     color: 'var(--av-status-in-progress-fg)' },
    action_required: { background: 'var(--av-status-action-required-bg)', color: 'var(--av-status-action-required-fg)' },
    pending:         { background: 'var(--av-neutral-100)',                color: 'var(--av-neutral-500)' },
  }[s];
}

const StepIndicatorSkeleton: React.FC = () => (
  <div className="avenews-step-indicator" style={{ padding: '10px 16px' }}>
    <div className="avenews-step-indicator__track">
      {[1,2,3,4,5].map((i) => (
        <div key={i} className="avenews-step-indicator__segment" style={{ background: 'var(--av-neutral-200)' }} />
      ))}
    </div>
    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '8px' }}>
      <div style={{ width: '72px', height: '20px', borderRadius: 'var(--av-radius-pill)', background: 'var(--av-neutral-200)' }} />
      <div style={{ flex: 1, height: '13px', background: 'var(--av-neutral-200)', borderRadius: '4px' }} />
    </div>
  </div>
);

export const StepIndicator: React.FC<StepIndicatorProps> = ({
  steps,
  currentStep,
  stepDisplay,
  label,
  loading   = false,
  error     = false,
  className,
}) => {
  const [expanded, setExpanded] = useState(false);
  if (loading) return <StepIndicatorSkeleton />;

  const resolvedSteps = error
    ? steps.map((s) => s.id === currentStep ? { ...s, status: 'action_required' as StepStatus } : s)
    : steps;

  return (
    <div className={`avenews-step-indicator${className ? ` ${className}` : ''}`}>
      <div
        className="avenews-step-indicator__bar"
        onClick={() => setExpanded((v) => !v)}
        role="button"
        aria-expanded={expanded}
        aria-label={`${stepDisplay}: ${label}. ${expanded ? 'Collapse' : 'Expand'} step list.`}
      >
        <div className="avenews-step-indicator__track">
          {resolvedSteps.map((step) => (
            <div key={step.id} className={`avenews-step-indicator__segment ${segmentClass(step, currentStep)}`} />
          ))}
        </div>
        <div className="avenews-step-indicator__info">
          <span className="avenews-step-indicator__pill">{stepDisplay}</span>
          <span className="avenews-step-indicator__label">{label}</span>
          <span className="avenews-step-indicator__chevron" aria-hidden="true">{expanded ? '∧' : '∨'}</span>
        </div>
      </div>

      {expanded && (
        <div className="avenews-step-indicator__drawer">
          {resolvedSteps.map((step) => (
            <div key={step.id} className="avenews-step-indicator__step-row">
              <div className={`avenews-step-indicator__step-icon ${iconClass(step.status)}`}>
                {step.status === 'completed' ? '✓' : step.id}
              </div>
              <span className={`avenews-step-indicator__step-title ${titleClass(step.status)}`}>
                {step.title}
              </span>
              {step.status !== 'pending' && (
                <span className="avenews-step-indicator__step-badge" style={badgeStyle(step.status)}>
                  {step.status === 'completed' ? 'Completed' : statusLabels[step.status]}
                </span>
              )}
              {step.status === 'pending' && step.subtitle && (
                <span className="avenews-step-indicator__step-subtitle">{step.subtitle}</span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default StepIndicator;
