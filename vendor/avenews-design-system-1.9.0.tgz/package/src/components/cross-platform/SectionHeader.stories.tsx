import React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { SectionHeader } from './SectionHeader';

const meta: Meta<typeof SectionHeader> = {
  title: 'Avenews/Cross-Platform/SectionHeader',
  component: SectionHeader,
  parameters: { layout: 'padded' },
  argTypes: {
    variant: { control: 'select', options: ['default', 'with-action', 'with-count'] },
  },
};

export default meta;
type Story = StoryObj<typeof SectionHeader>;

export const Default: Story = {
  args: { title: 'Business details' },
};

export const WithAction: Story = {
  args: { title: 'Documents', variant: 'with-action', actionLabel: 'View all', onAction: () => {} },
};

export const WithCount: Story = {
  args: { title: 'Active loans', variant: 'with-count', count: 3 },
};

export const AllVariants: Story = {
  render: () => (
    <div style={{ maxWidth: 480, background: '#f6f8fc', padding: 0 }}>
      <SectionHeader title="Business details" />
      <SectionHeader title="Documents" variant="with-action" actionLabel="View all" onAction={() => {}} />
      <SectionHeader title="Active loans" variant="with-count" count={3} />
    </div>
  ),
};
