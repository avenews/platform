/**
 * Cross-platform components — shared between Ionic (mobile) and Web (portal).
 *
 * AUTO-GENERATED INDEX. Re-exports every component in this folder so
 * consumers can `import { X } from '@avenews/design-system/cross-platform'`
 * without knowing the underlying file structure.
 */

export { Badge } from './Badge';
export type { BadgeProps, BadgeVariant } from './Badge';
export { Alert } from './Alert';
export type { AlertButton, AlertButtonRole, AlertCheckbox, AlertInput, AlertProps, AlertRadio } from './Alert';
export { DocumentCategoryCard } from './DocumentCategoryCard';
export type { CategoryStatus, DocRow, DocumentCategoryCardProps } from './DocumentCategoryCard';
export { DocumentRow } from './DocumentRow';
export type { DocumentRowProps, DocumentStatus } from './DocumentRow';
export { Popover } from './Popover';
export type { PopoverContent, PopoverItem, PopoverProps, PopoverSide, PopoverSize } from './Popover';
export { SectionHeader } from './SectionHeader';
export type { SectionHeaderProps, SectionHeaderVariant } from './SectionHeader';
export { StepIndicator } from './StepIndicator';
export type { Step, StepIndicatorProps, StepStatus } from './StepIndicator';
