import React, { useEffect, useRef } from 'react';

export type PopoverContent = 'text' | 'list';
export type PopoverSize    = 'cover' | 'auto';
export type PopoverSide    = 'top' | 'bottom' | 'start' | 'end';

export interface PopoverItem {
  label:     string;
  onClick?:  () => void;
  disabled?: boolean;
}

export interface PopoverProps {
  open?:       boolean;
  content?:    PopoverContent;
  size?:       PopoverSize;
  side?:       PopoverSide;
  text?:       string;
  header?:     string;
  items?:      PopoverItem[];
  onDismiss?:  () => void;
  triggerRef?: React.RefObject<HTMLElement | null>;
  children?:   React.ReactNode;
  className?:  string;
}

const EDGE_GAP = 8;

export const Popover: React.FC<PopoverProps> = ({
  open      = false,
  content   = 'list',
  size      = 'auto',
  side      = 'bottom',
  text,
  header,
  items     = [],
  onDismiss,
  triggerRef,
  children,
  className,
}) => {
  const popoverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onDismiss?.(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open, onDismiss]);

  useEffect(() => {
    if (!open || !triggerRef?.current || !popoverRef.current) return;

    const trigger = triggerRef.current.getBoundingClientRect();
    const pop     = popoverRef.current;
    const gap     = 4;

    if (size === 'cover') pop.style.width = `${trigger.width}px`;

    const popRect = pop.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    let top = 0, left = 0;

    // All values are viewport-relative (position: fixed).
    // getBoundingClientRect() is already viewport-relative — no scrollX/Y needed.
    switch (side) {
      case 'top':
        top  = trigger.top - popRect.height - gap;
        left = trigger.left + (trigger.width - popRect.width) / 2;
        break;
      case 'start':
        top  = trigger.top + (trigger.height - popRect.height) / 2;
        left = trigger.left - popRect.width - gap;
        break;
      case 'end':
        top  = trigger.top + (trigger.height - popRect.height) / 2;
        left = trigger.right + gap;
        break;
      default: // bottom
        top  = trigger.bottom + gap;
        left = trigger.left + (trigger.width - popRect.width) / 2;
    }

    // Clamp to viewport so the popover never overflows any edge.
    left = Math.max(EDGE_GAP, Math.min(left, vw - popRect.width  - EDGE_GAP));
    top  = Math.max(EDGE_GAP, Math.min(top,  vh - popRect.height - EDGE_GAP));

    pop.style.top  = `${top}px`;
    pop.style.left = `${left}px`;
  }, [open, side, size, triggerRef]);

  if (!open) return null;

  const isText = content === 'text';
  const isList = content === 'list';

  const popoverClass = [
    'avenews-popover',
    `avenews-popover--${content}`,
    `avenews-popover--${side}`,
    size === 'cover' ? 'avenews-popover--cover' : '',
    triggerRef ? 'avenews-popover--anchored' : '',
    className,
  ].filter(Boolean).join(' ');

  return (
    <>
      <div className="avenews-popover__backdrop" onClick={onDismiss} aria-hidden="true" />
      <div ref={popoverRef} className={popoverClass} role="dialog" aria-modal="true">
        {children ?? (
          <>
            {isText && text && <p className="avenews-popover__text">{text}</p>}
            {isList && (
              <div className="avenews-popover__list">
                {header && <div className="avenews-popover__list-header">{header}</div>}
                {items.map((item, i) => (
                  <button
                    key={i}
                    type="button"
                    className={['avenews-popover__item', item.disabled ? 'avenews-popover__item--disabled' : ''].filter(Boolean).join(' ')}
                    onClick={item.disabled ? undefined : () => { item.onClick?.(); onDismiss?.(); }}
                    disabled={item.disabled}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
};

export default Popover;
