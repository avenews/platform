import type { Meta, StoryObj } from '@storybook/react';
import { Badge } from './Badge';
import type { BadgeVariant } from './Badge';

// ─── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof Badge> = {
  title: 'Avenews/Cross-Platform/Badge',
  component: Badge,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Compact label chip for counts, statuses, and semantic tags. ' +
          'Supports 14 colour variants, large-number truncation (1k+), a loading skeleton, ' +
          'and an `hideOnEmpty` guard that returns null when count is zero.',
      },
    },
    layout: 'centered',
  },
  argTypes: {
    variant: {
      control: 'select',
      options: [
        'primary', 'secondary', 'tertiary',
        'success', 'warning', 'danger',
        'light', 'medium', 'dark', 'info', 'neutral',
        'success-subtle', 'warning-subtle', 'danger-subtle', 'info-subtle',
      ] satisfies BadgeVariant[],
    },
    count:       { control: 'text' },
    hideOnEmpty: { control: 'boolean' },
    loading:     { control: 'boolean' },
  },
  args: {
    count:       5,
    variant:     'primary',
    hideOnEmpty: true,
    loading:     false,
  },
};

export default meta;
type Story = StoryObj<typeof Badge>;

// ─── Playground ───────────────────────────────────────────────────────────────

export const Default: Story = {
  name: 'Default',
  args: { count: 5, variant: 'primary' },
};

// ─── Number counts ────────────────────────────────────────────────────────────

export const Zero: Story = {
  name: 'Count / Zero (hidden)',
  args: { count: 0, hideOnEmpty: true },
  decorators: [(Story) => (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
      <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 13, color: 'var(--av-color-text-muted)' }}>
        badge renders null →
      </span>
      <Story />
    </div>
  )],
};

export const ZeroVisible: Story = {
  name: 'Count / Zero (visible)',
  args: { count: 0, hideOnEmpty: false },
};

export const SmallCount: Story = { name: 'Count / 1',    args: { count: 1 } };
export const LargeCount: Story = { name: 'Count / 99',   args: { count: 99 } };

export const Thousands: Story = {
  name: 'Count / 1000+ (truncated)',
  args: { count: 1234 },
};

export const StringLabel: Story = {
  name: 'Count / String label',
  args: { count: 'New', variant: 'primary' },
};

// ─── States ───────────────────────────────────────────────────────────────────

export const Loading: Story = {
  name: 'State / Loading skeleton',
  args: { count: 5, loading: true },
};

// ─── All solid variants ───────────────────────────────────────────────────────

const SOLID_VARIANTS: BadgeVariant[] = [
  'primary', 'secondary', 'tertiary',
  'success', 'warning', 'danger',
  'light', 'medium', 'dark', 'info', 'neutral',
];

export const AllSolidVariants: Story = {
  name: 'Variants / All solid',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'center' }}>
      {SOLID_VARIANTS.map((v) => (
        <div key={v} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <Badge count={5} variant={v} />
          <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 11, color: 'var(--av-color-text-muted)' }}>
            {v}
          </span>
        </div>
      ))}
    </div>
  ),
};

const SUBTLE_VARIANTS: BadgeVariant[] = [
  'success-subtle', 'warning-subtle', 'danger-subtle', 'info-subtle',
];

export const AllSubtleVariants: Story = {
  name: 'Variants / Subtle',
  render: () => (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'center' }}>
      {SUBTLE_VARIANTS.map((v) => (
        <div key={v} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <Badge count={5} variant={v} />
          <span style={{ fontFamily: 'var(--av-font-body)', fontSize: 11, color: 'var(--av-color-text-muted)' }}>
            {v}
          </span>
        </div>
      ))}
    </div>
  ),
};

// ─── App use-cases ────────────────────────────────────────────────────────────

export const DocumentsActionRequired: Story = {
  name: 'App / Documents action required',
  args: { count: 3, variant: 'danger' },
};

export const NotificationCount: Story = {
  name: 'App / Notification count',
  args: { count: 12, variant: 'primary' },
};

export const StatusNew: Story = {
  name: 'App / Status "New"',
  args: { count: 'New', variant: 'success-subtle' },
};

export const InReview: Story = {
  name: 'App / Status "In Review"',
  args: { count: 'In Review', variant: 'info-subtle' },
};
