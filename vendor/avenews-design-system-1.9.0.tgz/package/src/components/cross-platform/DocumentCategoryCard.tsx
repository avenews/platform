import React from 'react';
import { statusLabels, StatusKey } from '../../tokens/colours';
import { DocumentRow, DocumentStatus } from './DocumentRow';

export type CategoryStatus = DocumentStatus;

export interface DocRow {
  name:   string;
  status: DocumentStatus;
}

export interface DocumentCategoryCardProps {
  index:      number;
  title:      string;
  status:     CategoryStatus;
  docs:       DocRow[];
  hint?:      string;
  loading?:   boolean;
  error?:     boolean;
  className?: string;
}

function statusClass(s: CategoryStatus): string {
  return {
    action_required: 'status-action-required',
    in_review:       'status-in-review',
    completed:       'status-completed',
    optional:        'status-optional',
  }[s];
}

const CardSkeleton: React.FC = () => (
  <div className="avenews-category-card status-pending">
    <div className="avenews-category-card__header">
      <div style={{ width: '55%', height: '14px', background: 'var(--av-neutral-200)', borderRadius: '4px' }} />
      <div style={{ width: '80px', height: '20px', background: 'var(--av-neutral-200)', borderRadius: 'var(--av-radius-pill)' }} />
    </div>
    <hr className="avenews-category-card__divider" />
    <div className="avenews-category-card__docs">
      {[1,2,3].map((i) => (
        <div key={i} className="avenews-doc-row status-pending" style={{ alignItems: 'center' }}>
          <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'var(--av-neutral-200)', flexShrink: 0 }} />
          <div style={{ flex: 1, height: '12px', background: 'var(--av-neutral-200)', borderRadius: '4px' }} />
          <div style={{ width: '64px', height: '20px', background: 'var(--av-neutral-200)', borderRadius: 'var(--av-radius-pill)' }} />
        </div>
      ))}
    </div>
  </div>
);

export const DocumentCategoryCard: React.FC<DocumentCategoryCardProps> = ({
  index,
  title,
  status,
  docs,
  hint,
  loading  = false,
  error    = false,
  className,
}) => {
  if (loading) return <CardSkeleton />;

  const resolvedStatus: CategoryStatus = error ? 'action_required' : status;
  const pillLabel = error ? 'Error' : statusLabels[resolvedStatus];

  return (
    <div
      className={`avenews-category-card ${statusClass(resolvedStatus)}${className ? ` ${className}` : ''}`}
      role="region"
      aria-label={`${index}. ${title} — ${pillLabel}`}
    >
      <div className="avenews-category-card__header">
        <h3 className="avenews-category-card__title">{index}.&nbsp;{title}</h3>
        <span className="avenews-category-card__pill">{pillLabel}</span>
      </div>
      <hr className="avenews-category-card__divider" />
      <div className="avenews-category-card__docs">
        {docs.map((doc) => (
          <DocumentRow
            key={doc.name}
            name={doc.name}
            status={error ? 'action_required' : doc.status}
          />
        ))}
      </div>
      {hint && <p className="avenews-category-card__hint">{hint}</p>}
    </div>
  );
};

export default DocumentCategoryCard;
