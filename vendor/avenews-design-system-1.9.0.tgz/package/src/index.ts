// ─── Layer 1 + 2: Tokens ──────────────────────────────────────────────────────

export {
  brand,
  aqua,
  darkblue,
  purple,
  tertiary,
  medium,
  statusBase,
  statusScale,
  neutral,
  text,
  surface,
  statusPairs,
  statusLabels,
  colours,
} from './tokens/colours';
export type { StatusKey, StatusPair } from './tokens/colours';

export {
  fontFamily,
  fontWeight,
  fontSize,
  lineHeight,
  letterSpacing,
  typeStyles,
  typography,
} from './tokens/typography';

export { spacing }  from './tokens/spacing';
export type { SpacingKey } from './tokens/spacing';

export { radius } from './tokens/radius';
export type { RadiusKey } from './tokens/radius';

// ─── Ionic components (canonical source: src/components/ionic/) ───────────────

export { Button } from './components/ionic/Button';
export type { ButtonProps, ButtonVariant, ButtonSize, ButtonExpand } from './components/ionic/Button';

export { Badge } from './components/ionic/Badge';
export type { BadgeProps, BadgeVariant } from './components/ionic/Badge';

export { Chip } from './components/ionic/Chip';
export type { ChipProps, ChipColor, ChipFill, ChipVariant } from './components/ionic/Chip';

export { Input } from './components/ionic/Input';
export type { InputProps, InputLabelPlacement, InputType } from './components/ionic/Input';

export { Card } from './components/ionic/Card';
export type { CardProps, CardLayout, CardAction, CardColor } from './components/ionic/Card';

export { Searchbar } from './components/ionic/Searchbar';
export type { SearchbarProps, SearchbarCancelButton, SearchbarClearButton } from './components/ionic/Searchbar';

export { ProgressTracker } from './components/ionic/ProgressTracker';
export type { ProgressTrackerProps, ProgressType, ProgressColor } from './components/ionic/ProgressTracker';

export { InlineBanner } from './components/ionic/InlineBanner';
export type { InlineBannerProps, InlineBannerVariant } from './components/ionic/InlineBanner';

export { Toggle } from './components/ionic/Toggle';
export type { ToggleProps } from './components/ionic/Toggle';

export { EmptyState } from './components/ionic/EmptyState';
export type { EmptyStateProps, EmptyStateVariant, EmptyStateAction } from './components/ionic/EmptyState';

export { Accordion } from './components/ionic/Accordion';
export type { AccordionProps, AccordionItem } from './components/ionic/Accordion';

export { Segment } from './components/ionic/Segment';
export type { SegmentProps, SegmentOption } from './components/ionic/Segment';

export { ActionSheet } from './components/ionic/ActionSheet';
export type { ActionSheetProps, ActionSheetButton } from './components/ionic/ActionSheet';

export { Checkbox } from './components/ionic/Checkbox';
export type { CheckboxProps, CheckboxColor } from './components/ionic/Checkbox';

export { Datetime } from './components/ionic/Datetime';
export type { DatetimeProps, DatetimeColor, DatetimePresentation } from './components/ionic/Datetime';

export { Picker } from './components/ionic/Picker';
export type { PickerProps, PickerColumnDef, PickerOption } from './components/ionic/Picker';

export { Fab } from './components/ionic/Fab';
export type { FabProps, FabColor, FabSize } from './components/ionic/Fab';

export { Textarea } from './components/ionic/Textarea';
export type { TextareaProps, TextareaLabelPlacement } from './components/ionic/Textarea';

export { Item, ItemDivider } from './components/ionic/Item';
export type { ItemProps, ItemDividerProps, ItemColor, ItemLines, ItemVariant } from './components/ionic/Item';

export { Note } from './components/ionic/Note';
export type { NoteProps, NoteColor, NoteAlign } from './components/ionic/Note';

export { List, ListHeader } from './components/ionic/List';
export type { ListProps, ListHeaderProps, ListColor, ListLines, ListHeaderSize } from './components/ionic/List';

export { Avatar, Thumbnail, MediaIcon } from './components/ionic/Media';
export type { AvatarProps, ThumbnailProps, MediaIconProps, MediaIconColor, MediaIconSize, AvatarSize, ThumbnailSize } from './components/ionic/Media';

export { Menu } from './components/ionic/Menu';
export type { MenuProps, MenuSide, MenuType } from './components/ionic/Menu';

export { Modal } from './components/ionic/Modal';
export type { ModalProps, ModalVariant, ModalSize, ModalButton } from './components/ionic/Modal';

// ─── Web-canonical components (source: src/components/web/) ──────────────────
// No Ionic equivalent — these are the only implementation.

export { Alert } from './components/cross-platform/Alert';
export type { AlertProps, AlertButton, AlertInput, AlertCheckbox, AlertRadio, AlertButtonRole } from './components/cross-platform/Alert';

export { Popover } from './components/cross-platform/Popover';
export type { PopoverProps, PopoverContent, PopoverSize, PopoverSide, PopoverItem } from './components/cross-platform/Popover';

export { StepIndicator } from './components/cross-platform/StepIndicator';
export type { StepIndicatorProps, Step, StepStatus } from './components/cross-platform/StepIndicator';

export { DocumentRow } from './components/cross-platform/DocumentRow';
export type { DocumentRowProps, DocumentStatus } from './components/cross-platform/DocumentRow';

export { DocumentCategoryCard } from './components/cross-platform/DocumentCategoryCard';
export type { DocumentCategoryCardProps, CategoryStatus, DocRow } from './components/cross-platform/DocumentCategoryCard';

// ─── Shared ───────────────────────────────────────────────────────────────────
export type { UploadCardProps, UploadStatus } from './components/shared/types';
export { cn, formatFileSize, clamp } from './components/shared/utils';

// ─── Ionic versions ───────────────────────────────────────────────────────────
export { UploadCard as IonicUploadCard } from './components/ionic/UploadCard';

// ─── Web versions (no Ionic dependency) ──────────────────────────────────────
export { Button as WebButton } from './components/web/Button';
export type { ButtonProps as WebButtonProps } from './components/web/Button';

export { Input as WebInput } from './components/web/Input';
export type { InputProps as WebInputProps } from './components/web/Input';

export { UploadCard as WebUploadCard } from './components/web/UploadCard';

export { Badge as WebBadge } from './components/cross-platform/Badge';
export type { BadgeProps as WebBadgeProps, BadgeVariant as WebBadgeVariant } from './components/cross-platform/Badge';

export { Chip as WebChip } from './components/web/Chip';
export type { ChipProps as WebChipProps, ChipColor as WebChipColor, ChipFill as WebChipFill } from './components/web/Chip';

export { Card as WebCard } from './components/web/Card';
export type { CardProps as WebCardProps, CardLayout as WebCardLayout, CardAction as WebCardAction, CardColor as WebCardColor } from './components/web/Card';

export { Toggle as WebToggle } from './components/web/Toggle';
export type { ToggleProps as WebToggleProps } from './components/web/Toggle';

export { Checkbox as WebCheckbox } from './components/web/Checkbox';
export type { CheckboxProps as WebCheckboxProps, CheckboxColor as WebCheckboxColor } from './components/web/Checkbox';

export { Searchbar as WebSearchbar } from './components/web/Searchbar';
export type { SearchbarProps as WebSearchbarProps } from './components/web/Searchbar';

export { Segment as WebSegment } from './components/web/Segment';
export type { SegmentProps as WebSegmentProps, SegmentOption as WebSegmentOption } from './components/web/Segment';

export { InlineBanner as WebInlineBanner } from './components/web/InlineBanner';
export type { InlineBannerProps as WebInlineBannerProps, InlineBannerVariant as WebInlineBannerVariant } from './components/web/InlineBanner';

export { EmptyState as WebEmptyState } from './components/web/EmptyState';
export type { EmptyStateProps as WebEmptyStateProps, EmptyStateVariant as WebEmptyStateVariant, EmptyStateAction as WebEmptyStateAction } from './components/web/EmptyState';

export { Modal as WebModal } from './components/web/Modal';
export type { ModalProps as WebModalProps, ModalVariant as WebModalVariant, ModalSize as WebModalSize, ModalButton as WebModalButton } from './components/web/Modal';

export { ActionSheet as WebActionSheet } from './components/web/ActionSheet';
export type { ActionSheetProps as WebActionSheetProps, ActionSheetButton as WebActionSheetButton } from './components/web/ActionSheet';

export { Item as WebItem, ItemDivider as WebItemDivider } from './components/web/Item';
export type { ItemProps as WebItemProps, ItemDividerProps as WebItemDividerProps, ItemColor as WebItemColor, ItemLines as WebItemLines, ItemVariant as WebItemVariant } from './components/web/Item';

export { List as WebList, ListHeader as WebListHeader } from './components/web/List';
export type { ListProps as WebListProps, ListHeaderProps as WebListHeaderProps, ListColor as WebListColor, ListLines as WebListLines, ListHeaderSize as WebListHeaderSize } from './components/web/List';

export { Avatar as WebAvatar, Thumbnail as WebThumbnail, MediaIcon as WebMediaIcon } from './components/web/Media';
export type { AvatarProps as WebAvatarProps, ThumbnailProps as WebThumbnailProps, MediaIconProps as WebMediaIconProps, MediaIconColor as WebMediaIconColor, MediaIconSize as WebMediaIconSize } from './components/web/Media';

export { Accordion as WebAccordion } from './components/web/Accordion';
export type { AccordionProps as WebAccordionProps, AccordionItem as WebAccordionItem } from './components/web/Accordion';

export { StepIndicator as WebStepIndicator } from './components/cross-platform/StepIndicator';
export type { StepIndicatorProps as WebStepIndicatorProps, Step as WebStep, StepStatus as WebStepStatus } from './components/cross-platform/StepIndicator';

export { Alert as WebAlert } from './components/cross-platform/Alert';
export type { AlertProps as WebAlertProps, AlertButton as WebAlertButton, AlertInput as WebAlertInput, AlertCheckbox as WebAlertCheckbox, AlertRadio as WebAlertRadio, AlertButtonRole as WebAlertButtonRole } from './components/cross-platform/Alert';

export { Popover as WebPopover } from './components/cross-platform/Popover';
export type { PopoverProps as WebPopoverProps, PopoverContent as WebPopoverContent, PopoverSize as WebPopoverSize, PopoverSide as WebPopoverSide, PopoverItem as WebPopoverItem } from './components/cross-platform/Popover';

export { DocumentRow as WebDocumentRow } from './components/cross-platform/DocumentRow';
export type { DocumentRowProps as WebDocumentRowProps, DocumentStatus as WebDocumentStatus } from './components/cross-platform/DocumentRow';

export { DocumentCategoryCard as WebDocumentCategoryCard } from './components/cross-platform/DocumentCategoryCard';
export type { DocumentCategoryCardProps as WebDocumentCategoryCardProps, CategoryStatus as WebCategoryStatus, DocRow as WebDocRow } from './components/cross-platform/DocumentCategoryCard';

export { Note as WebNote } from './components/web/Note';
export type { NoteProps as WebNoteProps, NoteColor as WebNoteColor, NoteAlign as WebNoteAlign } from './components/web/Note';

export { ProgressTracker as WebProgressTracker } from './components/web/ProgressTracker';
export type { ProgressTrackerProps as WebProgressTrackerProps, ProgressType as WebProgressType, ProgressColor as WebProgressColor } from './components/web/ProgressTracker';

// ─── Radio ────────────────────────────────────────────────────────────────────

export { RadioGroup } from './components/ionic/Radio';
export type { RadioGroupProps, RadioColor, RadioLayout, RadioOption } from './components/ionic/Radio';

export { Radio as WebRadio, RadioGroup as WebRadioGroup } from './components/web/Radio';
export type { RadioProps as WebRadioProps, RadioGroupProps as WebRadioGroupProps, RadioColor as WebRadioColor, RadioLayout as WebRadioLayout, RadioOption as WebRadioOption } from './components/web/Radio';

// ─── ProgressBar ─────────────────────────────────────────────────────────────

export { ProgressBar } from './components/ionic/ProgressBar';
export type { ProgressBarProps, ProgressBarColor, ProgressBarSize, ProgressBarSegment } from './components/ionic/ProgressBar';

export { ProgressBar as WebProgressBar } from './components/web/ProgressBar';
export type { ProgressBarProps as WebProgressBarProps, ProgressBarColor as WebProgressBarColor, ProgressBarSize as WebProgressBarSize, ProgressBarStyle as WebProgressBarStyle, ProgressBarSegment as WebProgressBarSegment } from './components/web/ProgressBar';

// ─── Loader ───────────────────────────────────────────────────────────────────

export { Loader } from './components/ionic/Loader';
export type { LoaderProps, LoaderVariant, LoaderSize, LoaderColor, SpinnerType } from './components/ionic/Loader';

export { Loader as WebLoader } from './components/web/Loader';
export type { LoaderProps as WebLoaderProps, LoaderVariant as WebLoaderVariant, LoaderSize as WebLoaderSize, LoaderColor as WebLoaderColor } from './components/web/Loader';

// ─── Select ───────────────────────────────────────────────────────────────────

export { Select } from './components/ionic/Select';
export type { SelectProps, SelectOption } from './components/ionic/Select';

export { Select as WebSelect } from './components/web/Select';
export type { SelectProps as WebSelectProps, SelectOption as WebSelectOption } from './components/web/Select';

// ─── Tabs ─────────────────────────────────────────────────────────────────────

export { Tabs } from './components/ionic/Tabs';
export type { TabsProps, TabItem, TabsSlot } from './components/ionic/Tabs';

export { Tabs as WebTabs } from './components/web/Tabs';
export type { TabsProps as WebTabsProps, TabItem as WebTabItem, TabsVariant } from './components/web/Tabs';

// ─── Toast ────────────────────────────────────────────────────────────────────

export { Toast } from './components/ionic/Toast';
export type { ToastProps, ToastColor, ToastPosition as IonicToastPosition, ToastButton } from './components/ionic/Toast';

export { Toast as WebToast } from './components/web/Toast';
export type { ToastProps as WebToastProps, ToastVariant, ToastPosition, ToastAction } from './components/web/Toast';

// ─── Toolbar ─────────────────────────────────────────────────────────────────

export { Toolbar } from './components/ionic/Toolbar';
export type { ToolbarProps as IonicToolbarProps, ToolbarColor, ToolbarAction as IonicToolbarAction } from './components/ionic/Toolbar';

export { Toolbar as WebToolbar } from './components/web/Toolbar';
export type { ToolbarProps as WebToolbarProps, ToolbarVariant, ToolbarAction } from './components/web/Toolbar';

// ─── Header ──────────────────────────────────────────────────────────────────

export { Header } from './components/ionic/Header';
export type { HeaderProps as IonicHeaderProps, HeaderVariant as IonicHeaderVariant, HeaderSize as IonicHeaderSize } from './components/ionic/Header';

export { Header as WebHeader } from './components/web/Header';
export type { HeaderProps as WebHeaderProps, HeaderVariant, HeaderSize } from './components/web/Header';

// ─── Icon ─────────────────────────────────────────────────────────────────────

export { Icon } from './components/ionic/Icon';
export type { IconProps as IonicIconProps, IconSize as IonicIconSize } from './components/ionic/Icon';

export { Icon as WebIcon } from './components/web/Icon';
export type { IconProps as WebIconProps, IconName, IconSize } from './components/web/Icon';

// ─── InfoRow ─────────────────────────────────────────────────────────────

export { InfoRow } from './components/ionic/InfoRow';
export type { InfoRowProps, InfoRowVariant, InfoRowLines } from './components/ionic/InfoRow';

export { InfoRow as WebInfoRow } from './components/web/InfoRow';
export type { InfoRowProps as WebInfoRowProps, InfoRowVariant as WebInfoRowVariant } from './components/web/InfoRow';

// ─── SectionHeader ───────────────────────────────────────────────────────

export { SectionHeader } from './components/cross-platform/SectionHeader';
export type { SectionHeaderProps, SectionHeaderVariant } from './components/cross-platform/SectionHeader';

// ─── DataList ────────────────────────────────────────────────────────────

export { DataList } from './components/ionic/DataList';
export type { DataListProps, DataListVariant, DataField } from './components/ionic/DataList';

export { DataList as WebDataList } from './components/web/DataList';
export type { DataListProps as WebDataListProps, DataListVariant as WebDataListVariant, DataField as WebDataField } from './components/web/DataList';

// ─── Footer ──────────────────────────────────────────────────────────────────

export { Footer } from './components/ionic/Footer';
export type { FooterProps as IonicFooterProps, FooterAction as IonicFooterAction, FooterColor, FooterFill } from './components/ionic/Footer';

export { Footer as WebFooter } from './components/web/Footer';
export type { FooterProps as WebFooterProps, FooterAction as WebFooterAction, FooterVariant, FooterLayout, FooterPosition } from './components/web/Footer';
