import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta = {
  title: 'Foundations/Typography',
};

export default meta;

type Story = StoryObj;

const Row = ({
  label,
  meta: metaText,
  style,
}: {
  label: string;
  meta?: string;
  style: React.CSSProperties;
}) => (
  <div style={{ display: 'flex', alignItems: 'baseline', gap: 24, marginBottom: 20, borderBottom: '1px solid #e6eaee', paddingBottom: 16 }}>
    <div style={{ ...style, minWidth: 0, flex: 1 }}>{label}</div>
    {metaText && (
      <div style={{ fontSize: 11, color: '#93a1b0', flexShrink: 0, fontFamily: 'Poppins, sans-serif', whiteSpace: 'nowrap' }}>{metaText}</div>
    )}
  </div>
);

export const Overview: Story = {
  render: () => (
    <div style={{ fontFamily: 'Poppins, sans-serif', padding: 16, color: '#232830', maxWidth: 800 }}>

      <h2 style={{ fontFamily: '"Plus Jakarta Sans", sans-serif', fontSize: 20, fontWeight: 700, marginTop: 0, marginBottom: 24 }}>
        Typography Scale
      </h2>

      <p style={{ fontSize: 12, color: '#6c7a8b', marginBottom: 24 }}>
        H1–H3 use <strong>Plus Jakarta Sans Bold</strong>. All other type uses <strong>Poppins</strong>.
      </p>

      <Row
        label="H1 — Screen Heading"
        meta="Plus Jakarta Sans · Bold · 26px · lh 1.2"
        style={{ fontFamily: '"Plus Jakarta Sans", sans-serif', fontSize: 26, fontWeight: 700, lineHeight: 1.2 }}
      />
      <Row
        label="H2 — Section Heading"
        meta="Plus Jakarta Sans · Bold · 24px · lh 1.2"
        style={{ fontFamily: '"Plus Jakarta Sans", sans-serif', fontSize: 24, fontWeight: 700, lineHeight: 1.2 }}
      />
      <Row
        label="H3 — Sub-section Heading"
        meta="Plus Jakarta Sans · Bold · 22px · lh 1.2"
        style={{ fontFamily: '"Plus Jakarta Sans", sans-serif', fontSize: 22, fontWeight: 700, lineHeight: 1.2 }}
      />
      <Row
        label="H4 — Card Title / Dialog Header"
        meta="Poppins · SemiBold · 20px · lh 1.2"
        style={{ fontSize: 20, fontWeight: 600, lineHeight: 1.2 }}
      />
      <Row
        label="H5 — Section Label"
        meta="Poppins · SemiBold · 18px · lh 1.2"
        style={{ fontSize: 18, fontWeight: 600, lineHeight: 1.2 }}
      />
      <Row
        label="H6 — Sub-label"
        meta="Poppins · SemiBold · 16px · lh 1.2"
        style={{ fontSize: 16, fontWeight: 600, lineHeight: 1.2 }}
      />
      <Row
        label="Paragraph — Body text, input values"
        meta="Poppins · Regular · 16px · lh 1.4"
        style={{ fontSize: 16, fontWeight: 400, lineHeight: 1.4 }}
      />
      <Row
        label="Card Subtitle / Small body"
        meta="Poppins · Medium · 14px · lh 1.4"
        style={{ fontSize: 14, fontWeight: 500, color: '#6c7a8b', lineHeight: 1.4 }}
      />
      <Row
        label="BUTTON DEFAULT"
        meta="Poppins · SemiBold · 14px · ls 0.02em"
        style={{ fontSize: 14, fontWeight: 600, letterSpacing: '0.02em', textTransform: 'uppercase', color: 'var(--av-color-action)' }}
      />
      <Row
        label="Input stacked label"
        meta="Poppins · Regular · 13px · ls -0.025em"
        style={{ fontSize: 13, fontWeight: 400, letterSpacing: '-0.025em', color: '#6c7a8b' }}
      />
      <Row
        label="Badge Label"
        meta="Poppins · SemiBold · 13px · ls -0.01em"
        style={{ fontSize: 13, fontWeight: 600, letterSpacing: '-0.01em', color: 'var(--av-color-action)' }}
      />
      <Row
        label="Input helper / error text"
        meta="Poppins · Regular · 12px · ls -0.025em"
        style={{ fontSize: 12, fontWeight: 400, letterSpacing: '-0.025em', color: '#6c7a8b' }}
      />
      <Row
        label="Note label"
        meta="Poppins · Regular · 11px · ls -0.025em"
        style={{ fontSize: 11, fontWeight: 400, letterSpacing: '-0.025em', color: '#93a1b0' }}
      />
      <Row
        label="TAB LABEL"
        meta="Poppins · SemiBold · 10px · ls -0.025em"
        style={{ fontSize: 10, fontWeight: 600, letterSpacing: '-0.025em', color: '#6c7a8b' }}
      />

    </div>
  ),
};
