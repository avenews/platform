/**
 * Icon catalogue — visual reference of every icon in the curated web set.
 *
 * This page renders all 47 web Icon names in a labelled grid so designers and
 * engineers can browse the catalogue without reading source. Search-friendly:
 * each tile shows its `name` value in monospace text below the glyph.
 *
 * Add a new icon: append the catalogue entry in `src/components/web/Icon.tsx`
 * (both the IconName union and the ICONS map). It will appear here automatically
 * because this story imports the IconName type and iterates over a constant
 * derived from the same source.
 */
import type { Meta, StoryObj } from '@storybook/react';
import { Icon, type IconName, type IconSize } from '../components/web/Icon';

const meta: Meta = {
  title: 'Foundations/Icons',
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Curated 47-icon SVG set used by the web component library. Each icon ' +
          'is a 24×24 outline-stroke glyph that inherits `currentColor`. The ' +
          'Avenews/Web/Icon stories cover prop usage, sizes, and per-icon overrides.',
      },
    },
  },
};
export default meta;
type Story = StoryObj;

// ─── Catalogue (kept in sync with src/components/web/Icon.tsx IconName union) ──
const CATALOGUE: IconName[] = [
  'add',
  'arrow-back',
  'arrow-forward',
  'attach',
  'bar-chart',
  'calendar',
  'call',
  'cash',
  'checkmark',
  'checkmark-circle',
  'chevron-back',
  'chevron-down',
  'chevron-forward',
  'chevron-up',
  'close',
  'close-circle',
  'create',
  'document',
  'document-text',
  'download',
  'ellipsis-horizontal',
  'ellipsis-vertical',
  'eye',
  'eye-off',
  'heart',
  'help-circle',
  'home',
  'information-circle',
  'list',
  'mail',
  'menu',
  'notifications',
  'person',
  'receipt',
  'refresh',
  'remove',
  'search',
  'settings',
  'share',
  'shield-checkmark',
  'star',
  'time',
  'trash',
  'upload',
  'wallet',
  'warning',
];

// ─── Catalogue grid (default size = md / 20px) ────────────────────────────────

export const Catalogue: Story = {
  render: () => (
    <div style={{ padding: 'var(--av-space-6)', background: 'var(--av-color-surface-subtle)' }}>
      <header style={{ marginBottom: 'var(--av-space-6)' }}>
        <h1 style={{
          font: '700 26px/1.2 "Plus Jakarta Sans", sans-serif',
          color: 'var(--av-color-text-heading)',
          margin: 0,
        }}>
          Icon catalogue
        </h1>
        <p style={{
          margin: '8px 0 0',
          color: 'var(--av-color-text-muted)',
          font: '400 14px/1.4 "Poppins", sans-serif',
        }}>
          {CATALOGUE.length} icons. Use <code>{'<Icon name="icon-name" />'}</code> in web components.
        </p>
      </header>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
          gap: 'var(--av-space-3)',
        }}
      >
        {CATALOGUE.map((name) => (
          <div
            key={name}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 'var(--av-space-2)',
              padding: 'var(--av-space-4) var(--av-space-3)',
              background: 'var(--av-color-surface)',
              border: '1px solid var(--av-color-surface-border)',
              borderRadius: 'var(--av-radius-md)',
              transition: 'border-color 0.15s, box-shadow 0.15s',
            }}
          >
            <Icon name={name} size="lg" color="var(--av-color-text)" />
            <code
              style={{
                font: '400 11px/1.2 ui-monospace, SFMono-Regular, monospace',
                color: 'var(--av-color-text-muted)',
                userSelect: 'all',
                textAlign: 'center',
                wordBreak: 'break-all',
              }}
            >
              {name}
            </code>
          </div>
        ))}
      </div>
    </div>
  ),
};

// ─── Sizes ────────────────────────────────────────────────────────────────────

const SIZES: { size: IconSize; px: number; usedFor: string }[] = [
  { size: 'xs', px: 14, usedFor: 'inline annotation, badge dot' },
  { size: 'sm', px: 16, usedFor: 'form field affixes, helper text' },
  { size: 'md', px: 20, usedFor: 'default — inline with body text' },
  { size: 'lg', px: 24, usedFor: 'item rows, list affordances' },
  { size: 'xl', px: 32, usedFor: 'empty states, document categories' },
];

export const Sizes: Story = {
  render: () => (
    <div style={{ padding: 'var(--av-space-6)' }}>
      <h2 style={{
        font: '700 22px/1.2 "Plus Jakarta Sans", sans-serif',
        color: 'var(--av-color-text-heading)',
        margin: '0 0 var(--av-space-4) 0',
      }}>
        Sizes
      </h2>
      <table style={{
        width: '100%',
        maxWidth: '720px',
        borderCollapse: 'collapse',
        font: '400 14px/1.4 "Poppins", sans-serif',
      }}>
        <thead>
          <tr style={{ borderBottom: '1px solid var(--av-color-surface-border)' }}>
            <th style={{ textAlign: 'left', padding: 'var(--av-space-2)', width: '80px' }}>Size</th>
            <th style={{ textAlign: 'left', padding: 'var(--av-space-2)', width: '80px' }}>Pixels</th>
            <th style={{ textAlign: 'left', padding: 'var(--av-space-2)', width: '60px' }}>Glyph</th>
            <th style={{ textAlign: 'left', padding: 'var(--av-space-2)' }}>Used for</th>
          </tr>
        </thead>
        <tbody>
          {SIZES.map(({ size, px, usedFor }) => (
            <tr key={size} style={{ borderBottom: '1px solid var(--av-color-surface-border)' }}>
              <td style={{ padding: 'var(--av-space-2)' }}>
                <code style={{ font: '400 13px/1 ui-monospace, monospace' }}>{size}</code>
              </td>
              <td style={{ padding: 'var(--av-space-2)', color: 'var(--av-color-text-muted)' }}>{px}px</td>
              <td style={{ padding: 'var(--av-space-2)' }}>
                <Icon name="checkmark-circle" size={size} color="var(--ion-color-primary)" />
              </td>
              <td style={{ padding: 'var(--av-space-2)', color: 'var(--av-color-text-muted)' }}>{usedFor}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  ),
};

// ─── Semantic colour samples ──────────────────────────────────────────────────

export const SemanticColours: Story = {
  render: () => {
    const samples: { name: IconName; color: string; label: string }[] = [
      { name: 'checkmark-circle',  color: 'var(--ion-color-success)', label: 'success' },
      { name: 'warning',           color: 'var(--ion-color-warning)', label: 'warning' },
      { name: 'close-circle',      color: 'var(--ion-color-danger)',  label: 'danger' },
      { name: 'information-circle',color: 'var(--ion-color-secondary)',label: 'info' },
      { name: 'help-circle',       color: 'var(--av-color-text-muted)',label: 'muted' },
    ];
    return (
      <div style={{ padding: 'var(--av-space-6)', display: 'flex', gap: 'var(--av-space-4)', flexWrap: 'wrap' }}>
        {samples.map(({ name, color, label }) => (
          <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
            <Icon name={name} size="xl" color={color} />
            <code style={{ font: '400 11px/1 ui-monospace, monospace', color: 'var(--av-color-text-muted)' }}>{label}</code>
          </div>
        ))}
      </div>
    );
  },
};
