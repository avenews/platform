import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta = {
  title: 'Foundations/Colour',
};

export default meta;

type Story = StoryObj;

const Swatch = ({
  name,
  value,
  textColor = '#fff',
}: {
  name: string;
  value: string;
  textColor?: string;
}) => (
  <div
    style={{
      background: value,
      color: textColor,
      borderRadius: 8,
      padding: '12px 14px',
      minHeight: 80,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      border: textColor !== '#fff' ? '1px solid #d0d7df' : 'none',
      fontSize: 13,
      fontFamily: 'Poppins, sans-serif',
    }}
  >
    <strong style={{ fontSize: 12 }}>{name}</strong>
    <span style={{ opacity: 0.85 }}>{value}</span>
  </div>
);

const Grid = ({ children }: { children: React.ReactNode }) => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12, marginBottom: 32 }}>
    {children}
  </div>
);

export const Overview: Story = {
  render: () => (
    <div style={{ fontFamily: 'Poppins, sans-serif', padding: 16, maxWidth: 900 }}>

      <h2 style={{ fontSize: 20, fontFamily: '"Plus Jakarta Sans", sans-serif', marginBottom: 12, marginTop: 0 }}>Brand — Aqua</h2>
      <Grid>
        <Swatch name="Aqua/300" value="#73e6ed" textColor="#0d343f" />
        <Swatch name="Aqua/500 — Primary" value="#16b3c4" />
        <Swatch name="Aqua/600 — Hover" value="#1691a4" />
        <Swatch name="Aqua/700 — Active" value="#187486" />
      </Grid>

      <h2 style={{ fontSize: 20, fontFamily: '"Plus Jakarta Sans", sans-serif', marginBottom: 12 }}>Secondary — Darkblue</h2>
      <Grid>
        <Swatch name="Darkblue/300" value="#81d4f8" textColor="#0d343f" />
        <Swatch name="Darkblue/500" value="#16a7e1" />
        <Swatch name="Darkblue/700" value="#096a9b" />
      </Grid>

      <h2 style={{ fontSize: 20, fontFamily: '"Plus Jakarta Sans", sans-serif', marginBottom: 12 }}>Tertiary & Medium</h2>
      <Grid>
        <Swatch name="Tertiary/Base" value="#0f4b6b" />
        <Swatch name="Tertiary/Shade" value="#092a3e" />
        <Swatch name="Tertiary/Tint" value="#096a9b" />
        <Swatch name="Medium/Base" value="#1d5e6d" />
        <Swatch name="Dark BG (Aqua950)" value="#0d343f" />
      </Grid>

      <h2 style={{ fontSize: 20, fontFamily: '"Plus Jakarta Sans", sans-serif', marginBottom: 12 }}>Status</h2>
      <Grid>
        <Swatch name="Success/300" value="#92e3b4" textColor="#217445" />
        <Swatch name="Success/500" value="#39c173" />
        <Swatch name="Success/700" value="#217445" />
        <Swatch name="Warning/300" value="#f4c350" textColor="#9a4d0e" />
        <Swatch name="Warning/500" value="#df9013" />
        <Swatch name="Warning/700" value="#9a4d0e" />
        <Swatch name="Danger/300" value="#f9a8a8" textColor="#b42121" />
        <Swatch name="Danger/500" value="#ea4c4c" />
        <Swatch name="Danger/700" value="#b42121" />
      </Grid>

      <h2 style={{ fontSize: 20, fontFamily: '"Plus Jakarta Sans", sans-serif', marginBottom: 12 }}>Neutral (Text steps)</h2>
      <Grid>
        <Swatch name="50" value="#f3f5f7" textColor="#232830" />
        <Swatch name="100" value="#e6eaee" textColor="#232830" />
        <Swatch name="200" value="#d0d7df" textColor="#232830" />
        <Swatch name="300" value="#b7c1cc" textColor="#232830" />
        <Swatch name="400" value="#93a1b0" textColor="#fff" />
        <Swatch name="500" value="#6c7a8b" />
        <Swatch name="600" value="#5b6776" />
        <Swatch name="700" value="#4a5360" />
        <Swatch name="800" value="#373e49" />
        <Swatch name="900" value="#232830" />
        <Swatch name="950" value="#15191f" />
      </Grid>

      <h2 style={{ fontSize: 20, fontFamily: '"Plus Jakarta Sans", sans-serif', marginBottom: 12 }}>Document Status Pairs</h2>
      <Grid>
        <div style={{ borderRadius: 8, overflow: 'hidden', border: '1px solid #df9013' }}>
          <div style={{ background: '#fef3e2', padding: '10px 14px', fontSize: 13, fontWeight: 600, color: '#9a4d0e' }}>Action Required</div>
          <div style={{ padding: '6px 14px 10px', fontSize: 11, color: '#9a4d0e', fontFamily: 'Poppins' }}>#fef3e2 / #9a4d0e</div>
        </div>
        <div style={{ borderRadius: 8, overflow: 'hidden', border: '1px solid #16a7e1' }}>
          <div style={{ background: '#e3f4fd', padding: '10px 14px', fontSize: 13, fontWeight: 600, color: '#096a9b' }}>In Review</div>
          <div style={{ padding: '6px 14px 10px', fontSize: 11, color: '#096a9b', fontFamily: 'Poppins' }}>#e3f4fd / #096a9b</div>
        </div>
        <div style={{ borderRadius: 8, overflow: 'hidden', border: '1px solid #39c173' }}>
          <div style={{ background: '#e8f8ef', padding: '10px 14px', fontSize: 13, fontWeight: 600, color: '#217445' }}>Completed</div>
          <div style={{ padding: '6px 14px 10px', fontSize: 11, color: '#217445', fontFamily: 'Poppins' }}>#e8f8ef / #217445</div>
        </div>
        <div style={{ borderRadius: 8, overflow: 'hidden', border: '1px solid #d0d7df' }}>
          <div style={{ background: '#f3f5f7', padding: '10px 14px', fontSize: 13, fontWeight: 600, color: '#6c7a8b' }}>Pending</div>
          <div style={{ padding: '6px 14px 10px', fontSize: 11, color: '#6c7a8b', fontFamily: 'Poppins' }}>#f3f5f7 / #6c7a8b</div>
        </div>
        <div style={{ borderRadius: 8, overflow: 'hidden', border: '1px solid var(--av-color-action)' }}>
          <div style={{ background: '#e3f8fa', padding: '10px 14px', fontSize: 13, fontWeight: 600, color: 'var(--av-color-action)' }}>In Progress</div>
          <div style={{ padding: '6px 14px 10px', fontSize: 11, color: 'var(--av-color-action)', fontFamily: 'Poppins' }}>#e3f8fa / #16b3c4</div>
        </div>
      </Grid>

    </div>
  ),
};
